﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient.View.Common
{
   
    public partial class frmPopUp : DemoClient.Controllers.BasePopupForm
    {
        string _Sql = string.Empty;
        string _SqlText = string.Empty;
        public DataRow dRow { get; set; }

        public frmPopUp(String _sql, String _searchText)
        {
            InitializeComponent();
            _Sql = _sql;
            _txtSearch.Text = _searchText;
            setSQL(_sql);
        }

        void setSQL(String _sql)
        {              
            _SqlText = "";
            if (_sql == "MDLMST")
            {
                _SqlText += "SELECT * FROM MDLMST";
                _SqlText += " WHERE mdl_cd like '%" + _txtSearch.Text + "%'";
                _SqlText += "    OR mdl_nm like '%" + _txtSearch.Text + "%'";
            }
            else if (_sql == "MOLMST")
            {
                _SqlText += "SELECT * FROM MOLMST";
                _SqlText += " WHERE mol_cd like '%" + _txtSearch.Text + "%'";
                _SqlText += "    OR mol_no like '%" + _txtSearch.Text + "%'";
                _SqlText += "    OR mol_nm like '%" + _txtSearch.Text + "%'";
            }
            else if (_sql == "PRCMST")
            {
                _SqlText += "SELECT * FROM PRCMST";
                _SqlText += " WHERE proc_cd like '%" + _txtSearch.Text + "%'";
                _SqlText += "    OR proc_nm like '%" + _txtSearch.Text + "%'";
                _SqlText += "    AND USE_YN = 'Y'";
            }
        }

        private void frmPopUp_Load(object sender, EventArgs e)
        {
            DataTable _dt01 = base.GetDataTable(_SqlText);
            gPopup.DataSource = _dt01;
        }

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            try
            {

                DataRow _row = gridView1.GetFocusedDataRow();
                dRow = _row;
                // OK 반환
                this.DialogResult = System.Windows.Forms.DialogResult.OK;

                this.Close();
            }
			catch (Exception err)
			{

                MessageBox.Show(err.Message);
			}
        }

        private void _btnSearch_Click(object sender, EventArgs e)
        {
            setSQL(_Sql);
            DataTable _dt01 = base.GetDataTable(_SqlText);
            gPopup.DataSource = _dt01;

        }


        private void _btnSearchAll_Click(object sender, EventArgs e)
        {
            _txtSearch.Text = "";
            setSQL(_Sql);
            DataTable _dt01 = base.GetDataTable(_SqlText);
            gPopup.DataSource = _dt01;
        }
    }
}
