﻿namespace DemoClient._Test
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.VAN_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.VAN_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFF_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFF_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USER_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRADEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSREQENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSREQNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSRESENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSRESNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISOILONLY = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CREDITENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CREDITNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.METHODENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.METHODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CANCELDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.REQUESTDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DUEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.APPRNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISSUEDBYENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISSUEDBYNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUYINGENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUYINGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CARDNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.APPRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HALBU = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SERVICECHARGE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TAXAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CARDFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.INAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STATUS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DEVICENO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFFNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUSINESSNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFFNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EXECYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USERMEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFF_BIGO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.textBox1 = new BANANA.Windows.Controls.TextBox();
			this.groupBox1 = new BANANA.Windows.Controls.GroupBox();
			this.comboBox1 = new BANANA.Windows.Controls.ComboBox();
			this.textBox2 = new BANANA.Windows.Controls.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this._cmbSUCCESSRESENUM = new BANANA.Windows.Controls.ComboBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this._cmbVAN_CD = new BANANA.Windows.Controls.ComboBox();
			this._txtUSER_ID = new BANANA.Windows.Controls.TextBox();
			this._cmbCREDITENUM = new BANANA.Windows.Controls.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this._cmbISSUEDBYENUM = new BANANA.Windows.Controls.ComboBox();
			this._cmbSUCCESSREQENUM = new BANANA.Windows.Controls.ComboBox();
			this._cmbBUYINGENUM = new BANANA.Windows.Controls.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpTRADEDATE1 = new BANANA.Windows.Controls.DateTimePicker();
			this.label12 = new System.Windows.Forms.Label();
			this._dtpTRADEDATE2 = new BANANA.Windows.Controls.DateTimePicker();
			this._txtAFF_NM = new BANANA.Windows.Controls.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this._txtAPPRNO = new BANANA.Windows.Controls.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
			this._txtAPPRAMT1 = new BANANA.Windows.Controls.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this._txtAPPRAMT2 = new BANANA.Windows.Controls.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this._txtUSERMEMO = new BANANA.Windows.Controls.TextBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this._txtSum06 = new BANANA.Windows.Controls.TextBox();
			this._txtSum05 = new BANANA.Windows.Controls.TextBox();
			this.label16 = new BANANA.Windows.Controls.Label();
			this._txtSum04 = new BANANA.Windows.Controls.TextBox();
			this._txtSum03 = new BANANA.Windows.Controls.TextBox();
			this.label15 = new BANANA.Windows.Controls.Label();
			this._txtSum02 = new BANANA.Windows.Controls.TextBox();
			this._txtSum01 = new BANANA.Windows.Controls.TextBox();
			this.label14 = new BANANA.Windows.Controls.Label();
			this.button1 = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel3.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// maskedTextBox1
			// 
			this.maskedTextBox1.Location = new System.Drawing.Point(14, 109);
			this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.maskedTextBox1.Mask = "000000-0000000";
			this.maskedTextBox1.Name = "maskedTextBox1";
			this.maskedTextBox1.Size = new System.Drawing.Size(116, 21);
			this.maskedTextBox1.TabIndex = 0;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Controls.Add(this.gridView1, 0, 0);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(33, 212);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 2;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(234, 92);
			this.tableLayoutPanel1.TabIndex = 1;
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX,
            this.VAN_CD,
            this.VAN_NM,
            this.AFF_CD,
            this.AFF_NM,
            this.USER_ID,
            this.TRADEDATE,
            this.SUCCESSREQENUM,
            this.SUCCESSREQNAME,
            this.SUCCESSRESENUM,
            this.SUCCESSRESNAME,
            this.ISOILONLY,
            this.CREDITENUM,
            this.CREDITNAME,
            this.METHODENUM,
            this.METHODNAME,
            this.CANCELDATE,
            this.REQUESTDATE,
            this.DUEDATE,
            this.APPRNO,
            this.ISSUEDBYENUM,
            this.ISSUEDBYNAME,
            this.BUYINGENUM,
            this.BUYINGNAME,
            this.CARDNO,
            this.APPRAMT,
            this.HALBU,
            this.SERVICECHARGE,
            this.TAXAMT,
            this.CARDFEE,
            this.INAMT,
            this.STATUS,
            this.DEVICENO,
            this.AFFNO,
            this.BUSINESSNO,
            this.AFFNAME,
            this.EXECYN,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME,
            this.USERMEMO,
            this.AFF_BIGO,
            this.BIGO1,
            this.BIGO2,
            this.BIGO3,
            this.BIGO4,
            this.BIGO5,
            this.BIGO6});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(4, 2);
			this.gridView1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(109, 42);
			this.gridView1.TabIndex = 2;
			// 
			// IDX
			// 
			this.IDX.DataPropertyName = "IDX";
			this.IDX.Frozen = true;
			this.IDX.HeaderText = "일련번호";
			this.IDX.Name = "IDX";
			this.IDX.ReadOnly = true;
			this.IDX.Visible = false;
			this.IDX.Width = 76;
			// 
			// VAN_CD
			// 
			this.VAN_CD.DataPropertyName = "VAN_CD";
			this.VAN_CD.Frozen = true;
			this.VAN_CD.HeaderText = "VAN코드";
			this.VAN_CD.Name = "VAN_CD";
			this.VAN_CD.ReadOnly = true;
			this.VAN_CD.Visible = false;
			this.VAN_CD.Width = 78;
			// 
			// VAN_NM
			// 
			this.VAN_NM.DataPropertyName = "VAN_NM";
			this.VAN_NM.Frozen = true;
			this.VAN_NM.HeaderText = "VAN명";
			this.VAN_NM.Name = "VAN_NM";
			this.VAN_NM.ReadOnly = true;
			this.VAN_NM.Width = 67;
			// 
			// AFF_CD
			// 
			this.AFF_CD.DataPropertyName = "AFF_CD";
			this.AFF_CD.Frozen = true;
			this.AFF_CD.HeaderText = "가맹점코드";
			this.AFF_CD.Name = "AFF_CD";
			this.AFF_CD.ReadOnly = true;
			this.AFF_CD.Visible = false;
			this.AFF_CD.Width = 87;
			// 
			// AFF_NM
			// 
			this.AFF_NM.DataPropertyName = "AFF_NM";
			this.AFF_NM.Frozen = true;
			this.AFF_NM.HeaderText = "가맹점명";
			this.AFF_NM.Name = "AFF_NM";
			this.AFF_NM.ReadOnly = true;
			this.AFF_NM.Width = 76;
			// 
			// USER_ID
			// 
			this.USER_ID.DataPropertyName = "USER_ID";
			this.USER_ID.Frozen = true;
			this.USER_ID.HeaderText = "아이디";
			this.USER_ID.Name = "USER_ID";
			this.USER_ID.ReadOnly = true;
			this.USER_ID.Width = 65;
			// 
			// TRADEDATE
			// 
			this.TRADEDATE.DataPropertyName = "TRADEDATE";
			dataGridViewCellStyle2.Format = "G";
			dataGridViewCellStyle2.NullValue = null;
			this.TRADEDATE.DefaultCellStyle = dataGridViewCellStyle2;
			this.TRADEDATE.Frozen = true;
			this.TRADEDATE.HeaderText = "거래일자";
			this.TRADEDATE.Name = "TRADEDATE";
			this.TRADEDATE.ReadOnly = true;
			this.TRADEDATE.Width = 76;
			// 
			// SUCCESSREQENUM
			// 
			this.SUCCESSREQENUM.DataPropertyName = "SUCCESSREQENUM";
			this.SUCCESSREQENUM.Frozen = true;
			this.SUCCESSREQENUM.HeaderText = "승인요청상태";
			this.SUCCESSREQENUM.Name = "SUCCESSREQENUM";
			this.SUCCESSREQENUM.ReadOnly = true;
			this.SUCCESSREQENUM.Width = 98;
			// 
			// SUCCESSREQNAME
			// 
			this.SUCCESSREQNAME.DataPropertyName = "SUCCESSREQNAME";
			this.SUCCESSREQNAME.HeaderText = "승인요청상태(원)";
			this.SUCCESSREQNAME.Name = "SUCCESSREQNAME";
			this.SUCCESSREQNAME.ReadOnly = true;
			this.SUCCESSREQNAME.ToolTipText = "승인요청상태가 애매할 경우를 대비해서 원 데이터를 저장";
			this.SUCCESSREQNAME.Width = 117;
			// 
			// SUCCESSRESENUM
			// 
			this.SUCCESSRESENUM.DataPropertyName = "SUCCESSRESENUM";
			this.SUCCESSRESENUM.HeaderText = "승인결과상태";
			this.SUCCESSRESENUM.Name = "SUCCESSRESENUM";
			this.SUCCESSRESENUM.ReadOnly = true;
			this.SUCCESSRESENUM.Width = 98;
			// 
			// SUCCESSRESNAME
			// 
			this.SUCCESSRESNAME.DataPropertyName = "SUCCESSRESNAME";
			this.SUCCESSRESNAME.HeaderText = "승인결과상태(원)";
			this.SUCCESSRESNAME.Name = "SUCCESSRESNAME";
			this.SUCCESSRESNAME.ReadOnly = true;
			this.SUCCESSRESNAME.Width = 117;
			// 
			// ISOILONLY
			// 
			this.ISOILONLY.DataPropertyName = "ISOILONLY";
			this.ISOILONLY.HeaderText = "유류카드 여부";
			this.ISOILONLY.Name = "ISOILONLY";
			this.ISOILONLY.ReadOnly = true;
			this.ISOILONLY.Width = 102;
			// 
			// CREDITENUM
			// 
			this.CREDITENUM.DataPropertyName = "CREDITENUM";
			this.CREDITENUM.HeaderText = "카드종류";
			this.CREDITENUM.Name = "CREDITENUM";
			this.CREDITENUM.ReadOnly = true;
			this.CREDITENUM.Width = 76;
			// 
			// CREDITNAME
			// 
			this.CREDITNAME.DataPropertyName = "CREDITNAME";
			this.CREDITNAME.HeaderText = "카드종류(원)";
			this.CREDITNAME.Name = "CREDITNAME";
			this.CREDITNAME.ReadOnly = true;
			this.CREDITNAME.ToolTipText = "카드종류가 애매할 경우를 대비해서 원 데이터를 저장";
			this.CREDITNAME.Width = 95;
			// 
			// METHODENUM
			// 
			this.METHODENUM.DataPropertyName = "METHODENUM";
			this.METHODENUM.HeaderText = "승인방법";
			this.METHODENUM.Name = "METHODENUM";
			this.METHODENUM.ReadOnly = true;
			this.METHODENUM.Width = 76;
			// 
			// METHODNAME
			// 
			this.METHODNAME.DataPropertyName = "METHODNAME";
			this.METHODNAME.HeaderText = "승인방법(원)";
			this.METHODNAME.Name = "METHODNAME";
			this.METHODNAME.ReadOnly = true;
			this.METHODNAME.ToolTipText = "승인방법이 애매할 경우를 대비해서 원 데이터를 저장";
			this.METHODNAME.Width = 95;
			// 
			// CANCELDATE
			// 
			this.CANCELDATE.DataPropertyName = "CANCELDATE";
			dataGridViewCellStyle3.Format = "G";
			dataGridViewCellStyle3.NullValue = null;
			this.CANCELDATE.DefaultCellStyle = dataGridViewCellStyle3;
			this.CANCELDATE.HeaderText = "승인취소일/원거래일";
			this.CANCELDATE.Name = "CANCELDATE";
			this.CANCELDATE.ReadOnly = true;
			this.CANCELDATE.Width = 136;
			// 
			// REQUESTDATE
			// 
			this.REQUESTDATE.DataPropertyName = "REQUESTDATE";
			this.REQUESTDATE.HeaderText = "청구일자";
			this.REQUESTDATE.Name = "REQUESTDATE";
			this.REQUESTDATE.ReadOnly = true;
			this.REQUESTDATE.Width = 76;
			// 
			// DUEDATE
			// 
			this.DUEDATE.DataPropertyName = "DUEDATE";
			dataGridViewCellStyle4.Format = "G";
			this.DUEDATE.DefaultCellStyle = dataGridViewCellStyle4;
			this.DUEDATE.HeaderText = "입금예정일/입금일";
			this.DUEDATE.Name = "DUEDATE";
			this.DUEDATE.ReadOnly = true;
			this.DUEDATE.Width = 125;
			// 
			// APPRNO
			// 
			this.APPRNO.DataPropertyName = "APPRNO";
			this.APPRNO.HeaderText = "승인번호";
			this.APPRNO.Name = "APPRNO";
			this.APPRNO.ReadOnly = true;
			this.APPRNO.Width = 76;
			// 
			// ISSUEDBYENUM
			// 
			this.ISSUEDBYENUM.DataPropertyName = "ISSUEDBYENUM";
			this.ISSUEDBYENUM.HeaderText = "발급사";
			this.ISSUEDBYENUM.Name = "ISSUEDBYENUM";
			this.ISSUEDBYENUM.ReadOnly = true;
			this.ISSUEDBYENUM.Width = 65;
			// 
			// ISSUEDBYNAME
			// 
			this.ISSUEDBYNAME.DataPropertyName = "ISSUEDBYNAME";
			this.ISSUEDBYNAME.HeaderText = "발급사(원)";
			this.ISSUEDBYNAME.Name = "ISSUEDBYNAME";
			this.ISSUEDBYNAME.ReadOnly = true;
			this.ISSUEDBYNAME.ToolTipText = "발급사가 애매할 경우를 대비해서 원 데이터를 저장";
			this.ISSUEDBYNAME.Width = 84;
			// 
			// BUYINGENUM
			// 
			this.BUYINGENUM.DataPropertyName = "BUYINGENUM";
			this.BUYINGENUM.HeaderText = "매입사";
			this.BUYINGENUM.Name = "BUYINGENUM";
			this.BUYINGENUM.ReadOnly = true;
			this.BUYINGENUM.Width = 65;
			// 
			// BUYINGNAME
			// 
			this.BUYINGNAME.DataPropertyName = "BUYINGNAME";
			this.BUYINGNAME.HeaderText = "매입사(원)";
			this.BUYINGNAME.Name = "BUYINGNAME";
			this.BUYINGNAME.ReadOnly = true;
			this.BUYINGNAME.ToolTipText = "매입사가 애매할 경우를 대비해서 원 데이터를 저장";
			this.BUYINGNAME.Width = 84;
			// 
			// CARDNO
			// 
			this.CARDNO.DataPropertyName = "CARDNO";
			this.CARDNO.HeaderText = "카드번호";
			this.CARDNO.Name = "CARDNO";
			this.CARDNO.ReadOnly = true;
			this.CARDNO.Width = 76;
			// 
			// APPRAMT
			// 
			this.APPRAMT.DataPropertyName = "APPRAMT";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			dataGridViewCellStyle5.NullValue = "0";
			this.APPRAMT.DefaultCellStyle = dataGridViewCellStyle5;
			this.APPRAMT.HeaderText = "승인금액①";
			this.APPRAMT.Name = "APPRAMT";
			this.APPRAMT.ReadOnly = true;
			this.APPRAMT.Width = 87;
			// 
			// HALBU
			// 
			this.HALBU.DataPropertyName = "HALBU";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			dataGridViewCellStyle6.NullValue = "0";
			this.HALBU.DefaultCellStyle = dataGridViewCellStyle6;
			this.HALBU.HeaderText = "할부";
			this.HALBU.Name = "HALBU";
			this.HALBU.ReadOnly = true;
			this.HALBU.Width = 54;
			// 
			// SERVICECHARGE
			// 
			this.SERVICECHARGE.DataPropertyName = "SERVICECHARGE";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			dataGridViewCellStyle7.NullValue = "0";
			this.SERVICECHARGE.DefaultCellStyle = dataGridViewCellStyle7;
			this.SERVICECHARGE.HeaderText = "봉사료";
			this.SERVICECHARGE.Name = "SERVICECHARGE";
			this.SERVICECHARGE.ReadOnly = true;
			this.SERVICECHARGE.Width = 65;
			// 
			// TAXAMT
			// 
			this.TAXAMT.DataPropertyName = "TAXAMT";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			dataGridViewCellStyle8.NullValue = "0";
			this.TAXAMT.DefaultCellStyle = dataGridViewCellStyle8;
			this.TAXAMT.HeaderText = "부가세";
			this.TAXAMT.Name = "TAXAMT";
			this.TAXAMT.ReadOnly = true;
			this.TAXAMT.Width = 65;
			// 
			// CARDFEE
			// 
			this.CARDFEE.DataPropertyName = "CARDFEE";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N1";
			dataGridViewCellStyle9.NullValue = "0";
			this.CARDFEE.DefaultCellStyle = dataGridViewCellStyle9;
			this.CARDFEE.HeaderText = "매입카드수수료②";
			this.CARDFEE.Name = "CARDFEE";
			this.CARDFEE.ReadOnly = true;
			this.CARDFEE.Width = 120;
			// 
			// INAMT
			// 
			this.INAMT.DataPropertyName = "INAMT";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N1";
			dataGridViewCellStyle10.NullValue = "0";
			this.INAMT.DefaultCellStyle = dataGridViewCellStyle10;
			this.INAMT.HeaderText = "입금예정금액(① - ②)";
			this.INAMT.Name = "INAMT";
			this.INAMT.ReadOnly = true;
			this.INAMT.ToolTipText = "입금예정금액 = 승인금액① - 매입카드수수료②";
			this.INAMT.Width = 141;
			// 
			// STATUS
			// 
			this.STATUS.DataPropertyName = "STATUS";
			this.STATUS.HeaderText = "처리상태";
			this.STATUS.Name = "STATUS";
			this.STATUS.ReadOnly = true;
			this.STATUS.Width = 76;
			// 
			// DEVICENO
			// 
			this.DEVICENO.DataPropertyName = "DEVICENO";
			this.DEVICENO.HeaderText = "단말기번호";
			this.DEVICENO.Name = "DEVICENO";
			this.DEVICENO.ReadOnly = true;
			this.DEVICENO.Width = 87;
			// 
			// AFFNO
			// 
			this.AFFNO.DataPropertyName = "AFFNO";
			this.AFFNO.HeaderText = "가맹점번호";
			this.AFFNO.Name = "AFFNO";
			this.AFFNO.ReadOnly = true;
			this.AFFNO.ToolTipText = "카드사의 가맹점번호입니다.";
			this.AFFNO.Width = 87;
			// 
			// BUSINESSNO
			// 
			this.BUSINESSNO.DataPropertyName = "BUSINESSNO";
			this.BUSINESSNO.HeaderText = "사업자등록번호";
			this.BUSINESSNO.Name = "BUSINESSNO";
			this.BUSINESSNO.ReadOnly = true;
			this.BUSINESSNO.Width = 109;
			// 
			// AFFNAME
			// 
			this.AFFNAME.DataPropertyName = "AFFNAME";
			this.AFFNAME.HeaderText = "가맹점명";
			this.AFFNAME.Name = "AFFNAME";
			this.AFFNAME.ReadOnly = true;
			this.AFFNAME.ToolTipText = "카드사의 가맹점명입니다.";
			this.AFFNAME.Width = 76;
			// 
			// EXECYN
			// 
			this.EXECYN.DataPropertyName = "EXECYN";
			this.EXECYN.HeaderText = "출금원장등록여부";
			this.EXECYN.Name = "EXECYN";
			this.EXECYN.ReadOnly = true;
			this.EXECYN.Width = 120;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			dataGridViewCellStyle11.Format = "G";
			this.SYSREGDATE.DefaultCellStyle = dataGridViewCellStyle11;
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 98;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 98;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			dataGridViewCellStyle12.Format = "G";
			this.SYSMODDATE.DefaultCellStyle = dataGridViewCellStyle12;
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 98;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 98;
			// 
			// USERMEMO
			// 
			this.USERMEMO.DataPropertyName = "USERMEMO";
			this.USERMEMO.HeaderText = "메모";
			this.USERMEMO.Name = "USERMEMO";
			this.USERMEMO.ReadOnly = true;
			this.USERMEMO.Width = 54;
			// 
			// AFF_BIGO
			// 
			this.AFF_BIGO.DataPropertyName = "AFF_BIGO";
			this.AFF_BIGO.HeaderText = "가맹점 비고";
			this.AFF_BIGO.Name = "AFF_BIGO";
			this.AFF_BIGO.ReadOnly = true;
			this.AFF_BIGO.Width = 91;
			// 
			// BIGO1
			// 
			this.BIGO1.DataPropertyName = "BIGO1";
			this.BIGO1.HeaderText = "BIGO1";
			this.BIGO1.Name = "BIGO1";
			this.BIGO1.ReadOnly = true;
			this.BIGO1.Width = 65;
			// 
			// BIGO2
			// 
			this.BIGO2.DataPropertyName = "BIGO2";
			this.BIGO2.HeaderText = "BIGO2";
			this.BIGO2.Name = "BIGO2";
			this.BIGO2.ReadOnly = true;
			this.BIGO2.Width = 65;
			// 
			// BIGO3
			// 
			this.BIGO3.DataPropertyName = "BIGO3";
			this.BIGO3.HeaderText = "BIGO3";
			this.BIGO3.Name = "BIGO3";
			this.BIGO3.ReadOnly = true;
			this.BIGO3.Width = 65;
			// 
			// BIGO4
			// 
			this.BIGO4.DataPropertyName = "BIGO4";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle13.Format = "N2";
			dataGridViewCellStyle13.NullValue = "0";
			this.BIGO4.DefaultCellStyle = dataGridViewCellStyle13;
			this.BIGO4.HeaderText = "BIGO4";
			this.BIGO4.Name = "BIGO4";
			this.BIGO4.ReadOnly = true;
			this.BIGO4.Width = 65;
			// 
			// BIGO5
			// 
			this.BIGO5.DataPropertyName = "BIGO5";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle14.Format = "N2";
			dataGridViewCellStyle14.NullValue = "0";
			this.BIGO5.DefaultCellStyle = dataGridViewCellStyle14;
			this.BIGO5.HeaderText = "BIGO5";
			this.BIGO5.Name = "BIGO5";
			this.BIGO5.ReadOnly = true;
			this.BIGO5.Width = 65;
			// 
			// BIGO6
			// 
			this.BIGO6.DataPropertyName = "BIGO6";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle15.Format = "N2";
			dataGridViewCellStyle15.NullValue = "0";
			this.BIGO6.DefaultCellStyle = dataGridViewCellStyle15;
			this.BIGO6.HeaderText = "BIGO6";
			this.BIGO6.Name = "BIGO6";
			this.BIGO6.ReadOnly = true;
			this.BIGO6.Width = 65;
			// 
			// textBox1
			// 
			this.textBox1.Compulsory = true;
			this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this.textBox1.Location = new System.Drawing.Point(32, 56);
			this.textBox1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(116, 20);
			this.textBox1.TabIndex = 2;
			this.textBox1.ValidationGroup = "a";
			this.textBox1.WaterMarkColor = System.Drawing.Color.Empty;
			this.textBox1.WaterMarkText = "";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.textBox1);
			this.groupBox1.Location = new System.Drawing.Point(328, 109);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.groupBox1.Size = new System.Drawing.Size(234, 92);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "groupBox1";
			// 
			// comboBox1
			// 
			this.comboBox1.Compulsory = true;
			this.comboBox1.DataSource = null;
			this.comboBox1.DroppedDown = false;
			this.comboBox1.Location = new System.Drawing.Point(500, 226);
			this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.comboBox1.MaximumSize = new System.Drawing.Size(584, 55);
			this.comboBox1.MinimumSize = new System.Drawing.Size(116, 19);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.SelectedIndex = -1;
			this.comboBox1.SelectedItem = null;
			this.comboBox1.SelectedValue = null;
			this.comboBox1.Size = new System.Drawing.Size(141, 20);
			this.comboBox1.TabIndex = 5;
			this.comboBox1.ValidationGroup = "a";
			// 
			// textBox2
			// 
			this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this.textBox2.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this.textBox2.Location = new System.Drawing.Point(634, 144);
			this.textBox2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(116, 20);
			this.textBox2.TabIndex = 6;
			this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox2.ValidationGroup = null;
			this.textBox2.WaterMarkColor = System.Drawing.Color.Empty;
			this.textBox2.WaterMarkText = "";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.tableLayoutPanel6);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox2.Location = new System.Drawing.Point(0, 0);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.groupBox2.Size = new System.Drawing.Size(1516, 98);
			this.groupBox2.TabIndex = 7;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 9;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 151F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 151F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 151F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 396F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 8, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbSUCCESSRESENUM, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this.label10, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label17, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.label9, 0, 2);
			this.tableLayoutPanel6.Controls.Add(this.label2, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this.label8, 2, 2);
			this.tableLayoutPanel6.Controls.Add(this._cmbVAN_CD, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtUSER_ID, 5, 2);
			this.tableLayoutPanel6.Controls.Add(this._cmbCREDITENUM, 1, 1);
			this.tableLayoutPanel6.Controls.Add(this.label13, 4, 2);
			this.tableLayoutPanel6.Controls.Add(this._cmbISSUEDBYENUM, 1, 2);
			this.tableLayoutPanel6.Controls.Add(this._cmbSUCCESSREQENUM, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbBUYINGENUM, 3, 2);
			this.tableLayoutPanel6.Controls.Add(this.label3, 6, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 7, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtAFF_NM, 3, 1);
			this.tableLayoutPanel6.Controls.Add(this.label1, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label11, 2, 1);
			this.tableLayoutPanel6.Controls.Add(this.label5, 4, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtAPPRNO, 5, 1);
			this.tableLayoutPanel6.Controls.Add(this.label7, 6, 1);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel3, 7, 1);
			this.tableLayoutPanel6.Controls.Add(this.label6, 6, 2);
			this.tableLayoutPanel6.Controls.Add(this._txtUSERMEMO, 7, 2);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(4, 16);
			this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 3;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1508, 80);
			this.tableLayoutPanel6.TabIndex = 1011;
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._btnSearch);
			this.flowLayoutPanel4.Controls.Add(this._btnExcel);
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(1278, 1);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(368, 25);
			this.flowLayoutPanel4.TabIndex = 1019;
			// 
			// _btnSearch
			// 
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(4, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "     검    색";
			this._btnSearch.Size = new System.Drawing.Size(88, 22);
			this._btnSearch.TabIndex = 0;
			this._btnSearch.Text = "     검    색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			// 
			// _btnExcel
			// 
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(100, 2);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "     엑    셀";
			this._btnExcel.Size = new System.Drawing.Size(88, 22);
			this._btnExcel.TabIndex = 1010;
			this._btnExcel.Text = "     엑    셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			// 
			// _cmbSUCCESSRESENUM
			// 
			this._cmbSUCCESSRESENUM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbSUCCESSRESENUM.DataSource = null;
			this._cmbSUCCESSRESENUM.DelegateProperty = true;
			this._cmbSUCCESSRESENUM.DroppedDown = false;
			this._cmbSUCCESSRESENUM.Location = new System.Drawing.Point(627, 3);
			this._cmbSUCCESSRESENUM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._cmbSUCCESSRESENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbSUCCESSRESENUM.MinimumSize = new System.Drawing.Size(101, 22);
			this._cmbSUCCESSRESENUM.Name = "_cmbSUCCESSRESENUM";
			this._cmbSUCCESSRESENUM.SelectedIndex = -1;
			this._cmbSUCCESSRESENUM.SelectedItem = null;
			this._cmbSUCCESSRESENUM.SelectedValue = null;
			this._cmbSUCCESSRESENUM.Size = new System.Drawing.Size(140, 22);
			this._cmbSUCCESSRESENUM.TabIndex = 50;
			this._cmbSUCCESSRESENUM.ValidationGroup = null;
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(60, 7);
			this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(42, 12);
			this.label10.TabIndex = 7;
			this.label10.Text = "VAN명";
			// 
			// label17
			// 
			this.label17.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(541, 7);
			this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(77, 12);
			this.label17.TabIndex = 132;
			this.label17.Text = "승인결과상태";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(37, 60);
			this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(65, 12);
			this.label9.TabIndex = 23;
			this.label9.Text = "발급사구분";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(49, 33);
			this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(53, 12);
			this.label2.TabIndex = 19;
			this.label2.Text = "카드구분";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(295, 60);
			this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(65, 12);
			this.label8.TabIndex = 24;
			this.label8.Text = "매입사구분";
			// 
			// _cmbVAN_CD
			// 
			this._cmbVAN_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbVAN_CD.DataSource = null;
			this._cmbVAN_CD.DelegateProperty = true;
			this._cmbVAN_CD.DropDownWidth = 250;
			this._cmbVAN_CD.DroppedDown = false;
			this._cmbVAN_CD.Location = new System.Drawing.Point(111, 3);
			this._cmbVAN_CD.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._cmbVAN_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbVAN_CD.MinimumSize = new System.Drawing.Size(101, 22);
			this._cmbVAN_CD.Name = "_cmbVAN_CD";
			this._cmbVAN_CD.SelectedIndex = -1;
			this._cmbVAN_CD.SelectedItem = null;
			this._cmbVAN_CD.SelectedValue = null;
			this._cmbVAN_CD.Size = new System.Drawing.Size(140, 22);
			this._cmbVAN_CD.TabIndex = 10;
			this._cmbVAN_CD.ValidationGroup = null;
			// 
			// _txtUSER_ID
			// 
			this._txtUSER_ID.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtUSER_ID.DelegateProperty = true;
			this._txtUSER_ID.Location = new System.Drawing.Point(627, 55);
			this._txtUSER_ID.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtUSER_ID.Name = "_txtUSER_ID";
			this._txtUSER_ID.Size = new System.Drawing.Size(140, 21);
			this._txtUSER_ID.TabIndex = 100;
			this._txtUSER_ID.ValidationGroup = null;
			this._txtUSER_ID.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtUSER_ID.WaterMarkText = "";
			// 
			// _cmbCREDITENUM
			// 
			this._cmbCREDITENUM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCREDITENUM.DataSource = null;
			this._cmbCREDITENUM.DelegateProperty = true;
			this._cmbCREDITENUM.DroppedDown = false;
			this._cmbCREDITENUM.Location = new System.Drawing.Point(111, 29);
			this._cmbCREDITENUM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._cmbCREDITENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCREDITENUM.MinimumSize = new System.Drawing.Size(101, 22);
			this._cmbCREDITENUM.Name = "_cmbCREDITENUM";
			this._cmbCREDITENUM.SelectedIndex = -1;
			this._cmbCREDITENUM.SelectedItem = null;
			this._cmbCREDITENUM.SelectedValue = null;
			this._cmbCREDITENUM.Size = new System.Drawing.Size(140, 22);
			this._cmbCREDITENUM.TabIndex = 60;
			this._cmbCREDITENUM.ValidationGroup = null;
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(577, 60);
			this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(41, 12);
			this.label13.TabIndex = 10;
			this.label13.Text = "아이디";
			// 
			// _cmbISSUEDBYENUM
			// 
			this._cmbISSUEDBYENUM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbISSUEDBYENUM.DataSource = null;
			this._cmbISSUEDBYENUM.DelegateProperty = true;
			this._cmbISSUEDBYENUM.DroppedDown = false;
			this._cmbISSUEDBYENUM.Location = new System.Drawing.Point(111, 56);
			this._cmbISSUEDBYENUM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._cmbISSUEDBYENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbISSUEDBYENUM.MinimumSize = new System.Drawing.Size(101, 22);
			this._cmbISSUEDBYENUM.Name = "_cmbISSUEDBYENUM";
			this._cmbISSUEDBYENUM.SelectedIndex = -1;
			this._cmbISSUEDBYENUM.SelectedItem = null;
			this._cmbISSUEDBYENUM.SelectedValue = null;
			this._cmbISSUEDBYENUM.Size = new System.Drawing.Size(140, 22);
			this._cmbISSUEDBYENUM.TabIndex = 110;
			this._cmbISSUEDBYENUM.ValidationGroup = null;
			// 
			// _cmbSUCCESSREQENUM
			// 
			this._cmbSUCCESSREQENUM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbSUCCESSREQENUM.DataSource = null;
			this._cmbSUCCESSREQENUM.DelegateProperty = true;
			this._cmbSUCCESSREQENUM.DroppedDown = false;
			this._cmbSUCCESSREQENUM.Location = new System.Drawing.Point(369, 3);
			this._cmbSUCCESSREQENUM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._cmbSUCCESSREQENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbSUCCESSREQENUM.MinimumSize = new System.Drawing.Size(101, 22);
			this._cmbSUCCESSREQENUM.Name = "_cmbSUCCESSREQENUM";
			this._cmbSUCCESSREQENUM.SelectedIndex = -1;
			this._cmbSUCCESSREQENUM.SelectedItem = null;
			this._cmbSUCCESSREQENUM.SelectedValue = null;
			this._cmbSUCCESSREQENUM.Size = new System.Drawing.Size(140, 22);
			this._cmbSUCCESSREQENUM.TabIndex = 40;
			this._cmbSUCCESSREQENUM.ValidationGroup = null;
			// 
			// _cmbBUYINGENUM
			// 
			this._cmbBUYINGENUM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbBUYINGENUM.DataSource = null;
			this._cmbBUYINGENUM.DelegateProperty = true;
			this._cmbBUYINGENUM.DroppedDown = false;
			this._cmbBUYINGENUM.Location = new System.Drawing.Point(369, 56);
			this._cmbBUYINGENUM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._cmbBUYINGENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbBUYINGENUM.MinimumSize = new System.Drawing.Size(101, 22);
			this._cmbBUYINGENUM.Name = "_cmbBUYINGENUM";
			this._cmbBUYINGENUM.SelectedIndex = -1;
			this._cmbBUYINGENUM.SelectedItem = null;
			this._cmbBUYINGENUM.SelectedValue = null;
			this._cmbBUYINGENUM.Size = new System.Drawing.Size(141, 22);
			this._cmbBUYINGENUM.TabIndex = 120;
			this._cmbBUYINGENUM.ValidationGroup = null;
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(823, 7);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(53, 12);
			this.label3.TabIndex = 20;
			this.label3.Text = "거래일자";
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._dtpTRADEDATE1);
			this.flowLayoutPanel2.Controls.Add(this.label12);
			this.flowLayoutPanel2.Controls.Add(this._dtpTRADEDATE2);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(881, 1);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(396, 25);
			this.flowLayoutPanel2.TabIndex = 1012;
			// 
			// _dtpTRADEDATE1
			// 
			this._dtpTRADEDATE1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE1.Checked = false;
			this._dtpTRADEDATE1.CustomFormat = "yyyy-MM-dd HH:mm";
			this._dtpTRADEDATE1.DelegateProperty = true;
			this._dtpTRADEDATE1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE1.Location = new System.Drawing.Point(4, 2);
			this._dtpTRADEDATE1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._dtpTRADEDATE1.MaximumSize = new System.Drawing.Size(291, 22);
			this._dtpTRADEDATE1.MinimumSize = new System.Drawing.Size(101, 22);
			this._dtpTRADEDATE1.Name = "_dtpTRADEDATE1";
			this._dtpTRADEDATE1.Size = new System.Drawing.Size(173, 27);
			this._dtpTRADEDATE1.TabIndex = 20;
			this._dtpTRADEDATE1.ValidationGroup = null;
			this._dtpTRADEDATE1.Value = new System.DateTime(2014, 7, 26, 12, 42, 41, 355);
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(163, 7);
			this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(14, 12);
			this.label12.TabIndex = 38;
			this.label12.Text = "~";
			// 
			// _dtpTRADEDATE2
			// 
			this._dtpTRADEDATE2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE2.Checked = false;
			this._dtpTRADEDATE2.CustomFormat = "yyyy-MM-dd HH:mm";
			this._dtpTRADEDATE2.DelegateProperty = true;
			this._dtpTRADEDATE2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE2.Location = new System.Drawing.Point(185, 2);
			this._dtpTRADEDATE2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._dtpTRADEDATE2.MaximumSize = new System.Drawing.Size(291, 22);
			this._dtpTRADEDATE2.MinimumSize = new System.Drawing.Size(101, 22);
			this._dtpTRADEDATE2.Name = "_dtpTRADEDATE2";
			this._dtpTRADEDATE2.Size = new System.Drawing.Size(173, 27);
			this._dtpTRADEDATE2.TabIndex = 30;
			this._dtpTRADEDATE2.ValidationGroup = null;
			this._dtpTRADEDATE2.Value = new System.DateTime(2014, 7, 25, 12, 10, 42, 127);
			// 
			// _txtAFF_NM
			// 
			this._txtAFF_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAFF_NM.DelegateProperty = true;
			this._txtAFF_NM.Location = new System.Drawing.Point(369, 29);
			this._txtAFF_NM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtAFF_NM.Name = "_txtAFF_NM";
			this._txtAFF_NM.Size = new System.Drawing.Size(140, 21);
			this._txtAFF_NM.TabIndex = 90;
			this._txtAFF_NM.ValidationGroup = null;
			this._txtAFF_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAFF_NM.WaterMarkText = "";
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(283, 7);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(77, 12);
			this.label1.TabIndex = 18;
			this.label1.Text = "승인요청상태";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(307, 33);
			this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(53, 12);
			this.label11.TabIndex = 8;
			this.label11.Text = "가맹점명";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(565, 33);
			this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(53, 12);
			this.label5.TabIndex = 22;
			this.label5.Text = "승인번호";
			// 
			// _txtAPPRNO
			// 
			this._txtAPPRNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRNO.DelegateProperty = true;
			this._txtAPPRNO.Location = new System.Drawing.Point(627, 29);
			this._txtAPPRNO.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtAPPRNO.Name = "_txtAPPRNO";
			this._txtAPPRNO.Size = new System.Drawing.Size(140, 21);
			this._txtAPPRNO.TabIndex = 150;
			this._txtAPPRNO.ValidationGroup = null;
			this._txtAPPRNO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAPPRNO.WaterMarkText = "";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(823, 33);
			this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(53, 12);
			this.label7.TabIndex = 25;
			this.label7.Text = "승인금액";
			// 
			// flowLayoutPanel3
			// 
			this.flowLayoutPanel3.Controls.Add(this._txtAPPRAMT1);
			this.flowLayoutPanel3.Controls.Add(this.label4);
			this.flowLayoutPanel3.Controls.Add(this._txtAPPRAMT2);
			this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel3.Location = new System.Drawing.Point(881, 27);
			this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel3.Name = "flowLayoutPanel3";
			this.flowLayoutPanel3.Size = new System.Drawing.Size(396, 25);
			this.flowLayoutPanel3.TabIndex = 1018;
			// 
			// _txtAPPRAMT1
			// 
			this._txtAPPRAMT1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRAMT1.DelegateProperty = true;
			this._txtAPPRAMT1.Location = new System.Drawing.Point(4, 2);
			this._txtAPPRAMT1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtAPPRAMT1.Name = "_txtAPPRAMT1";
			this._txtAPPRAMT1.Size = new System.Drawing.Size(151, 21);
			this._txtAPPRAMT1.TabIndex = 130;
			this._txtAPPRAMT1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtAPPRAMT1.ValidationGroup = null;
			this._txtAPPRAMT1.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAPPRAMT1.WaterMarkText = "";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(163, 6);
			this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(14, 12);
			this.label4.TabIndex = 37;
			this.label4.Text = "~";
			// 
			// _txtAPPRAMT2
			// 
			this._txtAPPRAMT2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRAMT2.DelegateProperty = true;
			this._txtAPPRAMT2.Location = new System.Drawing.Point(185, 2);
			this._txtAPPRAMT2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtAPPRAMT2.Name = "_txtAPPRAMT2";
			this._txtAPPRAMT2.Size = new System.Drawing.Size(151, 21);
			this._txtAPPRAMT2.TabIndex = 140;
			this._txtAPPRAMT2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtAPPRAMT2.ValidationGroup = null;
			this._txtAPPRAMT2.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAPPRAMT2.WaterMarkText = "";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(847, 60);
			this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(29, 12);
			this.label6.TabIndex = 26;
			this.label6.Text = "메모";
			// 
			// _txtUSERMEMO
			// 
			this._txtUSERMEMO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtUSERMEMO.DelegateProperty = true;
			this._txtUSERMEMO.Location = new System.Drawing.Point(885, 55);
			this._txtUSERMEMO.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtUSERMEMO.Name = "_txtUSERMEMO";
			this._txtUSERMEMO.Size = new System.Drawing.Size(333, 21);
			this._txtUSERMEMO.TabIndex = 160;
			this._txtUSERMEMO.ValidationGroup = null;
			this._txtUSERMEMO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtUSERMEMO.WaterMarkText = "";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this._txtSum06);
			this.groupBox3.Controls.Add(this._txtSum05);
			this.groupBox3.Controls.Add(this.label16);
			this.groupBox3.Controls.Add(this._txtSum04);
			this.groupBox3.Controls.Add(this._txtSum03);
			this.groupBox3.Controls.Add(this.label15);
			this.groupBox3.Controls.Add(this._txtSum02);
			this.groupBox3.Controls.Add(this._txtSum01);
			this.groupBox3.Controls.Add(this.label14);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox3.Location = new System.Drawing.Point(0, 316);
			this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.groupBox3.Size = new System.Drawing.Size(1516, 46);
			this.groupBox3.TabIndex = 8;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "합계";
			// 
			// _txtSum06
			// 
			this._txtSum06.DelegateProperty = true;
			this._txtSum06.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum06.Location = new System.Drawing.Point(946, 16);
			this._txtSum06.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtSum06.Name = "_txtSum06";
			this._txtSum06.ReadOnly = true;
			this._txtSum06.Size = new System.Drawing.Size(92, 20);
			this._txtSum06.TabIndex = 8;
			this._txtSum06.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum06.ValidationGroup = null;
			this._txtSum06.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSum06.WaterMarkText = "";
			// 
			// _txtSum05
			// 
			this._txtSum05.DelegateProperty = true;
			this._txtSum05.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum05.Location = new System.Drawing.Point(787, 16);
			this._txtSum05.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtSum05.Name = "_txtSum05";
			this._txtSum05.ReadOnly = true;
			this._txtSum05.Size = new System.Drawing.Size(152, 20);
			this._txtSum05.TabIndex = 7;
			this._txtSum05.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum05.ValidationGroup = null;
			this._txtSum05.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSum05.WaterMarkText = "";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(704, 18);
			this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(67, 12);
			this.label16.TabIndex = 6;
			this.label16.Text = "승인 - 취소";
			// 
			// _txtSum04
			// 
			this._txtSum04.DelegateProperty = true;
			this._txtSum04.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum04.Location = new System.Drawing.Point(570, 16);
			this._txtSum04.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtSum04.Name = "_txtSum04";
			this._txtSum04.ReadOnly = true;
			this._txtSum04.Size = new System.Drawing.Size(92, 20);
			this._txtSum04.TabIndex = 5;
			this._txtSum04.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum04.ValidationGroup = null;
			this._txtSum04.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSum04.WaterMarkText = "";
			// 
			// _txtSum03
			// 
			this._txtSum03.DelegateProperty = true;
			this._txtSum03.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum03.Location = new System.Drawing.Point(410, 16);
			this._txtSum03.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtSum03.Name = "_txtSum03";
			this._txtSum03.ReadOnly = true;
			this._txtSum03.Size = new System.Drawing.Size(152, 20);
			this._txtSum03.TabIndex = 4;
			this._txtSum03.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum03.ValidationGroup = null;
			this._txtSum03.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSum03.WaterMarkText = "";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(368, 18);
			this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(29, 12);
			this.label15.TabIndex = 3;
			this.label15.Text = "취소";
			// 
			// _txtSum02
			// 
			this._txtSum02.DelegateProperty = true;
			this._txtSum02.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum02.Location = new System.Drawing.Point(242, 16);
			this._txtSum02.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtSum02.Name = "_txtSum02";
			this._txtSum02.ReadOnly = true;
			this._txtSum02.Size = new System.Drawing.Size(92, 20);
			this._txtSum02.TabIndex = 2;
			this._txtSum02.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum02.ValidationGroup = null;
			this._txtSum02.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSum02.WaterMarkText = "";
			// 
			// _txtSum01
			// 
			this._txtSum01.DelegateProperty = true;
			this._txtSum01.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum01.Location = new System.Drawing.Point(81, 16);
			this._txtSum01.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this._txtSum01.Name = "_txtSum01";
			this._txtSum01.ReadOnly = true;
			this._txtSum01.Size = new System.Drawing.Size(152, 20);
			this._txtSum01.TabIndex = 1;
			this._txtSum01.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum01.ValidationGroup = null;
			this._txtSum01.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSum01.WaterMarkText = "";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(38, 18);
			this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(29, 12);
			this.label14.TabIndex = 0;
			this.label14.Text = "승인";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(388, 282);
			this.button1.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.button1.Name = "button1";
			this.button1.Reserved = "button1";
			this.button1.Size = new System.Drawing.Size(88, 22);
			this.button1.TabIndex = 3;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.ValidationGroup = "a";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1516, 362);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Controls.Add(this.maskedTextBox1);
			this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.tableLayoutPanel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			this.flowLayoutPanel3.ResumeLayout(false);
			this.flowLayoutPanel3.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MaskedTextBox maskedTextBox1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private BANANA.Windows.Controls.TextBox textBox1;
		private DemoClient.Controls.BananaButton button1;
		private BANANA.Windows.Controls.GroupBox groupBox1;
		private BANANA.Windows.Controls.ComboBox comboBox1;
		private BANANA.Windows.Controls.TextBox textBox2;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn VAN_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn VAN_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFF_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFF_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn USER_ID;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRADEDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSREQENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSREQNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSRESENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSRESNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISOILONLY;
		private System.Windows.Forms.DataGridViewTextBoxColumn CREDITENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CREDITNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn METHODENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn METHODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn CANCELDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn REQUESTDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn DUEDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn APPRNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISSUEDBYENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISSUEDBYNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUYINGENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUYINGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn CARDNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn APPRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn HALBU;
		private System.Windows.Forms.DataGridViewTextBoxColumn SERVICECHARGE;
		private System.Windows.Forms.DataGridViewTextBoxColumn TAXAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CARDFEE;
		private System.Windows.Forms.DataGridViewTextBoxColumn INAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn STATUS;
		private System.Windows.Forms.DataGridViewTextBoxColumn DEVICENO;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFFNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUSINESSNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFFNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn EXECYN;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn USERMEMO;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFF_BIGO;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO1;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO2;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO3;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO4;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO5;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO6;
		private System.Windows.Forms.GroupBox groupBox2;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private DemoClient.Controls.BananaButton _btnSearch;
		private DemoClient.Controls.BananaButton _btnExcel;
		private BANANA.Windows.Controls.ComboBox _cmbSUCCESSRESENUM;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label8;
		private BANANA.Windows.Controls.ComboBox _cmbVAN_CD;
		private BANANA.Windows.Controls.TextBox _txtUSER_ID;
		private BANANA.Windows.Controls.ComboBox _cmbCREDITENUM;
		private System.Windows.Forms.Label label13;
		private BANANA.Windows.Controls.ComboBox _cmbISSUEDBYENUM;
		private BANANA.Windows.Controls.ComboBox _cmbSUCCESSREQENUM;
		private BANANA.Windows.Controls.ComboBox _cmbBUYINGENUM;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE1;
		private System.Windows.Forms.Label label12;
		private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE2;
		private BANANA.Windows.Controls.TextBox _txtAFF_NM;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label5;
		private BANANA.Windows.Controls.TextBox _txtAPPRNO;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
		private BANANA.Windows.Controls.TextBox _txtAPPRAMT1;
		private System.Windows.Forms.Label label4;
		private BANANA.Windows.Controls.TextBox _txtAPPRAMT2;
		private System.Windows.Forms.Label label6;
		private BANANA.Windows.Controls.TextBox _txtUSERMEMO;
		private System.Windows.Forms.GroupBox groupBox3;
		private BANANA.Windows.Controls.TextBox _txtSum06;
		private BANANA.Windows.Controls.TextBox _txtSum05;
		private BANANA.Windows.Controls.Label label16;
		private BANANA.Windows.Controls.TextBox _txtSum04;
		private BANANA.Windows.Controls.TextBox _txtSum03;
		private BANANA.Windows.Controls.Label label15;
		private BANANA.Windows.Controls.TextBox _txtSum02;
		private BANANA.Windows.Controls.TextBox _txtSum01;
		private BANANA.Windows.Controls.Label label14;
	}
}