﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient._Test
{
	public partial class Form2 : DemoClient.Controllers.BaseForm
	{
		public Form2()
		{
			InitializeComponent();
		}
	}
}
