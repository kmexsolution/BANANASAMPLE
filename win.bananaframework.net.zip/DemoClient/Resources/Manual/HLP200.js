﻿
// 메뉴로 이동
function showMenu(mnu_cd) {
	window.external.ShowMenu(mnu_cd);
}