﻿namespace DemoClient.View.WDR
{
    partial class WDR0910
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WDR0910));
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_USE_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_GIJUN_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_CAL_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_INTST_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_PER = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_LMT_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.gridView3 = new DemoClient.Controls.GridView();
			this.H_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BAS0852_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HST_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EXCPT_DT_STRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EXCPT_DT_END = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HST_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter2 = new DemoClient.Controls.CollapsibleSplitter();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.gridView2 = new DemoClient.Controls.GridView();
			this.BAS0851_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_ACTN_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MEMO2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
			this._txtDPST_AMT_S_S = new BANANA.Windows.Controls.TextBox();
			this.label11 = new BANANA.Windows.Controls.Label();
			this._txtDPST_AMT_E_S = new BANANA.Windows.Controls.TextBox();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this._cmbDPST_CAL_CD_S = new BANANA.Windows.Controls.ComboBox();
			this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label40 = new BANANA.Windows.Controls.Label();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label39 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this.label38 = new BANANA.Windows.Controls.Label();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpDPST_STRT_DT_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label10 = new BANANA.Windows.Controls.Label();
			this._dtpDPST_STRT_DT_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this._cmbDPST_GIJUN_CD_S = new BANANA.Windows.Controls.ComboBox();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.panel1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.gridView1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.Location = new System.Drawing.Point(0, 76);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(537, 594);
			this.groupBox2.TabIndex = 8;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STR_CD,
            this.STR_NM,
            this.DPST_STRT_DT,
            this.DPST_USE_YN,
            this.DPST_GIJUN_NM,
            this.DPST_CAL_NM,
            this.DPST_INTST_YN,
            this.DPST_PER,
            this.DPST_LMT_AMT,
            this.DPST_AMT,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 21);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.RowTemplate.Height = 23;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(531, 570);
			this.gridView1.TabIndex = 1;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 111;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 96;
			// 
			// DPST_STRT_DT
			// 
			this.DPST_STRT_DT.DataPropertyName = "DPST_STRT_DT";
			this.DPST_STRT_DT.HeaderText = "적용시작일";
			this.DPST_STRT_DT.Name = "DPST_STRT_DT";
			this.DPST_STRT_DT.ReadOnly = true;
			this.DPST_STRT_DT.Width = 111;
			// 
			// DPST_USE_YN
			// 
			this.DPST_USE_YN.DataPropertyName = "DPST_USE_YN";
			this.DPST_USE_YN.HeaderText = "사용여부";
			this.DPST_USE_YN.Name = "DPST_USE_YN";
			this.DPST_USE_YN.ReadOnly = true;
			this.DPST_USE_YN.Width = 96;
			// 
			// DPST_GIJUN_NM
			// 
			this.DPST_GIJUN_NM.DataPropertyName = "DPST_GIJUN_NM";
			this.DPST_GIJUN_NM.HeaderText = "차감기준";
			this.DPST_GIJUN_NM.Name = "DPST_GIJUN_NM";
			this.DPST_GIJUN_NM.ReadOnly = true;
			this.DPST_GIJUN_NM.Width = 96;
			// 
			// DPST_CAL_NM
			// 
			this.DPST_CAL_NM.DataPropertyName = "DPST_CAL_NM";
			this.DPST_CAL_NM.HeaderText = "계산방법";
			this.DPST_CAL_NM.Name = "DPST_CAL_NM";
			this.DPST_CAL_NM.ReadOnly = true;
			this.DPST_CAL_NM.Width = 96;
			// 
			// DPST_INTST_YN
			// 
			this.DPST_INTST_YN.DataPropertyName = "DPST_INTST_YN";
			this.DPST_INTST_YN.HeaderText = "미차감이자";
			this.DPST_INTST_YN.Name = "DPST_INTST_YN";
			this.DPST_INTST_YN.ReadOnly = true;
			this.DPST_INTST_YN.Width = 111;
			// 
			// DPST_PER
			// 
			this.DPST_PER.DataPropertyName = "DPST_PER";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DPST_PER.DefaultCellStyle = dataGridViewCellStyle2;
			this.DPST_PER.HeaderText = "차감수치";
			this.DPST_PER.Name = "DPST_PER";
			this.DPST_PER.ReadOnly = true;
			this.DPST_PER.Width = 96;
			// 
			// DPST_LMT_AMT
			// 
			this.DPST_LMT_AMT.DataPropertyName = "DPST_LMT_AMT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			this.DPST_LMT_AMT.DefaultCellStyle = dataGridViewCellStyle3;
			this.DPST_LMT_AMT.HeaderText = "일적립한도";
			this.DPST_LMT_AMT.Name = "DPST_LMT_AMT";
			this.DPST_LMT_AMT.ReadOnly = true;
			this.DPST_LMT_AMT.Width = 111;
			// 
			// DPST_AMT
			// 
			this.DPST_AMT.DataPropertyName = "DPST_AMT";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = null;
			this.DPST_AMT.DefaultCellStyle = dataGridViewCellStyle4;
			this.DPST_AMT.HeaderText = "보증한도금액";
			this.DPST_AMT.Name = "DPST_AMT";
			this.DPST_AMT.ReadOnly = true;
			this.DPST_AMT.Width = 126;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 126;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 126;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 126;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 126;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.panel1;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(537, 76);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 7;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.groupBox4);
			this.panel1.Controls.Add(this.collapsibleSplitter2);
			this.panel1.Controls.Add(this.groupBox3);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(545, 76);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(600, 594);
			this.panel1.TabIndex = 5;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.gridView3);
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox4.Location = new System.Drawing.Point(0, 444);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(600, 150);
			this.groupBox4.TabIndex = 7;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "예외기간";
			// 
			// gridView3
			// 
			this.gridView3.AutoSelectRowWithRightButton = false;
			this.gridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
			this.gridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.gridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.H_IDX,
            this.BAS0852_IDX,
            this.HST_NAME,
            this.EXCPT_DT_STRT,
            this.EXCPT_DT_END,
            this.MEMO,
            this.SYSREGDATE2,
            this.SYSREGNAME2,
            this.HST_TYPE});
			this.gridView3.DelegateProperty = true;
			this.gridView3.Location = new System.Drawing.Point(3, 21);
			this.gridView3.Name = "gridView3";
			this.gridView3.ReadOnly = true;
			this.gridView3.RowTemplate.Height = 23;
			this.gridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView3.Size = new System.Drawing.Size(594, 126);
			this.gridView3.TabIndex = 2;
			// 
			// H_IDX
			// 
			this.H_IDX.DataPropertyName = "IDX";
			this.H_IDX.HeaderText = "이력 일련번호";
			this.H_IDX.Name = "H_IDX";
			this.H_IDX.ReadOnly = true;
			this.H_IDX.Width = 131;
			// 
			// BAS0852_IDX
			// 
			this.BAS0852_IDX.DataPropertyName = "BAS0852_IDX";
			this.BAS0852_IDX.HeaderText = "예외기간 일련번호";
			this.BAS0852_IDX.Name = "BAS0852_IDX";
			this.BAS0852_IDX.ReadOnly = true;
			this.BAS0852_IDX.Width = 161;
			// 
			// HST_NAME
			// 
			this.HST_NAME.DataPropertyName = "HST_NAME";
			this.HST_NAME.HeaderText = "이력구분";
			this.HST_NAME.Name = "HST_NAME";
			this.HST_NAME.ReadOnly = true;
			this.HST_NAME.Width = 96;
			// 
			// EXCPT_DT_STRT
			// 
			this.EXCPT_DT_STRT.DataPropertyName = "EXCPT_DT_STRT";
			this.EXCPT_DT_STRT.HeaderText = "예외시작일";
			this.EXCPT_DT_STRT.Name = "EXCPT_DT_STRT";
			this.EXCPT_DT_STRT.ReadOnly = true;
			this.EXCPT_DT_STRT.Width = 111;
			// 
			// EXCPT_DT_END
			// 
			this.EXCPT_DT_END.DataPropertyName = "EXCPT_DT_END";
			this.EXCPT_DT_END.HeaderText = "예외종료일";
			this.EXCPT_DT_END.Name = "EXCPT_DT_END";
			this.EXCPT_DT_END.ReadOnly = true;
			this.EXCPT_DT_END.Width = 111;
			// 
			// MEMO
			// 
			this.MEMO.DataPropertyName = "MEMO";
			this.MEMO.HeaderText = "메모";
			this.MEMO.Name = "MEMO";
			this.MEMO.ReadOnly = true;
			this.MEMO.Width = 66;
			// 
			// SYSREGDATE2
			// 
			this.SYSREGDATE2.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE2.HeaderText = "시스템등록일";
			this.SYSREGDATE2.Name = "SYSREGDATE2";
			this.SYSREGDATE2.ReadOnly = true;
			this.SYSREGDATE2.Width = 126;
			// 
			// SYSREGNAME2
			// 
			this.SYSREGNAME2.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME2.HeaderText = "시스템등록자";
			this.SYSREGNAME2.Name = "SYSREGNAME2";
			this.SYSREGNAME2.ReadOnly = true;
			this.SYSREGNAME2.Width = 126;
			// 
			// HST_TYPE
			// 
			this.HST_TYPE.DataPropertyName = "HST_TYPE";
			this.HST_TYPE.HeaderText = "HST_TYPE";
			this.HST_TYPE.Name = "HST_TYPE";
			this.HST_TYPE.ReadOnly = true;
			this.HST_TYPE.Visible = false;
			this.HST_TYPE.Width = 107;
			// 
			// collapsibleSplitter2
			// 
			this.collapsibleSplitter2.AnimationDelay = 20;
			this.collapsibleSplitter2.AnimationStep = 20;
			this.collapsibleSplitter2.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter2.ControlToHide = this.panel1;
			this.collapsibleSplitter2.Dock = System.Windows.Forms.DockStyle.Top;
			this.collapsibleSplitter2.ExpandParentForm = false;
			this.collapsibleSplitter2.Location = new System.Drawing.Point(0, 436);
			this.collapsibleSplitter2.Name = "collapsibleSplitter1";
			this.collapsibleSplitter2.TabIndex = 6;
			this.collapsibleSplitter2.TabStop = false;
			this.collapsibleSplitter2.UseAnimations = false;
			this.collapsibleSplitter2.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView2);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox3.Location = new System.Drawing.Point(0, 0);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(600, 436);
			this.groupBox3.TabIndex = 0;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "상세 정보";
			// 
			// gridView2
			// 
			this.gridView2.AutoSelectRowWithRightButton = false;
			this.gridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle6.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
			this.gridView2.ColumnHeadersHeight = 50;
			this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BAS0851_IDX,
            this.DPST_DT,
            this.DPST_ACTN_AMT,
            this.MEMO2});
			this.gridView2.DelegateProperty = true;
			this.gridView2.Location = new System.Drawing.Point(3, 21);
			this.gridView2.Name = "gridView2";
			this.gridView2.ReadOnly = true;
			this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView2.Size = new System.Drawing.Size(594, 412);
			this.gridView2.TabIndex = 3;
			// 
			// BAS0851_IDX
			// 
			this.BAS0851_IDX.DataPropertyName = "BAS0851_IDX";
			this.BAS0851_IDX.Frozen = true;
			this.BAS0851_IDX.HeaderText = "일련번호";
			this.BAS0851_IDX.Name = "BAS0851_IDX";
			this.BAS0851_IDX.ReadOnly = true;
			this.BAS0851_IDX.Width = 94;
			// 
			// DPST_DT
			// 
			this.DPST_DT.DataPropertyName = "DPST_DT";
			this.DPST_DT.HeaderText = "실행일자";
			this.DPST_DT.Name = "DPST_DT";
			this.DPST_DT.ReadOnly = true;
			this.DPST_DT.Width = 94;
			// 
			// DPST_ACTN_AMT
			// 
			this.DPST_ACTN_AMT.DataPropertyName = "DPST_ACTN_AMT";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			this.DPST_ACTN_AMT.DefaultCellStyle = dataGridViewCellStyle7;
			this.DPST_ACTN_AMT.HeaderText = "실행금액";
			this.DPST_ACTN_AMT.Name = "DPST_ACTN_AMT";
			this.DPST_ACTN_AMT.ReadOnly = true;
			this.DPST_ACTN_AMT.Width = 94;
			// 
			// MEMO2
			// 
			this.MEMO2.DataPropertyName = "MEMO";
			this.MEMO2.HeaderText = "메모";
			this.MEMO2.Name = "MEMO2";
			this.MEMO2.ReadOnly = true;
			this.MEMO2.Width = 66;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1145, 76);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 7;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 260F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel6, 5, 1);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 6, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbDPST_CAL_CD_S, 3, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label40, 4, 1);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label39, 2, 1);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label38, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel5, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbDPST_GIJUN_CD_S, 1, 1);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 2;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 52);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// flowLayoutPanel6
			// 
			this.flowLayoutPanel6.Controls.Add(this._txtDPST_AMT_S_S);
			this.flowLayoutPanel6.Controls.Add(this.label11);
			this.flowLayoutPanel6.Controls.Add(this._txtDPST_AMT_E_S);
			this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel6.Location = new System.Drawing.Point(536, 29);
			this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel6.Name = "flowLayoutPanel6";
			this.flowLayoutPanel6.Size = new System.Drawing.Size(260, 27);
			this.flowLayoutPanel6.TabIndex = 150;
			// 
			// _txtDPST_AMT_S_S
			// 
			this._txtDPST_AMT_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtDPST_AMT_S_S.DelegateProperty = true;
			this._txtDPST_AMT_S_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtDPST_AMT_S_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtDPST_AMT_S_S.Location = new System.Drawing.Point(3, 3);
			this._txtDPST_AMT_S_S.Name = "_txtDPST_AMT_S_S";
			this._txtDPST_AMT_S_S.Size = new System.Drawing.Size(110, 23);
			this._txtDPST_AMT_S_S.TabIndex = 10;
			this._txtDPST_AMT_S_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtDPST_AMT_S_S.ValidationGroup = "A";
			this._txtDPST_AMT_S_S.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtDPST_AMT_S_S.WaterMarkText = "";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(119, 7);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(18, 15);
			this.label11.TabIndex = 1116;
			this.label11.Text = "~";
			// 
			// _txtDPST_AMT_E_S
			// 
			this._txtDPST_AMT_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtDPST_AMT_E_S.DelegateProperty = true;
			this._txtDPST_AMT_E_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtDPST_AMT_E_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtDPST_AMT_E_S.Location = new System.Drawing.Point(143, 3);
			this._txtDPST_AMT_E_S.Name = "_txtDPST_AMT_E_S";
			this._txtDPST_AMT_E_S.Size = new System.Drawing.Size(110, 23);
			this._txtDPST_AMT_E_S.TabIndex = 20;
			this._txtDPST_AMT_E_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtDPST_AMT_E_S.ValidationGroup = "A";
			this._txtDPST_AMT_E_S.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtDPST_AMT_E_S.WaterMarkText = "";
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._btnSearch);
			this.flowLayoutPanel2.Controls.Add(this._btnExcel);
			this.flowLayoutPanel2.Location = new System.Drawing.Point(797, 1);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
			this.flowLayoutPanel2.Size = new System.Drawing.Size(243, 27);
			this.flowLayoutPanel2.TabIndex = 160;
			// 
			// _btnSearch
			// 
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 23);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(75, 2);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 23);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// _cmbDPST_CAL_CD_S
			// 
			this._cmbDPST_CAL_CD_S.DataSource = null;
			this._cmbDPST_CAL_CD_S.DelegateProperty = true;
			this._cmbDPST_CAL_CD_S.DroppedDown = false;
			this._cmbDPST_CAL_CD_S.Location = new System.Drawing.Point(317, 32);
			this._cmbDPST_CAL_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbDPST_CAL_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbDPST_CAL_CD_S.Name = "_cmbDPST_CAL_CD_S";
			this._cmbDPST_CAL_CD_S.SelectedIndex = -1;
			this._cmbDPST_CAL_CD_S.SelectedItem = null;
			this._cmbDPST_CAL_CD_S.SelectedValue = null;
			this._cmbDPST_CAL_CD_S.Size = new System.Drawing.Size(124, 23);
			this._cmbDPST_CAL_CD_S.TabIndex = 140;
			this._cmbDPST_CAL_CD_S.ValidationGroup = null;
			// 
			// _txtSTR_CD_S
			// 
			this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD_S.AutoTab = false;
			this._txtSTR_CD_S.DelegateProperty = true;
			this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_CD_S.Location = new System.Drawing.Point(317, 4);
			this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
			this._txtSTR_CD_S.Size = new System.Drawing.Size(124, 23);
			this._txtSTR_CD_S.TabIndex = 110;
			this._txtSTR_CD_S.ValidationGroup = null;
			this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_CD_S.WaterMarkText = "";
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 4);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(124, 23);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label40
			// 
			this.label40.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label40.AutoSize = true;
			this.label40.Location = new System.Drawing.Point(450, 29);
			this.label40.Name = "label40";
			this.label40.Size = new System.Drawing.Size(82, 27);
			this.label40.TabIndex = 1119;
			this.label40.Text = "보증한도금액";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(21, 7);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(67, 15);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// label39
			// 
			this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label39.AutoSize = true;
			this.label39.Location = new System.Drawing.Point(243, 35);
			this.label39.Name = "label39";
			this.label39.Size = new System.Drawing.Size(67, 15);
			this.label39.TabIndex = 1118;
			this.label39.Text = "계산방법";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(228, 7);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(82, 15);
			this.label36.TabIndex = 1115;
			this.label36.Text = "가맹점코드";
			// 
			// label38
			// 
			this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label38.AutoSize = true;
			this.label38.Location = new System.Drawing.Point(21, 35);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(67, 15);
			this.label38.TabIndex = 1117;
			this.label38.Text = "차감기준";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(450, 7);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(82, 15);
			this.label37.TabIndex = 1116;
			this.label37.Text = "적용시작일";
			// 
			// flowLayoutPanel5
			// 
			this.flowLayoutPanel5.Controls.Add(this._dtpDPST_STRT_DT_S_S);
			this.flowLayoutPanel5.Controls.Add(this.label10);
			this.flowLayoutPanel5.Controls.Add(this._dtpDPST_STRT_DT_E_S);
			this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel5.Location = new System.Drawing.Point(536, 1);
			this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel5.Name = "flowLayoutPanel5";
			this.flowLayoutPanel5.Size = new System.Drawing.Size(260, 27);
			this.flowLayoutPanel5.TabIndex = 120;
			// 
			// _dtpDPST_STRT_DT_S_S
			// 
			this._dtpDPST_STRT_DT_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpDPST_STRT_DT_S_S.Checked = false;
			this._dtpDPST_STRT_DT_S_S.CustomFormat = "yyyy-MM-dd";
			this._dtpDPST_STRT_DT_S_S.DelegateProperty = true;
			this._dtpDPST_STRT_DT_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpDPST_STRT_DT_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpDPST_STRT_DT_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpDPST_STRT_DT_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpDPST_STRT_DT_S_S.Name = "_dtpDPST_STRT_DT_S_S";
			this._dtpDPST_STRT_DT_S_S.ShowCheckBox = true;
			this._dtpDPST_STRT_DT_S_S.Size = new System.Drawing.Size(110, 21);
			this._dtpDPST_STRT_DT_S_S.TabIndex = 10;
			this._dtpDPST_STRT_DT_S_S.ValidationGroup = "A";
			this._dtpDPST_STRT_DT_S_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(119, 6);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(18, 15);
			this.label10.TabIndex = 1115;
			this.label10.Text = "~";
			// 
			// _dtpDPST_STRT_DT_E_S
			// 
			this._dtpDPST_STRT_DT_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpDPST_STRT_DT_E_S.Checked = false;
			this._dtpDPST_STRT_DT_E_S.CustomFormat = "yyyy-MM-dd";
			this._dtpDPST_STRT_DT_E_S.DelegateProperty = true;
			this._dtpDPST_STRT_DT_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpDPST_STRT_DT_E_S.Location = new System.Drawing.Point(143, 3);
			this._dtpDPST_STRT_DT_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpDPST_STRT_DT_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpDPST_STRT_DT_E_S.Name = "_dtpDPST_STRT_DT_E_S";
			this._dtpDPST_STRT_DT_E_S.ShowCheckBox = true;
			this._dtpDPST_STRT_DT_E_S.Size = new System.Drawing.Size(110, 21);
			this._dtpDPST_STRT_DT_E_S.TabIndex = 20;
			this._dtpDPST_STRT_DT_E_S.ValidationGroup = "A";
			this._dtpDPST_STRT_DT_E_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
			// 
			// _cmbDPST_GIJUN_CD_S
			// 
			this._cmbDPST_GIJUN_CD_S.DataSource = null;
			this._cmbDPST_GIJUN_CD_S.DelegateProperty = true;
			this._cmbDPST_GIJUN_CD_S.DroppedDown = false;
			this._cmbDPST_GIJUN_CD_S.Location = new System.Drawing.Point(95, 32);
			this._cmbDPST_GIJUN_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbDPST_GIJUN_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbDPST_GIJUN_CD_S.Name = "_cmbDPST_GIJUN_CD_S";
			this._cmbDPST_GIJUN_CD_S.SelectedIndex = -1;
			this._cmbDPST_GIJUN_CD_S.SelectedItem = null;
			this._cmbDPST_GIJUN_CD_S.SelectedValue = null;
			this._cmbDPST_GIJUN_CD_S.Size = new System.Drawing.Size(124, 23);
			this._cmbDPST_GIJUN_CD_S.TabIndex = 130;
			this._cmbDPST_GIJUN_CD_S.ValidationGroup = null;
			// 
			// WDR0910
			// 
			this.ClientSize = new System.Drawing.Size(1145, 670);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.collapsibleSplitter1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "WDR0910";
			this.Text = "보증예치금적립내역조회:WDR0910";
			this.Load += new System.EventHandler(this.WDR0910_Load);
			this.Shown += new System.EventHandler(this.WDR0910_Shown);
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.panel1.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel6.ResumeLayout(false);
			this.flowLayoutPanel6.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel5.ResumeLayout(false);
			this.flowLayoutPanel5.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
		private BANANA.Windows.Controls.TextBox _txtDPST_AMT_S_S;
		private BANANA.Windows.Controls.Label label11;
		private BANANA.Windows.Controls.TextBox _txtDPST_AMT_E_S;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private DemoClient.Controls.BananaButton _btnSearch;
		private DemoClient.Controls.BananaButton _btnExcel;
		private BANANA.Windows.Controls.ComboBox _cmbDPST_CAL_CD_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
		private BANANA.Windows.Controls.Label label40;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label39;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label38;
		private BANANA.Windows.Controls.Label label37;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
		private BANANA.Windows.Controls.DateTimePicker _dtpDPST_STRT_DT_S_S;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.DateTimePicker _dtpDPST_STRT_DT_E_S;
		private BANANA.Windows.Controls.ComboBox _cmbDPST_GIJUN_CD_S;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.GroupBox groupBox4;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter2;
		private System.Windows.Forms.GroupBox groupBox3;
		private DemoClient.Controls.GridView gridView2;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_STRT_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_USE_YN;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_GIJUN_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_CAL_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_INTST_YN;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_PER;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_LMT_AMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_AMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn BAS0851_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_ACTN_AMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO2;
		private DemoClient.Controls.GridView gridView3;
		private System.Windows.Forms.DataGridViewTextBoxColumn H_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn BAS0852_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn HST_NAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn EXCPT_DT_STRT;
		private System.Windows.Forms.DataGridViewTextBoxColumn EXCPT_DT_END;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME2;
		private System.Windows.Forms.DataGridViewTextBoxColumn HST_TYPE;




    }
}
