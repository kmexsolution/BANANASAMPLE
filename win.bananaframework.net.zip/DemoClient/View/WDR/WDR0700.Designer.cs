﻿namespace DemoClient.View.WDR
{
	partial class WDR0700
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WDR0700));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this._txtUSERMEMO = new BANANA.Windows.Controls.TextBox();
			this._txtUSER_ID = new BANANA.Windows.Controls.TextBox();
			this.label17 = new BANANA.Windows.Controls.Label();
			this._txtAPPRNO = new BANANA.Windows.Controls.TextBox();
			this.label15 = new BANANA.Windows.Controls.Label();
			this._cmbSUCCESSREQENUM = new BANANA.Windows.Controls.ComboBox();
			this._cmbVAN_CD = new BANANA.Windows.Controls.ComboBox();
			this.label14 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this._cmbBUYINGENUM = new BANANA.Windows.Controls.ComboBox();
			this._cmbISSUEDBYENUM = new BANANA.Windows.Controls.ComboBox();
			this._cmbSUCCESSRESENUM = new BANANA.Windows.Controls.ComboBox();
			this.label13 = new BANANA.Windows.Controls.Label();
			this.label11 = new BANANA.Windows.Controls.Label();
			this.label2 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this._cmbCREDITENUM = new BANANA.Windows.Controls.ComboBox();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._txtAPPRAMT1 = new BANANA.Windows.Controls.TextBox();
			this.label5 = new BANANA.Windows.Controls.Label();
			this._txtAPPRAMT2 = new BANANA.Windows.Controls.TextBox();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpTRADEDATE1 = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._dtpTRADEDATE2 = new BANANA.Windows.Controls.DateTimePicker();
			this.label4 = new BANANA.Windows.Controls.Label();
			this.label12 = new BANANA.Windows.Controls.Label();
			this.label16 = new BANANA.Windows.Controls.Label();
			this.label3 = new BANANA.Windows.Controls.Label();
			this._txtAFF_NM = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.groupBox2 = new BANANA.Windows.Controls.GroupBox();
			this._txtSum06 = new BANANA.Windows.Controls.TextBox();
			this._txtSum05 = new BANANA.Windows.Controls.TextBox();
			this.label10 = new BANANA.Windows.Controls.Label();
			this.label9 = new BANANA.Windows.Controls.Label();
			this._txtSum04 = new BANANA.Windows.Controls.TextBox();
			this._txtSum03 = new BANANA.Windows.Controls.TextBox();
			this.label8 = new BANANA.Windows.Controls.Label();
			this.label7 = new BANANA.Windows.Controls.Label();
			this._txtSum02 = new BANANA.Windows.Controls.TextBox();
			this._txtSum01 = new BANANA.Windows.Controls.TextBox();
			this.label6 = new BANANA.Windows.Controls.Label();
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.VAN_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.VAN_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFF_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFF_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USER_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRADEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSREQENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSREQNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSRESENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUCCESSRESNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISOILONLY = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CREDITENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CREDITNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.METHODENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.METHODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CANCELDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.REQUESTDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DUEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.APPRNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISSUEDBYENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISSUEDBYNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUYINGENUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUYINGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CARDNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.APPRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HALBU = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SERVICECHARGE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TAXAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CARDFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.INAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STATUS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DEVICENO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFFNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUSINESSNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFFNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EXECYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USERMEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AFF_BIGO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIGO6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1891, 104);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 9;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 340F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this._txtUSERMEMO, 7, 2);
			this.tableLayoutPanel6.Controls.Add(this._txtUSER_ID, 5, 2);
			this.tableLayoutPanel6.Controls.Add(this.label17, 4, 2);
			this.tableLayoutPanel6.Controls.Add(this._txtAPPRNO, 5, 1);
			this.tableLayoutPanel6.Controls.Add(this.label15, 6, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbSUCCESSREQENUM, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbVAN_CD, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label14, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 8, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbBUYINGENUM, 3, 2);
			this.tableLayoutPanel6.Controls.Add(this._cmbISSUEDBYENUM, 1, 2);
			this.tableLayoutPanel6.Controls.Add(this._cmbSUCCESSRESENUM, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this.label13, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.label11, 0, 2);
			this.tableLayoutPanel6.Controls.Add(this.label2, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbCREDITENUM, 1, 1);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 7, 1);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 7, 0);
			this.tableLayoutPanel6.Controls.Add(this.label4, 6, 1);
			this.tableLayoutPanel6.Controls.Add(this.label12, 2, 2);
			this.tableLayoutPanel6.Controls.Add(this.label16, 6, 2);
			this.tableLayoutPanel6.Controls.Add(this.label3, 4, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtAFF_NM, 3, 1);
			this.tableLayoutPanel6.Controls.Add(this.label35, 2, 1);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 3;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1885, 80);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// _txtUSERMEMO
			// 
			this._txtUSERMEMO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtUSERMEMO.AutoTab = false;
			this._txtUSERMEMO.DelegateProperty = true;
			this._txtUSERMEMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtUSERMEMO.Location = new System.Drawing.Point(761, 60);
			this._txtUSERMEMO.Name = "_txtUSERMEMO";
			this._txtUSERMEMO.Size = new System.Drawing.Size(290, 23);
			this._txtUSERMEMO.TabIndex = 103;
			this._txtUSERMEMO.ValidationGroup = null;
			this._txtUSERMEMO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtUSERMEMO.WaterMarkText = "";
			// 
			// _txtUSER_ID
			// 
			this._txtUSER_ID.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtUSER_ID.AutoTab = false;
			this._txtUSER_ID.DelegateProperty = true;
			this._txtUSER_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtUSER_ID.Location = new System.Drawing.Point(539, 60);
			this._txtUSER_ID.Name = "_txtUSER_ID";
			this._txtUSER_ID.Size = new System.Drawing.Size(120, 23);
			this._txtUSER_ID.TabIndex = 102;
			this._txtUSER_ID.ValidationGroup = null;
			this._txtUSER_ID.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtUSER_ID.WaterMarkText = "";
			// 
			// label17
			// 
			this.label17.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(480, 63);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(52, 15);
			this.label17.TabIndex = 1118;
			this.label17.Text = "아이디";
			// 
			// _txtAPPRNO
			// 
			this._txtAPPRNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRNO.AutoTab = false;
			this._txtAPPRNO.DelegateProperty = true;
			this._txtAPPRNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAPPRNO.Location = new System.Drawing.Point(539, 32);
			this._txtAPPRNO.Name = "_txtAPPRNO";
			this._txtAPPRNO.Size = new System.Drawing.Size(120, 23);
			this._txtAPPRNO.TabIndex = 101;
			this._txtAPPRNO.ValidationGroup = null;
			this._txtAPPRNO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAPPRNO.WaterMarkText = "";
			// 
			// label15
			// 
			this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(687, 7);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(67, 15);
			this.label15.TabIndex = 1122;
			this.label15.Text = "거래일자";
			// 
			// _cmbSUCCESSREQENUM
			// 
			this._cmbSUCCESSREQENUM.DataSource = null;
			this._cmbSUCCESSREQENUM.DelegateProperty = true;
			this._cmbSUCCESSREQENUM.DroppedDown = false;
			this._cmbSUCCESSREQENUM.Location = new System.Drawing.Point(317, 4);
			this._cmbSUCCESSREQENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbSUCCESSREQENUM.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbSUCCESSREQENUM.Name = "_cmbSUCCESSREQENUM";
			this._cmbSUCCESSREQENUM.SelectedIndex = -1;
			this._cmbSUCCESSREQENUM.SelectedItem = null;
			this._cmbSUCCESSREQENUM.SelectedValue = null;
			this._cmbSUCCESSREQENUM.Size = new System.Drawing.Size(120, 23);
			this._cmbSUCCESSREQENUM.TabIndex = 121;
			this._cmbSUCCESSREQENUM.ValidationGroup = null;
			// 
			// _cmbVAN_CD
			// 
			this._cmbVAN_CD.DataSource = null;
			this._cmbVAN_CD.DelegateProperty = true;
			this._cmbVAN_CD.DroppedDown = false;
			this._cmbVAN_CD.Location = new System.Drawing.Point(95, 4);
			this._cmbVAN_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbVAN_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbVAN_CD.Name = "_cmbVAN_CD";
			this._cmbVAN_CD.SelectedIndex = -1;
			this._cmbVAN_CD.SelectedItem = null;
			this._cmbVAN_CD.SelectedValue = null;
			this._cmbVAN_CD.Size = new System.Drawing.Size(120, 23);
			this._cmbVAN_CD.TabIndex = 141;
			this._cmbVAN_CD.ValidationGroup = null;
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(40, 7);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(48, 15);
			this.label14.TabIndex = 1119;
			this.label14.Text = "VAN명";
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._btnSearch);
			this.flowLayoutPanel4.Controls.Add(this._btnExcel);
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(1099, 1);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
			this.flowLayoutPanel4.Size = new System.Drawing.Size(785, 27);
			this.flowLayoutPanel4.TabIndex = 220;
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 23);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(75, 2);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 23);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// _cmbBUYINGENUM
			// 
			this._cmbBUYINGENUM.DataSource = null;
			this._cmbBUYINGENUM.DelegateProperty = true;
			this._cmbBUYINGENUM.DroppedDown = false;
			this._cmbBUYINGENUM.Location = new System.Drawing.Point(317, 60);
			this._cmbBUYINGENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbBUYINGENUM.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbBUYINGENUM.Name = "_cmbBUYINGENUM";
			this._cmbBUYINGENUM.SelectedIndex = -1;
			this._cmbBUYINGENUM.SelectedItem = null;
			this._cmbBUYINGENUM.SelectedValue = null;
			this._cmbBUYINGENUM.Size = new System.Drawing.Size(120, 23);
			this._cmbBUYINGENUM.TabIndex = 190;
			this._cmbBUYINGENUM.ValidationGroup = null;
			// 
			// _cmbISSUEDBYENUM
			// 
			this._cmbISSUEDBYENUM.DataSource = null;
			this._cmbISSUEDBYENUM.DelegateProperty = true;
			this._cmbISSUEDBYENUM.DroppedDown = false;
			this._cmbISSUEDBYENUM.Location = new System.Drawing.Point(95, 60);
			this._cmbISSUEDBYENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbISSUEDBYENUM.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbISSUEDBYENUM.Name = "_cmbISSUEDBYENUM";
			this._cmbISSUEDBYENUM.SelectedIndex = -1;
			this._cmbISSUEDBYENUM.SelectedItem = null;
			this._cmbISSUEDBYENUM.SelectedValue = null;
			this._cmbISSUEDBYENUM.Size = new System.Drawing.Size(120, 23);
			this._cmbISSUEDBYENUM.TabIndex = 180;
			this._cmbISSUEDBYENUM.ValidationGroup = null;
			// 
			// _cmbSUCCESSRESENUM
			// 
			this._cmbSUCCESSRESENUM.DataSource = null;
			this._cmbSUCCESSRESENUM.DelegateProperty = true;
			this._cmbSUCCESSRESENUM.DroppedDown = false;
			this._cmbSUCCESSRESENUM.Location = new System.Drawing.Point(539, 4);
			this._cmbSUCCESSRESENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbSUCCESSRESENUM.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbSUCCESSRESENUM.Name = "_cmbSUCCESSRESENUM";
			this._cmbSUCCESSRESENUM.SelectedIndex = -1;
			this._cmbSUCCESSRESENUM.SelectedItem = null;
			this._cmbSUCCESSRESENUM.SelectedValue = null;
			this._cmbSUCCESSRESENUM.Size = new System.Drawing.Size(120, 23);
			this._cmbSUCCESSRESENUM.TabIndex = 120;
			this._cmbSUCCESSRESENUM.ValidationGroup = null;
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(450, 1);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(82, 27);
			this.label13.TabIndex = 1121;
			this.label13.Text = "승인결과상태";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(6, 63);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(82, 15);
			this.label11.TabIndex = 1119;
			this.label11.Text = "발급사구분";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(21, 35);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 15);
			this.label2.TabIndex = 1115;
			this.label2.Text = "카드구분";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(228, 1);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(82, 27);
			this.label36.TabIndex = 1115;
			this.label36.Text = "승인요청상태";
			// 
			// _cmbCREDITENUM
			// 
			this._cmbCREDITENUM.DataSource = null;
			this._cmbCREDITENUM.DelegateProperty = true;
			this._cmbCREDITENUM.DroppedDown = false;
			this._cmbCREDITENUM.Location = new System.Drawing.Point(95, 32);
			this._cmbCREDITENUM.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCREDITENUM.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCREDITENUM.Name = "_cmbCREDITENUM";
			this._cmbCREDITENUM.SelectedIndex = -1;
			this._cmbCREDITENUM.SelectedItem = null;
			this._cmbCREDITENUM.SelectedValue = null;
			this._cmbCREDITENUM.Size = new System.Drawing.Size(120, 23);
			this._cmbCREDITENUM.TabIndex = 140;
			this._cmbCREDITENUM.ValidationGroup = null;
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._txtAPPRAMT1);
			this.flowLayoutPanel2.Controls.Add(this.label5);
			this.flowLayoutPanel2.Controls.Add(this._txtAPPRAMT2);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(758, 29);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(340, 27);
			this.flowLayoutPanel2.TabIndex = 170;
			// 
			// _txtAPPRAMT1
			// 
			this._txtAPPRAMT1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRAMT1.AutoTab = false;
			this._txtAPPRAMT1.DelegateProperty = true;
			this._txtAPPRAMT1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAPPRAMT1.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtAPPRAMT1.Location = new System.Drawing.Point(3, 3);
			this._txtAPPRAMT1.Name = "_txtAPPRAMT1";
			this._txtAPPRAMT1.Size = new System.Drawing.Size(130, 23);
			this._txtAPPRAMT1.TabIndex = 10;
			this._txtAPPRAMT1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtAPPRAMT1.ValidationGroup = null;
			this._txtAPPRAMT1.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAPPRAMT1.WaterMarkText = "";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(139, 7);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(18, 15);
			this.label5.TabIndex = 102;
			this.label5.Text = "~";
			// 
			// _txtAPPRAMT2
			// 
			this._txtAPPRAMT2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRAMT2.AutoTab = false;
			this._txtAPPRAMT2.DelegateProperty = true;
			this._txtAPPRAMT2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAPPRAMT2.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtAPPRAMT2.Location = new System.Drawing.Point(163, 3);
			this._txtAPPRAMT2.Name = "_txtAPPRAMT2";
			this._txtAPPRAMT2.Size = new System.Drawing.Size(130, 23);
			this._txtAPPRAMT2.TabIndex = 20;
			this._txtAPPRAMT2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtAPPRAMT2.ValidationGroup = null;
			this._txtAPPRAMT2.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAPPRAMT2.WaterMarkText = "";
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE1);
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE2);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(758, 1);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(340, 27);
			this.flowLayoutPanel1.TabIndex = 130;
			// 
			// _dtpTRADEDATE1
			// 
			this._dtpTRADEDATE1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE1.Checked = false;
			this._dtpTRADEDATE1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpTRADEDATE1.DelegateProperty = true;
			this._dtpTRADEDATE1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE1.Location = new System.Drawing.Point(3, 3);
			this._dtpTRADEDATE1.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE1.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE1.Name = "_dtpTRADEDATE1";
			this._dtpTRADEDATE1.Size = new System.Drawing.Size(130, 21);
			this._dtpTRADEDATE1.TabIndex = 10;
			this._dtpTRADEDATE1.ValidationGroup = null;
			this._dtpTRADEDATE1.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(139, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(18, 15);
			this.label1.TabIndex = 1;
			this.label1.Text = "~";
			// 
			// _dtpTRADEDATE2
			// 
			this._dtpTRADEDATE2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE2.Checked = false;
			this._dtpTRADEDATE2.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpTRADEDATE2.DelegateProperty = true;
			this._dtpTRADEDATE2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE2.Location = new System.Drawing.Point(163, 3);
			this._dtpTRADEDATE2.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE2.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE2.Name = "_dtpTRADEDATE2";
			this._dtpTRADEDATE2.Size = new System.Drawing.Size(130, 21);
			this._dtpTRADEDATE2.TabIndex = 20;
			this._dtpTRADEDATE2.ValidationGroup = null;
			this._dtpTRADEDATE2.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(687, 35);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(67, 15);
			this.label4.TabIndex = 1118;
			this.label4.Text = "승인금액";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(228, 63);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(82, 15);
			this.label12.TabIndex = 1120;
			this.label12.Text = "매입사구분";
			// 
			// label16
			// 
			this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(717, 63);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(37, 15);
			this.label16.TabIndex = 1124;
			this.label16.Text = "메모";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(465, 35);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(67, 15);
			this.label3.TabIndex = 1117;
			this.label3.Text = "승인번호";
			// 
			// _txtAFF_NM
			// 
			this._txtAFF_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAFF_NM.AutoTab = false;
			this._txtAFF_NM.DelegateProperty = true;
			this._txtAFF_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAFF_NM.Location = new System.Drawing.Point(317, 32);
			this._txtAFF_NM.Name = "_txtAFF_NM";
			this._txtAFF_NM.Size = new System.Drawing.Size(120, 23);
			this._txtAFF_NM.TabIndex = 100;
			this._txtAFF_NM.ValidationGroup = null;
			this._txtAFF_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAFF_NM.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(243, 35);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(67, 15);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this._txtSum06);
			this.groupBox2.Controls.Add(this._txtSum05);
			this.groupBox2.Controls.Add(this.label10);
			this.groupBox2.Controls.Add(this.label9);
			this.groupBox2.Controls.Add(this._txtSum04);
			this.groupBox2.Controls.Add(this._txtSum03);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this._txtSum02);
			this.groupBox2.Controls.Add(this._txtSum01);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox2.Location = new System.Drawing.Point(0, 792);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1891, 50);
			this.groupBox2.TabIndex = 4;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "합산 정보";
			// 
			// _txtSum06
			// 
			this._txtSum06.DelegateProperty = true;
			this._txtSum06.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum06.Location = new System.Drawing.Point(602, 17);
			this._txtSum06.Name = "_txtSum06";
			this._txtSum06.ReadOnly = true;
			this._txtSum06.Size = new System.Drawing.Size(67, 23);
			this._txtSum06.TabIndex = 10;
			this._txtSum06.TabStop = false;
			this._txtSum06.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum06.ValidationGroup = null;
			this._txtSum06.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSum06.WaterMarkText = "";
			// 
			// _txtSum05
			// 
			this._txtSum05.DelegateProperty = true;
			this._txtSum05.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum05.Location = new System.Drawing.Point(501, 17);
			this._txtSum05.Name = "_txtSum05";
			this._txtSum05.ReadOnly = true;
			this._txtSum05.Size = new System.Drawing.Size(100, 23);
			this._txtSum05.TabIndex = 9;
			this._txtSum05.TabStop = false;
			this._txtSum05.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum05.ValidationGroup = null;
			this._txtSum05.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSum05.WaterMarkText = "";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(466, 20);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(37, 15);
			this.label10.TabIndex = 8;
			this.label10.Text = "합계";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(447, 20);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(15, 15);
			this.label9.TabIndex = 7;
			this.label9.Text = "=";
			// 
			// _txtSum04
			// 
			this._txtSum04.DelegateProperty = true;
			this._txtSum04.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum04.Location = new System.Drawing.Point(374, 17);
			this._txtSum04.Name = "_txtSum04";
			this._txtSum04.ReadOnly = true;
			this._txtSum04.Size = new System.Drawing.Size(67, 23);
			this._txtSum04.TabIndex = 6;
			this._txtSum04.TabStop = false;
			this._txtSum04.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum04.ValidationGroup = null;
			this._txtSum04.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSum04.WaterMarkText = "";
			// 
			// _txtSum03
			// 
			this._txtSum03.DelegateProperty = true;
			this._txtSum03.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum03.Location = new System.Drawing.Point(273, 17);
			this._txtSum03.Name = "_txtSum03";
			this._txtSum03.ReadOnly = true;
			this._txtSum03.Size = new System.Drawing.Size(100, 23);
			this._txtSum03.TabIndex = 5;
			this._txtSum03.TabStop = false;
			this._txtSum03.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum03.ValidationGroup = null;
			this._txtSum03.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSum03.WaterMarkText = "";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(238, 20);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(37, 15);
			this.label8.TabIndex = 4;
			this.label8.Text = "취소";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(222, 20);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(15, 15);
			this.label7.TabIndex = 3;
			this.label7.Text = "-";
			// 
			// _txtSum02
			// 
			this._txtSum02.DelegateProperty = true;
			this._txtSum02.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum02.Location = new System.Drawing.Point(149, 17);
			this._txtSum02.Name = "_txtSum02";
			this._txtSum02.ReadOnly = true;
			this._txtSum02.Size = new System.Drawing.Size(67, 23);
			this._txtSum02.TabIndex = 2;
			this._txtSum02.TabStop = false;
			this._txtSum02.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum02.ValidationGroup = null;
			this._txtSum02.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSum02.WaterMarkText = "";
			// 
			// _txtSum01
			// 
			this._txtSum01.DelegateProperty = true;
			this._txtSum01.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSum01.Location = new System.Drawing.Point(48, 17);
			this._txtSum01.Name = "_txtSum01";
			this._txtSum01.ReadOnly = true;
			this._txtSum01.Size = new System.Drawing.Size(100, 23);
			this._txtSum01.TabIndex = 1;
			this._txtSum01.TabStop = false;
			this._txtSum01.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSum01.ValidationGroup = null;
			this._txtSum01.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSum01.WaterMarkText = "";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(13, 20);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(37, 15);
			this.label6.TabIndex = 0;
			this.label6.Text = "승인";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(0, 104);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(1891, 688);
			this.groupBox3.TabIndex = 5;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX,
            this.VAN_CD,
            this.VAN_NM,
            this.AFF_CD,
            this.AFF_NM,
            this.USER_ID,
            this.TRADEDATE,
            this.SUCCESSREQENUM,
            this.SUCCESSREQNAME,
            this.SUCCESSRESENUM,
            this.SUCCESSRESNAME,
            this.ISOILONLY,
            this.CREDITENUM,
            this.CREDITNAME,
            this.METHODENUM,
            this.METHODNAME,
            this.CANCELDATE,
            this.REQUESTDATE,
            this.DUEDATE,
            this.APPRNO,
            this.ISSUEDBYENUM,
            this.ISSUEDBYNAME,
            this.BUYINGENUM,
            this.BUYINGNAME,
            this.CARDNO,
            this.APPRAMT,
            this.HALBU,
            this.SERVICECHARGE,
            this.TAXAMT,
            this.CARDFEE,
            this.INAMT,
            this.STATUS,
            this.DEVICENO,
            this.AFFNO,
            this.BUSINESSNO,
            this.AFFNAME,
            this.EXECYN,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME,
            this.USERMEMO,
            this.AFF_BIGO,
            this.BIGO1,
            this.BIGO2,
            this.BIGO3,
            this.BIGO4,
            this.BIGO5,
            this.BIGO6});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 21);
			this.gridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(1885, 664);
			this.gridView1.TabIndex = 3;
			this.gridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView1_DataBindingComplete);
			// 
			// IDX
			// 
			this.IDX.DataPropertyName = "IDX";
			this.IDX.Frozen = true;
			this.IDX.HeaderText = "일련번호";
			this.IDX.Name = "IDX";
			this.IDX.ReadOnly = true;
			this.IDX.Visible = false;
			this.IDX.Width = 94;
			// 
			// VAN_CD
			// 
			this.VAN_CD.DataPropertyName = "VAN_CD";
			this.VAN_CD.Frozen = true;
			this.VAN_CD.HeaderText = "VAN코드";
			this.VAN_CD.Name = "VAN_CD";
			this.VAN_CD.ReadOnly = true;
			this.VAN_CD.Visible = false;
			this.VAN_CD.Width = 96;
			// 
			// VAN_NM
			// 
			this.VAN_NM.DataPropertyName = "VAN_NM";
			this.VAN_NM.Frozen = true;
			this.VAN_NM.HeaderText = "VAN명";
			this.VAN_NM.Name = "VAN_NM";
			this.VAN_NM.ReadOnly = true;
			this.VAN_NM.Width = 82;
			// 
			// AFF_CD
			// 
			this.AFF_CD.DataPropertyName = "AFF_CD";
			this.AFF_CD.Frozen = true;
			this.AFF_CD.HeaderText = "가맹점코드";
			this.AFF_CD.Name = "AFF_CD";
			this.AFF_CD.ReadOnly = true;
			this.AFF_CD.Visible = false;
			this.AFF_CD.Width = 108;
			// 
			// AFF_NM
			// 
			this.AFF_NM.DataPropertyName = "AFF_NM";
			this.AFF_NM.Frozen = true;
			this.AFF_NM.HeaderText = "가맹점명";
			this.AFF_NM.Name = "AFF_NM";
			this.AFF_NM.ReadOnly = true;
			this.AFF_NM.Width = 94;
			// 
			// USER_ID
			// 
			this.USER_ID.DataPropertyName = "USER_ID";
			this.USER_ID.Frozen = true;
			this.USER_ID.HeaderText = "아이디";
			this.USER_ID.Name = "USER_ID";
			this.USER_ID.ReadOnly = true;
			this.USER_ID.Width = 80;
			// 
			// TRADEDATE
			// 
			this.TRADEDATE.DataPropertyName = "TRADEDATE";
			dataGridViewCellStyle2.Format = "G";
			dataGridViewCellStyle2.NullValue = null;
			this.TRADEDATE.DefaultCellStyle = dataGridViewCellStyle2;
			this.TRADEDATE.Frozen = true;
			this.TRADEDATE.HeaderText = "거래일자";
			this.TRADEDATE.Name = "TRADEDATE";
			this.TRADEDATE.ReadOnly = true;
			this.TRADEDATE.Width = 94;
			// 
			// SUCCESSREQENUM
			// 
			this.SUCCESSREQENUM.DataPropertyName = "SUCCESSREQENUM";
			this.SUCCESSREQENUM.Frozen = true;
			this.SUCCESSREQENUM.HeaderText = "승인요청상태";
			this.SUCCESSREQENUM.Name = "SUCCESSREQENUM";
			this.SUCCESSREQENUM.ReadOnly = true;
			this.SUCCESSREQENUM.Width = 122;
			// 
			// SUCCESSREQNAME
			// 
			this.SUCCESSREQNAME.DataPropertyName = "SUCCESSREQNAME";
			this.SUCCESSREQNAME.HeaderText = "승인요청상태(원)";
			this.SUCCESSREQNAME.Name = "SUCCESSREQNAME";
			this.SUCCESSREQNAME.ReadOnly = true;
			this.SUCCESSREQNAME.ToolTipText = "승인요청상태가 애매할 경우를 대비해서 원 데이터를 저장";
			this.SUCCESSREQNAME.Width = 146;
			// 
			// SUCCESSRESENUM
			// 
			this.SUCCESSRESENUM.DataPropertyName = "SUCCESSRESENUM";
			this.SUCCESSRESENUM.HeaderText = "승인결과상태";
			this.SUCCESSRESENUM.Name = "SUCCESSRESENUM";
			this.SUCCESSRESENUM.ReadOnly = true;
			this.SUCCESSRESENUM.Width = 122;
			// 
			// SUCCESSRESNAME
			// 
			this.SUCCESSRESNAME.DataPropertyName = "SUCCESSRESNAME";
			this.SUCCESSRESNAME.HeaderText = "승인결과상태(원)";
			this.SUCCESSRESNAME.Name = "SUCCESSRESNAME";
			this.SUCCESSRESNAME.ReadOnly = true;
			this.SUCCESSRESNAME.Width = 146;
			// 
			// ISOILONLY
			// 
			this.ISOILONLY.DataPropertyName = "ISOILONLY";
			this.ISOILONLY.HeaderText = "유류카드 여부";
			this.ISOILONLY.Name = "ISOILONLY";
			this.ISOILONLY.ReadOnly = true;
			this.ISOILONLY.Width = 127;
			// 
			// CREDITENUM
			// 
			this.CREDITENUM.DataPropertyName = "CREDITENUM";
			this.CREDITENUM.HeaderText = "카드종류";
			this.CREDITENUM.Name = "CREDITENUM";
			this.CREDITENUM.ReadOnly = true;
			this.CREDITENUM.Width = 94;
			// 
			// CREDITNAME
			// 
			this.CREDITNAME.DataPropertyName = "CREDITNAME";
			this.CREDITNAME.HeaderText = "카드종류(원)";
			this.CREDITNAME.Name = "CREDITNAME";
			this.CREDITNAME.ReadOnly = true;
			this.CREDITNAME.ToolTipText = "카드종류가 애매할 경우를 대비해서 원 데이터를 저장";
			this.CREDITNAME.Width = 118;
			// 
			// METHODENUM
			// 
			this.METHODENUM.DataPropertyName = "METHODENUM";
			this.METHODENUM.HeaderText = "승인방법";
			this.METHODENUM.Name = "METHODENUM";
			this.METHODENUM.ReadOnly = true;
			this.METHODENUM.Width = 94;
			// 
			// METHODNAME
			// 
			this.METHODNAME.DataPropertyName = "METHODNAME";
			this.METHODNAME.HeaderText = "승인방법(원)";
			this.METHODNAME.Name = "METHODNAME";
			this.METHODNAME.ReadOnly = true;
			this.METHODNAME.ToolTipText = "승인방법이 애매할 경우를 대비해서 원 데이터를 저장";
			this.METHODNAME.Width = 118;
			// 
			// CANCELDATE
			// 
			this.CANCELDATE.DataPropertyName = "CANCELDATE";
			dataGridViewCellStyle3.Format = "G";
			dataGridViewCellStyle3.NullValue = null;
			this.CANCELDATE.DefaultCellStyle = dataGridViewCellStyle3;
			this.CANCELDATE.HeaderText = "승인취소일/원거래일";
			this.CANCELDATE.Name = "CANCELDATE";
			this.CANCELDATE.ReadOnly = true;
			this.CANCELDATE.Width = 170;
			// 
			// REQUESTDATE
			// 
			this.REQUESTDATE.DataPropertyName = "REQUESTDATE";
			this.REQUESTDATE.HeaderText = "청구일자";
			this.REQUESTDATE.Name = "REQUESTDATE";
			this.REQUESTDATE.ReadOnly = true;
			this.REQUESTDATE.Width = 94;
			// 
			// DUEDATE
			// 
			this.DUEDATE.DataPropertyName = "DUEDATE";
			dataGridViewCellStyle4.Format = "G";
			this.DUEDATE.DefaultCellStyle = dataGridViewCellStyle4;
			this.DUEDATE.HeaderText = "입금예정일/입금일";
			this.DUEDATE.Name = "DUEDATE";
			this.DUEDATE.ReadOnly = true;
			this.DUEDATE.Width = 156;
			// 
			// APPRNO
			// 
			this.APPRNO.DataPropertyName = "APPRNO";
			this.APPRNO.HeaderText = "승인번호";
			this.APPRNO.Name = "APPRNO";
			this.APPRNO.ReadOnly = true;
			this.APPRNO.Width = 94;
			// 
			// ISSUEDBYENUM
			// 
			this.ISSUEDBYENUM.DataPropertyName = "ISSUEDBYENUM";
			this.ISSUEDBYENUM.HeaderText = "발급사";
			this.ISSUEDBYENUM.Name = "ISSUEDBYENUM";
			this.ISSUEDBYENUM.ReadOnly = true;
			this.ISSUEDBYENUM.Width = 80;
			// 
			// ISSUEDBYNAME
			// 
			this.ISSUEDBYNAME.DataPropertyName = "ISSUEDBYNAME";
			this.ISSUEDBYNAME.HeaderText = "발급사(원)";
			this.ISSUEDBYNAME.Name = "ISSUEDBYNAME";
			this.ISSUEDBYNAME.ReadOnly = true;
			this.ISSUEDBYNAME.ToolTipText = "발급사가 애매할 경우를 대비해서 원 데이터를 저장";
			this.ISSUEDBYNAME.Width = 104;
			// 
			// BUYINGENUM
			// 
			this.BUYINGENUM.DataPropertyName = "BUYINGENUM";
			this.BUYINGENUM.HeaderText = "매입사";
			this.BUYINGENUM.Name = "BUYINGENUM";
			this.BUYINGENUM.ReadOnly = true;
			this.BUYINGENUM.Width = 80;
			// 
			// BUYINGNAME
			// 
			this.BUYINGNAME.DataPropertyName = "BUYINGNAME";
			this.BUYINGNAME.HeaderText = "매입사(원)";
			this.BUYINGNAME.Name = "BUYINGNAME";
			this.BUYINGNAME.ReadOnly = true;
			this.BUYINGNAME.ToolTipText = "매입사가 애매할 경우를 대비해서 원 데이터를 저장";
			this.BUYINGNAME.Width = 104;
			// 
			// CARDNO
			// 
			this.CARDNO.DataPropertyName = "CARDNO";
			this.CARDNO.HeaderText = "카드번호";
			this.CARDNO.Name = "CARDNO";
			this.CARDNO.ReadOnly = true;
			this.CARDNO.Width = 94;
			// 
			// APPRAMT
			// 
			this.APPRAMT.DataPropertyName = "APPRAMT";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			dataGridViewCellStyle5.NullValue = "0";
			this.APPRAMT.DefaultCellStyle = dataGridViewCellStyle5;
			this.APPRAMT.HeaderText = "승인금액①";
			this.APPRAMT.Name = "APPRAMT";
			this.APPRAMT.ReadOnly = true;
			this.APPRAMT.Width = 108;
			// 
			// HALBU
			// 
			this.HALBU.DataPropertyName = "HALBU";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			dataGridViewCellStyle6.NullValue = "0";
			this.HALBU.DefaultCellStyle = dataGridViewCellStyle6;
			this.HALBU.HeaderText = "할부";
			this.HALBU.Name = "HALBU";
			this.HALBU.ReadOnly = true;
			this.HALBU.Width = 66;
			// 
			// SERVICECHARGE
			// 
			this.SERVICECHARGE.DataPropertyName = "SERVICECHARGE";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			dataGridViewCellStyle7.NullValue = "0";
			this.SERVICECHARGE.DefaultCellStyle = dataGridViewCellStyle7;
			this.SERVICECHARGE.HeaderText = "봉사료";
			this.SERVICECHARGE.Name = "SERVICECHARGE";
			this.SERVICECHARGE.ReadOnly = true;
			this.SERVICECHARGE.Width = 80;
			// 
			// TAXAMT
			// 
			this.TAXAMT.DataPropertyName = "TAXAMT";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			dataGridViewCellStyle8.NullValue = "0";
			this.TAXAMT.DefaultCellStyle = dataGridViewCellStyle8;
			this.TAXAMT.HeaderText = "부가세";
			this.TAXAMT.Name = "TAXAMT";
			this.TAXAMT.ReadOnly = true;
			this.TAXAMT.Width = 80;
			// 
			// CARDFEE
			// 
			this.CARDFEE.DataPropertyName = "CARDFEE";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N1";
			dataGridViewCellStyle9.NullValue = "0";
			this.CARDFEE.DefaultCellStyle = dataGridViewCellStyle9;
			this.CARDFEE.HeaderText = "매입카드수수료②";
			this.CARDFEE.Name = "CARDFEE";
			this.CARDFEE.ReadOnly = true;
			this.CARDFEE.Width = 150;
			// 
			// INAMT
			// 
			this.INAMT.DataPropertyName = "INAMT";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N1";
			dataGridViewCellStyle10.NullValue = "0";
			this.INAMT.DefaultCellStyle = dataGridViewCellStyle10;
			this.INAMT.HeaderText = "입금예정금액(① - ②)";
			this.INAMT.Name = "INAMT";
			this.INAMT.ReadOnly = true;
			this.INAMT.ToolTipText = "입금예정금액 = 승인금액① - 매입카드수수료②";
			this.INAMT.Width = 176;
			// 
			// STATUS
			// 
			this.STATUS.DataPropertyName = "STATUS";
			this.STATUS.HeaderText = "처리상태";
			this.STATUS.Name = "STATUS";
			this.STATUS.ReadOnly = true;
			this.STATUS.Width = 94;
			// 
			// DEVICENO
			// 
			this.DEVICENO.DataPropertyName = "DEVICENO";
			this.DEVICENO.HeaderText = "단말기번호";
			this.DEVICENO.Name = "DEVICENO";
			this.DEVICENO.ReadOnly = true;
			this.DEVICENO.Width = 108;
			// 
			// AFFNO
			// 
			this.AFFNO.DataPropertyName = "AFFNO";
			this.AFFNO.HeaderText = "가맹점번호";
			this.AFFNO.Name = "AFFNO";
			this.AFFNO.ReadOnly = true;
			this.AFFNO.ToolTipText = "카드사의 가맹점번호입니다.";
			this.AFFNO.Width = 108;
			// 
			// BUSINESSNO
			// 
			this.BUSINESSNO.DataPropertyName = "BUSINESSNO";
			this.BUSINESSNO.HeaderText = "사업자등록번호";
			this.BUSINESSNO.Name = "BUSINESSNO";
			this.BUSINESSNO.ReadOnly = true;
			this.BUSINESSNO.Width = 136;
			// 
			// AFFNAME
			// 
			this.AFFNAME.DataPropertyName = "AFFNAME";
			this.AFFNAME.HeaderText = "가맹점명";
			this.AFFNAME.Name = "AFFNAME";
			this.AFFNAME.ReadOnly = true;
			this.AFFNAME.ToolTipText = "카드사의 가맹점명입니다.";
			this.AFFNAME.Width = 94;
			// 
			// EXECYN
			// 
			this.EXECYN.DataPropertyName = "EXECYN";
			this.EXECYN.HeaderText = "출금원장등록여부";
			this.EXECYN.Name = "EXECYN";
			this.EXECYN.ReadOnly = true;
			this.EXECYN.Width = 150;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			dataGridViewCellStyle11.Format = "G";
			this.SYSREGDATE.DefaultCellStyle = dataGridViewCellStyle11;
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 122;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 122;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			dataGridViewCellStyle12.Format = "G";
			this.SYSMODDATE.DefaultCellStyle = dataGridViewCellStyle12;
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 122;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 122;
			// 
			// USERMEMO
			// 
			this.USERMEMO.DataPropertyName = "USERMEMO";
			this.USERMEMO.HeaderText = "메모";
			this.USERMEMO.Name = "USERMEMO";
			this.USERMEMO.ReadOnly = true;
			this.USERMEMO.Width = 66;
			// 
			// AFF_BIGO
			// 
			this.AFF_BIGO.DataPropertyName = "AFF_BIGO";
			this.AFF_BIGO.HeaderText = "가맹점 비고";
			this.AFF_BIGO.Name = "AFF_BIGO";
			this.AFF_BIGO.ReadOnly = true;
			this.AFF_BIGO.Width = 113;
			// 
			// BIGO1
			// 
			this.BIGO1.DataPropertyName = "BIGO1";
			this.BIGO1.HeaderText = "BIGO1";
			this.BIGO1.Name = "BIGO1";
			this.BIGO1.ReadOnly = true;
			this.BIGO1.Width = 80;
			// 
			// BIGO2
			// 
			this.BIGO2.DataPropertyName = "BIGO2";
			this.BIGO2.HeaderText = "BIGO2";
			this.BIGO2.Name = "BIGO2";
			this.BIGO2.ReadOnly = true;
			this.BIGO2.Width = 80;
			// 
			// BIGO3
			// 
			this.BIGO3.DataPropertyName = "BIGO3";
			this.BIGO3.HeaderText = "BIGO3";
			this.BIGO3.Name = "BIGO3";
			this.BIGO3.ReadOnly = true;
			this.BIGO3.Width = 80;
			// 
			// BIGO4
			// 
			this.BIGO4.DataPropertyName = "BIGO4";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle13.Format = "N2";
			dataGridViewCellStyle13.NullValue = "0";
			this.BIGO4.DefaultCellStyle = dataGridViewCellStyle13;
			this.BIGO4.HeaderText = "BIGO4";
			this.BIGO4.Name = "BIGO4";
			this.BIGO4.ReadOnly = true;
			this.BIGO4.Width = 80;
			// 
			// BIGO5
			// 
			this.BIGO5.DataPropertyName = "BIGO5";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle14.Format = "N2";
			dataGridViewCellStyle14.NullValue = "0";
			this.BIGO5.DefaultCellStyle = dataGridViewCellStyle14;
			this.BIGO5.HeaderText = "BIGO5";
			this.BIGO5.Name = "BIGO5";
			this.BIGO5.ReadOnly = true;
			this.BIGO5.Width = 80;
			// 
			// BIGO6
			// 
			this.BIGO6.DataPropertyName = "BIGO6";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle15.Format = "N2";
			dataGridViewCellStyle15.NullValue = "0";
			this.BIGO6.DefaultCellStyle = dataGridViewCellStyle15;
			this.BIGO6.HeaderText = "BIGO6";
			this.BIGO6.Name = "BIGO6";
			this.BIGO6.ReadOnly = true;
			this.BIGO6.Width = 80;
			// 
			// WDR0700
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1891, 842);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.Name = "WDR0700";
			this.Text = "거래원장조회:WDR0700";
			this.Load += new System.EventHandler(this.WDR0100_Load);
			this.Shown += new System.EventHandler(this.WDR0100_Shown);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private DemoClient.Controls.BananaButton _btnSearch;
		private DemoClient.Controls.BananaButton _btnExcel;
		private BANANA.Windows.Controls.ComboBox _cmbBUYINGENUM;
		private BANANA.Windows.Controls.ComboBox _cmbISSUEDBYENUM;
		private BANANA.Windows.Controls.ComboBox _cmbSUCCESSRESENUM;
		private BANANA.Windows.Controls.Label label13;
		private BANANA.Windows.Controls.Label label11;
		private BANANA.Windows.Controls.Label label2;
		private BANANA.Windows.Controls.TextBox _txtAFF_NM;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label3;
		private BANANA.Windows.Controls.ComboBox _cmbCREDITENUM;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private BANANA.Windows.Controls.TextBox _txtAPPRAMT1;
		private BANANA.Windows.Controls.Label label5;
		private BANANA.Windows.Controls.TextBox _txtAPPRAMT2;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE1;
		private BANANA.Windows.Controls.Label label1;
		private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE2;
		private BANANA.Windows.Controls.Label label4;
		private BANANA.Windows.Controls.Label label12;
		private BANANA.Windows.Controls.Label label16;
		private BANANA.Windows.Controls.GroupBox groupBox2;
		private BANANA.Windows.Controls.TextBox _txtSum06;
		private BANANA.Windows.Controls.TextBox _txtSum05;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.Label label9;
		private BANANA.Windows.Controls.TextBox _txtSum04;
		private BANANA.Windows.Controls.TextBox _txtSum03;
		private BANANA.Windows.Controls.Label label8;
		private BANANA.Windows.Controls.Label label7;
		private BANANA.Windows.Controls.TextBox _txtSum02;
		private BANANA.Windows.Controls.TextBox _txtSum01;
		private BANANA.Windows.Controls.Label label6;
		private BANANA.Windows.Controls.GroupBox groupBox3;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn VAN_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn VAN_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFF_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFF_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn USER_ID;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRADEDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSREQENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSREQNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSRESENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUCCESSRESNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISOILONLY;
		private System.Windows.Forms.DataGridViewTextBoxColumn CREDITENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CREDITNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn METHODENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn METHODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn CANCELDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn REQUESTDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn DUEDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn APPRNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISSUEDBYENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISSUEDBYNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUYINGENUM;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUYINGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn CARDNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn APPRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn HALBU;
		private System.Windows.Forms.DataGridViewTextBoxColumn SERVICECHARGE;
		private System.Windows.Forms.DataGridViewTextBoxColumn TAXAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CARDFEE;
		private System.Windows.Forms.DataGridViewTextBoxColumn INAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn STATUS;
		private System.Windows.Forms.DataGridViewTextBoxColumn DEVICENO;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFFNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUSINESSNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFFNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn EXECYN;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn USERMEMO;
		private System.Windows.Forms.DataGridViewTextBoxColumn AFF_BIGO;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO1;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO2;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO3;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO4;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO5;
		private System.Windows.Forms.DataGridViewTextBoxColumn BIGO6;
		private BANANA.Windows.Controls.Label label14;
		private BANANA.Windows.Controls.ComboBox _cmbVAN_CD;
		private BANANA.Windows.Controls.ComboBox _cmbSUCCESSREQENUM;
		private BANANA.Windows.Controls.Label label15;
		private BANANA.Windows.Controls.TextBox _txtAPPRNO;
		private BANANA.Windows.Controls.TextBox _txtUSER_ID;
		private BANANA.Windows.Controls.Label label17;
		private BANANA.Windows.Controls.TextBox _txtUSERMEMO;

	}
}