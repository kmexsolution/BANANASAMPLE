﻿namespace DemoClient.View.WDR
{
    partial class WDR0810
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WDR0810));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this._cmbMNS_GUBUN_CD_S = new BANANA.Windows.Controls.ComboBox();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpMNS_APP_DT_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label10 = new BANANA.Windows.Controls.Label();
			this._dtpMNS_APP_DT_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this._cmbMNS_USE_YN_S = new BANANA.Windows.Controls.ComboBox();
			this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label39 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this.label38 = new BANANA.Windows.Controls.Label();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.gridView3 = new DemoClient.Controls.GridView();
			this.H_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BAS0832_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HST_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EXCPT_DT_STRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EXCPT_DT_END = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MEMO3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HST_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter2 = new DemoClient.Controls.CollapsibleSplitter();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.gridView2 = new DemoClient.Controls.GridView();
			this.BAS0831_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_ACTN_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_PROCESS_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MEMO2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.BAS0830_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_APP_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_GUBUN_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_USE_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band1 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.MNS_AMT_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_REG_CD_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISCOMPLETE_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band2 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.MNS_AMT_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_GIJUN_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_REG_CD_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_CAL_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_INTST_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_PER = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_ACTN_AMT_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ISCOMPLETE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_GUBUN_CODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._cmbMNS_REG_CD_S = new BANANA.Windows.Controls.ComboBox();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1145, 76);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 7;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 260F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this._cmbMNS_REG_CD_S, 5, 1);
			this.tableLayoutPanel6.Controls.Add(this.label1, 4, 1);
			this.tableLayoutPanel6.Controls.Add(this._cmbMNS_GUBUN_CD_S, 1, 1);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbMNS_USE_YN_S, 3, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label39, 2, 1);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label38, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 6, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 2;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 56);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// _cmbMNS_GUBUN_CD_S
			// 
			this._cmbMNS_GUBUN_CD_S.DataSource = null;
			this._cmbMNS_GUBUN_CD_S.DelegateProperty = true;
			this._cmbMNS_GUBUN_CD_S.DroppedDown = false;
			this._cmbMNS_GUBUN_CD_S.Location = new System.Drawing.Point(95, 32);
			this._cmbMNS_GUBUN_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbMNS_GUBUN_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbMNS_GUBUN_CD_S.Name = "_cmbMNS_GUBUN_CD_S";
			this._cmbMNS_GUBUN_CD_S.SelectedIndex = -1;
			this._cmbMNS_GUBUN_CD_S.SelectedItem = null;
			this._cmbMNS_GUBUN_CD_S.SelectedValue = null;
			this._cmbMNS_GUBUN_CD_S.Size = new System.Drawing.Size(124, 21);
			this._cmbMNS_GUBUN_CD_S.TabIndex = 141;
			this._cmbMNS_GUBUN_CD_S.ValidationGroup = null;
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._dtpMNS_APP_DT_S_S);
			this.flowLayoutPanel1.Controls.Add(this.label10);
			this.flowLayoutPanel1.Controls.Add(this._dtpMNS_APP_DT_E_S);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(536, 1);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(260, 27);
			this.flowLayoutPanel1.TabIndex = 163;
			// 
			// _dtpMNS_APP_DT_S_S
			// 
			this._dtpMNS_APP_DT_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpMNS_APP_DT_S_S.Checked = false;
			this._dtpMNS_APP_DT_S_S.CustomFormat = "yyyy-MM-dd";
			this._dtpMNS_APP_DT_S_S.DelegateProperty = true;
			this._dtpMNS_APP_DT_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpMNS_APP_DT_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpMNS_APP_DT_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpMNS_APP_DT_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpMNS_APP_DT_S_S.Name = "_dtpMNS_APP_DT_S_S";
			this._dtpMNS_APP_DT_S_S.Size = new System.Drawing.Size(110, 21);
			this._dtpMNS_APP_DT_S_S.TabIndex = 10;
			this._dtpMNS_APP_DT_S_S.ValidationGroup = "A";
			this._dtpMNS_APP_DT_S_S.Value = new System.DateTime(2016, 8, 25, 0, 0, 0, 0);
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(119, 7);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(14, 12);
			this.label10.TabIndex = 1115;
			this.label10.Text = "~";
			// 
			// _dtpMNS_APP_DT_E_S
			// 
			this._dtpMNS_APP_DT_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpMNS_APP_DT_E_S.Checked = false;
			this._dtpMNS_APP_DT_E_S.CustomFormat = "yyyy-MM-dd";
			this._dtpMNS_APP_DT_E_S.DelegateProperty = true;
			this._dtpMNS_APP_DT_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpMNS_APP_DT_E_S.Location = new System.Drawing.Point(139, 3);
			this._dtpMNS_APP_DT_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpMNS_APP_DT_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpMNS_APP_DT_E_S.Name = "_dtpMNS_APP_DT_E_S";
			this._dtpMNS_APP_DT_E_S.Size = new System.Drawing.Size(110, 21);
			this._dtpMNS_APP_DT_E_S.TabIndex = 20;
			this._dtpMNS_APP_DT_E_S.ValidationGroup = "A";
			this._dtpMNS_APP_DT_E_S.Value = new System.DateTime(2016, 8, 25, 0, 0, 0, 0);
			// 
			// _cmbMNS_USE_YN_S
			// 
			this._cmbMNS_USE_YN_S.DataSource = null;
			this._cmbMNS_USE_YN_S.DelegateProperty = true;
			this._cmbMNS_USE_YN_S.DroppedDown = false;
			this._cmbMNS_USE_YN_S.Location = new System.Drawing.Point(317, 32);
			this._cmbMNS_USE_YN_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbMNS_USE_YN_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbMNS_USE_YN_S.Name = "_cmbMNS_USE_YN_S";
			this._cmbMNS_USE_YN_S.SelectedIndex = -1;
			this._cmbMNS_USE_YN_S.SelectedItem = null;
			this._cmbMNS_USE_YN_S.SelectedValue = null;
			this._cmbMNS_USE_YN_S.Size = new System.Drawing.Size(124, 21);
			this._cmbMNS_USE_YN_S.TabIndex = 140;
			this._cmbMNS_USE_YN_S.ValidationGroup = null;
			// 
			// _txtSTR_CD_S
			// 
			this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD_S.AutoTab = false;
			this._txtSTR_CD_S.DelegateProperty = true;
			this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_CD_S.Location = new System.Drawing.Point(317, 4);
			this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
			this._txtSTR_CD_S.Size = new System.Drawing.Size(124, 20);
			this._txtSTR_CD_S.TabIndex = 110;
			this._txtSTR_CD_S.ValidationGroup = null;
			this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_CD_S.WaterMarkText = "";
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 4);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(124, 20);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(35, 8);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(53, 12);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// label39
			// 
			this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label39.AutoSize = true;
			this.label39.Location = new System.Drawing.Point(257, 36);
			this.label39.Name = "label39";
			this.label39.Size = new System.Drawing.Size(53, 12);
			this.label39.TabIndex = 1118;
			this.label39.Text = "사용여부";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(245, 8);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(65, 12);
			this.label36.TabIndex = 1115;
			this.label36.Text = "가맹점코드";
			// 
			// label38
			// 
			this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label38.AutoSize = true;
			this.label38.Location = new System.Drawing.Point(5, 36);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(83, 12);
			this.label38.TabIndex = 1117;
			this.label38.Text = "출금/차감구분";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(491, 8);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(41, 12);
			this.label37.TabIndex = 1116;
			this.label37.Text = "적용일";
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._btnSearch);
			this.flowLayoutPanel2.Location = new System.Drawing.Point(797, 1);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
			this.flowLayoutPanel2.Size = new System.Drawing.Size(243, 27);
			this.flowLayoutPanel2.TabIndex = 1119;
			// 
			// _btnSearch
			// 
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 23);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.groupBox4);
			this.panel1.Controls.Add(this.collapsibleSplitter2);
			this.panel1.Controls.Add(this.groupBox3);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(545, 76);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(600, 594);
			this.panel1.TabIndex = 4;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.gridView3);
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox4.Location = new System.Drawing.Point(0, 444);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(600, 150);
			this.groupBox4.TabIndex = 7;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "차감 예외기간";
			// 
			// gridView3
			// 
			this.gridView3.AutoSelectRowWithRightButton = false;
			this.gridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.gridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.H_IDX,
            this.BAS0832_IDX,
            this.HST_NAME,
            this.EXCPT_DT_STRT,
            this.EXCPT_DT_END,
            this.MEMO3,
            this.SYSREGDATE3,
            this.SYSREGNAME3,
            this.HST_TYPE});
			this.gridView3.DelegateProperty = true;
			this.gridView3.Location = new System.Drawing.Point(3, 17);
			this.gridView3.Name = "gridView3";
			this.gridView3.ReadOnly = true;
			this.gridView3.RowTemplate.Height = 23;
			this.gridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView3.Size = new System.Drawing.Size(594, 130);
			this.gridView3.TabIndex = 2;
			// 
			// H_IDX
			// 
			this.H_IDX.DataPropertyName = "IDX";
			this.H_IDX.HeaderText = "이력 일련번호";
			this.H_IDX.Name = "H_IDX";
			this.H_IDX.ReadOnly = true;
			this.H_IDX.Width = 106;
			// 
			// BAS0832_IDX
			// 
			this.BAS0832_IDX.DataPropertyName = "BAS0832_IDX";
			this.BAS0832_IDX.HeaderText = "예외기간 일련번호";
			this.BAS0832_IDX.Name = "BAS0832_IDX";
			this.BAS0832_IDX.ReadOnly = true;
			this.BAS0832_IDX.Width = 130;
			// 
			// HST_NAME
			// 
			this.HST_NAME.DataPropertyName = "HST_NAME";
			this.HST_NAME.HeaderText = "이력구분";
			this.HST_NAME.Name = "HST_NAME";
			this.HST_NAME.ReadOnly = true;
			this.HST_NAME.Width = 78;
			// 
			// EXCPT_DT_STRT
			// 
			this.EXCPT_DT_STRT.DataPropertyName = "EXCPT_DT_STRT";
			this.EXCPT_DT_STRT.HeaderText = "예외시작일";
			this.EXCPT_DT_STRT.Name = "EXCPT_DT_STRT";
			this.EXCPT_DT_STRT.ReadOnly = true;
			this.EXCPT_DT_STRT.Width = 90;
			// 
			// EXCPT_DT_END
			// 
			this.EXCPT_DT_END.DataPropertyName = "EXCPT_DT_END";
			this.EXCPT_DT_END.HeaderText = "예외종료일";
			this.EXCPT_DT_END.Name = "EXCPT_DT_END";
			this.EXCPT_DT_END.ReadOnly = true;
			this.EXCPT_DT_END.Width = 90;
			// 
			// MEMO3
			// 
			this.MEMO3.DataPropertyName = "MEMO";
			this.MEMO3.HeaderText = "메모";
			this.MEMO3.Name = "MEMO3";
			this.MEMO3.ReadOnly = true;
			this.MEMO3.Width = 54;
			// 
			// SYSREGDATE3
			// 
			this.SYSREGDATE3.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE3.HeaderText = "시스템등록일";
			this.SYSREGDATE3.Name = "SYSREGDATE3";
			this.SYSREGDATE3.ReadOnly = true;
			this.SYSREGDATE3.Width = 102;
			// 
			// SYSREGNAME3
			// 
			this.SYSREGNAME3.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME3.HeaderText = "시스템등록자";
			this.SYSREGNAME3.Name = "SYSREGNAME3";
			this.SYSREGNAME3.ReadOnly = true;
			this.SYSREGNAME3.Width = 102;
			// 
			// HST_TYPE
			// 
			this.HST_TYPE.DataPropertyName = "HST_TYPE";
			this.HST_TYPE.HeaderText = "HST_TYPE";
			this.HST_TYPE.Name = "HST_TYPE";
			this.HST_TYPE.ReadOnly = true;
			this.HST_TYPE.Visible = false;
			this.HST_TYPE.Width = 107;
			// 
			// collapsibleSplitter2
			// 
			this.collapsibleSplitter2.AnimationDelay = 20;
			this.collapsibleSplitter2.AnimationStep = 20;
			this.collapsibleSplitter2.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter2.ControlToHide = this.panel1;
			this.collapsibleSplitter2.Dock = System.Windows.Forms.DockStyle.Top;
			this.collapsibleSplitter2.ExpandParentForm = false;
			this.collapsibleSplitter2.Location = new System.Drawing.Point(0, 436);
			this.collapsibleSplitter2.Name = "collapsibleSplitter1";
			this.collapsibleSplitter2.TabIndex = 6;
			this.collapsibleSplitter2.TabStop = false;
			this.collapsibleSplitter2.UseAnimations = false;
			this.collapsibleSplitter2.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView2);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox3.Location = new System.Drawing.Point(0, 0);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(600, 436);
			this.groupBox3.TabIndex = 0;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "상세 정보";
			// 
			// gridView2
			// 
			this.gridView2.AutoSelectRowWithRightButton = false;
			this.gridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			this.gridView2.ColumnHeadersHeight = 50;
			this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BAS0831_IDX,
            this.MNS_DT,
            this.MNS_ACTN_AMT,
            this.MNS_PROCESS_CD,
            this.MEMO2,
            this.SYSREGDATE2,
            this.SYSREGNAME2});
			this.gridView2.DelegateProperty = true;
			this.gridView2.Location = new System.Drawing.Point(3, 17);
			this.gridView2.Name = "gridView2";
			this.gridView2.ReadOnly = true;
			this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView2.Size = new System.Drawing.Size(594, 416);
			this.gridView2.TabIndex = 3;
			// 
			// BAS0831_IDX
			// 
			this.BAS0831_IDX.DataPropertyName = "BAS0831_IDX";
			this.BAS0831_IDX.Frozen = true;
			this.BAS0831_IDX.HeaderText = "일련번호";
			this.BAS0831_IDX.Name = "BAS0831_IDX";
			this.BAS0831_IDX.ReadOnly = true;
			this.BAS0831_IDX.Width = 76;
			// 
			// MNS_DT
			// 
			this.MNS_DT.DataPropertyName = "MNS_DT";
			this.MNS_DT.HeaderText = "실행일자";
			this.MNS_DT.Name = "MNS_DT";
			this.MNS_DT.ReadOnly = true;
			this.MNS_DT.Width = 76;
			// 
			// MNS_ACTN_AMT
			// 
			this.MNS_ACTN_AMT.DataPropertyName = "MNS_ACTN_AMT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			this.MNS_ACTN_AMT.DefaultCellStyle = dataGridViewCellStyle3;
			this.MNS_ACTN_AMT.HeaderText = "실행금액";
			this.MNS_ACTN_AMT.Name = "MNS_ACTN_AMT";
			this.MNS_ACTN_AMT.ReadOnly = true;
			this.MNS_ACTN_AMT.Width = 76;
			// 
			// MNS_PROCESS_CD
			// 
			this.MNS_PROCESS_CD.DataPropertyName = "MNS_PROCESS_CD";
			this.MNS_PROCESS_CD.HeaderText = "처리방법";
			this.MNS_PROCESS_CD.Name = "MNS_PROCESS_CD";
			this.MNS_PROCESS_CD.ReadOnly = true;
			this.MNS_PROCESS_CD.Width = 76;
			// 
			// MEMO2
			// 
			this.MEMO2.DataPropertyName = "MEMO";
			this.MEMO2.HeaderText = "메모";
			this.MEMO2.Name = "MEMO2";
			this.MEMO2.ReadOnly = true;
			this.MEMO2.Width = 54;
			// 
			// SYSREGDATE2
			// 
			this.SYSREGDATE2.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE2.HeaderText = "시스템등록일";
			this.SYSREGDATE2.Name = "SYSREGDATE2";
			this.SYSREGDATE2.ReadOnly = true;
			this.SYSREGDATE2.Width = 98;
			// 
			// SYSREGNAME2
			// 
			this.SYSREGNAME2.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME2.HeaderText = "시스템등록자명";
			this.SYSREGNAME2.Name = "SYSREGNAME2";
			this.SYSREGNAME2.ReadOnly = true;
			this.SYSREGNAME2.Width = 109;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.panel1;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(537, 76);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 6;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.gridView1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.Location = new System.Drawing.Point(0, 76);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(537, 594);
			this.groupBox2.TabIndex = 7;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BAS0830_IDX,
            this.STR_CD,
            this.STR_NM,
            this.MNS_APP_DT,
            this.MNS_GUBUN_CD,
            this.MNS_USE_YN,
            this.Band1,
            this.MNS_AMT_1,
            this.MNS_REG_CD_1,
            this.ISCOMPLETE_1,
            this.Band2,
            this.MNS_AMT_2,
            this.MNS_GIJUN_CD,
            this.MNS_REG_CD_2,
            this.MNS_CAL_CD,
            this.MNS_INTST_YN,
            this.MNS_PER,
            this.MNS_ACTN_AMT_2,
            this.ISCOMPLETE,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME,
            this.MNS_GUBUN_CODE});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 17);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(531, 574);
			this.gridView1.TabIndex = 1;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			// 
			// BAS0830_IDX
			// 
			this.BAS0830_IDX.DataPropertyName = "BAS0830_IDX";
			this.BAS0830_IDX.Frozen = true;
			this.BAS0830_IDX.HeaderText = "일련번호";
			this.BAS0830_IDX.Name = "BAS0830_IDX";
			this.BAS0830_IDX.ReadOnly = true;
			this.BAS0830_IDX.Width = 76;
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.Frozen = true;
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 87;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 76;
			// 
			// MNS_APP_DT
			// 
			this.MNS_APP_DT.DataPropertyName = "MNS_APP_DT";
			this.MNS_APP_DT.Frozen = true;
			this.MNS_APP_DT.HeaderText = "적용일";
			this.MNS_APP_DT.Name = "MNS_APP_DT";
			this.MNS_APP_DT.ReadOnly = true;
			this.MNS_APP_DT.Width = 65;
			// 
			// MNS_GUBUN_CD
			// 
			this.MNS_GUBUN_CD.DataPropertyName = "MNS_GUBUN_CD";
			this.MNS_GUBUN_CD.Frozen = true;
			this.MNS_GUBUN_CD.HeaderText = "출금/차감구분";
			this.MNS_GUBUN_CD.Name = "MNS_GUBUN_CD";
			this.MNS_GUBUN_CD.ReadOnly = true;
			this.MNS_GUBUN_CD.Width = 103;
			// 
			// MNS_USE_YN
			// 
			this.MNS_USE_YN.DataPropertyName = "MNS_USE_YN";
			this.MNS_USE_YN.Frozen = true;
			this.MNS_USE_YN.HeaderText = "사용여부";
			this.MNS_USE_YN.Name = "MNS_USE_YN";
			this.MNS_USE_YN.ReadOnly = true;
			this.MNS_USE_YN.Width = 76;
			// 
			// Band1
			// 
			this.Band1.HeaderText = "강제출금";
			this.Band1.Name = "Band1";
			this.Band1.ReadOnly = true;
			this.Band1.TargetColumnss.Add("MNS_AMT_1");
			this.Band1.TargetColumnss.Add("MNS_REG_CD_1");
			this.Band1.TargetColumnss.Add("ISCOMPLETE_1");
			this.Band1.Width = 57;
			// 
			// MNS_AMT_1
			// 
			this.MNS_AMT_1.DataPropertyName = "MNS_AMT_1";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			this.MNS_AMT_1.DefaultCellStyle = dataGridViewCellStyle5;
			this.MNS_AMT_1.HeaderText = "출금금액";
			this.MNS_AMT_1.Name = "MNS_AMT_1";
			this.MNS_AMT_1.ReadOnly = true;
			this.MNS_AMT_1.Width = 76;
			// 
			// MNS_REG_CD_1
			// 
			this.MNS_REG_CD_1.DataPropertyName = "MNS_REG_CD_1";
			this.MNS_REG_CD_1.HeaderText = "출금사유";
			this.MNS_REG_CD_1.Name = "MNS_REG_CD_1";
			this.MNS_REG_CD_1.ReadOnly = true;
			this.MNS_REG_CD_1.Width = 76;
			// 
			// ISCOMPLETE_1
			// 
			this.ISCOMPLETE_1.DataPropertyName = "ISCOMPLETE_1";
			this.ISCOMPLETE_1.HeaderText = "출금완료여부";
			this.ISCOMPLETE_1.Name = "ISCOMPLETE_1";
			this.ISCOMPLETE_1.ReadOnly = true;
			this.ISCOMPLETE_1.Width = 98;
			// 
			// Band2
			// 
			this.Band2.HeaderText = "자동차감";
			this.Band2.Name = "Band2";
			this.Band2.ReadOnly = true;
			this.Band2.TargetColumnss.Add("MNS_AMT_2");
			this.Band2.TargetColumnss.Add("MNS_GIJUN_CD");
			this.Band2.TargetColumnss.Add("MNS_REG_CD_2");
			this.Band2.TargetColumnss.Add("MNS_CAL_CD");
			this.Band2.TargetColumnss.Add("MNS_INTST_YN");
			this.Band2.TargetColumnss.Add("MNS_PER");
			this.Band2.TargetColumnss.Add("MNS_ACTN_AMT_2");
			this.Band2.TargetColumnss.Add("ISCOMPLETE");
			this.Band2.Width = 57;
			// 
			// MNS_AMT_2
			// 
			this.MNS_AMT_2.DataPropertyName = "MNS_AMT_2";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			this.MNS_AMT_2.DefaultCellStyle = dataGridViewCellStyle6;
			this.MNS_AMT_2.HeaderText = "차감금액";
			this.MNS_AMT_2.Name = "MNS_AMT_2";
			this.MNS_AMT_2.ReadOnly = true;
			this.MNS_AMT_2.Width = 76;
			// 
			// MNS_GIJUN_CD
			// 
			this.MNS_GIJUN_CD.DataPropertyName = "MNS_GIJUN_CD";
			this.MNS_GIJUN_CD.HeaderText = "차감기준";
			this.MNS_GIJUN_CD.Name = "MNS_GIJUN_CD";
			this.MNS_GIJUN_CD.ReadOnly = true;
			this.MNS_GIJUN_CD.Width = 76;
			// 
			// MNS_REG_CD_2
			// 
			this.MNS_REG_CD_2.DataPropertyName = "MNS_REG_CD_2";
			this.MNS_REG_CD_2.HeaderText = "차감사유";
			this.MNS_REG_CD_2.Name = "MNS_REG_CD_2";
			this.MNS_REG_CD_2.ReadOnly = true;
			this.MNS_REG_CD_2.Width = 76;
			// 
			// MNS_CAL_CD
			// 
			this.MNS_CAL_CD.DataPropertyName = "MNS_CAL_CD";
			this.MNS_CAL_CD.HeaderText = "계산방법";
			this.MNS_CAL_CD.Name = "MNS_CAL_CD";
			this.MNS_CAL_CD.ReadOnly = true;
			this.MNS_CAL_CD.Width = 76;
			// 
			// MNS_INTST_YN
			// 
			this.MNS_INTST_YN.DataPropertyName = "MNS_INTST_YN";
			this.MNS_INTST_YN.HeaderText = "이자발생 여부";
			this.MNS_INTST_YN.Name = "MNS_INTST_YN";
			this.MNS_INTST_YN.ReadOnly = true;
			this.MNS_INTST_YN.Width = 102;
			// 
			// MNS_PER
			// 
			this.MNS_PER.DataPropertyName = "MNS_PER";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			this.MNS_PER.DefaultCellStyle = dataGridViewCellStyle7;
			this.MNS_PER.HeaderText = "차감수치";
			this.MNS_PER.Name = "MNS_PER";
			this.MNS_PER.ReadOnly = true;
			this.MNS_PER.Width = 76;
			// 
			// MNS_ACTN_AMT_2
			// 
			this.MNS_ACTN_AMT_2.DataPropertyName = "MNS_ACTN_AMT_2";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			this.MNS_ACTN_AMT_2.DefaultCellStyle = dataGridViewCellStyle8;
			this.MNS_ACTN_AMT_2.HeaderText = "잔여금액";
			this.MNS_ACTN_AMT_2.Name = "MNS_ACTN_AMT_2";
			this.MNS_ACTN_AMT_2.ReadOnly = true;
			this.MNS_ACTN_AMT_2.Width = 76;
			// 
			// ISCOMPLETE
			// 
			this.ISCOMPLETE.DataPropertyName = "ISCOMPLETE_2";
			this.ISCOMPLETE.HeaderText = "차감완료여부";
			this.ISCOMPLETE.Name = "ISCOMPLETE";
			this.ISCOMPLETE.ReadOnly = true;
			this.ISCOMPLETE.Width = 98;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 98;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자명";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 109;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 98;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자명";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 109;
			// 
			// MNS_GUBUN_CODE
			// 
			this.MNS_GUBUN_CODE.DataPropertyName = "MNS_GUBUN_CODE";
			this.MNS_GUBUN_CODE.HeaderText = "MNS_GUBUN_CODE";
			this.MNS_GUBUN_CODE.Name = "MNS_GUBUN_CODE";
			this.MNS_GUBUN_CODE.ReadOnly = true;
			this.MNS_GUBUN_CODE.Visible = false;
			this.MNS_GUBUN_CODE.Width = 138;
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(455, 36);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(77, 12);
			this.label1.TabIndex = 1120;
			this.label1.Text = "자동차감사유";
			// 
			// _cmbMNS_REG_CD_S
			// 
			this._cmbMNS_REG_CD_S.DataSource = null;
			this._cmbMNS_REG_CD_S.DelegateProperty = true;
			this._cmbMNS_REG_CD_S.DroppedDown = false;
			this._cmbMNS_REG_CD_S.Location = new System.Drawing.Point(539, 32);
			this._cmbMNS_REG_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbMNS_REG_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbMNS_REG_CD_S.Name = "_cmbMNS_REG_CD_S";
			this._cmbMNS_REG_CD_S.SelectedIndex = -1;
			this._cmbMNS_REG_CD_S.SelectedItem = null;
			this._cmbMNS_REG_CD_S.SelectedValue = null;
			this._cmbMNS_REG_CD_S.Size = new System.Drawing.Size(124, 21);
			this._cmbMNS_REG_CD_S.TabIndex = 142;
			this._cmbMNS_REG_CD_S.ValidationGroup = null;
			// 
			// WDR0810
			// 
			this.ClientSize = new System.Drawing.Size(1145, 670);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.collapsibleSplitter1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "WDR0810";
			this.Text = "강제출금/차감내역조회:WDR0810";
			this.Load += new System.EventHandler(this.WDR0810_Load);
			this.Shown += new System.EventHandler(this.WDR0810_Shown);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private BANANA.Windows.Controls.ComboBox _cmbMNS_GUBUN_CD_S;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.DateTimePicker _dtpMNS_APP_DT_S_S;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.DateTimePicker _dtpMNS_APP_DT_E_S;
		private BANANA.Windows.Controls.ComboBox _cmbMNS_USE_YN_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label39;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label38;
		private BANANA.Windows.Controls.Label label37;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private DemoClient.Controls.BananaButton _btnSearch;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.GroupBox groupBox4;
		private DemoClient.Controls.GridView gridView3;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter2;
		private System.Windows.Forms.GroupBox groupBox3;
		private DemoClient.Controls.GridView gridView2;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn BAS0831_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_ACTN_AMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_PROCESS_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME2;
		private System.Windows.Forms.DataGridViewTextBoxColumn H_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn BAS0832_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn HST_NAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn EXCPT_DT_STRT;
		private System.Windows.Forms.DataGridViewTextBoxColumn EXCPT_DT_END;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO3;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE3;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME3;
		private System.Windows.Forms.DataGridViewTextBoxColumn HST_TYPE;
		private System.Windows.Forms.DataGridViewTextBoxColumn BAS0830_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_APP_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_GUBUN_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_USE_YN;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band1;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_1;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_REG_CD_1;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISCOMPLETE_1;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band2;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_2;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_GIJUN_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_REG_CD_2;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_CAL_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_INTST_YN;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_PER;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_ACTN_AMT_2;
		private System.Windows.Forms.DataGridViewTextBoxColumn ISCOMPLETE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_GUBUN_CODE;
		private BANANA.Windows.Controls.Label label1;
		private BANANA.Windows.Controls.ComboBox _cmbMNS_REG_CD_S;





	}
}
