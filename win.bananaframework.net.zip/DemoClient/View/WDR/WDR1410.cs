﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient.View.WDR
{
    public partial class WDR1410 : DemoClient.Controllers.BaseForm
    {
        public WDR1410()
        {
            InitializeComponent();
        }
    }
}