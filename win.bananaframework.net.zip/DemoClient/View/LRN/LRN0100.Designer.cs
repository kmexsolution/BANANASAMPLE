﻿namespace DemoClient.View.LRN
{
	partial class LRN0100
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LRN0100));
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BI_SAUP_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNCDNM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNMNT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.INTRRTYEAR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNSTATENM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.EVDEFYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TODAYYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DELAYDAY = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNSTDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNENDDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.FRPYDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.FRPYSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RCNT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.FPRINCIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RESTORGAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.INTRTOT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.FDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this._btnSave = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbINTRY = new BANANA.Windows.Controls.RadioButton();
			this._rbINTRN = new BANANA.Windows.Controls.RadioButton();
			this._dtpEXECDT = new BANANA.Windows.Controls.DateTimePicker();
			this.label13 = new System.Windows.Forms.Label();
			this._cmbLNSTATE_S1 = new BANANA.Windows.Controls.ComboBox();
			this._txtBIGO = new BANANA.Windows.Controls.TextBox();
			this._txtLNAMT = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM = new BANANA.Windows.Controls.TextBox();
			this.label101 = new BANANA.Windows.Controls.Label();
			this.lblUSR_ID = new BANANA.Windows.Controls.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this._txtIDX = new BANANA.Windows.Controls.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this._btnAdd01 = new DemoClient.Controls.BananaButton();
			this._btnRun = new DemoClient.Controls.BananaButton();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpLNEXEC_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._dtpLNEXEC_E = new BANANA.Windows.Controls.DateTimePicker();
			this._cmbLNSTATE = new BANANA.Windows.Controls.ComboBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.gridView4 = new DemoClient.Controls.GridView();
			this.LRN0100_R5_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_RPYSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_RPYDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_PRINCIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_INTEREST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_DLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_TOTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_METHOD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_RELID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_RSTR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0100_R5_CI_AGT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.gridView3 = new DemoClient.Controls.GridView();
			this.D_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.D_RPYSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.D_ISUDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.D_TGPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.D_OVERDAY = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.D_DLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.D_MEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnRPYAMT = new DemoClient.Controls.BananaButton();
			this._btnCAL = new DemoClient.Controls.BananaButton();
			this.gridView2 = new DemoClient.Controls.GridView();
			this.LRN0120_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RPYSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RPYDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RPYAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_PRINCIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_INTEREST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_ODLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RTNPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RTNINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RTNDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_NONPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_NONINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_CDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_OVERDUEYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_TOTPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RESTPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LRN0120_RPYYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._btn_EXCEL_LRN0120 = new DemoClient.Controls.BananaButton();
			this._btnSTR_RPC = new DemoClient.Controls.BananaButton();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel6.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
			this.flowLayoutPanel5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
			this.flowLayoutPanel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView1);
			this.groupBox3.Controls.Add(this.collapsibleSplitter1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(0, 57);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(656, 325);
			this.groupBox3.TabIndex = 3;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX,
            this.STR_CD,
            this.STR_NM,
            this.BI_SAUP_NO,
            this.LNCDNM,
            this.LNAMT,
            this.LNMNT,
            this.INTRRTYEAR,
            this.SYSREGNAME,
            this.LNSTATENM,
            this.EVDEFYN,
            this.TODAYYN,
            this.DELAYDAY,
            this.LNSTDT,
            this.LNENDDT,
            this.FRPYDT,
            this.FRPYSEQ,
            this.RCNT,
            this.FPRINCIPAL,
            this.RESTORGAMT,
            this.INTRTOT,
            this.FDLYINTST});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 17);
			this.gridView1.MultiSelect = false;
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.RowTemplate.Height = 23;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(642, 305);
			this.gridView1.TabIndex = 0;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			this.gridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellDoubleClick);
			this.gridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView1_DataBindingComplete);
			// 
			// IDX
			// 
			this.IDX.DataPropertyName = "IDX";
			dataGridViewCellStyle2.NullValue = "0";
			this.IDX.DefaultCellStyle = dataGridViewCellStyle2;
			this.IDX.Frozen = true;
			this.IDX.HeaderText = "대출원장번호";
			this.IDX.Name = "IDX";
			this.IDX.ReadOnly = true;
			this.IDX.Width = 98;
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.Frozen = true;
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 87;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 76;
			// 
			// BI_SAUP_NO
			// 
			this.BI_SAUP_NO.DataPropertyName = "BI_SAUP_NO";
			this.BI_SAUP_NO.HeaderText = "사업자번호";
			this.BI_SAUP_NO.Name = "BI_SAUP_NO";
			this.BI_SAUP_NO.ReadOnly = true;
			this.BI_SAUP_NO.Width = 87;
			// 
			// LNCDNM
			// 
			this.LNCDNM.DataPropertyName = "LNCDNM";
			this.LNCDNM.HeaderText = "여신사명";
			this.LNCDNM.Name = "LNCDNM";
			this.LNCDNM.ReadOnly = true;
			this.LNCDNM.Visible = false;
			this.LNCDNM.Width = 76;
			// 
			// LNAMT
			// 
			this.LNAMT.DataPropertyName = "LNAMT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			dataGridViewCellStyle3.NullValue = "0";
			this.LNAMT.DefaultCellStyle = dataGridViewCellStyle3;
			this.LNAMT.HeaderText = "대출요청금액";
			this.LNAMT.Name = "LNAMT";
			this.LNAMT.ReadOnly = true;
			this.LNAMT.Width = 98;
			// 
			// LNMNT
			// 
			this.LNMNT.DataPropertyName = "LNMNT";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = "0";
			this.LNMNT.DefaultCellStyle = dataGridViewCellStyle4;
			this.LNMNT.HeaderText = "신청일수";
			this.LNMNT.Name = "LNMNT";
			this.LNMNT.ReadOnly = true;
			this.LNMNT.Width = 76;
			// 
			// INTRRTYEAR
			// 
			this.INTRRTYEAR.DataPropertyName = "INTRRTYEAR";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.INTRRTYEAR.DefaultCellStyle = dataGridViewCellStyle5;
			this.INTRRTYEAR.HeaderText = "연이율";
			this.INTRRTYEAR.Name = "INTRRTYEAR";
			this.INTRRTYEAR.ReadOnly = true;
			this.INTRRTYEAR.Width = 65;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 65;
			// 
			// LNSTATENM
			// 
			this.LNSTATENM.DataPropertyName = "LNSTATENM";
			this.LNSTATENM.HeaderText = "대출상태";
			this.LNSTATENM.Name = "LNSTATENM";
			this.LNSTATENM.ReadOnly = true;
			this.LNSTATENM.Width = 76;
			// 
			// EVDEFYN
			// 
			this.EVDEFYN.DataPropertyName = "EVDEFYN";
			this.EVDEFYN.HeaderText = "기한이익상실여부";
			this.EVDEFYN.Name = "EVDEFYN";
			this.EVDEFYN.ReadOnly = true;
			this.EVDEFYN.Width = 120;
			// 
			// TODAYYN
			// 
			this.TODAYYN.DataPropertyName = "TODAYYN";
			this.TODAYYN.HeaderText = "금일상환여부";
			this.TODAYYN.Name = "TODAYYN";
			this.TODAYYN.ReadOnly = true;
			this.TODAYYN.Width = 98;
			// 
			// DELAYDAY
			// 
			this.DELAYDAY.DataPropertyName = "DELAYDAY";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			dataGridViewCellStyle6.NullValue = "0";
			this.DELAYDAY.DefaultCellStyle = dataGridViewCellStyle6;
			this.DELAYDAY.HeaderText = "연체일수";
			this.DELAYDAY.Name = "DELAYDAY";
			this.DELAYDAY.ReadOnly = true;
			this.DELAYDAY.Width = 76;
			// 
			// LNSTDT
			// 
			this.LNSTDT.DataPropertyName = "LNSTDT";
			this.LNSTDT.HeaderText = "상환시작일";
			this.LNSTDT.Name = "LNSTDT";
			this.LNSTDT.ReadOnly = true;
			this.LNSTDT.Width = 87;
			// 
			// LNENDDT
			// 
			this.LNENDDT.DataPropertyName = "LNENDDT";
			this.LNENDDT.HeaderText = "상환만료일";
			this.LNENDDT.Name = "LNENDDT";
			this.LNENDDT.ReadOnly = true;
			this.LNENDDT.Width = 87;
			// 
			// FRPYDT
			// 
			this.FRPYDT.DataPropertyName = "FRPYDT";
			this.FRPYDT.HeaderText = "최종입금일";
			this.FRPYDT.Name = "FRPYDT";
			this.FRPYDT.ReadOnly = true;
			this.FRPYDT.Width = 87;
			// 
			// FRPYSEQ
			// 
			this.FRPYSEQ.DataPropertyName = "FRPYSEQ";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			dataGridViewCellStyle7.NullValue = "0";
			this.FRPYSEQ.DefaultCellStyle = dataGridViewCellStyle7;
			this.FRPYSEQ.HeaderText = "상환회차";
			this.FRPYSEQ.Name = "FRPYSEQ";
			this.FRPYSEQ.ReadOnly = true;
			this.FRPYSEQ.Width = 76;
			// 
			// RCNT
			// 
			this.RCNT.DataPropertyName = "RCNT";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			dataGridViewCellStyle8.NullValue = "0";
			this.RCNT.DefaultCellStyle = dataGridViewCellStyle8;
			this.RCNT.HeaderText = "잔여회차";
			this.RCNT.Name = "RCNT";
			this.RCNT.ReadOnly = true;
			this.RCNT.Width = 76;
			// 
			// FPRINCIPAL
			// 
			this.FPRINCIPAL.DataPropertyName = "FPRINCIPAL";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N0";
			dataGridViewCellStyle9.NullValue = "0";
			this.FPRINCIPAL.DefaultCellStyle = dataGridViewCellStyle9;
			this.FPRINCIPAL.HeaderText = "총상환원금";
			this.FPRINCIPAL.Name = "FPRINCIPAL";
			this.FPRINCIPAL.ReadOnly = true;
			this.FPRINCIPAL.Width = 87;
			// 
			// RESTORGAMT
			// 
			this.RESTORGAMT.DataPropertyName = "RESTORGAMT";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N0";
			dataGridViewCellStyle10.NullValue = "0";
			this.RESTORGAMT.DefaultCellStyle = dataGridViewCellStyle10;
			this.RESTORGAMT.HeaderText = "잔여원금";
			this.RESTORGAMT.Name = "RESTORGAMT";
			this.RESTORGAMT.ReadOnly = true;
			this.RESTORGAMT.Width = 76;
			// 
			// INTRTOT
			// 
			this.INTRTOT.DataPropertyName = "INTRTOT";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle11.Format = "N0";
			dataGridViewCellStyle11.NullValue = "0";
			this.INTRTOT.DefaultCellStyle = dataGridViewCellStyle11;
			this.INTRTOT.HeaderText = "총이자금액(예정)";
			this.INTRTOT.Name = "INTRTOT";
			this.INTRTOT.ReadOnly = true;
			this.INTRTOT.Width = 117;
			// 
			// FDLYINTST
			// 
			this.FDLYINTST.DataPropertyName = "FDLYINTST";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle12.Format = "N0";
			dataGridViewCellStyle12.NullValue = "0";
			this.FDLYINTST.DefaultCellStyle = dataGridViewCellStyle12;
			this.FDLYINTST.HeaderText = "연체이자금액";
			this.FDLYINTST.Name = "FDLYINTST";
			this.FDLYINTST.ReadOnly = true;
			this.FDLYINTST.Width = 98;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.groupBox2;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(645, 17);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 1114;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this._btnSave);
			this.groupBox2.Controls.Add(this.tableLayoutPanel1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
			this.groupBox2.Location = new System.Drawing.Point(656, 57);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(698, 325);
			this.groupBox2.TabIndex = 33;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "상세 정보";
			// 
			// _btnSave
			// 
			this._btnSave.ButtonConfirm = true;
			this._btnSave.DelegateProperty = true;
			this._btnSave.Enabled = false;
			this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.Location = new System.Drawing.Point(610, 272);
			this._btnSave.Name = "_btnSave";
			this._btnSave.Reserved = "      저   장";
			this._btnSave.Size = new System.Drawing.Size(75, 27);
			this._btnSave.TabIndex = 1112;
			this._btnSave.Text = "      저   장";
			this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.UseVisualStyleBackColor = true;
			this._btnSave.ValidationGroup = "a";
			this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 6;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 119F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel6, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this._dtpEXECDT, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.label13, 4, 1);
			this.tableLayoutPanel1.Controls.Add(this._cmbLNSTATE_S1, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtBIGO, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtLNAMT, 5, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtSTR_NM, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this.label101, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.label7, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtIDX, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label10, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.label14, 0, 3);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 5;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 145F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(692, 245);
			this.tableLayoutPanel1.TabIndex = 1;
			// 
			// flowLayoutPanel6
			// 
			this.flowLayoutPanel6.Controls.Add(this._rbINTRY);
			this.flowLayoutPanel6.Controls.Add(this._rbINTRN);
			this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel6.Location = new System.Drawing.Point(107, 54);
			this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel6.Name = "flowLayoutPanel6";
			this.flowLayoutPanel6.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel6.Size = new System.Drawing.Size(123, 27);
			this.flowLayoutPanel6.TabIndex = 1117;
			// 
			// _rbINTRY
			// 
			this._rbINTRY.AutoSize = true;
			this._rbINTRY.Checked = true;
			this._rbINTRY.DelegateProperty = true;
			this._rbINTRY.Enabled = false;
			this._rbINTRY.Location = new System.Drawing.Point(3, 6);
			this._rbINTRY.Name = "_rbINTRY";
			this._rbINTRY.Size = new System.Drawing.Size(31, 16);
			this._rbINTRY.TabIndex = 10;
			this._rbINTRY.TabStop = true;
			this._rbINTRY.Text = "Y";
			this._rbINTRY.UseVisualStyleBackColor = true;
			// 
			// _rbINTRN
			// 
			this._rbINTRN.AutoSize = true;
			this._rbINTRN.DelegateProperty = true;
			this._rbINTRN.Enabled = false;
			this._rbINTRN.Location = new System.Drawing.Point(40, 6);
			this._rbINTRN.Name = "_rbINTRN";
			this._rbINTRN.Size = new System.Drawing.Size(32, 16);
			this._rbINTRN.TabIndex = 20;
			this._rbINTRN.Text = "N";
			this._rbINTRN.UseVisualStyleBackColor = true;
			// 
			// _dtpEXECDT
			// 
			this._dtpEXECDT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpEXECDT.Checked = false;
			this._dtpEXECDT.CustomFormat = "yyyy-MM-dd";
			this._dtpEXECDT.DelegateProperty = true;
			this._dtpEXECDT.Enabled = false;
			this._dtpEXECDT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpEXECDT.Location = new System.Drawing.Point(110, 30);
			this._dtpEXECDT.MaximumSize = new System.Drawing.Size(250, 20);
			this._dtpEXECDT.MinimumSize = new System.Drawing.Size(100, 20);
			this._dtpEXECDT.Name = "_dtpEXECDT";
			this._dtpEXECDT.Size = new System.Drawing.Size(117, 20);
			this._dtpEXECDT.TabIndex = 1115;
			this._dtpEXECDT.ValidationGroup = "a";
			this._dtpEXECDT.Value = new System.DateTime(2014, 7, 25, 10, 20, 16, 341);
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(494, 34);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(53, 12);
			this.label13.TabIndex = 1114;
			this.label13.Text = "대출금액";
			// 
			// _cmbLNSTATE_S1
			// 
			this._cmbLNSTATE_S1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbLNSTATE_S1.DataSource = null;
			this._cmbLNSTATE_S1.DelegateProperty = true;
			this._cmbLNSTATE_S1.DroppedDown = false;
			this._cmbLNSTATE_S1.Location = new System.Drawing.Point(344, 30);
			this._cmbLNSTATE_S1.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbLNSTATE_S1.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbLNSTATE_S1.Name = "_cmbLNSTATE_S1";
			this._cmbLNSTATE_S1.SelectedIndex = -1;
			this._cmbLNSTATE_S1.SelectedItem = null;
			this._cmbLNSTATE_S1.SelectedValue = null;
			this._cmbLNSTATE_S1.Size = new System.Drawing.Size(113, 21);
			this._cmbLNSTATE_S1.TabIndex = 1114;
			this._cmbLNSTATE_S1.ValidationGroup = null;
			// 
			// _txtBIGO
			// 
			this.tableLayoutPanel1.SetColumnSpan(this._txtBIGO, 5);
			this._txtBIGO.DelegateProperty = true;
			this._txtBIGO.Dock = System.Windows.Forms.DockStyle.Fill;
			this._txtBIGO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO.Location = new System.Drawing.Point(110, 84);
			this._txtBIGO.Multiline = true;
			this._txtBIGO.Name = "_txtBIGO";
			this._txtBIGO.ReadOnly = true;
			this._txtBIGO.Size = new System.Drawing.Size(579, 139);
			this._txtBIGO.TabIndex = 1051;
			this._txtBIGO.ValidationGroup = null;
			this._txtBIGO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBIGO.WaterMarkText = "";
			// 
			// _txtLNAMT
			// 
			this._txtLNAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtLNAMT.DelegateProperty = true;
			this._txtLNAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtLNAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtLNAMT.Location = new System.Drawing.Point(553, 30);
			this._txtLNAMT.Name = "_txtLNAMT";
			this._txtLNAMT.Size = new System.Drawing.Size(136, 20);
			this._txtLNAMT.TabIndex = 1071;
			this._txtLNAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtLNAMT.ValidationGroup = null;
			this._txtLNAMT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtLNAMT.WaterMarkText = "";
			// 
			// _txtSTR_NM
			// 
			this._txtSTR_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM.DelegateProperty = true;
			this._txtSTR_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM.Location = new System.Drawing.Point(344, 3);
			this._txtSTR_NM.Name = "_txtSTR_NM";
			this._txtSTR_NM.ReadOnly = true;
			this._txtSTR_NM.Size = new System.Drawing.Size(113, 20);
			this._txtSTR_NM.TabIndex = 1010;
			this._txtSTR_NM.ValidationGroup = "a";
			this._txtSTR_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM.WaterMarkText = "";
			// 
			// label101
			// 
			this.label101.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label101.AutoSize = true;
			this.label101.Location = new System.Drawing.Point(27, 7);
			this.label101.Name = "label101";
			this.label101.Size = new System.Drawing.Size(77, 12);
			this.label101.TabIndex = 0;
			this.label101.Text = "대출원장번호";
			// 
			// lblUSR_ID
			// 
			this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_ID.AutoSize = true;
			this.lblUSR_ID.Location = new System.Drawing.Point(51, 34);
			this.lblUSR_ID.Name = "lblUSR_ID";
			this.lblUSR_ID.Size = new System.Drawing.Size(53, 12);
			this.lblUSR_ID.TabIndex = 2;
			this.lblUSR_ID.Text = "대출일자";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(285, 7);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(53, 12);
			this.label6.TabIndex = 9;
			this.label6.Text = "가맹점명";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(261, 34);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(77, 12);
			this.label7.TabIndex = 10;
			this.label7.Text = "대출원장상태";
			// 
			// _txtIDX
			// 
			this._txtIDX.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtIDX.DelegateProperty = true;
			this._txtIDX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtIDX.Location = new System.Drawing.Point(110, 3);
			this._txtIDX.Name = "_txtIDX";
			this._txtIDX.ReadOnly = true;
			this._txtIDX.Size = new System.Drawing.Size(117, 20);
			this._txtIDX.TabIndex = 1000;
			this._txtIDX.ValidationGroup = "a";
			this._txtIDX.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtIDX.WaterMarkText = "";
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(27, 61);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(77, 12);
			this.label10.TabIndex = 33;
			this.label10.Text = "연체이자발생";
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(51, 147);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(53, 12);
			this.label14.TabIndex = 32;
			this.label14.Text = "변경사유";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1354, 57);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 7;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 340F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 6, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbLNSTATE, 3, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 1;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1348, 37);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._btnSearch);
			this.flowLayoutPanel4.Controls.Add(this._btnExcel);
			this.flowLayoutPanel4.Controls.Add(this._btnAdd01);
			this.flowLayoutPanel4.Controls.Add(this._btnRun);
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(877, 1);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
			this.flowLayoutPanel4.Size = new System.Drawing.Size(470, 35);
			this.flowLayoutPanel4.TabIndex = 160;
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 27);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(75, 2);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 27);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// _btnAdd01
			// 
			this._btnAdd01.DelegateProperty = true;
			this._btnAdd01.Image = global::DemoClient.Properties.Resources._1377801089_62655;
			this._btnAdd01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnAdd01.Location = new System.Drawing.Point(150, 2);
			this._btnAdd01.Margin = new System.Windows.Forms.Padding(0);
			this._btnAdd01.Name = "_btnAdd01";
			this._btnAdd01.Reserved = "      추   가";
			this._btnAdd01.Size = new System.Drawing.Size(75, 27);
			this._btnAdd01.TabIndex = 1122;
			this._btnAdd01.Text = "      추   가";
			this._btnAdd01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnAdd01.UseVisualStyleBackColor = true;
			this._btnAdd01.ValidationGroup = null;
			this._btnAdd01.Click += new System.EventHandler(this._btnAdd_Click);
			// 
			// _btnRun
			// 
			this._btnRun.DelegateProperty = true;
			this._btnRun.Image = global::DemoClient.Properties.Resources._1377801219_62699;
			this._btnRun.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnRun.Location = new System.Drawing.Point(225, 2);
			this._btnRun.Margin = new System.Windows.Forms.Padding(0);
			this._btnRun.Name = "_btnRun";
			this._btnRun.Reserved = "      실   행";
			this._btnRun.Size = new System.Drawing.Size(75, 27);
			this._btnRun.TabIndex = 1123;
			this._btnRun.Text = "      실   행";
			this._btnRun.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnRun.UseVisualStyleBackColor = true;
			this._btnRun.ValidationGroup = null;
			this._btnRun.Click += new System.EventHandler(this._btnRun_Click);
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 8);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(120, 20);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(35, 12);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(53, 12);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(257, 12);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(53, 12);
			this.label36.TabIndex = 1115;
			this.label36.Text = "대출상태";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(479, 12);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(53, 12);
			this.label37.TabIndex = 1116;
			this.label37.Text = "대출일자";
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._dtpLNEXEC_S);
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this._dtpLNEXEC_E);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(536, 1);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(340, 35);
			this.flowLayoutPanel1.TabIndex = 120;
			// 
			// _dtpLNEXEC_S
			// 
			this._dtpLNEXEC_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpLNEXEC_S.Checked = false;
			this._dtpLNEXEC_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpLNEXEC_S.DelegateProperty = true;
			this._dtpLNEXEC_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpLNEXEC_S.Location = new System.Drawing.Point(3, 3);
			this._dtpLNEXEC_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpLNEXEC_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpLNEXEC_S.Name = "_dtpLNEXEC_S";
			this._dtpLNEXEC_S.Size = new System.Drawing.Size(150, 21);
			this._dtpLNEXEC_S.TabIndex = 10;
			this._dtpLNEXEC_S.ValidationGroup = null;
			this._dtpLNEXEC_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(159, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(14, 12);
			this.label1.TabIndex = 1;
			this.label1.Text = "~";
			// 
			// _dtpLNEXEC_E
			// 
			this._dtpLNEXEC_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpLNEXEC_E.Checked = false;
			this._dtpLNEXEC_E.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpLNEXEC_E.DelegateProperty = true;
			this._dtpLNEXEC_E.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpLNEXEC_E.Location = new System.Drawing.Point(179, 3);
			this._dtpLNEXEC_E.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpLNEXEC_E.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpLNEXEC_E.Name = "_dtpLNEXEC_E";
			this._dtpLNEXEC_E.Size = new System.Drawing.Size(150, 21);
			this._dtpLNEXEC_E.TabIndex = 20;
			this._dtpLNEXEC_E.ValidationGroup = null;
			this._dtpLNEXEC_E.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// _cmbLNSTATE
			// 
			this._cmbLNSTATE.DataSource = null;
			this._cmbLNSTATE.DelegateProperty = true;
			this._cmbLNSTATE.Dock = System.Windows.Forms.DockStyle.Fill;
			this._cmbLNSTATE.DroppedDown = false;
			this._cmbLNSTATE.Location = new System.Drawing.Point(317, 4);
			this._cmbLNSTATE.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbLNSTATE.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbLNSTATE.Name = "_cmbLNSTATE";
			this._cmbLNSTATE.SelectedIndex = -1;
			this._cmbLNSTATE.SelectedItem = null;
			this._cmbLNSTATE.SelectedValue = null;
			this._cmbLNSTATE.Size = new System.Drawing.Size(124, 21);
			this._cmbLNSTATE.TabIndex = 130;
			this._cmbLNSTATE.ValidationGroup = null;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.tableLayoutPanel2);
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox4.Location = new System.Drawing.Point(0, 382);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(1354, 351);
			this.groupBox4.TabIndex = 34;
			this.groupBox4.TabStop = false;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 3;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32F));
			this.tableLayoutPanel2.Controls.Add(this.gridView4, 2, 1);
			this.tableLayoutPanel2.Controls.Add(this.gridView3, 1, 1);
			this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel5, 2, 0);
			this.tableLayoutPanel2.Controls.Add(this.gridView2, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel3, 1, 0);
			this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel2, 0, 0);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 2;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 291F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(1348, 331);
			this.tableLayoutPanel2.TabIndex = 0;
			// 
			// gridView4
			// 
			this.gridView4.AutoSelectRowWithRightButton = false;
			this.gridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle13.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle13.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
			this.gridView4.ColumnHeadersHeight = 50;
			this.gridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LRN0100_R5_IDX,
            this.LRN0100_R5_RPYSEQ,
            this.LRN0100_R5_RPYDT,
            this.LRN0100_R5_PRINCIPAL,
            this.LRN0100_R5_INTEREST,
            this.LRN0100_R5_DLYINTST,
            this.LRN0100_R5_TOTAMT,
            this.LRN0100_R5_METHOD,
            this.LRN0100_R5_RELID,
            this.LRN0100_R5_RSTR_NM,
            this.LRN0100_R5_CI_AGT_NM});
			this.gridView4.DelegateProperty = true;
			this.gridView4.Location = new System.Drawing.Point(919, 43);
			this.gridView4.MultiSelect = false;
			this.gridView4.Name = "gridView4";
			this.gridView4.ReadOnly = true;
			this.gridView4.RowTemplate.Height = 23;
			this.gridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView4.Size = new System.Drawing.Size(426, 285);
			this.gridView4.TabIndex = 5;
			// 
			// LRN0100_R5_IDX
			// 
			this.LRN0100_R5_IDX.DataPropertyName = "LRN0100_R5_IDX";
			dataGridViewCellStyle14.NullValue = "0";
			this.LRN0100_R5_IDX.DefaultCellStyle = dataGridViewCellStyle14;
			this.LRN0100_R5_IDX.Frozen = true;
			this.LRN0100_R5_IDX.HeaderText = "상환번호";
			this.LRN0100_R5_IDX.Name = "LRN0100_R5_IDX";
			this.LRN0100_R5_IDX.ReadOnly = true;
			this.LRN0100_R5_IDX.Width = 76;
			// 
			// LRN0100_R5_RPYSEQ
			// 
			this.LRN0100_R5_RPYSEQ.DataPropertyName = "LRN0100_R5_RPYSEQ";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle15.Format = "N0";
			dataGridViewCellStyle15.NullValue = "0";
			this.LRN0100_R5_RPYSEQ.DefaultCellStyle = dataGridViewCellStyle15;
			this.LRN0100_R5_RPYSEQ.Frozen = true;
			this.LRN0100_R5_RPYSEQ.HeaderText = "회차";
			this.LRN0100_R5_RPYSEQ.Name = "LRN0100_R5_RPYSEQ";
			this.LRN0100_R5_RPYSEQ.ReadOnly = true;
			this.LRN0100_R5_RPYSEQ.Width = 54;
			// 
			// LRN0100_R5_RPYDT
			// 
			this.LRN0100_R5_RPYDT.DataPropertyName = "LRN0100_R5_RPYDT";
			this.LRN0100_R5_RPYDT.Frozen = true;
			this.LRN0100_R5_RPYDT.HeaderText = "상환일";
			this.LRN0100_R5_RPYDT.Name = "LRN0100_R5_RPYDT";
			this.LRN0100_R5_RPYDT.ReadOnly = true;
			this.LRN0100_R5_RPYDT.Width = 65;
			// 
			// LRN0100_R5_PRINCIPAL
			// 
			this.LRN0100_R5_PRINCIPAL.DataPropertyName = "LRN0100_R5_PRINCIPAL";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle16.Format = "N0";
			dataGridViewCellStyle16.NullValue = "0";
			this.LRN0100_R5_PRINCIPAL.DefaultCellStyle = dataGridViewCellStyle16;
			this.LRN0100_R5_PRINCIPAL.HeaderText = "상환원금";
			this.LRN0100_R5_PRINCIPAL.Name = "LRN0100_R5_PRINCIPAL";
			this.LRN0100_R5_PRINCIPAL.ReadOnly = true;
			this.LRN0100_R5_PRINCIPAL.Width = 76;
			// 
			// LRN0100_R5_INTEREST
			// 
			this.LRN0100_R5_INTEREST.DataPropertyName = "LRN0100_R5_INTEREST";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle17.Format = "N0";
			dataGridViewCellStyle17.NullValue = "0";
			this.LRN0100_R5_INTEREST.DefaultCellStyle = dataGridViewCellStyle17;
			this.LRN0100_R5_INTEREST.HeaderText = "상환이자";
			this.LRN0100_R5_INTEREST.Name = "LRN0100_R5_INTEREST";
			this.LRN0100_R5_INTEREST.ReadOnly = true;
			this.LRN0100_R5_INTEREST.Width = 76;
			// 
			// LRN0100_R5_DLYINTST
			// 
			this.LRN0100_R5_DLYINTST.DataPropertyName = "LRN0100_R5_DLYINTST";
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle18.Format = "N0";
			dataGridViewCellStyle18.NullValue = "0";
			this.LRN0100_R5_DLYINTST.DefaultCellStyle = dataGridViewCellStyle18;
			this.LRN0100_R5_DLYINTST.HeaderText = "상환연체이자";
			this.LRN0100_R5_DLYINTST.Name = "LRN0100_R5_DLYINTST";
			this.LRN0100_R5_DLYINTST.ReadOnly = true;
			this.LRN0100_R5_DLYINTST.Width = 98;
			// 
			// LRN0100_R5_TOTAMT
			// 
			this.LRN0100_R5_TOTAMT.DataPropertyName = "LRN0100_R5_TOTAMT";
			dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle19.Format = "N0";
			dataGridViewCellStyle19.NullValue = "0";
			this.LRN0100_R5_TOTAMT.DefaultCellStyle = dataGridViewCellStyle19;
			this.LRN0100_R5_TOTAMT.HeaderText = "합계";
			this.LRN0100_R5_TOTAMT.Name = "LRN0100_R5_TOTAMT";
			this.LRN0100_R5_TOTAMT.ReadOnly = true;
			this.LRN0100_R5_TOTAMT.Width = 54;
			// 
			// LRN0100_R5_METHOD
			// 
			this.LRN0100_R5_METHOD.DataPropertyName = "LRN0100_R5_METHODNM";
			this.LRN0100_R5_METHOD.HeaderText = "상환방법";
			this.LRN0100_R5_METHOD.Name = "LRN0100_R5_METHOD";
			this.LRN0100_R5_METHOD.ReadOnly = true;
			this.LRN0100_R5_METHOD.Width = 76;
			// 
			// LRN0100_R5_RELID
			// 
			this.LRN0100_R5_RELID.DataPropertyName = "LRN0100_R5_RELID";
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle20.Format = "N0";
			dataGridViewCellStyle20.NullValue = "0";
			this.LRN0100_R5_RELID.DefaultCellStyle = dataGridViewCellStyle20;
			this.LRN0100_R5_RELID.HeaderText = "연관번호";
			this.LRN0100_R5_RELID.Name = "LRN0100_R5_RELID";
			this.LRN0100_R5_RELID.ReadOnly = true;
			this.LRN0100_R5_RELID.Width = 76;
			// 
			// LRN0100_R5_RSTR_NM
			// 
			this.LRN0100_R5_RSTR_NM.DataPropertyName = "LRN0100_R5_RSTR_NM";
			this.LRN0100_R5_RSTR_NM.HeaderText = "가맹점명";
			this.LRN0100_R5_RSTR_NM.Name = "LRN0100_R5_RSTR_NM";
			this.LRN0100_R5_RSTR_NM.ReadOnly = true;
			this.LRN0100_R5_RSTR_NM.Width = 76;
			// 
			// LRN0100_R5_CI_AGT_NM
			// 
			this.LRN0100_R5_CI_AGT_NM.DataPropertyName = "LRN0100_R5_CI_AGT_NM";
			this.LRN0100_R5_CI_AGT_NM.HeaderText = "대리점명";
			this.LRN0100_R5_CI_AGT_NM.Name = "LRN0100_R5_CI_AGT_NM";
			this.LRN0100_R5_CI_AGT_NM.ReadOnly = true;
			this.LRN0100_R5_CI_AGT_NM.Width = 76;
			// 
			// gridView3
			// 
			this.gridView3.AutoSelectRowWithRightButton = false;
			this.gridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle21.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
			this.gridView3.ColumnHeadersHeight = 50;
			this.gridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.D_IDX,
            this.D_RPYSEQ,
            this.D_ISUDT,
            this.D_TGPRCP,
            this.D_OVERDAY,
            this.D_DLYINTST,
            this.D_MEMO});
			this.gridView3.DelegateProperty = true;
			this.gridView3.Location = new System.Drawing.Point(609, 43);
			this.gridView3.MultiSelect = false;
			this.gridView3.Name = "gridView3";
			this.gridView3.ReadOnly = true;
			this.gridView3.RowTemplate.Height = 23;
			this.gridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView3.Size = new System.Drawing.Size(304, 285);
			this.gridView3.TabIndex = 4;
			// 
			// D_IDX
			// 
			this.D_IDX.DataPropertyName = "D_IDX";
			dataGridViewCellStyle22.NullValue = "0";
			this.D_IDX.DefaultCellStyle = dataGridViewCellStyle22;
			this.D_IDX.Frozen = true;
			this.D_IDX.HeaderText = "연체번호";
			this.D_IDX.Name = "D_IDX";
			this.D_IDX.ReadOnly = true;
			this.D_IDX.Width = 76;
			// 
			// D_RPYSEQ
			// 
			this.D_RPYSEQ.DataPropertyName = "D_RPYSEQ";
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle23.Format = "N0";
			dataGridViewCellStyle23.NullValue = "0";
			this.D_RPYSEQ.DefaultCellStyle = dataGridViewCellStyle23;
			this.D_RPYSEQ.Frozen = true;
			this.D_RPYSEQ.HeaderText = "회차";
			this.D_RPYSEQ.Name = "D_RPYSEQ";
			this.D_RPYSEQ.ReadOnly = true;
			this.D_RPYSEQ.Width = 54;
			// 
			// D_ISUDT
			// 
			this.D_ISUDT.DataPropertyName = "D_ISUDT";
			this.D_ISUDT.Frozen = true;
			this.D_ISUDT.HeaderText = "발생일";
			this.D_ISUDT.Name = "D_ISUDT";
			this.D_ISUDT.ReadOnly = true;
			this.D_ISUDT.Width = 65;
			// 
			// D_TGPRCP
			// 
			this.D_TGPRCP.DataPropertyName = "D_TGPRCP";
			dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle24.Format = "N0";
			dataGridViewCellStyle24.NullValue = "0";
			this.D_TGPRCP.DefaultCellStyle = dataGridViewCellStyle24;
			this.D_TGPRCP.HeaderText = "대상원금";
			this.D_TGPRCP.Name = "D_TGPRCP";
			this.D_TGPRCP.ReadOnly = true;
			this.D_TGPRCP.Width = 76;
			// 
			// D_OVERDAY
			// 
			this.D_OVERDAY.DataPropertyName = "D_OVERDAY";
			dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle25.Format = "N0";
			dataGridViewCellStyle25.NullValue = "0";
			this.D_OVERDAY.DefaultCellStyle = dataGridViewCellStyle25;
			this.D_OVERDAY.HeaderText = "연체일수";
			this.D_OVERDAY.Name = "D_OVERDAY";
			this.D_OVERDAY.ReadOnly = true;
			this.D_OVERDAY.Width = 76;
			// 
			// D_DLYINTST
			// 
			this.D_DLYINTST.DataPropertyName = "D_DLYINTST";
			dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle26.Format = "N0";
			dataGridViewCellStyle26.NullValue = "0";
			this.D_DLYINTST.DefaultCellStyle = dataGridViewCellStyle26;
			this.D_DLYINTST.HeaderText = "연체이자";
			this.D_DLYINTST.Name = "D_DLYINTST";
			this.D_DLYINTST.ReadOnly = true;
			this.D_DLYINTST.Width = 76;
			// 
			// D_MEMO
			// 
			this.D_MEMO.DataPropertyName = "D_MEMO";
			this.D_MEMO.HeaderText = "메모";
			this.D_MEMO.Name = "D_MEMO";
			this.D_MEMO.ReadOnly = true;
			this.D_MEMO.Width = 54;
			// 
			// flowLayoutPanel5
			// 
			this.flowLayoutPanel5.Controls.Add(this._btnRPYAMT);
			this.flowLayoutPanel5.Controls.Add(this._btnCAL);
			this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel5.Location = new System.Drawing.Point(919, 3);
			this.flowLayoutPanel5.Name = "flowLayoutPanel5";
			this.flowLayoutPanel5.Size = new System.Drawing.Size(426, 34);
			this.flowLayoutPanel5.TabIndex = 2;
			// 
			// _btnRPYAMT
			// 
			this._btnRPYAMT.DelegateProperty = true;
			this._btnRPYAMT.Image = global::DemoClient.Properties.Resources._1377801219_62699;
			this._btnRPYAMT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnRPYAMT.Location = new System.Drawing.Point(0, 0);
			this._btnRPYAMT.Margin = new System.Windows.Forms.Padding(0);
			this._btnRPYAMT.Name = "_btnRPYAMT";
			this._btnRPYAMT.Reserved = "      변   경";
			this._btnRPYAMT.Size = new System.Drawing.Size(75, 27);
			this._btnRPYAMT.TabIndex = 1124;
			this._btnRPYAMT.Text = "      변   경";
			this._btnRPYAMT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnRPYAMT.UseVisualStyleBackColor = true;
			this._btnRPYAMT.ValidationGroup = null;
			this._btnRPYAMT.Visible = false;
			this._btnRPYAMT.Click += new System.EventHandler(this._btnRPYAMT_Click);
			// 
			// _btnCAL
			// 
			this._btnCAL.DelegateProperty = true;
			this._btnCAL.Image = global::DemoClient.Properties.Resources._1377801219_62699;
			this._btnCAL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnCAL.Location = new System.Drawing.Point(75, 0);
			this._btnCAL.Margin = new System.Windows.Forms.Padding(0);
			this._btnCAL.Name = "_btnCAL";
			this._btnCAL.Reserved = "    수기정산";
			this._btnCAL.Size = new System.Drawing.Size(79, 27);
			this._btnCAL.TabIndex = 1125;
			this._btnCAL.Text = "    수기정산";
			this._btnCAL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnCAL.UseVisualStyleBackColor = true;
			this._btnCAL.ValidationGroup = null;
			this._btnCAL.Click += new System.EventHandler(this._btnCAL_Click);
			// 
			// gridView2
			// 
			this.gridView2.AutoSelectRowWithRightButton = false;
			this.gridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle27.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
			this.gridView2.ColumnHeadersHeight = 50;
			this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LRN0120_IDX,
            this.LRN0120_RPYSEQ,
            this.LRN0120_RPYDT,
            this.LRN0120_RPYAMT,
            this.LRN0120_PRINCIPAL,
            this.LRN0120_INTEREST,
            this.LRN0120_ODLYINTST,
            this.LRN0120_RTNPRCP,
            this.LRN0120_RTNINTST,
            this.LRN0120_RTNDLYINTST,
            this.LRN0120_NONPRCP,
            this.LRN0120_NONINTST,
            this.LRN0120_CDLYINTST,
            this.LRN0120_OVERDUEYN,
            this.LRN0120_TOTPRCP,
            this.LRN0120_RESTPRCP,
            this.LRN0120_RPYYN});
			this.gridView2.DelegateProperty = true;
			this.gridView2.Location = new System.Drawing.Point(3, 43);
			this.gridView2.MultiSelect = false;
			this.gridView2.Name = "gridView2";
			this.gridView2.ReadOnly = true;
			this.gridView2.RowTemplate.Height = 23;
			this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView2.Size = new System.Drawing.Size(600, 285);
			this.gridView2.TabIndex = 1;
			// 
			// LRN0120_IDX
			// 
			this.LRN0120_IDX.DataPropertyName = "LRN0120_IDX";
			this.LRN0120_IDX.Frozen = true;
			this.LRN0120_IDX.HeaderText = "대출원장번호";
			this.LRN0120_IDX.Name = "LRN0120_IDX";
			this.LRN0120_IDX.ReadOnly = true;
			this.LRN0120_IDX.Width = 98;
			// 
			// LRN0120_RPYSEQ
			// 
			this.LRN0120_RPYSEQ.DataPropertyName = "LRN0120_RPYSEQ";
			dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle28.Format = "N0";
			dataGridViewCellStyle28.NullValue = "0";
			this.LRN0120_RPYSEQ.DefaultCellStyle = dataGridViewCellStyle28;
			this.LRN0120_RPYSEQ.Frozen = true;
			this.LRN0120_RPYSEQ.HeaderText = "회차";
			this.LRN0120_RPYSEQ.Name = "LRN0120_RPYSEQ";
			this.LRN0120_RPYSEQ.ReadOnly = true;
			this.LRN0120_RPYSEQ.Width = 54;
			// 
			// LRN0120_RPYDT
			// 
			this.LRN0120_RPYDT.DataPropertyName = "LRN0120_RPYDT";
			dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle29.NullValue = null;
			this.LRN0120_RPYDT.DefaultCellStyle = dataGridViewCellStyle29;
			this.LRN0120_RPYDT.Frozen = true;
			this.LRN0120_RPYDT.HeaderText = "예정일";
			this.LRN0120_RPYDT.Name = "LRN0120_RPYDT";
			this.LRN0120_RPYDT.ReadOnly = true;
			this.LRN0120_RPYDT.Width = 65;
			// 
			// LRN0120_RPYAMT
			// 
			this.LRN0120_RPYAMT.DataPropertyName = "LRN0120_RPYAMT";
			dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle30.Format = "N0";
			dataGridViewCellStyle30.NullValue = "0";
			this.LRN0120_RPYAMT.DefaultCellStyle = dataGridViewCellStyle30;
			this.LRN0120_RPYAMT.HeaderText = "원리금";
			this.LRN0120_RPYAMT.Name = "LRN0120_RPYAMT";
			this.LRN0120_RPYAMT.ReadOnly = true;
			this.LRN0120_RPYAMT.Width = 65;
			// 
			// LRN0120_PRINCIPAL
			// 
			this.LRN0120_PRINCIPAL.DataPropertyName = "LRN0120_PRINCIPAL";
			dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle31.Format = "N0";
			dataGridViewCellStyle31.NullValue = "0";
			this.LRN0120_PRINCIPAL.DefaultCellStyle = dataGridViewCellStyle31;
			this.LRN0120_PRINCIPAL.HeaderText = "원금";
			this.LRN0120_PRINCIPAL.Name = "LRN0120_PRINCIPAL";
			this.LRN0120_PRINCIPAL.ReadOnly = true;
			this.LRN0120_PRINCIPAL.Width = 54;
			// 
			// LRN0120_INTEREST
			// 
			this.LRN0120_INTEREST.DataPropertyName = "LRN0120_INTEREST";
			dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle32.Format = "N0";
			dataGridViewCellStyle32.NullValue = "0";
			this.LRN0120_INTEREST.DefaultCellStyle = dataGridViewCellStyle32;
			this.LRN0120_INTEREST.HeaderText = "이자";
			this.LRN0120_INTEREST.Name = "LRN0120_INTEREST";
			this.LRN0120_INTEREST.ReadOnly = true;
			this.LRN0120_INTEREST.Width = 54;
			// 
			// LRN0120_ODLYINTST
			// 
			this.LRN0120_ODLYINTST.DataPropertyName = "LRN0120_ODLYINTST";
			dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle33.Format = "N0";
			dataGridViewCellStyle33.NullValue = "0";
			this.LRN0120_ODLYINTST.DefaultCellStyle = dataGridViewCellStyle33;
			this.LRN0120_ODLYINTST.HeaderText = "연체이자[누적]";
			this.LRN0120_ODLYINTST.Name = "LRN0120_ODLYINTST";
			this.LRN0120_ODLYINTST.ReadOnly = true;
			this.LRN0120_ODLYINTST.Width = 106;
			// 
			// LRN0120_RTNPRCP
			// 
			this.LRN0120_RTNPRCP.DataPropertyName = "LRN0120_RTNPRCP";
			dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle34.Format = "N0";
			dataGridViewCellStyle34.NullValue = "0";
			this.LRN0120_RTNPRCP.DefaultCellStyle = dataGridViewCellStyle34;
			this.LRN0120_RTNPRCP.HeaderText = "상환원금";
			this.LRN0120_RTNPRCP.Name = "LRN0120_RTNPRCP";
			this.LRN0120_RTNPRCP.ReadOnly = true;
			this.LRN0120_RTNPRCP.Width = 76;
			// 
			// LRN0120_RTNINTST
			// 
			this.LRN0120_RTNINTST.DataPropertyName = "LRN0120_RTNINTST";
			dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle35.Format = "N0";
			dataGridViewCellStyle35.NullValue = "0";
			this.LRN0120_RTNINTST.DefaultCellStyle = dataGridViewCellStyle35;
			this.LRN0120_RTNINTST.HeaderText = "상환이자";
			this.LRN0120_RTNINTST.Name = "LRN0120_RTNINTST";
			this.LRN0120_RTNINTST.ReadOnly = true;
			this.LRN0120_RTNINTST.Width = 76;
			// 
			// LRN0120_RTNDLYINTST
			// 
			this.LRN0120_RTNDLYINTST.DataPropertyName = "LRN0120_RTNDLYINTST";
			dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle36.Format = "N0";
			dataGridViewCellStyle36.NullValue = "0";
			this.LRN0120_RTNDLYINTST.DefaultCellStyle = dataGridViewCellStyle36;
			this.LRN0120_RTNDLYINTST.HeaderText = "상환연체이자";
			this.LRN0120_RTNDLYINTST.Name = "LRN0120_RTNDLYINTST";
			this.LRN0120_RTNDLYINTST.ReadOnly = true;
			this.LRN0120_RTNDLYINTST.Width = 98;
			// 
			// LRN0120_NONPRCP
			// 
			this.LRN0120_NONPRCP.DataPropertyName = "LRN0120_NONPRCP";
			dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle37.Format = "N0";
			dataGridViewCellStyle37.NullValue = "0";
			this.LRN0120_NONPRCP.DefaultCellStyle = dataGridViewCellStyle37;
			this.LRN0120_NONPRCP.HeaderText = "미수원금";
			this.LRN0120_NONPRCP.Name = "LRN0120_NONPRCP";
			this.LRN0120_NONPRCP.ReadOnly = true;
			this.LRN0120_NONPRCP.Width = 76;
			// 
			// LRN0120_NONINTST
			// 
			this.LRN0120_NONINTST.DataPropertyName = "LRN0120_NONINTST";
			dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle38.Format = "N0";
			dataGridViewCellStyle38.NullValue = "0";
			this.LRN0120_NONINTST.DefaultCellStyle = dataGridViewCellStyle38;
			this.LRN0120_NONINTST.HeaderText = "미수이자";
			this.LRN0120_NONINTST.Name = "LRN0120_NONINTST";
			this.LRN0120_NONINTST.ReadOnly = true;
			this.LRN0120_NONINTST.Width = 76;
			// 
			// LRN0120_CDLYINTST
			// 
			this.LRN0120_CDLYINTST.DataPropertyName = "LRN0120_CDLYINTST";
			dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle39.Format = "N0";
			dataGridViewCellStyle39.NullValue = "0";
			this.LRN0120_CDLYINTST.DefaultCellStyle = dataGridViewCellStyle39;
			this.LRN0120_CDLYINTST.HeaderText = "미수연체이자";
			this.LRN0120_CDLYINTST.Name = "LRN0120_CDLYINTST";
			this.LRN0120_CDLYINTST.ReadOnly = true;
			this.LRN0120_CDLYINTST.Width = 98;
			// 
			// LRN0120_OVERDUEYN
			// 
			this.LRN0120_OVERDUEYN.DataPropertyName = "LRN0120_OVERDUEYN";
			dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.LRN0120_OVERDUEYN.DefaultCellStyle = dataGridViewCellStyle40;
			this.LRN0120_OVERDUEYN.HeaderText = "연체여부";
			this.LRN0120_OVERDUEYN.Name = "LRN0120_OVERDUEYN";
			this.LRN0120_OVERDUEYN.ReadOnly = true;
			this.LRN0120_OVERDUEYN.Width = 76;
			// 
			// LRN0120_TOTPRCP
			// 
			this.LRN0120_TOTPRCP.DataPropertyName = "LRN0120_TOTPRCP";
			dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle41.Format = "N0";
			dataGridViewCellStyle41.NullValue = "0";
			this.LRN0120_TOTPRCP.DefaultCellStyle = dataGridViewCellStyle41;
			this.LRN0120_TOTPRCP.HeaderText = "납입원금합계";
			this.LRN0120_TOTPRCP.Name = "LRN0120_TOTPRCP";
			this.LRN0120_TOTPRCP.ReadOnly = true;
			this.LRN0120_TOTPRCP.Width = 98;
			// 
			// LRN0120_RESTPRCP
			// 
			this.LRN0120_RESTPRCP.DataPropertyName = "LRN0120_RESTPRCP";
			dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle42.Format = "N0";
			dataGridViewCellStyle42.NullValue = "0";
			this.LRN0120_RESTPRCP.DefaultCellStyle = dataGridViewCellStyle42;
			this.LRN0120_RESTPRCP.HeaderText = "대출잔액";
			this.LRN0120_RESTPRCP.Name = "LRN0120_RESTPRCP";
			this.LRN0120_RESTPRCP.ReadOnly = true;
			this.LRN0120_RESTPRCP.Width = 76;
			// 
			// LRN0120_RPYYN
			// 
			this.LRN0120_RPYYN.DataPropertyName = "LRN0120_RPYYN";
			dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.LRN0120_RPYYN.DefaultCellStyle = dataGridViewCellStyle43;
			this.LRN0120_RPYYN.HeaderText = "종료여부";
			this.LRN0120_RPYYN.Name = "LRN0120_RPYYN";
			this.LRN0120_RPYYN.ReadOnly = true;
			this.LRN0120_RPYYN.Width = 76;
			// 
			// flowLayoutPanel3
			// 
			this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel3.Location = new System.Drawing.Point(609, 3);
			this.flowLayoutPanel3.Name = "flowLayoutPanel3";
			this.flowLayoutPanel3.Size = new System.Drawing.Size(304, 34);
			this.flowLayoutPanel3.TabIndex = 1;
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._btn_EXCEL_LRN0120);
			this.flowLayoutPanel2.Controls.Add(this._btnSTR_RPC);
			this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 3);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(241, 30);
			this.flowLayoutPanel2.TabIndex = 3;
			// 
			// _btn_EXCEL_LRN0120
			// 
			this._btn_EXCEL_LRN0120.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btn_EXCEL_LRN0120.DelegateProperty = true;
			this._btn_EXCEL_LRN0120.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btn_EXCEL_LRN0120.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btn_EXCEL_LRN0120.Location = new System.Drawing.Point(0, 2);
			this._btn_EXCEL_LRN0120.Margin = new System.Windows.Forms.Padding(0);
			this._btn_EXCEL_LRN0120.Name = "_btn_EXCEL_LRN0120";
			this._btn_EXCEL_LRN0120.Reserved = "      엑   셀";
			this._btn_EXCEL_LRN0120.Size = new System.Drawing.Size(75, 23);
			this._btn_EXCEL_LRN0120.TabIndex = 20;
			this._btn_EXCEL_LRN0120.Text = "      엑   셀";
			this._btn_EXCEL_LRN0120.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btn_EXCEL_LRN0120.UseVisualStyleBackColor = true;
			this._btn_EXCEL_LRN0120.ValidationGroup = null;
			this._btn_EXCEL_LRN0120.Click += new System.EventHandler(this._btn_EXCEL_LRN0120_Click);
			// 
			// _btnSTR_RPC
			// 
			this._btnSTR_RPC.DelegateProperty = true;
			this._btnSTR_RPC.Image = global::DemoClient.Properties.Resources._1377801219_62699;
			this._btnSTR_RPC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSTR_RPC.Location = new System.Drawing.Point(75, 0);
			this._btnSTR_RPC.Margin = new System.Windows.Forms.Padding(0);
			this._btnSTR_RPC.Name = "_btnSTR_RPC";
			this._btnSTR_RPC.Reserved = "      변   경";
			this._btnSTR_RPC.Size = new System.Drawing.Size(75, 27);
			this._btnSTR_RPC.TabIndex = 1124;
			this._btnSTR_RPC.Text = "      변   경";
			this._btnSTR_RPC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSTR_RPC.UseVisualStyleBackColor = true;
			this._btnSTR_RPC.ValidationGroup = null;
			this._btnSTR_RPC.Click += new System.EventHandler(this._btnSTR_RPC_Click);
			// 
			// LRN0100
			// 
			this.ClientSize = new System.Drawing.Size(1354, 733);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.groupBox4);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "LRN0100";
			this.Text = "비즈론원장관리:LRN0100";
			this.Load += new System.EventHandler(this.LRN0100_Load);
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.flowLayoutPanel6.ResumeLayout(false);
			this.flowLayoutPanel6.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
			this.flowLayoutPanel5.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label37;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.DateTimePicker _dtpLNEXEC_S;
		private BANANA.Windows.Controls.Label label1;
		private BANANA.Windows.Controls.DateTimePicker _dtpLNEXEC_E;
		private BANANA.Windows.Controls.GroupBox groupBox3;
		private DemoClient.Controls.GridView gridView1;
		private BANANA.Windows.Controls.ComboBox _cmbLNSTATE;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private DemoClient.Controls.BananaButton _btnSearch;
		private DemoClient.Controls.BananaButton _btnExcel;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.BananaButton _btnSave;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private BANANA.Windows.Controls.DateTimePicker _dtpEXECDT;
		private System.Windows.Forms.Label label13;
		private BANANA.Windows.Controls.ComboBox _cmbLNSTATE_S1;
		private BANANA.Windows.Controls.TextBox _txtBIGO;
		private BANANA.Windows.Controls.TextBox _txtLNAMT;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM;
		private BANANA.Windows.Controls.Label label101;
		private BANANA.Windows.Controls.Label lblUSR_ID;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private BANANA.Windows.Controls.TextBox _txtIDX;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label14;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
		private DemoClient.Controls.GridView gridView2;
		private DemoClient.Controls.BananaButton _btn_EXCEL_LRN0120;
		private DemoClient.Controls.GridView gridView4;
		private DemoClient.Controls.GridView gridView3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private DemoClient.Controls.BananaButton _btnAdd01;
        private DemoClient.Controls.BananaButton _btnRun;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
		private BANANA.Windows.Controls.RadioButton _rbINTRY;
		private BANANA.Windows.Controls.RadioButton _rbINTRN;
        private DemoClient.Controls.BananaButton _btnSTR_RPC;
		private DemoClient.Controls.BananaButton _btnRPYAMT;
		private DemoClient.Controls.BananaButton _btnCAL;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RPYSEQ;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RPYDT;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RPYAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_PRINCIPAL;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_INTEREST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_ODLYINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RTNPRCP;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RTNINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RTNDLYINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_NONPRCP;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_NONINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_CDLYINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_OVERDUEYN;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_TOTPRCP;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RESTPRCP;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0120_RPYYN;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_RPYSEQ;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_RPYDT;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_PRINCIPAL;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_INTEREST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_DLYINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_TOTAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_METHOD;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_RELID;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_RSTR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn LRN0100_R5_CI_AGT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_RPYSEQ;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_ISUDT;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_TGPRCP;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_OVERDAY;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_DLYINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn D_MEMO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn BI_SAUP_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn LNCDNM;
        private System.Windows.Forms.DataGridViewTextBoxColumn LNAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LNMNT;
        private System.Windows.Forms.DataGridViewTextBoxColumn INTRRTYEAR;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn LNSTATENM;
        private System.Windows.Forms.DataGridViewTextBoxColumn EVDEFYN;
        private System.Windows.Forms.DataGridViewTextBoxColumn TODAYYN;
        private System.Windows.Forms.DataGridViewTextBoxColumn DELAYDAY;
        private System.Windows.Forms.DataGridViewTextBoxColumn LNSTDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LNENDDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn FRPYDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn FRPYSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn RCNT;
        private System.Windows.Forms.DataGridViewTextBoxColumn FPRINCIPAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn RESTORGAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn INTRTOT;
        private System.Windows.Forms.DataGridViewTextBoxColumn FDLYINTST;
    }
}
