﻿namespace DemoClient.View.LRN
{
	partial class LRN0200
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LRN0200));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.gridView2 = new DemoClient.Controls.GridView();
            this.ORD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._txtTOTINTR = new BANANA.Windows.Controls.TextBox();
            this._txtTOTAMT = new BANANA.Windows.Controls.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this._dtpLNSTDT = new BANANA.Windows.Controls.DateTimePicker();
            this._dtpEXECDT = new BANANA.Windows.Controls.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this._txtINTRRTYEAR = new BANANA.Windows.Controls.TextBox();
            this._txtLNAMT = new BANANA.Windows.Controls.TextBox();
            this.lblUSR_ID = new BANANA.Windows.Controls.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this._txtLNMNT = new BANANA.Windows.Controls.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this._btnCAL = new DemoClient.Controls.BananaButton();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(682, 494);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 119F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 114F));
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.gridView2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this._txtTOTINTR, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtTOTAMT, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this._dtpLNSTDT, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this._dtpEXECDT, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtINTRRTYEAR, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtLNAMT, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this._txtLNMNT, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this._btnCAL, 4, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 373F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(676, 465);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 1121;
            this.label3.Text = "상환테이블";
            // 
            // gridView2
            // 
            this.gridView2.AutoSelectRowWithRightButton = false;
            this.gridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView2.ColumnHeadersHeight = 50;
            this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ORD,
            this.RDT,
            this.PRC,
            this.INT,
            this.PNI,
            this.RST});
            this.tableLayoutPanel1.SetColumnSpan(this.gridView2, 5);
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView2.DefaultCellStyle = dataGridViewCellStyle6;
            this.gridView2.DelegateProperty = true;
            this.gridView2.Location = new System.Drawing.Point(93, 84);
            this.gridView2.MultiSelect = false;
            this.gridView2.Name = "gridView2";
            this.gridView2.ReadOnly = true;
            this.gridView2.RowTemplate.Height = 23;
            this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView2.Size = new System.Drawing.Size(580, 367);
            this.gridView2.TabIndex = 1120;
            // 
            // ORD
            // 
            this.ORD.DataPropertyName = "ORD";
            this.ORD.HeaderText = "회차";
            this.ORD.Name = "ORD";
            this.ORD.ReadOnly = true;
            this.ORD.Width = 54;
            // 
            // RDT
            // 
            this.RDT.DataPropertyName = "RDT";
            this.RDT.HeaderText = "상환일자";
            this.RDT.Name = "RDT";
            this.RDT.ReadOnly = true;
            this.RDT.Width = 76;
            // 
            // PRC
            // 
            this.PRC.DataPropertyName = "PRC";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = "0";
            this.PRC.DefaultCellStyle = dataGridViewCellStyle2;
            this.PRC.HeaderText = "원금";
            this.PRC.MinimumWidth = 100;
            this.PRC.Name = "PRC";
            this.PRC.ReadOnly = true;
            // 
            // INT
            // 
            this.INT.DataPropertyName = "INT";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = "0";
            this.INT.DefaultCellStyle = dataGridViewCellStyle3;
            this.INT.HeaderText = "이자";
            this.INT.Name = "INT";
            this.INT.ReadOnly = true;
            this.INT.Width = 54;
            // 
            // PNI
            // 
            this.PNI.DataPropertyName = "PNI";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = "0";
            this.PNI.DefaultCellStyle = dataGridViewCellStyle4;
            this.PNI.HeaderText = "원리금";
            this.PNI.Name = "PNI";
            this.PNI.ReadOnly = true;
            this.PNI.Width = 65;
            // 
            // RST
            // 
            this.RST.DataPropertyName = "RST";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N0";
            dataGridViewCellStyle5.NullValue = "0";
            this.RST.DefaultCellStyle = dataGridViewCellStyle5;
            this.RST.HeaderText = "원금잔액";
            this.RST.Name = "RST";
            this.RST.ReadOnly = true;
            this.RST.Width = 76;
            // 
            // _txtTOTINTR
            // 
            this._txtTOTINTR.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTOTINTR.Compulsory = true;
            this._txtTOTINTR.DelegateProperty = true;
            this._txtTOTINTR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTOTINTR.Location = new System.Drawing.Point(327, 57);
            this._txtTOTINTR.Name = "_txtTOTINTR";
            this._txtTOTINTR.ReadOnly = true;
            this._txtTOTINTR.Size = new System.Drawing.Size(113, 20);
            this._txtTOTINTR.TabIndex = 1119;
            this._txtTOTINTR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtTOTINTR.ValidationGroup = "a";
            this._txtTOTINTR.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTOTINTR.WaterMarkText = "";
            // 
            // _txtTOTAMT
            // 
            this._txtTOTAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTOTAMT.Compulsory = true;
            this._txtTOTAMT.DelegateProperty = true;
            this._txtTOTAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTOTAMT.Location = new System.Drawing.Point(93, 57);
            this._txtTOTAMT.Name = "_txtTOTAMT";
            this._txtTOTAMT.ReadOnly = true;
            this._txtTOTAMT.Size = new System.Drawing.Size(113, 20);
            this._txtTOTAMT.TabIndex = 1118;
            this._txtTOTAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtTOTAMT.ValidationGroup = "a";
            this._txtTOTAMT.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTOTAMT.WaterMarkText = "";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1117;
            this.label2.Text = "총상환액";
            // 
            // _dtpLNSTDT
            // 
            this._dtpLNSTDT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpLNSTDT.Checked = false;
            this._dtpLNSTDT.CustomFormat = "yyyy-MM-dd";
            this._dtpLNSTDT.DelegateProperty = true;
            this._dtpLNSTDT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpLNSTDT.Location = new System.Drawing.Point(327, 30);
            this._dtpLNSTDT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpLNSTDT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpLNSTDT.Name = "_dtpLNSTDT";
            this._dtpLNSTDT.Size = new System.Drawing.Size(113, 20);
            this._dtpLNSTDT.TabIndex = 1116;
            this._dtpLNSTDT.ValidationGroup = "a";
            this._dtpLNSTDT.Value = new System.DateTime(2014, 7, 25, 10, 20, 16, 341);
            // 
            // _dtpEXECDT
            // 
            this._dtpEXECDT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpEXECDT.Checked = false;
            this._dtpEXECDT.CustomFormat = "yyyy-MM-dd";
            this._dtpEXECDT.DelegateProperty = true;
            this._dtpEXECDT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpEXECDT.Location = new System.Drawing.Point(93, 30);
            this._dtpEXECDT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpEXECDT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpEXECDT.Name = "_dtpEXECDT";
            this._dtpEXECDT.Size = new System.Drawing.Size(117, 20);
            this._dtpEXECDT.TabIndex = 1115;
            this._dtpEXECDT.ValidationGroup = "a";
            this._dtpEXECDT.Value = new System.DateTime(2014, 7, 25, 10, 20, 16, 341);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(471, 34);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 12);
            this.label13.TabIndex = 1114;
            this.label13.Text = "대출연이율(%)";
            // 
            // _txtINTRRTYEAR
            // 
            this._txtINTRRTYEAR.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtINTRRTYEAR.Compulsory = true;
            this._txtINTRRTYEAR.DelegateProperty = true;
            this._txtINTRRTYEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtINTRRTYEAR.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
            this._txtINTRRTYEAR.Location = new System.Drawing.Point(562, 30);
            this._txtINTRRTYEAR.Name = "_txtINTRRTYEAR";
            this._txtINTRRTYEAR.Size = new System.Drawing.Size(110, 20);
            this._txtINTRRTYEAR.TabIndex = 1071;
            this._txtINTRRTYEAR.Text = "34.50";
            this._txtINTRRTYEAR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtINTRRTYEAR.ValidationGroup = null;
            this._txtINTRRTYEAR.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtINTRRTYEAR.WaterMarkText = "";
            // 
            // _txtLNAMT
            // 
            this._txtLNAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtLNAMT.Compulsory = true;
            this._txtLNAMT.DelegateProperty = true;
            this._txtLNAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtLNAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtLNAMT.Location = new System.Drawing.Point(327, 3);
            this._txtLNAMT.Name = "_txtLNAMT";
            this._txtLNAMT.Size = new System.Drawing.Size(113, 20);
            this._txtLNAMT.TabIndex = 1010;
            this._txtLNAMT.Text = "10000000";
            this._txtLNAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtLNAMT.ValidationGroup = "a";
            this._txtLNAMT.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtLNAMT.WaterMarkText = "";
            // 
            // lblUSR_ID
            // 
            this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblUSR_ID.AutoSize = true;
            this.lblUSR_ID.Location = new System.Drawing.Point(34, 34);
            this.lblUSR_ID.Name = "lblUSR_ID";
            this.lblUSR_ID.Size = new System.Drawing.Size(53, 12);
            this.lblUSR_ID.TabIndex = 2;
            this.lblUSR_ID.Text = "대출일자";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(268, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "신청금액";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(503, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "대출일수";
            // 
            // _txtLNMNT
            // 
            this._txtLNMNT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtLNMNT.Compulsory = true;
            this._txtLNMNT.DelegateProperty = true;
            this._txtLNMNT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtLNMNT.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
            this._txtLNMNT.Location = new System.Drawing.Point(562, 3);
            this._txtLNMNT.Name = "_txtLNMNT";
            this._txtLNMNT.Size = new System.Drawing.Size(110, 20);
            this._txtLNMNT.TabIndex = 1000;
            this._txtLNMNT.Text = "100";
            this._txtLNMNT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtLNMNT.ValidationGroup = "a";
            this._txtLNMNT.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtLNMNT.WaterMarkText = "";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(244, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 34;
            this.label11.Text = "상환시작일자";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(256, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 33;
            this.label10.Text = "총대출이자";
            // 
            // _btnCAL
            // 
            this.tableLayoutPanel1.SetColumnSpan(this._btnCAL, 2);
            this._btnCAL.Dock = System.Windows.Forms.DockStyle.Fill;
            this._btnCAL.Location = new System.Drawing.Point(446, 57);
            this._btnCAL.Name = "_btnCAL";
            this._btnCAL.Reserved = "계산";
            this._btnCAL.Size = new System.Drawing.Size(227, 21);
            this._btnCAL.TabIndex = 1127;
            this._btnCAL.Text = "계산";
            this._btnCAL.UseVisualStyleBackColor = true;
            this._btnCAL.ValidationGroup = null;
            this._btnCAL.Click += new System.EventHandler(this._btnCAL_Click);
            // 
            // LRN0200
            // 
            this.ClientSize = new System.Drawing.Size(682, 494);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LRN0200";
            this.Text = "비즈론대출계산기:LRN0200";
            this.Load += new System.EventHandler(this.LRN0200_Load);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.ResumeLayout(false);

		}

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private DemoClient.Controls.GridView gridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ORD;
        private System.Windows.Forms.DataGridViewTextBoxColumn RDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRC;
        private System.Windows.Forms.DataGridViewTextBoxColumn INT;
        private System.Windows.Forms.DataGridViewTextBoxColumn PNI;
        private System.Windows.Forms.DataGridViewTextBoxColumn RST;
        private BANANA.Windows.Controls.TextBox _txtTOTINTR;
        private BANANA.Windows.Controls.TextBox _txtTOTAMT;
        private System.Windows.Forms.Label label2;
        private BANANA.Windows.Controls.DateTimePicker _dtpLNSTDT;
        private BANANA.Windows.Controls.DateTimePicker _dtpEXECDT;
        private System.Windows.Forms.Label label13;
        private BANANA.Windows.Controls.TextBox _txtINTRRTYEAR;
        private BANANA.Windows.Controls.TextBox _txtLNAMT;
        private BANANA.Windows.Controls.Label lblUSR_ID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private BANANA.Windows.Controls.TextBox _txtLNMNT;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private DemoClient.Controls.BananaButton _btnCAL;
    }
}
