﻿namespace DemoClient.View.LRN
{
    partial class LRN0130
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LRN0130));
            this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
            this.gridView1 = new DemoClient.Controls.GridView();
            this.LRN0130_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_RPYSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_RPYDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_PRINCIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_INTEREST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_DLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_TOTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_METHODNM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_RELID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LRN0130_AGTNM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this._btnSave = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new BANANA.Windows.Controls.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this._txtTOTAMT = new BANANA.Windows.Controls.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this._txtCDLYINTST = new BANANA.Windows.Controls.TextBox();
            this._txtNONINTST = new BANANA.Windows.Controls.TextBox();
            this._txtNONPRCP = new BANANA.Windows.Controls.TextBox();
            this._txtRTNINTST = new BANANA.Windows.Controls.TextBox();
            this._txtRTNPRCP = new BANANA.Windows.Controls.TextBox();
            this._txtPRINCIPAL = new BANANA.Windows.Controls.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this._txtRPYSEQ = new BANANA.Windows.Controls.TextBox();
            this.label5 = new BANANA.Windows.Controls.Label();
            this._txtIDX = new BANANA.Windows.Controls.TextBox();
            this.label4 = new BANANA.Windows.Controls.Label();
            this._dtpRPYDT = new BANANA.Windows.Controls.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this._cmbMETHOD = new BANANA.Windows.Controls.ComboBox();
            this._txtDLYINTST = new BANANA.Windows.Controls.TextBox();
            this._txtINTEREST = new BANANA.Windows.Controls.TextBox();
            this.label101 = new BANANA.Windows.Controls.Label();
            this.lblUSR_ID = new BANANA.Windows.Controls.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this._txtRPYSEQ_E = new BANANA.Windows.Controls.TextBox();
            this.label1 = new BANANA.Windows.Controls.Label();
            this._txtRPYSEQ_S = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label37 = new BANANA.Windows.Controls.Label();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.gridView1);
            this.groupBox3.Controls.Add(this.collapsibleSplitter1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 57);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(447, 613);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "상환내역목록";
            // 
            // gridView1
            // 
            this.gridView1.AutoSelectRowWithRightButton = false;
            this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView1.ColumnHeadersHeight = 50;
            this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LRN0130_IDX,
            this.LRN0130_RPYSEQ,
            this.LRN0130_RPYDT,
            this.LRN0130_PRINCIPAL,
            this.LRN0130_INTEREST,
            this.LRN0130_DLYINTST,
            this.LRN0130_TOTAMT,
            this.LRN0130_METHODNM,
            this.LRN0130_RELID,
            this.LRN0130_STR_NM,
            this.LRN0130_AGTNM});
            this.gridView1.DelegateProperty = true;
            this.gridView1.Location = new System.Drawing.Point(3, 17);
            this.gridView1.MultiSelect = false;
            this.gridView1.Name = "gridView1";
            this.gridView1.ReadOnly = true;
            this.gridView1.RowTemplate.Height = 23;
            this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView1.Size = new System.Drawing.Size(438, 593);
            this.gridView1.TabIndex = 1116;
            // 
            // LRN0130_IDX
            // 
            this.LRN0130_IDX.DataPropertyName = "LRN0130_IDX";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = "0";
            this.LRN0130_IDX.DefaultCellStyle = dataGridViewCellStyle2;
            this.LRN0130_IDX.Frozen = true;
            this.LRN0130_IDX.HeaderText = "상환번호";
            this.LRN0130_IDX.Name = "LRN0130_IDX";
            this.LRN0130_IDX.ReadOnly = true;
            this.LRN0130_IDX.Width = 76;
            // 
            // LRN0130_RPYSEQ
            // 
            this.LRN0130_RPYSEQ.DataPropertyName = "LRN0130_RPYSEQ";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = "0";
            this.LRN0130_RPYSEQ.DefaultCellStyle = dataGridViewCellStyle3;
            this.LRN0130_RPYSEQ.Frozen = true;
            this.LRN0130_RPYSEQ.HeaderText = "회차";
            this.LRN0130_RPYSEQ.Name = "LRN0130_RPYSEQ";
            this.LRN0130_RPYSEQ.ReadOnly = true;
            this.LRN0130_RPYSEQ.Width = 54;
            // 
            // LRN0130_RPYDT
            // 
            this.LRN0130_RPYDT.DataPropertyName = "LRN0130_RPYDT";
            this.LRN0130_RPYDT.HeaderText = "상환일";
            this.LRN0130_RPYDT.Name = "LRN0130_RPYDT";
            this.LRN0130_RPYDT.ReadOnly = true;
            this.LRN0130_RPYDT.Visible = false;
            this.LRN0130_RPYDT.Width = 65;
            // 
            // LRN0130_PRINCIPAL
            // 
            this.LRN0130_PRINCIPAL.DataPropertyName = "LRN0130_PRINCIPAL";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = "0";
            this.LRN0130_PRINCIPAL.DefaultCellStyle = dataGridViewCellStyle4;
            this.LRN0130_PRINCIPAL.HeaderText = "상환원금";
            this.LRN0130_PRINCIPAL.Name = "LRN0130_PRINCIPAL";
            this.LRN0130_PRINCIPAL.ReadOnly = true;
            this.LRN0130_PRINCIPAL.Width = 76;
            // 
            // LRN0130_INTEREST
            // 
            this.LRN0130_INTEREST.DataPropertyName = "LRN0130_INTEREST";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N0";
            dataGridViewCellStyle5.NullValue = "0";
            this.LRN0130_INTEREST.DefaultCellStyle = dataGridViewCellStyle5;
            this.LRN0130_INTEREST.HeaderText = "상환이자";
            this.LRN0130_INTEREST.Name = "LRN0130_INTEREST";
            this.LRN0130_INTEREST.ReadOnly = true;
            this.LRN0130_INTEREST.Width = 76;
            // 
            // LRN0130_DLYINTST
            // 
            this.LRN0130_DLYINTST.DataPropertyName = "LRN0130_DLYINTST";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = "0";
            this.LRN0130_DLYINTST.DefaultCellStyle = dataGridViewCellStyle6;
            this.LRN0130_DLYINTST.HeaderText = "상환연체이자";
            this.LRN0130_DLYINTST.Name = "LRN0130_DLYINTST";
            this.LRN0130_DLYINTST.ReadOnly = true;
            this.LRN0130_DLYINTST.Width = 98;
            // 
            // LRN0130_TOTAMT
            // 
            this.LRN0130_TOTAMT.DataPropertyName = "LRN0130_TOTAMT";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = "0";
            this.LRN0130_TOTAMT.DefaultCellStyle = dataGridViewCellStyle7;
            this.LRN0130_TOTAMT.HeaderText = "합계";
            this.LRN0130_TOTAMT.Name = "LRN0130_TOTAMT";
            this.LRN0130_TOTAMT.ReadOnly = true;
            this.LRN0130_TOTAMT.Width = 54;
            // 
            // LRN0130_METHODNM
            // 
            this.LRN0130_METHODNM.DataPropertyName = "LRN0130_METHODNM";
            this.LRN0130_METHODNM.HeaderText = "상환방법";
            this.LRN0130_METHODNM.Name = "LRN0130_METHODNM";
            this.LRN0130_METHODNM.ReadOnly = true;
            this.LRN0130_METHODNM.Width = 76;
            // 
            // LRN0130_RELID
            // 
            this.LRN0130_RELID.DataPropertyName = "LRN0130_RELID";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = "0";
            this.LRN0130_RELID.DefaultCellStyle = dataGridViewCellStyle8;
            this.LRN0130_RELID.HeaderText = "연관번호";
            this.LRN0130_RELID.Name = "LRN0130_RELID";
            this.LRN0130_RELID.ReadOnly = true;
            this.LRN0130_RELID.Width = 76;
            // 
            // LRN0130_STR_NM
            // 
            this.LRN0130_STR_NM.DataPropertyName = "LRN0130_STR_NM";
            this.LRN0130_STR_NM.HeaderText = "가맹점명";
            this.LRN0130_STR_NM.Name = "LRN0130_STR_NM";
            this.LRN0130_STR_NM.ReadOnly = true;
            this.LRN0130_STR_NM.Width = 76;
            // 
            // LRN0130_AGTNM
            // 
            this.LRN0130_AGTNM.DataPropertyName = "LRN0130_AGTNM";
            this.LRN0130_AGTNM.HeaderText = "대리점명";
            this.LRN0130_AGTNM.Name = "LRN0130_AGTNM";
            this.LRN0130_AGTNM.ReadOnly = true;
            this.LRN0130_AGTNM.Width = 76;
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.AnimationDelay = 20;
            this.collapsibleSplitter1.AnimationStep = 20;
            this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter1.ControlToHide = this.groupBox2;
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.collapsibleSplitter1.ExpandParentForm = false;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(441, 17);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.TabIndex = 1115;
            this.collapsibleSplitter1.TabStop = false;
            this.collapsibleSplitter1.UseAnimations = false;
            this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this._btnSave);
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.Location = new System.Drawing.Point(447, 57);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(698, 613);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "상세 정보";
            // 
            // _btnSave
            // 
            this._btnSave.ButtonConfirm = true;
            this._btnSave.DelegateProperty = true;
            this._btnSave.Enabled = false;
            this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave.Location = new System.Drawing.Point(611, 174);
            this._btnSave.Name = "_btnSave";
            this._btnSave.Reserved = "      저   장";
            this._btnSave.Size = new System.Drawing.Size(75, 27);
            this._btnSave.TabIndex = 1112;
            this._btnSave.Text = "      저   장";
            this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave.UseVisualStyleBackColor = true;
            this._btnSave.ValidationGroup = "a";
            this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 119F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 114F));
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this._txtTOTAMT, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtCDLYINTST, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this._txtNONINTST, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this._txtNONPRCP, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this._txtRTNINTST, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtRTNPRCP, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtPRINCIPAL, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label9, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtRPYSEQ, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this._txtIDX, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this._dtpRPYDT, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label13, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this._cmbMETHOD, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this._txtDLYINTST, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtINTEREST, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label101, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(692, 147);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox1.DelegateProperty = true;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox1.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this.textBox1.Location = new System.Drawing.Point(344, 111);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(113, 20);
            this.textBox1.TabIndex = 1140;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.ValidationGroup = "a";
            this.textBox1.WaterMarkColor = System.Drawing.Color.Silver;
            this.textBox1.WaterMarkText = "";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(273, 115);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 1139;
            this.label10.Text = "연관아이디";
            // 
            // _txtTOTAMT
            // 
            this._txtTOTAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTOTAMT.DelegateProperty = true;
            this._txtTOTAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTOTAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtTOTAMT.Location = new System.Drawing.Point(579, 30);
            this._txtTOTAMT.Name = "_txtTOTAMT";
            this._txtTOTAMT.ReadOnly = true;
            this._txtTOTAMT.Size = new System.Drawing.Size(110, 20);
            this._txtTOTAMT.TabIndex = 1138;
            this._txtTOTAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtTOTAMT.ValidationGroup = "a";
            this._txtTOTAMT.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTOTAMT.WaterMarkText = "";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(496, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 1137;
            this.label7.Text = "상환금액합계";
            // 
            // _txtCDLYINTST
            // 
            this._txtCDLYINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCDLYINTST.DelegateProperty = true;
            this._txtCDLYINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCDLYINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCDLYINTST.Location = new System.Drawing.Point(579, 84);
            this._txtCDLYINTST.Name = "_txtCDLYINTST";
            this._txtCDLYINTST.ReadOnly = true;
            this._txtCDLYINTST.Size = new System.Drawing.Size(110, 20);
            this._txtCDLYINTST.TabIndex = 1136;
            this._txtCDLYINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCDLYINTST.ValidationGroup = "a";
            this._txtCDLYINTST.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCDLYINTST.WaterMarkText = "";
            // 
            // _txtNONINTST
            // 
            this._txtNONINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtNONINTST.DelegateProperty = true;
            this._txtNONINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtNONINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtNONINTST.Location = new System.Drawing.Point(344, 84);
            this._txtNONINTST.Name = "_txtNONINTST";
            this._txtNONINTST.ReadOnly = true;
            this._txtNONINTST.Size = new System.Drawing.Size(113, 20);
            this._txtNONINTST.TabIndex = 1135;
            this._txtNONINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtNONINTST.ValidationGroup = "a";
            this._txtNONINTST.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtNONINTST.WaterMarkText = "";
            // 
            // _txtNONPRCP
            // 
            this._txtNONPRCP.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtNONPRCP.DelegateProperty = true;
            this._txtNONPRCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtNONPRCP.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtNONPRCP.Location = new System.Drawing.Point(110, 84);
            this._txtNONPRCP.Name = "_txtNONPRCP";
            this._txtNONPRCP.ReadOnly = true;
            this._txtNONPRCP.Size = new System.Drawing.Size(113, 20);
            this._txtNONPRCP.TabIndex = 1134;
            this._txtNONPRCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtNONPRCP.ValidationGroup = "a";
            this._txtNONPRCP.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtNONPRCP.WaterMarkText = "";
            // 
            // _txtRTNINTST
            // 
            this._txtRTNINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtRTNINTST.DelegateProperty = true;
            this._txtRTNINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtRTNINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtRTNINTST.Location = new System.Drawing.Point(344, 57);
            this._txtRTNINTST.Name = "_txtRTNINTST";
            this._txtRTNINTST.ReadOnly = true;
            this._txtRTNINTST.Size = new System.Drawing.Size(113, 20);
            this._txtRTNINTST.TabIndex = 1133;
            this._txtRTNINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtRTNINTST.ValidationGroup = "a";
            this._txtRTNINTST.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtRTNINTST.WaterMarkText = "";
            // 
            // _txtRTNPRCP
            // 
            this._txtRTNPRCP.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtRTNPRCP.DelegateProperty = true;
            this._txtRTNPRCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtRTNPRCP.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtRTNPRCP.Location = new System.Drawing.Point(110, 57);
            this._txtRTNPRCP.Name = "_txtRTNPRCP";
            this._txtRTNPRCP.ReadOnly = true;
            this._txtRTNPRCP.Size = new System.Drawing.Size(113, 20);
            this._txtRTNPRCP.TabIndex = 1132;
            this._txtRTNPRCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtRTNPRCP.ValidationGroup = "a";
            this._txtRTNPRCP.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtRTNPRCP.WaterMarkText = "";
            // 
            // _txtPRINCIPAL
            // 
            this._txtPRINCIPAL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPRINCIPAL.DelegateProperty = true;
            this._txtPRINCIPAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPRINCIPAL.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtPRINCIPAL.Location = new System.Drawing.Point(110, 30);
            this._txtPRINCIPAL.Name = "_txtPRINCIPAL";
            this._txtPRINCIPAL.ReadOnly = true;
            this._txtPRINCIPAL.Size = new System.Drawing.Size(113, 20);
            this._txtPRINCIPAL.TabIndex = 1131;
            this._txtPRINCIPAL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtPRINCIPAL.ValidationGroup = "a";
            this._txtPRINCIPAL.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPRINCIPAL.WaterMarkText = "";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(496, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 1130;
            this.label9.Text = "미수연체이자";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(285, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 1129;
            this.label8.Text = "미수이자";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 1128;
            this.label3.Text = "상환방법";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 1127;
            this.label2.Text = "상환대상원금";
            // 
            // _txtRPYSEQ
            // 
            this._txtRPYSEQ.DelegateProperty = true;
            this._txtRPYSEQ.Dock = System.Windows.Forms.DockStyle.Fill;
            this._txtRPYSEQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtRPYSEQ.Location = new System.Drawing.Point(344, 3);
            this._txtRPYSEQ.Name = "_txtRPYSEQ";
            this._txtRPYSEQ.ReadOnly = true;
            this._txtRPYSEQ.Size = new System.Drawing.Size(113, 20);
            this._txtRPYSEQ.TabIndex = 1126;
            this._txtRPYSEQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtRPYSEQ.ValidationGroup = "a";
            this._txtRPYSEQ.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtRPYSEQ.WaterMarkText = "";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(285, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 1125;
            this.label5.Text = "상환회차";
            // 
            // _txtIDX
            // 
            this._txtIDX.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtIDX.DelegateProperty = true;
            this._txtIDX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtIDX.Location = new System.Drawing.Point(110, 3);
            this._txtIDX.Name = "_txtIDX";
            this._txtIDX.ReadOnly = true;
            this._txtIDX.Size = new System.Drawing.Size(113, 20);
            this._txtIDX.TabIndex = 1124;
            this._txtIDX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtIDX.ValidationGroup = "a";
            this._txtIDX.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtIDX.WaterMarkText = "";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 1123;
            this.label4.Text = "대출원장번호";
            // 
            // _dtpRPYDT
            // 
            this._dtpRPYDT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpRPYDT.Checked = false;
            this._dtpRPYDT.CustomFormat = "yyyy-MM-dd";
            this._dtpRPYDT.DelegateProperty = true;
            this._dtpRPYDT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpRPYDT.Location = new System.Drawing.Point(579, 3);
            this._dtpRPYDT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpRPYDT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpRPYDT.Name = "_dtpRPYDT";
            this._dtpRPYDT.Size = new System.Drawing.Size(110, 20);
            this._dtpRPYDT.TabIndex = 1115;
            this._dtpRPYDT.ValidationGroup = "a";
            this._dtpRPYDT.Value = new System.DateTime(2014, 7, 25, 10, 20, 16, 341);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(496, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 1114;
            this.label13.Text = "상환연체이자";
            // 
            // _cmbMETHOD
            // 
            this._cmbMETHOD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._cmbMETHOD.Compulsory = true;
            this._cmbMETHOD.DataSource = null;
            this._cmbMETHOD.DelegateProperty = true;
            this._cmbMETHOD.DroppedDown = false;
            this._cmbMETHOD.Location = new System.Drawing.Point(110, 111);
            this._cmbMETHOD.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbMETHOD.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbMETHOD.Name = "_cmbMETHOD";
            this._cmbMETHOD.SelectedIndex = -1;
            this._cmbMETHOD.SelectedItem = null;
            this._cmbMETHOD.SelectedValue = null;
            this._cmbMETHOD.Size = new System.Drawing.Size(113, 21);
            this._cmbMETHOD.TabIndex = 1114;
            this._cmbMETHOD.ValidationGroup = "a";
            // 
            // _txtDLYINTST
            // 
            this._txtDLYINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtDLYINTST.DelegateProperty = true;
            this._txtDLYINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtDLYINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtDLYINTST.Location = new System.Drawing.Point(579, 57);
            this._txtDLYINTST.Name = "_txtDLYINTST";
            this._txtDLYINTST.ReadOnly = true;
            this._txtDLYINTST.Size = new System.Drawing.Size(110, 20);
            this._txtDLYINTST.TabIndex = 1071;
            this._txtDLYINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtDLYINTST.ValidationGroup = null;
            this._txtDLYINTST.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtDLYINTST.WaterMarkText = "";
            // 
            // _txtINTEREST
            // 
            this._txtINTEREST.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtINTEREST.DelegateProperty = true;
            this._txtINTEREST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtINTEREST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtINTEREST.Location = new System.Drawing.Point(344, 30);
            this._txtINTEREST.Name = "_txtINTEREST";
            this._txtINTEREST.ReadOnly = true;
            this._txtINTEREST.Size = new System.Drawing.Size(113, 20);
            this._txtINTEREST.TabIndex = 1010;
            this._txtINTEREST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtINTEREST.ValidationGroup = "a";
            this._txtINTEREST.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtINTEREST.WaterMarkText = "";
            // 
            // label101
            // 
            this.label101.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(51, 61);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(53, 12);
            this.label101.TabIndex = 0;
            this.label101.Text = "상환원금";
            // 
            // lblUSR_ID
            // 
            this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblUSR_ID.AutoSize = true;
            this.lblUSR_ID.Location = new System.Drawing.Point(520, 7);
            this.lblUSR_ID.Name = "lblUSR_ID";
            this.lblUSR_ID.Size = new System.Drawing.Size(53, 12);
            this.lblUSR_ID.TabIndex = 2;
            this.lblUSR_ID.Text = "상환일자";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(261, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "상환대상이자";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(285, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 34;
            this.label11.Text = "상환이자";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(51, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 32;
            this.label14.Text = "미수원금";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel6);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1145, 57);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "검색 조건";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 11;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 207F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 78F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 508F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Controls.Add(this._txtRPYSEQ_E, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this._txtRPYSEQ_S, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 9, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 8, 0);
            this.tableLayoutPanel6.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this._btnSearch, 6, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 37);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // _txtRPYSEQ_E
            // 
            this._txtRPYSEQ_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtRPYSEQ_E.AutoTab = false;
            this._txtRPYSEQ_E.DelegateProperty = true;
            this._txtRPYSEQ_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtRPYSEQ_E.Location = new System.Drawing.Point(233, 5);
            this._txtRPYSEQ_E.Name = "_txtRPYSEQ_E";
            this._txtRPYSEQ_E.Size = new System.Drawing.Size(103, 20);
            this._txtRPYSEQ_E.TabIndex = 1120;
            this._txtRPYSEQ_E.ValidationGroup = null;
            this._txtRPYSEQ_E.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtRPYSEQ_E.WaterMarkText = "";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(213, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 12);
            this.label1.TabIndex = 1119;
            this.label1.Text = "~";
            // 
            // _txtRPYSEQ_S
            // 
            this._txtRPYSEQ_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtRPYSEQ_S.AutoTab = false;
            this._txtRPYSEQ_S.DelegateProperty = true;
            this._txtRPYSEQ_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtRPYSEQ_S.Location = new System.Drawing.Point(93, 5);
            this._txtRPYSEQ_S.Name = "_txtRPYSEQ_S";
            this._txtRPYSEQ_S.Size = new System.Drawing.Size(103, 20);
            this._txtRPYSEQ_S.TabIndex = 1118;
            this._txtRPYSEQ_S.ValidationGroup = null;
            this._txtRPYSEQ_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtRPYSEQ_S.WaterMarkText = "";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(1228, 0);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(55, 30);
            this.flowLayoutPanel4.TabIndex = 160;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(720, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(508, 30);
            this.flowLayoutPanel1.TabIndex = 120;
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(58, 9);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(29, 12);
            this.label37.TabIndex = 1116;
            this.label37.Text = "회차";
            // 
            // _btnSearch
            // 
            this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(567, 1);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Reserved = "      검   색";
            this._btnSearch.Size = new System.Drawing.Size(75, 27);
            this._btnSearch.TabIndex = 1117;
            this._btnSearch.Text = "      검   색";
            this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
            // 
            // LRN0130
            // 
            this.ClientSize = new System.Drawing.Size(1145, 670);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LRN0130";
            this.Text = "비즈론상환내역관리:LRN0130";
            this.Load += new System.EventHandler(this.LRN0130_Load);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.Label label37;
        private BANANA.Windows.Controls.GroupBox groupBox3;
        private DemoClient.Controls.BananaButton _btnSearch;
        private System.Windows.Forms.GroupBox groupBox2;
        private DemoClient.Controls.BananaButton _btnSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private BANANA.Windows.Controls.DateTimePicker _dtpRPYDT;
        private System.Windows.Forms.Label label13;
        private BANANA.Windows.Controls.ComboBox _cmbMETHOD;
        private BANANA.Windows.Controls.TextBox _txtDLYINTST;
        private BANANA.Windows.Controls.TextBox _txtINTEREST;
        private BANANA.Windows.Controls.Label label101;
        private BANANA.Windows.Controls.Label lblUSR_ID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
        private BANANA.Windows.Controls.TextBox _txtRPYSEQ;
        private BANANA.Windows.Controls.Label label5;
        private BANANA.Windows.Controls.TextBox _txtIDX;
        private BANANA.Windows.Controls.Label label4;
        private BANANA.Windows.Controls.TextBox _txtRPYSEQ_S;
        private DemoClient.Controls.GridView gridView1;
        private BANANA.Windows.Controls.TextBox _txtRPYSEQ_E;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.TextBox _txtCDLYINTST;
        private BANANA.Windows.Controls.TextBox _txtNONINTST;
        private BANANA.Windows.Controls.TextBox _txtNONPRCP;
        private BANANA.Windows.Controls.TextBox _txtRTNINTST;
        private BANANA.Windows.Controls.TextBox _txtRTNPRCP;
        private BANANA.Windows.Controls.TextBox _txtPRINCIPAL;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private BANANA.Windows.Controls.TextBox textBox1;
        private System.Windows.Forms.Label label10;
        private BANANA.Windows.Controls.TextBox _txtTOTAMT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_IDX;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_RPYSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_RPYDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_PRINCIPAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_INTEREST;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_DLYINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_TOTAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_METHODNM;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_RELID;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_STR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn LRN0130_AGTNM;
    }
}
