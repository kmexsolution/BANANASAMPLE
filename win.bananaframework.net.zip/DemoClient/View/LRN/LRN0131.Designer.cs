﻿namespace DemoClient.View.LRN
{
    partial class LRN0131
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LRN0131));
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RPYSEQ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RPYDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RPYAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.PRINCIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.INTEREST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ODLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NONPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NONINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVERDUEYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TOTPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RESTPRCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RPYYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this._btnSave = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this._txtLNMNT = new BANANA.Windows.Controls.TextBox();
			this.label3 = new BANANA.Windows.Controls.Label();
			this._txtINAMT = new BANANA.Windows.Controls.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this._txtTOTAMT = new BANANA.Windows.Controls.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this._txtCDLYINTST = new BANANA.Windows.Controls.TextBox();
			this._txtNONINTST = new BANANA.Windows.Controls.TextBox();
			this._txtNONPRCP = new BANANA.Windows.Controls.TextBox();
			this._txtRTNINTST = new BANANA.Windows.Controls.TextBox();
			this._txtRTNPRCP = new BANANA.Windows.Controls.TextBox();
			this._txtPRINCIPAL = new BANANA.Windows.Controls.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this._txtIDX = new BANANA.Windows.Controls.TextBox();
			this.label4 = new BANANA.Windows.Controls.Label();
			this.label13 = new System.Windows.Forms.Label();
			this._txtDLYINTST = new BANANA.Windows.Controls.TextBox();
			this._txtINTEREST = new BANANA.Windows.Controls.TextBox();
			this.label101 = new BANANA.Windows.Controls.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
			this._txtRPYSEQ_E = new BANANA.Windows.Controls.TextBox();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._txtRPYSEQ_S = new BANANA.Windows.Controls.TextBox();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.label37 = new BANANA.Windows.Controls.Label();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView1);
			this.groupBox3.Controls.Add(this.collapsibleSplitter1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(0, 57);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(447, 613);
			this.groupBox3.TabIndex = 31;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "상환내역목록";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.RPYSEQ,
            this.RPYDT,
            this.RPYAMT,
            this.PRINCIPAL,
            this.INTEREST,
            this.ODLYINTST,
            this.RTNPRCP,
            this.RTNINTST,
            this.RTNDLYINTST,
            this.NONPRCP,
            this.NONINTST,
            this.CDLYINTST,
            this.OVERDUEYN,
            this.TOTPRCP,
            this.RESTPRCP,
            this.RPYYN});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 21);
			this.gridView1.MultiSelect = false;
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.RowTemplate.Height = 23;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(433, 589);
			this.gridView1.TabIndex = 1116;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			// 
			// dataGridViewTextBoxColumn4
			// 
			this.dataGridViewTextBoxColumn4.DataPropertyName = "STR_NM";
			this.dataGridViewTextBoxColumn4.Frozen = true;
			this.dataGridViewTextBoxColumn4.HeaderText = "가맹점명";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			this.dataGridViewTextBoxColumn4.ReadOnly = true;
			this.dataGridViewTextBoxColumn4.Width = 94;
			// 
			// RPYSEQ
			// 
			this.RPYSEQ.DataPropertyName = "RPYSEQ";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.Format = "N0";
			dataGridViewCellStyle2.NullValue = "0";
			this.RPYSEQ.DefaultCellStyle = dataGridViewCellStyle2;
			this.RPYSEQ.Frozen = true;
			this.RPYSEQ.HeaderText = "회차";
			this.RPYSEQ.Name = "RPYSEQ";
			this.RPYSEQ.ReadOnly = true;
			this.RPYSEQ.Width = 66;
			// 
			// RPYDT
			// 
			this.RPYDT.DataPropertyName = "RPYDT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.NullValue = null;
			this.RPYDT.DefaultCellStyle = dataGridViewCellStyle3;
			this.RPYDT.Frozen = true;
			this.RPYDT.HeaderText = "예정일";
			this.RPYDT.Name = "RPYDT";
			this.RPYDT.ReadOnly = true;
			this.RPYDT.Width = 80;
			// 
			// RPYAMT
			// 
			this.RPYAMT.DataPropertyName = "RPYAMT";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = "0";
			this.RPYAMT.DefaultCellStyle = dataGridViewCellStyle4;
			this.RPYAMT.HeaderText = "원리금";
			this.RPYAMT.Name = "RPYAMT";
			this.RPYAMT.ReadOnly = true;
			this.RPYAMT.Width = 80;
			// 
			// PRINCIPAL
			// 
			this.PRINCIPAL.DataPropertyName = "PRINCIPAL";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			dataGridViewCellStyle5.NullValue = "0";
			this.PRINCIPAL.DefaultCellStyle = dataGridViewCellStyle5;
			this.PRINCIPAL.HeaderText = "원금";
			this.PRINCIPAL.Name = "PRINCIPAL";
			this.PRINCIPAL.ReadOnly = true;
			this.PRINCIPAL.Width = 66;
			// 
			// INTEREST
			// 
			this.INTEREST.DataPropertyName = "INTEREST";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			dataGridViewCellStyle6.NullValue = "0";
			this.INTEREST.DefaultCellStyle = dataGridViewCellStyle6;
			this.INTEREST.HeaderText = "이자";
			this.INTEREST.Name = "INTEREST";
			this.INTEREST.ReadOnly = true;
			this.INTEREST.Width = 66;
			// 
			// ODLYINTST
			// 
			this.ODLYINTST.DataPropertyName = "ODLYINTST";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			dataGridViewCellStyle7.NullValue = "0";
			this.ODLYINTST.DefaultCellStyle = dataGridViewCellStyle7;
			this.ODLYINTST.HeaderText = "연체이자[누적]";
			this.ODLYINTST.Name = "ODLYINTST";
			this.ODLYINTST.ReadOnly = true;
			this.ODLYINTST.Width = 132;
			// 
			// RTNPRCP
			// 
			this.RTNPRCP.DataPropertyName = "RTNPRCP";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			dataGridViewCellStyle8.NullValue = "0";
			this.RTNPRCP.DefaultCellStyle = dataGridViewCellStyle8;
			this.RTNPRCP.HeaderText = "상환원금";
			this.RTNPRCP.Name = "RTNPRCP";
			this.RTNPRCP.ReadOnly = true;
			this.RTNPRCP.Width = 94;
			// 
			// RTNINTST
			// 
			this.RTNINTST.DataPropertyName = "RTNINTST";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N0";
			dataGridViewCellStyle9.NullValue = "0";
			this.RTNINTST.DefaultCellStyle = dataGridViewCellStyle9;
			this.RTNINTST.HeaderText = "상환이자";
			this.RTNINTST.Name = "RTNINTST";
			this.RTNINTST.ReadOnly = true;
			this.RTNINTST.Width = 94;
			// 
			// RTNDLYINTST
			// 
			this.RTNDLYINTST.DataPropertyName = "RTNDLYINTST";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N0";
			dataGridViewCellStyle10.NullValue = "0";
			this.RTNDLYINTST.DefaultCellStyle = dataGridViewCellStyle10;
			this.RTNDLYINTST.HeaderText = "상환연체이자";
			this.RTNDLYINTST.Name = "RTNDLYINTST";
			this.RTNDLYINTST.ReadOnly = true;
			this.RTNDLYINTST.Width = 122;
			// 
			// NONPRCP
			// 
			this.NONPRCP.DataPropertyName = "NONPRCP";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle11.Format = "N0";
			dataGridViewCellStyle11.NullValue = "0";
			this.NONPRCP.DefaultCellStyle = dataGridViewCellStyle11;
			this.NONPRCP.HeaderText = "미수원금";
			this.NONPRCP.Name = "NONPRCP";
			this.NONPRCP.ReadOnly = true;
			this.NONPRCP.Width = 94;
			// 
			// NONINTST
			// 
			this.NONINTST.DataPropertyName = "NONINTST";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle12.Format = "N0";
			dataGridViewCellStyle12.NullValue = "0";
			this.NONINTST.DefaultCellStyle = dataGridViewCellStyle12;
			this.NONINTST.HeaderText = "미수이자";
			this.NONINTST.Name = "NONINTST";
			this.NONINTST.ReadOnly = true;
			this.NONINTST.Width = 94;
			// 
			// CDLYINTST
			// 
			this.CDLYINTST.DataPropertyName = "CDLYINTST";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle13.Format = "N0";
			dataGridViewCellStyle13.NullValue = "0";
			this.CDLYINTST.DefaultCellStyle = dataGridViewCellStyle13;
			this.CDLYINTST.HeaderText = "미수연체이자";
			this.CDLYINTST.Name = "CDLYINTST";
			this.CDLYINTST.ReadOnly = true;
			this.CDLYINTST.Width = 122;
			// 
			// OVERDUEYN
			// 
			this.OVERDUEYN.DataPropertyName = "OVERDUEYN";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.OVERDUEYN.DefaultCellStyle = dataGridViewCellStyle14;
			this.OVERDUEYN.HeaderText = "연체여부";
			this.OVERDUEYN.Name = "OVERDUEYN";
			this.OVERDUEYN.ReadOnly = true;
			this.OVERDUEYN.Width = 94;
			// 
			// TOTPRCP
			// 
			this.TOTPRCP.DataPropertyName = "TOTPRCP";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle15.Format = "N0";
			dataGridViewCellStyle15.NullValue = "0";
			this.TOTPRCP.DefaultCellStyle = dataGridViewCellStyle15;
			this.TOTPRCP.HeaderText = "납입원금합계";
			this.TOTPRCP.Name = "TOTPRCP";
			this.TOTPRCP.ReadOnly = true;
			this.TOTPRCP.Width = 122;
			// 
			// RESTPRCP
			// 
			this.RESTPRCP.DataPropertyName = "RESTPRCP";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle16.Format = "N0";
			dataGridViewCellStyle16.NullValue = "0";
			this.RESTPRCP.DefaultCellStyle = dataGridViewCellStyle16;
			this.RESTPRCP.HeaderText = "대출잔액";
			this.RESTPRCP.Name = "RESTPRCP";
			this.RESTPRCP.ReadOnly = true;
			this.RESTPRCP.Width = 94;
			// 
			// RPYYN
			// 
			this.RPYYN.DataPropertyName = "RPYYN";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.RPYYN.DefaultCellStyle = dataGridViewCellStyle17;
			this.RPYYN.HeaderText = "종료여부";
			this.RPYYN.Name = "RPYYN";
			this.RPYYN.ReadOnly = true;
			this.RPYYN.Width = 94;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.groupBox2;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(436, 21);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 1115;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this._btnSave);
			this.groupBox2.Controls.Add(this.tableLayoutPanel1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
			this.groupBox2.Location = new System.Drawing.Point(447, 57);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(698, 613);
			this.groupBox2.TabIndex = 34;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "상환 대상 정보(합계)";
			// 
			// _btnSave
			// 
			this._btnSave.ButtonConfirm = true;
			this._btnSave.DelegateProperty = true;
			this._btnSave.Enabled = false;
			this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.Location = new System.Drawing.Point(611, 207);
			this._btnSave.Name = "_btnSave";
			this._btnSave.Reserved = "      저   장";
			this._btnSave.Size = new System.Drawing.Size(75, 27);
			this._btnSave.TabIndex = 1112;
			this._btnSave.Text = "      저   장";
			this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.UseVisualStyleBackColor = true;
			this._btnSave.ValidationGroup = "a";
			this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 6;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 119F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 114F));
			this.tableLayoutPanel1.Controls.Add(this._txtLNMNT, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this._txtINAMT, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this.label12, 0, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtTOTAMT, 5, 1);
			this.tableLayoutPanel1.Controls.Add(this.label7, 4, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtCDLYINTST, 5, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtNONINTST, 3, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtNONPRCP, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtRTNINTST, 3, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtRTNPRCP, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtPRINCIPAL, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.label9, 4, 3);
			this.tableLayoutPanel1.Controls.Add(this.label8, 2, 3);
			this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtIDX, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.label13, 4, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtDLYINTST, 5, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this.label101, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.label6, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.label11, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.label14, 0, 3);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 6;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(692, 149);
			this.tableLayoutPanel1.TabIndex = 1;
			// 
			// _txtLNMNT
			// 
			this._txtLNMNT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtLNMNT.DelegateProperty = true;
			this._txtLNMNT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtLNMNT.Location = new System.Drawing.Point(344, 3);
			this._txtLNMNT.Name = "_txtLNMNT";
			this._txtLNMNT.ReadOnly = true;
			this._txtLNMNT.Size = new System.Drawing.Size(113, 23);
			this._txtLNMNT.TabIndex = 1144;
			this._txtLNMNT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtLNMNT.ValidationGroup = "a";
			this._txtLNMNT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtLNMNT.WaterMarkText = "";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(271, 6);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(67, 15);
			this.label3.TabIndex = 1143;
			this.label3.Text = "대출일수";
			// 
			// _txtINAMT
			// 
			this._txtINAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINAMT.Compulsory = true;
			this._txtINAMT.DelegateProperty = true;
			this._txtINAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtINAMT.Location = new System.Drawing.Point(110, 111);
			this._txtINAMT.Name = "_txtINAMT";
			this._txtINAMT.Size = new System.Drawing.Size(113, 23);
			this._txtINAMT.TabIndex = 1142;
			this._txtINAMT.Text = "0";
			this._txtINAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINAMT.ValidationGroup = "a";
			this._txtINAMT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINAMT.WaterMarkText = "";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(37, 114);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(67, 15);
			this.label12.TabIndex = 1141;
			this.label12.Text = "입금금액";
			// 
			// _txtTOTAMT
			// 
			this._txtTOTAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtTOTAMT.DelegateProperty = true;
			this._txtTOTAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtTOTAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtTOTAMT.Location = new System.Drawing.Point(579, 30);
			this._txtTOTAMT.Name = "_txtTOTAMT";
			this._txtTOTAMT.ReadOnly = true;
			this._txtTOTAMT.Size = new System.Drawing.Size(110, 23);
			this._txtTOTAMT.TabIndex = 1138;
			this._txtTOTAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtTOTAMT.ValidationGroup = "a";
			this._txtTOTAMT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtTOTAMT.WaterMarkText = "";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(476, 33);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(97, 15);
			this.label7.TabIndex = 1137;
			this.label7.Text = "상환금액합계";
			// 
			// _txtCDLYINTST
			// 
			this._txtCDLYINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCDLYINTST.DelegateProperty = true;
			this._txtCDLYINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCDLYINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtCDLYINTST.Location = new System.Drawing.Point(579, 84);
			this._txtCDLYINTST.Name = "_txtCDLYINTST";
			this._txtCDLYINTST.ReadOnly = true;
			this._txtCDLYINTST.Size = new System.Drawing.Size(110, 23);
			this._txtCDLYINTST.TabIndex = 1136;
			this._txtCDLYINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCDLYINTST.ValidationGroup = "a";
			this._txtCDLYINTST.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCDLYINTST.WaterMarkText = "";
			// 
			// _txtNONINTST
			// 
			this._txtNONINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtNONINTST.DelegateProperty = true;
			this._txtNONINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtNONINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtNONINTST.Location = new System.Drawing.Point(344, 84);
			this._txtNONINTST.Name = "_txtNONINTST";
			this._txtNONINTST.ReadOnly = true;
			this._txtNONINTST.Size = new System.Drawing.Size(113, 23);
			this._txtNONINTST.TabIndex = 1135;
			this._txtNONINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtNONINTST.ValidationGroup = "a";
			this._txtNONINTST.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtNONINTST.WaterMarkText = "";
			// 
			// _txtNONPRCP
			// 
			this._txtNONPRCP.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtNONPRCP.DelegateProperty = true;
			this._txtNONPRCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtNONPRCP.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtNONPRCP.Location = new System.Drawing.Point(110, 84);
			this._txtNONPRCP.Name = "_txtNONPRCP";
			this._txtNONPRCP.ReadOnly = true;
			this._txtNONPRCP.Size = new System.Drawing.Size(113, 23);
			this._txtNONPRCP.TabIndex = 1134;
			this._txtNONPRCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtNONPRCP.ValidationGroup = "a";
			this._txtNONPRCP.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtNONPRCP.WaterMarkText = "";
			// 
			// _txtRTNINTST
			// 
			this._txtRTNINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtRTNINTST.DelegateProperty = true;
			this._txtRTNINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtRTNINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtRTNINTST.Location = new System.Drawing.Point(344, 57);
			this._txtRTNINTST.Name = "_txtRTNINTST";
			this._txtRTNINTST.ReadOnly = true;
			this._txtRTNINTST.Size = new System.Drawing.Size(113, 23);
			this._txtRTNINTST.TabIndex = 1133;
			this._txtRTNINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtRTNINTST.ValidationGroup = "a";
			this._txtRTNINTST.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtRTNINTST.WaterMarkText = "";
			// 
			// _txtRTNPRCP
			// 
			this._txtRTNPRCP.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtRTNPRCP.DelegateProperty = true;
			this._txtRTNPRCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtRTNPRCP.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtRTNPRCP.Location = new System.Drawing.Point(110, 57);
			this._txtRTNPRCP.Name = "_txtRTNPRCP";
			this._txtRTNPRCP.ReadOnly = true;
			this._txtRTNPRCP.Size = new System.Drawing.Size(113, 23);
			this._txtRTNPRCP.TabIndex = 1132;
			this._txtRTNPRCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtRTNPRCP.ValidationGroup = "a";
			this._txtRTNPRCP.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtRTNPRCP.WaterMarkText = "";
			// 
			// _txtPRINCIPAL
			// 
			this._txtPRINCIPAL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPRINCIPAL.DelegateProperty = true;
			this._txtPRINCIPAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPRINCIPAL.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtPRINCIPAL.Location = new System.Drawing.Point(110, 30);
			this._txtPRINCIPAL.Name = "_txtPRINCIPAL";
			this._txtPRINCIPAL.ReadOnly = true;
			this._txtPRINCIPAL.Size = new System.Drawing.Size(113, 23);
			this._txtPRINCIPAL.TabIndex = 1131;
			this._txtPRINCIPAL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtPRINCIPAL.ValidationGroup = "a";
			this._txtPRINCIPAL.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPRINCIPAL.WaterMarkText = "";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(476, 87);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(97, 15);
			this.label9.TabIndex = 1130;
			this.label9.Text = "미수연체이자";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(271, 87);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(67, 15);
			this.label8.TabIndex = 1129;
			this.label8.Text = "미수이자";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(7, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(97, 15);
			this.label2.TabIndex = 1127;
			this.label2.Text = "상환대상원금";
			// 
			// _txtIDX
			// 
			this._txtIDX.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtIDX.DelegateProperty = true;
			this._txtIDX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtIDX.Location = new System.Drawing.Point(110, 3);
			this._txtIDX.Name = "_txtIDX";
			this._txtIDX.ReadOnly = true;
			this._txtIDX.Size = new System.Drawing.Size(113, 23);
			this._txtIDX.TabIndex = 1124;
			this._txtIDX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtIDX.ValidationGroup = "a";
			this._txtIDX.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtIDX.WaterMarkText = "";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(7, 6);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(97, 15);
			this.label4.TabIndex = 1123;
			this.label4.Text = "대출원장번호";
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(476, 60);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(97, 15);
			this.label13.TabIndex = 1114;
			this.label13.Text = "상환연체이자";
			// 
			// _txtDLYINTST
			// 
			this._txtDLYINTST.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtDLYINTST.DelegateProperty = true;
			this._txtDLYINTST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtDLYINTST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtDLYINTST.Location = new System.Drawing.Point(579, 57);
			this._txtDLYINTST.Name = "_txtDLYINTST";
			this._txtDLYINTST.ReadOnly = true;
			this._txtDLYINTST.Size = new System.Drawing.Size(110, 23);
			this._txtDLYINTST.TabIndex = 1071;
			this._txtDLYINTST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtDLYINTST.ValidationGroup = null;
			this._txtDLYINTST.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtDLYINTST.WaterMarkText = "";
			// 
			// _txtINTEREST
			// 
			this._txtINTEREST.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST.DelegateProperty = true;
			this._txtINTEREST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtINTEREST.Location = new System.Drawing.Point(344, 30);
			this._txtINTEREST.Name = "_txtINTEREST";
			this._txtINTEREST.ReadOnly = true;
			this._txtINTEREST.Size = new System.Drawing.Size(113, 23);
			this._txtINTEREST.TabIndex = 1010;
			this._txtINTEREST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST.ValidationGroup = "a";
			this._txtINTEREST.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST.WaterMarkText = "";
			// 
			// label101
			// 
			this.label101.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label101.AutoSize = true;
			this.label101.Location = new System.Drawing.Point(37, 60);
			this.label101.Name = "label101";
			this.label101.Size = new System.Drawing.Size(67, 15);
			this.label101.TabIndex = 0;
			this.label101.Text = "상환원금";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(241, 33);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(97, 15);
			this.label6.TabIndex = 9;
			this.label6.Text = "상환대상이자";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(271, 60);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(67, 15);
			this.label11.TabIndex = 34;
			this.label11.Text = "상환이자";
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(37, 87);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(67, 15);
			this.label14.TabIndex = 32;
			this.label14.Text = "미수원금";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1145, 57);
			this.groupBox1.TabIndex = 30;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.ColumnCount = 11;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 29F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 207F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 78F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 508F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel6.Controls.Add(this._txtRPYSEQ_E, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this.label1, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtRPYSEQ_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 9, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 8, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this._btnSearch, 6, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 2;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 33);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// _txtRPYSEQ_E
			// 
			this._txtRPYSEQ_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtRPYSEQ_E.AutoTab = false;
			this._txtRPYSEQ_E.DelegateProperty = true;
			this._txtRPYSEQ_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtRPYSEQ_E.Location = new System.Drawing.Point(233, 3);
			this._txtRPYSEQ_E.Name = "_txtRPYSEQ_E";
			this._txtRPYSEQ_E.Size = new System.Drawing.Size(103, 23);
			this._txtRPYSEQ_E.TabIndex = 1120;
			this._txtRPYSEQ_E.ValidationGroup = null;
			this._txtRPYSEQ_E.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtRPYSEQ_E.WaterMarkText = "";
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(209, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(18, 15);
			this.label1.TabIndex = 1119;
			this.label1.Text = "~";
			// 
			// _txtRPYSEQ_S
			// 
			this._txtRPYSEQ_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtRPYSEQ_S.AutoTab = false;
			this._txtRPYSEQ_S.DelegateProperty = true;
			this._txtRPYSEQ_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtRPYSEQ_S.Location = new System.Drawing.Point(93, 3);
			this._txtRPYSEQ_S.Name = "_txtRPYSEQ_S";
			this._txtRPYSEQ_S.Size = new System.Drawing.Size(103, 23);
			this._txtRPYSEQ_S.TabIndex = 1118;
			this._txtRPYSEQ_S.ValidationGroup = null;
			this._txtRPYSEQ_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtRPYSEQ_S.WaterMarkText = "";
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(1228, 0);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(55, 30);
			this.flowLayoutPanel4.TabIndex = 160;
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(720, 0);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(508, 30);
			this.flowLayoutPanel1.TabIndex = 120;
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(50, 7);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(37, 15);
			this.label37.TabIndex = 1116;
			this.label37.Text = "회차";
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(567, 1);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 27);
			this._btnSearch.TabIndex = 1117;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// LRN0131
			// 
			this.ClientSize = new System.Drawing.Size(1145, 670);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "LRN0131";
			this.Text = "비즈론상환수기입금처리:LRN0131";
			this.Load += new System.EventHandler(this.LRN0131_Load);
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.Label label37;
        private BANANA.Windows.Controls.GroupBox groupBox3;
        private DemoClient.Controls.BananaButton _btnSearch;
        private System.Windows.Forms.GroupBox groupBox2;
        private DemoClient.Controls.BananaButton _btnSave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label13;
        private BANANA.Windows.Controls.TextBox _txtDLYINTST;
        private BANANA.Windows.Controls.TextBox _txtINTEREST;
        private BANANA.Windows.Controls.Label label101;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
        private BANANA.Windows.Controls.TextBox _txtIDX;
        private BANANA.Windows.Controls.Label label4;
        private BANANA.Windows.Controls.TextBox _txtRPYSEQ_S;
        private BANANA.Windows.Controls.TextBox _txtRPYSEQ_E;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.TextBox _txtCDLYINTST;
        private BANANA.Windows.Controls.TextBox _txtNONINTST;
        private BANANA.Windows.Controls.TextBox _txtNONPRCP;
        private BANANA.Windows.Controls.TextBox _txtRTNINTST;
        private BANANA.Windows.Controls.TextBox _txtRTNPRCP;
        private BANANA.Windows.Controls.TextBox _txtPRINCIPAL;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private BANANA.Windows.Controls.TextBox _txtTOTAMT;
        private System.Windows.Forms.Label label7;
        private BANANA.Windows.Controls.TextBox _txtINAMT;
        private System.Windows.Forms.Label label12;
        private DemoClient.Controls.GridView gridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn RPYSEQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn RPYDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn RPYAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRINCIPAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn INTEREST;
        private System.Windows.Forms.DataGridViewTextBoxColumn ODLYINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNPRCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNDLYINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn NONPRCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn NONINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn CDLYINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn OVERDUEYN;
        private System.Windows.Forms.DataGridViewTextBoxColumn TOTPRCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn RESTPRCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn RPYYN;
        private BANANA.Windows.Controls.TextBox _txtLNMNT;
        private BANANA.Windows.Controls.Label label3;



    }
}
