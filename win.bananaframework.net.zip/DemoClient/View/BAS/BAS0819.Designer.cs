﻿namespace DemoClient.View.BAS
{
	partial class BAS0819
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0819));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpBY_APP_DT_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label5 = new System.Windows.Forms.Label();
			this._dtpBY_APP_DT_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpSYSMODDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._dtpSYSMODDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label40 = new BANANA.Windows.Controls.Label();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.label2 = new BANANA.Windows.Controls.Label();
			this._txtSYSREGNAME_S = new BANANA.Windows.Controls.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.GROUP_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HST_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BY_APP_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band01 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band02 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band03 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band04 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band05 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band06 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band07 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band08 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band09 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CHK_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.OVR_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DAY_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.USE_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSDELDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSDELNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel3.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1354, 76);
			this.groupBox1.TabIndex = 24;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 9;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel3, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 8, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 5, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label40, 4, 1);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.label2, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtSYSREGNAME_S, 1, 1);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 2;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1348, 52);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// flowLayoutPanel3
			// 
			this.tableLayoutPanel6.SetColumnSpan(this.flowLayoutPanel3, 3);
			this.flowLayoutPanel3.Controls.Add(this._dtpBY_APP_DT_S_S);
			this.flowLayoutPanel3.Controls.Add(this.label5);
			this.flowLayoutPanel3.Controls.Add(this._dtpBY_APP_DT_E_S);
			this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel3.Location = new System.Drawing.Point(536, 1);
			this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel3.Name = "flowLayoutPanel3";
			this.flowLayoutPanel3.Size = new System.Drawing.Size(352, 27);
			this.flowLayoutPanel3.TabIndex = 120;
			// 
			// _dtpBY_APP_DT_S_S
			// 
			this._dtpBY_APP_DT_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpBY_APP_DT_S_S.Checked = false;
			this._dtpBY_APP_DT_S_S.CustomFormat = "yyyy-MM-dd";
			this._dtpBY_APP_DT_S_S.DelegateProperty = true;
			this._dtpBY_APP_DT_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpBY_APP_DT_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpBY_APP_DT_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpBY_APP_DT_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpBY_APP_DT_S_S.Name = "_dtpBY_APP_DT_S_S";
			this._dtpBY_APP_DT_S_S.ShowCheckBox = true;
			this._dtpBY_APP_DT_S_S.Size = new System.Drawing.Size(100, 21);
			this._dtpBY_APP_DT_S_S.TabIndex = 10;
			this._dtpBY_APP_DT_S_S.ValidationGroup = null;
			this._dtpBY_APP_DT_S_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(109, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(18, 15);
			this.label5.TabIndex = 25;
			this.label5.Text = "~";
			// 
			// _dtpBY_APP_DT_E_S
			// 
			this._dtpBY_APP_DT_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpBY_APP_DT_E_S.Checked = false;
			this._dtpBY_APP_DT_E_S.CustomFormat = "yyyy-MM-dd";
			this._dtpBY_APP_DT_E_S.DelegateProperty = true;
			this._dtpBY_APP_DT_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpBY_APP_DT_E_S.Location = new System.Drawing.Point(133, 5);
			this._dtpBY_APP_DT_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpBY_APP_DT_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpBY_APP_DT_E_S.Name = "_dtpBY_APP_DT_E_S";
			this._dtpBY_APP_DT_E_S.ShowCheckBox = true;
			this._dtpBY_APP_DT_E_S.Size = new System.Drawing.Size(100, 21);
			this._dtpBY_APP_DT_E_S.TabIndex = 20;
			this._dtpBY_APP_DT_E_S.ValidationGroup = null;
			this._dtpBY_APP_DT_E_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._btnSearch);
			this.flowLayoutPanel2.Controls.Add(this._btnExcel);
			this.flowLayoutPanel2.Location = new System.Drawing.Point(889, 1);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
			this.flowLayoutPanel2.Size = new System.Drawing.Size(243, 27);
			this.flowLayoutPanel2.TabIndex = 150;
			// 
			// _btnSearch
			// 
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 23);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(75, 2);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 23);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// flowLayoutPanel1
			// 
			this.tableLayoutPanel6.SetColumnSpan(this.flowLayoutPanel1, 3);
			this.flowLayoutPanel1.Controls.Add(this._dtpSYSMODDATE_S_S);
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this._dtpSYSMODDATE_E_S);
			this.flowLayoutPanel1.Location = new System.Drawing.Point(536, 29);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(352, 27);
			this.flowLayoutPanel1.TabIndex = 140;
			// 
			// _dtpSYSMODDATE_S_S
			// 
			this._dtpSYSMODDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpSYSMODDATE_S_S.Checked = false;
			this._dtpSYSMODDATE_S_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpSYSMODDATE_S_S.DelegateProperty = true;
			this._dtpSYSMODDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpSYSMODDATE_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpSYSMODDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpSYSMODDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpSYSMODDATE_S_S.Name = "_dtpSYSMODDATE_S_S";
			this._dtpSYSMODDATE_S_S.Size = new System.Drawing.Size(150, 21);
			this._dtpSYSMODDATE_S_S.TabIndex = 10;
			this._dtpSYSMODDATE_S_S.ValidationGroup = null;
			this._dtpSYSMODDATE_S_S.Value = new System.DateTime(2014, 8, 8, 14, 1, 19, 638);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(159, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(18, 15);
			this.label1.TabIndex = 21;
			this.label1.Text = "~";
			// 
			// _dtpSYSMODDATE_E_S
			// 
			this._dtpSYSMODDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpSYSMODDATE_E_S.Checked = false;
			this._dtpSYSMODDATE_E_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpSYSMODDATE_E_S.DelegateProperty = true;
			this._dtpSYSMODDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpSYSMODDATE_E_S.Location = new System.Drawing.Point(183, 5);
			this._dtpSYSMODDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpSYSMODDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpSYSMODDATE_E_S.Name = "_dtpSYSMODDATE_E_S";
			this._dtpSYSMODDATE_E_S.Size = new System.Drawing.Size(150, 21);
			this._dtpSYSMODDATE_E_S.TabIndex = 20;
			this._dtpSYSMODDATE_E_S.ValidationGroup = null;
			this._dtpSYSMODDATE_E_S.Value = new System.DateTime(2014, 8, 8, 14, 1, 19, 635);
			// 
			// _txtSTR_CD_S
			// 
			this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD_S.AutoTab = false;
			this._txtSTR_CD_S.DelegateProperty = true;
			this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_CD_S.Location = new System.Drawing.Point(317, 4);
			this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
			this._txtSTR_CD_S.Size = new System.Drawing.Size(124, 23);
			this._txtSTR_CD_S.TabIndex = 110;
			this._txtSTR_CD_S.ValidationGroup = null;
			this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_CD_S.WaterMarkText = "";
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 4);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(124, 23);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label40
			// 
			this.label40.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label40.AutoSize = true;
			this.label40.Location = new System.Drawing.Point(465, 35);
			this.label40.Name = "label40";
			this.label40.Size = new System.Drawing.Size(67, 15);
			this.label40.TabIndex = 1119;
			this.label40.Text = "처리기간";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(21, 7);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(67, 15);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(228, 7);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(82, 15);
			this.label36.TabIndex = 1115;
			this.label36.Text = "가맹점코드";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(450, 7);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(82, 15);
			this.label37.TabIndex = 1116;
			this.label37.Text = "적용시작일";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(36, 35);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(52, 15);
			this.label2.TabIndex = 1121;
			this.label2.Text = "처리자";
			// 
			// _txtSYSREGNAME_S
			// 
			this._txtSYSREGNAME_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSYSREGNAME_S.DelegateProperty = true;
			this._txtSYSREGNAME_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSYSREGNAME_S.Location = new System.Drawing.Point(95, 32);
			this._txtSYSREGNAME_S.Name = "_txtSYSREGNAME_S";
			this._txtSYSREGNAME_S.Size = new System.Drawing.Size(124, 23);
			this._txtSYSREGNAME_S.TabIndex = 130;
			this._txtSYSREGNAME_S.ValidationGroup = null;
			this._txtSYSREGNAME_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSYSREGNAME_S.WaterMarkText = "";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.gridView1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.Location = new System.Drawing.Point(0, 76);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1354, 657);
			this.groupBox2.TabIndex = 25;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.GROUP_NO,
            this.HST_TYPE,
            this.STR_CD,
            this.STR_NM,
            this.BY_APP_DT,
            this.MEMO,
            this.Band01,
            this.CHK_BC,
            this.CRD_BC,
            this.OVR_BC,
            this.DAY_BC,
            this.USE_BC,
            this.Band02,
            this.CHK_LT,
            this.CRD_LT,
            this.OVR_LT,
            this.DAY_LT,
            this.USE_LT,
            this.Band03,
            this.CHK_SS,
            this.CRD_SS,
            this.OVR_SS,
            this.DAY_SS,
            this.USE_SS,
            this.Band04,
            this.CHK_SH,
            this.CRD_SH,
            this.OVR_SH,
            this.DAY_SH,
            this.USE_SH,
            this.Band05,
            this.CHK_HD,
            this.CRD_HD,
            this.OVR_HD,
            this.DAY_HD,
            this.USE_HD,
            this.Band06,
            this.CHK_KB,
            this.CRD_KB,
            this.OVR_KB,
            this.DAY_KB,
            this.USE_KB,
            this.Band07,
            this.CHK_SK,
            this.CRD_SK,
            this.OVR_SK,
            this.DAY_SK,
            this.USE_SK,
            this.Band08,
            this.CHK_NH,
            this.CRD_NH,
            this.OVR_NH,
            this.DAY_NH,
            this.USE_NH,
            this.Band09,
            this.CHK_FR,
            this.CRD_FR,
            this.OVR_FR,
            this.DAY_FR,
            this.USE_FR,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME,
            this.SYSDELDATE,
            this.SYSDELNAME});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 21);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(1348, 633);
			this.gridView1.TabIndex = 1;
			// 
			// GROUP_NO
			// 
			this.GROUP_NO.DataPropertyName = "GROUP_NO";
			this.GROUP_NO.Frozen = true;
			this.GROUP_NO.HeaderText = "그룹번호";
			this.GROUP_NO.Name = "GROUP_NO";
			this.GROUP_NO.ReadOnly = true;
			this.GROUP_NO.Width = 94;
			// 
			// HST_TYPE
			// 
			this.HST_TYPE.DataPropertyName = "HST_TYPE";
			this.HST_TYPE.Frozen = true;
			this.HST_TYPE.HeaderText = "이력구분";
			this.HST_TYPE.Name = "HST_TYPE";
			this.HST_TYPE.ReadOnly = true;
			this.HST_TYPE.Width = 94;
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 108;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 94;
			// 
			// BY_APP_DT
			// 
			this.BY_APP_DT.DataPropertyName = "BY_APP_DT";
			this.BY_APP_DT.HeaderText = "적용시작일";
			this.BY_APP_DT.Name = "BY_APP_DT";
			this.BY_APP_DT.ReadOnly = true;
			this.BY_APP_DT.Width = 108;
			// 
			// MEMO
			// 
			this.MEMO.HeaderText = "메모";
			this.MEMO.Name = "MEMO";
			this.MEMO.ReadOnly = true;
			this.MEMO.Width = 66;
			// 
			// Band01
			// 
			this.Band01.HeaderText = "비씨카드";
			this.Band01.Name = "Band01";
			this.Band01.ReadOnly = true;
			this.Band01.TargetColumnss.Add("CHK_BC");
			this.Band01.TargetColumnss.Add("CRD_BC");
			this.Band01.TargetColumnss.Add("OVR_BC");
			this.Band01.TargetColumnss.Add("DAY_BC");
			this.Band01.TargetColumnss.Add("USE_BC");
			this.Band01.Width = 71;
			// 
			// CHK_BC
			// 
			this.CHK_BC.DataPropertyName = "CHK_BC";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_BC.DefaultCellStyle = dataGridViewCellStyle2;
			this.CHK_BC.HeaderText = "체크";
			this.CHK_BC.Name = "CHK_BC";
			this.CHK_BC.ReadOnly = true;
			this.CHK_BC.Width = 66;
			// 
			// CRD_BC
			// 
			this.CRD_BC.DataPropertyName = "CRD_BC";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_BC.DefaultCellStyle = dataGridViewCellStyle3;
			this.CRD_BC.HeaderText = "신용";
			this.CRD_BC.Name = "CRD_BC";
			this.CRD_BC.ReadOnly = true;
			this.CRD_BC.Width = 66;
			// 
			// OVR_BC
			// 
			this.OVR_BC.DataPropertyName = "OVR_BC";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_BC.DefaultCellStyle = dataGridViewCellStyle4;
			this.OVR_BC.HeaderText = "해외";
			this.OVR_BC.Name = "OVR_BC";
			this.OVR_BC.ReadOnly = true;
			this.OVR_BC.Width = 66;
			// 
			// DAY_BC
			// 
			this.DAY_BC.DataPropertyName = "DAY_BC";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_BC.DefaultCellStyle = dataGridViewCellStyle5;
			this.DAY_BC.HeaderText = "주기";
			this.DAY_BC.Name = "DAY_BC";
			this.DAY_BC.ReadOnly = true;
			this.DAY_BC.Width = 66;
			// 
			// USE_BC
			// 
			this.USE_BC.DataPropertyName = "USE_BC";
			this.USE_BC.HeaderText = "매입";
			this.USE_BC.Name = "USE_BC";
			this.USE_BC.ReadOnly = true;
			this.USE_BC.Width = 66;
			// 
			// Band02
			// 
			this.Band02.HeaderText = "롯데카드";
			this.Band02.Name = "Band02";
			this.Band02.ReadOnly = true;
			this.Band02.TargetColumnss.Add("CHK_LT");
			this.Band02.TargetColumnss.Add("CRD_LT");
			this.Band02.TargetColumnss.Add("OVR_LT");
			this.Band02.TargetColumnss.Add("DAY_LT");
			this.Band02.TargetColumnss.Add("USE_LT");
			this.Band02.Width = 71;
			// 
			// CHK_LT
			// 
			this.CHK_LT.DataPropertyName = "CHK_LT";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_LT.DefaultCellStyle = dataGridViewCellStyle6;
			this.CHK_LT.HeaderText = "체크";
			this.CHK_LT.Name = "CHK_LT";
			this.CHK_LT.ReadOnly = true;
			this.CHK_LT.Width = 66;
			// 
			// CRD_LT
			// 
			this.CRD_LT.DataPropertyName = "CRD_LT";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_LT.DefaultCellStyle = dataGridViewCellStyle7;
			this.CRD_LT.HeaderText = "신용";
			this.CRD_LT.Name = "CRD_LT";
			this.CRD_LT.ReadOnly = true;
			this.CRD_LT.Width = 66;
			// 
			// OVR_LT
			// 
			this.OVR_LT.DataPropertyName = "OVR_LT";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_LT.DefaultCellStyle = dataGridViewCellStyle8;
			this.OVR_LT.HeaderText = "해외";
			this.OVR_LT.Name = "OVR_LT";
			this.OVR_LT.ReadOnly = true;
			this.OVR_LT.Width = 66;
			// 
			// DAY_LT
			// 
			this.DAY_LT.DataPropertyName = "DAY_LT";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_LT.DefaultCellStyle = dataGridViewCellStyle9;
			this.DAY_LT.HeaderText = "주기";
			this.DAY_LT.Name = "DAY_LT";
			this.DAY_LT.ReadOnly = true;
			this.DAY_LT.Width = 66;
			// 
			// USE_LT
			// 
			this.USE_LT.DataPropertyName = "USE_LT";
			this.USE_LT.HeaderText = "매입";
			this.USE_LT.Name = "USE_LT";
			this.USE_LT.ReadOnly = true;
			this.USE_LT.Width = 66;
			// 
			// Band03
			// 
			this.Band03.HeaderText = "삼성카드";
			this.Band03.Name = "Band03";
			this.Band03.ReadOnly = true;
			this.Band03.TargetColumnss.Add("CHK_SS");
			this.Band03.TargetColumnss.Add("CRD_SS");
			this.Band03.TargetColumnss.Add("OVR_SS");
			this.Band03.TargetColumnss.Add("DAY_SS");
			this.Band03.TargetColumnss.Add("USE_SS");
			this.Band03.Width = 71;
			// 
			// CHK_SS
			// 
			this.CHK_SS.DataPropertyName = "CHK_SS";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_SS.DefaultCellStyle = dataGridViewCellStyle10;
			this.CHK_SS.HeaderText = "체크";
			this.CHK_SS.Name = "CHK_SS";
			this.CHK_SS.ReadOnly = true;
			this.CHK_SS.Width = 66;
			// 
			// CRD_SS
			// 
			this.CRD_SS.DataPropertyName = "CRD_SS";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_SS.DefaultCellStyle = dataGridViewCellStyle11;
			this.CRD_SS.HeaderText = "신용";
			this.CRD_SS.Name = "CRD_SS";
			this.CRD_SS.ReadOnly = true;
			this.CRD_SS.Width = 66;
			// 
			// OVR_SS
			// 
			this.OVR_SS.DataPropertyName = "OVR_SS";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_SS.DefaultCellStyle = dataGridViewCellStyle12;
			this.OVR_SS.HeaderText = "해외";
			this.OVR_SS.Name = "OVR_SS";
			this.OVR_SS.ReadOnly = true;
			this.OVR_SS.Width = 66;
			// 
			// DAY_SS
			// 
			this.DAY_SS.DataPropertyName = "DAY_SS";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_SS.DefaultCellStyle = dataGridViewCellStyle13;
			this.DAY_SS.HeaderText = "주기";
			this.DAY_SS.Name = "DAY_SS";
			this.DAY_SS.ReadOnly = true;
			this.DAY_SS.Width = 66;
			// 
			// USE_SS
			// 
			this.USE_SS.DataPropertyName = "USE_SS";
			this.USE_SS.HeaderText = "매입";
			this.USE_SS.Name = "USE_SS";
			this.USE_SS.ReadOnly = true;
			this.USE_SS.Width = 66;
			// 
			// Band04
			// 
			this.Band04.HeaderText = "신한카드";
			this.Band04.Name = "Band04";
			this.Band04.ReadOnly = true;
			this.Band04.TargetColumnss.Add("CHK_SH");
			this.Band04.TargetColumnss.Add("CRD_SH");
			this.Band04.TargetColumnss.Add("OVR_SH");
			this.Band04.TargetColumnss.Add("DAY_SH");
			this.Band04.TargetColumnss.Add("USE_SH");
			this.Band04.Width = 71;
			// 
			// CHK_SH
			// 
			this.CHK_SH.DataPropertyName = "CHK_SH";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_SH.DefaultCellStyle = dataGridViewCellStyle14;
			this.CHK_SH.HeaderText = "체크";
			this.CHK_SH.Name = "CHK_SH";
			this.CHK_SH.ReadOnly = true;
			this.CHK_SH.Width = 66;
			// 
			// CRD_SH
			// 
			this.CRD_SH.DataPropertyName = "CRD_SH";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_SH.DefaultCellStyle = dataGridViewCellStyle15;
			this.CRD_SH.HeaderText = "신용";
			this.CRD_SH.Name = "CRD_SH";
			this.CRD_SH.ReadOnly = true;
			this.CRD_SH.Width = 66;
			// 
			// OVR_SH
			// 
			this.OVR_SH.DataPropertyName = "OVR_SH";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_SH.DefaultCellStyle = dataGridViewCellStyle16;
			this.OVR_SH.HeaderText = "해외";
			this.OVR_SH.Name = "OVR_SH";
			this.OVR_SH.ReadOnly = true;
			this.OVR_SH.Width = 66;
			// 
			// DAY_SH
			// 
			this.DAY_SH.DataPropertyName = "DAY_SH";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_SH.DefaultCellStyle = dataGridViewCellStyle17;
			this.DAY_SH.HeaderText = "주기";
			this.DAY_SH.Name = "DAY_SH";
			this.DAY_SH.ReadOnly = true;
			this.DAY_SH.Width = 66;
			// 
			// USE_SH
			// 
			this.USE_SH.DataPropertyName = "USE_SH";
			this.USE_SH.HeaderText = "매입";
			this.USE_SH.Name = "USE_SH";
			this.USE_SH.ReadOnly = true;
			this.USE_SH.Width = 66;
			// 
			// Band05
			// 
			this.Band05.HeaderText = "현대카드";
			this.Band05.Name = "Band05";
			this.Band05.ReadOnly = true;
			this.Band05.TargetColumnss.Add("CHK_HD");
			this.Band05.TargetColumnss.Add("CRD_HD");
			this.Band05.TargetColumnss.Add("OVR_HD");
			this.Band05.TargetColumnss.Add("DAY_HD");
			this.Band05.TargetColumnss.Add("USE_HD");
			this.Band05.Width = 71;
			// 
			// CHK_HD
			// 
			this.CHK_HD.DataPropertyName = "CHK_HD";
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_HD.DefaultCellStyle = dataGridViewCellStyle18;
			this.CHK_HD.HeaderText = "체크";
			this.CHK_HD.Name = "CHK_HD";
			this.CHK_HD.ReadOnly = true;
			this.CHK_HD.Width = 66;
			// 
			// CRD_HD
			// 
			this.CRD_HD.DataPropertyName = "CRD_HD";
			dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_HD.DefaultCellStyle = dataGridViewCellStyle19;
			this.CRD_HD.HeaderText = "신용";
			this.CRD_HD.Name = "CRD_HD";
			this.CRD_HD.ReadOnly = true;
			this.CRD_HD.Width = 66;
			// 
			// OVR_HD
			// 
			this.OVR_HD.DataPropertyName = "OVR_HD";
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_HD.DefaultCellStyle = dataGridViewCellStyle20;
			this.OVR_HD.HeaderText = "해외";
			this.OVR_HD.Name = "OVR_HD";
			this.OVR_HD.ReadOnly = true;
			this.OVR_HD.Width = 66;
			// 
			// DAY_HD
			// 
			this.DAY_HD.DataPropertyName = "DAY_HD";
			dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_HD.DefaultCellStyle = dataGridViewCellStyle21;
			this.DAY_HD.HeaderText = "주기";
			this.DAY_HD.Name = "DAY_HD";
			this.DAY_HD.ReadOnly = true;
			this.DAY_HD.Width = 66;
			// 
			// USE_HD
			// 
			this.USE_HD.DataPropertyName = "USE_HD";
			this.USE_HD.HeaderText = "매입";
			this.USE_HD.Name = "USE_HD";
			this.USE_HD.ReadOnly = true;
			this.USE_HD.Width = 66;
			// 
			// Band06
			// 
			this.Band06.HeaderText = "KB국민카드";
			this.Band06.Name = "Band06";
			this.Band06.ReadOnly = true;
			this.Band06.TargetColumnss.Add("CHK_KB");
			this.Band06.TargetColumnss.Add("CRD_KB");
			this.Band06.TargetColumnss.Add("OVR_KB");
			this.Band06.TargetColumnss.Add("DAY_KB");
			this.Band06.TargetColumnss.Add("USE_KB");
			this.Band06.Width = 89;
			// 
			// CHK_KB
			// 
			this.CHK_KB.DataPropertyName = "CHK_KB";
			dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_KB.DefaultCellStyle = dataGridViewCellStyle22;
			this.CHK_KB.HeaderText = "체크";
			this.CHK_KB.Name = "CHK_KB";
			this.CHK_KB.ReadOnly = true;
			this.CHK_KB.Width = 66;
			// 
			// CRD_KB
			// 
			this.CRD_KB.DataPropertyName = "CRD_KB";
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_KB.DefaultCellStyle = dataGridViewCellStyle23;
			this.CRD_KB.HeaderText = "신용";
			this.CRD_KB.Name = "CRD_KB";
			this.CRD_KB.ReadOnly = true;
			this.CRD_KB.Width = 66;
			// 
			// OVR_KB
			// 
			this.OVR_KB.DataPropertyName = "OVR_KB";
			dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_KB.DefaultCellStyle = dataGridViewCellStyle24;
			this.OVR_KB.HeaderText = "해외";
			this.OVR_KB.Name = "OVR_KB";
			this.OVR_KB.ReadOnly = true;
			this.OVR_KB.Width = 66;
			// 
			// DAY_KB
			// 
			this.DAY_KB.DataPropertyName = "DAY_KB";
			dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_KB.DefaultCellStyle = dataGridViewCellStyle25;
			this.DAY_KB.HeaderText = "주기";
			this.DAY_KB.Name = "DAY_KB";
			this.DAY_KB.ReadOnly = true;
			this.DAY_KB.Width = 66;
			// 
			// USE_KB
			// 
			this.USE_KB.DataPropertyName = "USE_KB";
			this.USE_KB.HeaderText = "매입";
			this.USE_KB.Name = "USE_KB";
			this.USE_KB.ReadOnly = true;
			this.USE_KB.Width = 66;
			// 
			// Band07
			// 
			this.Band07.HeaderText = "하나SK카드";
			this.Band07.Name = "Band07";
			this.Band07.ReadOnly = true;
			this.Band07.TargetColumnss.Add("CHK_SK");
			this.Band07.TargetColumnss.Add("CRD_SK");
			this.Band07.TargetColumnss.Add("OVR_SK");
			this.Band07.TargetColumnss.Add("DAY_SK");
			this.Band07.TargetColumnss.Add("USE_SK");
			this.Band07.Width = 88;
			// 
			// CHK_SK
			// 
			this.CHK_SK.DataPropertyName = "CHK_SK";
			dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_SK.DefaultCellStyle = dataGridViewCellStyle26;
			this.CHK_SK.HeaderText = "체크";
			this.CHK_SK.Name = "CHK_SK";
			this.CHK_SK.ReadOnly = true;
			this.CHK_SK.Width = 66;
			// 
			// CRD_SK
			// 
			this.CRD_SK.DataPropertyName = "CRD_SK";
			dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_SK.DefaultCellStyle = dataGridViewCellStyle27;
			this.CRD_SK.HeaderText = "신용";
			this.CRD_SK.Name = "CRD_SK";
			this.CRD_SK.ReadOnly = true;
			this.CRD_SK.Width = 66;
			// 
			// OVR_SK
			// 
			this.OVR_SK.DataPropertyName = "OVR_SK";
			dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_SK.DefaultCellStyle = dataGridViewCellStyle28;
			this.OVR_SK.HeaderText = "해외";
			this.OVR_SK.Name = "OVR_SK";
			this.OVR_SK.ReadOnly = true;
			this.OVR_SK.Width = 66;
			// 
			// DAY_SK
			// 
			this.DAY_SK.DataPropertyName = "DAY_SK";
			dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_SK.DefaultCellStyle = dataGridViewCellStyle29;
			this.DAY_SK.HeaderText = "주기";
			this.DAY_SK.Name = "DAY_SK";
			this.DAY_SK.ReadOnly = true;
			this.DAY_SK.Width = 66;
			// 
			// USE_SK
			// 
			this.USE_SK.DataPropertyName = "USE_SK";
			this.USE_SK.HeaderText = "매입";
			this.USE_SK.Name = "USE_SK";
			this.USE_SK.ReadOnly = true;
			this.USE_SK.Width = 66;
			// 
			// Band08
			// 
			this.Band08.HeaderText = "NH농협은행";
			this.Band08.Name = "Band08";
			this.Band08.ReadOnly = true;
			this.Band08.TargetColumnss.Add("CHK_NH");
			this.Band08.TargetColumnss.Add("CRD_NH");
			this.Band08.TargetColumnss.Add("OVR_NH");
			this.Band08.TargetColumnss.Add("DAY_NH");
			this.Band08.TargetColumnss.Add("USE_NH");
			this.Band08.Width = 93;
			// 
			// CHK_NH
			// 
			this.CHK_NH.DataPropertyName = "CHK_NH";
			dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_NH.DefaultCellStyle = dataGridViewCellStyle30;
			this.CHK_NH.HeaderText = "체크";
			this.CHK_NH.Name = "CHK_NH";
			this.CHK_NH.ReadOnly = true;
			this.CHK_NH.Width = 66;
			// 
			// CRD_NH
			// 
			this.CRD_NH.DataPropertyName = "CRD_NH";
			dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_NH.DefaultCellStyle = dataGridViewCellStyle31;
			this.CRD_NH.HeaderText = "신용";
			this.CRD_NH.Name = "CRD_NH";
			this.CRD_NH.ReadOnly = true;
			this.CRD_NH.Width = 66;
			// 
			// OVR_NH
			// 
			this.OVR_NH.DataPropertyName = "OVR_NH";
			dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_NH.DefaultCellStyle = dataGridViewCellStyle32;
			this.OVR_NH.HeaderText = "해외";
			this.OVR_NH.Name = "OVR_NH";
			this.OVR_NH.ReadOnly = true;
			this.OVR_NH.Width = 66;
			// 
			// DAY_NH
			// 
			this.DAY_NH.DataPropertyName = "DAY_NH";
			dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_NH.DefaultCellStyle = dataGridViewCellStyle33;
			this.DAY_NH.HeaderText = "주기";
			this.DAY_NH.Name = "DAY_NH";
			this.DAY_NH.ReadOnly = true;
			this.DAY_NH.Width = 66;
			// 
			// USE_NH
			// 
			this.USE_NH.DataPropertyName = "USE_NH";
			this.USE_NH.HeaderText = "매입";
			this.USE_NH.Name = "USE_NH";
			this.USE_NH.ReadOnly = true;
			this.USE_NH.Width = 66;
			// 
			// Band09
			// 
			this.Band09.HeaderText = "외환카드";
			this.Band09.Name = "Band09";
			this.Band09.ReadOnly = true;
			this.Band09.TargetColumnss.Add("CHK_FR");
			this.Band09.TargetColumnss.Add("CRD_FR");
			this.Band09.TargetColumnss.Add("OVR_FR");
			this.Band09.TargetColumnss.Add("DAY_FR");
			this.Band09.TargetColumnss.Add("USE_FR");
			this.Band09.Width = 71;
			// 
			// CHK_FR
			// 
			this.CHK_FR.DataPropertyName = "CHK_FR";
			dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_FR.DefaultCellStyle = dataGridViewCellStyle34;
			this.CHK_FR.HeaderText = "체크";
			this.CHK_FR.Name = "CHK_FR";
			this.CHK_FR.ReadOnly = true;
			this.CHK_FR.Width = 66;
			// 
			// CRD_FR
			// 
			this.CRD_FR.DataPropertyName = "CRD_FR";
			dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_FR.DefaultCellStyle = dataGridViewCellStyle35;
			this.CRD_FR.HeaderText = "신용";
			this.CRD_FR.Name = "CRD_FR";
			this.CRD_FR.ReadOnly = true;
			this.CRD_FR.Width = 66;
			// 
			// OVR_FR
			// 
			this.OVR_FR.DataPropertyName = "OVR_FR";
			dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.OVR_FR.DefaultCellStyle = dataGridViewCellStyle36;
			this.OVR_FR.HeaderText = "해외";
			this.OVR_FR.Name = "OVR_FR";
			this.OVR_FR.ReadOnly = true;
			this.OVR_FR.Width = 66;
			// 
			// DAY_FR
			// 
			this.DAY_FR.DataPropertyName = "DAY_FR";
			dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DAY_FR.DefaultCellStyle = dataGridViewCellStyle37;
			this.DAY_FR.HeaderText = "주기";
			this.DAY_FR.Name = "DAY_FR";
			this.DAY_FR.ReadOnly = true;
			this.DAY_FR.Width = 66;
			// 
			// USE_FR
			// 
			this.USE_FR.DataPropertyName = "USE_FR";
			this.USE_FR.HeaderText = "매입";
			this.USE_FR.Name = "USE_FR";
			this.USE_FR.ReadOnly = true;
			this.USE_FR.Width = 66;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.MinimumWidth = 140;
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 140;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 122;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.MinimumWidth = 140;
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 140;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 122;
			// 
			// SYSDELDATE
			// 
			this.SYSDELDATE.DataPropertyName = "SYSDELDATE";
			this.SYSDELDATE.HeaderText = "시스템삭제일";
			this.SYSDELDATE.MinimumWidth = 140;
			this.SYSDELDATE.Name = "SYSDELDATE";
			this.SYSDELDATE.ReadOnly = true;
			this.SYSDELDATE.Width = 140;
			// 
			// SYSDELNAME
			// 
			this.SYSDELNAME.DataPropertyName = "SYSDELNAME";
			this.SYSDELNAME.HeaderText = "시스템삭제자";
			this.SYSDELNAME.Name = "SYSDELNAME";
			this.SYSDELNAME.ReadOnly = true;
			this.SYSDELNAME.Width = 122;
			// 
			// BAS0819
			// 
			this.ClientSize = new System.Drawing.Size(1354, 733);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "BAS0819";
			this.Text = "가맹점.매입카드이력조회:BAS0819";
			this.Load += new System.EventHandler(this.BAS0819_Load);
			this.Shown += new System.EventHandler(this.BAS0819_Shown);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel3.ResumeLayout(false);
			this.flowLayoutPanel3.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private BANANA.Windows.Controls.TextBox _txtSYSREGNAME_S;
		private BANANA.Windows.Controls.Label label2;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private DemoClient.Controls.BananaButton _btnSearch;
		private DemoClient.Controls.BananaButton _btnExcel;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.Label label1;
		private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
		private BANANA.Windows.Controls.Label label40;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label37;
		private BANANA.Windows.Controls.DateTimePicker _dtpSYSMODDATE_E_S;
		private BANANA.Windows.Controls.DateTimePicker _dtpSYSMODDATE_S_S;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
		private BANANA.Windows.Controls.DateTimePicker _dtpBY_APP_DT_S_S;
		private System.Windows.Forms.Label label5;
		private BANANA.Windows.Controls.DateTimePicker _dtpBY_APP_DT_E_S;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn GROUP_NO;
		private System.Windows.Forms.DataGridViewTextBoxColumn HST_TYPE;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn BY_APP_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band01;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_BC;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band02;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_LT;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band03;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_SS;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band04;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_SH;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band05;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_HD;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band06;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_KB;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band07;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_SK;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band08;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_NH;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band09;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn OVR_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn DAY_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn USE_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSDELDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSDELNAME;
	}
}
