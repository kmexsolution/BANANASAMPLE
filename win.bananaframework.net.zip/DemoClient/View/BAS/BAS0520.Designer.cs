﻿namespace DemoClient.View.BAS
{
	partial class BAS0520
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0520));
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.label16 = new BANANA.Windows.Controls.Label();
			this.label7 = new BANANA.Windows.Controls.Label();
			this._txtCODE_NAME = new BANANA.Windows.Controls.TextBox();
			this.label9 = new BANANA.Windows.Controls.Label();
			this._txtORDERBY = new BANANA.Windows.Controls.TextBox();
			this.label5 = new BANANA.Windows.Controls.Label();
			this._txtBIGO2 = new BANANA.Windows.Controls.TextBox();
			this._txtBIGO4 = new BANANA.Windows.Controls.TextBox();
			this._txtBIGO6 = new BANANA.Windows.Controls.TextBox();
			this.label10 = new BANANA.Windows.Controls.Label();
			this.label14 = new BANANA.Windows.Controls.Label();
			this._txtMAIN_CODE = new BANANA.Windows.Controls.TextBox();
			this.label6 = new BANANA.Windows.Controls.Label();
			this.label8 = new BANANA.Windows.Controls.Label();
			this.label15 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbDISPLAYY = new BANANA.Windows.Controls.RadioButton();
			this._rbDISPLAYN = new BANANA.Windows.Controls.RadioButton();
			this.label11 = new BANANA.Windows.Controls.Label();
			this._txtBIGO1 = new BANANA.Windows.Controls.TextBox();
			this._txtBIGO3 = new BANANA.Windows.Controls.TextBox();
			this._txtBIGO5 = new BANANA.Windows.Controls.TextBox();
			this._btnClose = new DemoClient.Controls.BananaButton();
			this._btnSave = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 4;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.Controls.Add(this.label16, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.label7, 2, 0);
			this.tableLayoutPanel2.Controls.Add(this._txtCODE_NAME, 3, 0);
			this.tableLayoutPanel2.Controls.Add(this.label9, 2, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtORDERBY, 3, 1);
			this.tableLayoutPanel2.Controls.Add(this.label5, 2, 2);
			this.tableLayoutPanel2.Controls.Add(this._txtBIGO2, 3, 2);
			this.tableLayoutPanel2.Controls.Add(this._txtBIGO4, 3, 3);
			this.tableLayoutPanel2.Controls.Add(this._txtBIGO6, 3, 4);
			this.tableLayoutPanel2.Controls.Add(this.label10, 2, 3);
			this.tableLayoutPanel2.Controls.Add(this.label14, 2, 4);
			this.tableLayoutPanel2.Controls.Add(this._txtMAIN_CODE, 1, 0);
			this.tableLayoutPanel2.Controls.Add(this.label6, 0, 2);
			this.tableLayoutPanel2.Controls.Add(this.label8, 0, 3);
			this.tableLayoutPanel2.Controls.Add(this.label15, 0, 4);
			this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel1, 1, 1);
			this.tableLayoutPanel2.Controls.Add(this.label11, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtBIGO1, 1, 2);
			this.tableLayoutPanel2.Controls.Add(this._txtBIGO3, 1, 3);
			this.tableLayoutPanel2.Controls.Add(this._txtBIGO5, 1, 4);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 5;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(464, 135);
			this.tableLayoutPanel2.TabIndex = 1;
			// 
			// label16
			// 
			this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(36, 7);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(51, 13);
			this.label16.TabIndex = 22;
			this.label16.Text = "메인코드";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(277, 7);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(40, 13);
			this.label7.TabIndex = 13;
			this.label7.Text = "코드명";
			// 
			// _txtCODE_NAME
			// 
			this._txtCODE_NAME.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCODE_NAME.Compulsory = true;
			this._txtCODE_NAME.DelegateProperty = true;
			this._txtCODE_NAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCODE_NAME.Location = new System.Drawing.Point(323, 3);
			this._txtCODE_NAME.Name = "_txtCODE_NAME";
			this._txtCODE_NAME.Size = new System.Drawing.Size(130, 20);
			this._txtCODE_NAME.TabIndex = 1030;
			this._txtCODE_NAME.ValidationGroup = "a";
			this._txtCODE_NAME.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCODE_NAME.WaterMarkText = "";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(288, 34);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(29, 13);
			this.label9.TabIndex = 15;
			this.label9.Text = "순서";
			// 
			// _txtORDERBY
			// 
			this._txtORDERBY.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtORDERBY.DelegateProperty = true;
			this._txtORDERBY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtORDERBY.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtORDERBY.Location = new System.Drawing.Point(323, 30);
			this._txtORDERBY.Name = "_txtORDERBY";
			this._txtORDERBY.Size = new System.Drawing.Size(130, 20);
			this._txtORDERBY.TabIndex = 1050;
			this._txtORDERBY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtORDERBY.ValidationGroup = null;
			this._txtORDERBY.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtORDERBY.WaterMarkText = "";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(282, 61);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(35, 13);
			this.label5.TabIndex = 11;
			this.label5.Text = "비고2";
			// 
			// _txtBIGO2
			// 
			this._txtBIGO2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBIGO2.DelegateProperty = true;
			this._txtBIGO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO2.Location = new System.Drawing.Point(323, 57);
			this._txtBIGO2.Name = "_txtBIGO2";
			this._txtBIGO2.Size = new System.Drawing.Size(130, 20);
			this._txtBIGO2.TabIndex = 1070;
			this._txtBIGO2.ValidationGroup = null;
			this._txtBIGO2.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBIGO2.WaterMarkText = "";
			// 
			// _txtBIGO4
			// 
			this._txtBIGO4.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBIGO4.DelegateProperty = true;
			this._txtBIGO4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO4.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtBIGO4.Location = new System.Drawing.Point(323, 84);
			this._txtBIGO4.Name = "_txtBIGO4";
			this._txtBIGO4.Size = new System.Drawing.Size(130, 20);
			this._txtBIGO4.TabIndex = 1090;
			this._txtBIGO4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBIGO4.ValidationGroup = null;
			this._txtBIGO4.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBIGO4.WaterMarkText = "";
			// 
			// _txtBIGO6
			// 
			this._txtBIGO6.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBIGO6.DelegateProperty = true;
			this._txtBIGO6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO6.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtBIGO6.Location = new System.Drawing.Point(323, 111);
			this._txtBIGO6.Name = "_txtBIGO6";
			this._txtBIGO6.Size = new System.Drawing.Size(130, 20);
			this._txtBIGO6.TabIndex = 1110;
			this._txtBIGO6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBIGO6.ValidationGroup = null;
			this._txtBIGO6.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBIGO6.WaterMarkText = "";
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(282, 88);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(35, 13);
			this.label10.TabIndex = 16;
			this.label10.Text = "비고4";
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(282, 115);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(35, 13);
			this.label14.TabIndex = 20;
			this.label14.Text = "비고6";
			// 
			// _txtMAIN_CODE
			// 
			this._txtMAIN_CODE.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtMAIN_CODE.DelegateProperty = true;
			this._txtMAIN_CODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtMAIN_CODE.Location = new System.Drawing.Point(93, 3);
			this._txtMAIN_CODE.Name = "_txtMAIN_CODE";
			this._txtMAIN_CODE.ReadOnly = true;
			this._txtMAIN_CODE.Size = new System.Drawing.Size(130, 20);
			this._txtMAIN_CODE.TabIndex = 1010;
			this._txtMAIN_CODE.TabStop = false;
			this._txtMAIN_CODE.ValidationGroup = null;
			this._txtMAIN_CODE.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtMAIN_CODE.WaterMarkText = "";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(52, 61);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(35, 13);
			this.label6.TabIndex = 12;
			this.label6.Text = "비고1";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(52, 88);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(35, 13);
			this.label8.TabIndex = 14;
			this.label8.Text = "비고3";
			// 
			// label15
			// 
			this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(52, 115);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(35, 13);
			this.label15.TabIndex = 21;
			this.label15.Text = "비고5";
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._rbDISPLAYY);
			this.flowLayoutPanel1.Controls.Add(this._rbDISPLAYN);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(90, 27);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel1.Size = new System.Drawing.Size(140, 27);
			this.flowLayoutPanel1.TabIndex = 1040;
			// 
			// _rbDISPLAYY
			// 
			this._rbDISPLAYY.AutoSize = true;
			this._rbDISPLAYY.Checked = true;
			this._rbDISPLAYY.DelegateProperty = true;
			this._rbDISPLAYY.Location = new System.Drawing.Point(3, 6);
			this._rbDISPLAYY.Name = "_rbDISPLAYY";
			this._rbDISPLAYY.Size = new System.Drawing.Size(32, 17);
			this._rbDISPLAYY.TabIndex = 10;
			this._rbDISPLAYY.TabStop = true;
			this._rbDISPLAYY.Text = "Y";
			this._rbDISPLAYY.UseVisualStyleBackColor = true;
			// 
			// _rbDISPLAYN
			// 
			this._rbDISPLAYN.AutoSize = true;
			this._rbDISPLAYN.DelegateProperty = true;
			this._rbDISPLAYN.Location = new System.Drawing.Point(41, 6);
			this._rbDISPLAYN.Name = "_rbDISPLAYN";
			this._rbDISPLAYN.Size = new System.Drawing.Size(33, 17);
			this._rbDISPLAYN.TabIndex = 20;
			this._rbDISPLAYN.Text = "N";
			this._rbDISPLAYN.UseVisualStyleBackColor = true;
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(36, 34);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(51, 13);
			this.label11.TabIndex = 17;
			this.label11.Text = "사용여부";
			// 
			// _txtBIGO1
			// 
			this._txtBIGO1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBIGO1.DelegateProperty = true;
			this._txtBIGO1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO1.Location = new System.Drawing.Point(93, 57);
			this._txtBIGO1.Name = "_txtBIGO1";
			this._txtBIGO1.Size = new System.Drawing.Size(130, 20);
			this._txtBIGO1.TabIndex = 1060;
			this._txtBIGO1.ValidationGroup = null;
			this._txtBIGO1.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBIGO1.WaterMarkText = "";
			// 
			// _txtBIGO3
			// 
			this._txtBIGO3.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBIGO3.DelegateProperty = true;
			this._txtBIGO3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO3.Location = new System.Drawing.Point(93, 84);
			this._txtBIGO3.Name = "_txtBIGO3";
			this._txtBIGO3.Size = new System.Drawing.Size(130, 20);
			this._txtBIGO3.TabIndex = 1080;
			this._txtBIGO3.ValidationGroup = null;
			this._txtBIGO3.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBIGO3.WaterMarkText = "";
			// 
			// _txtBIGO5
			// 
			this._txtBIGO5.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBIGO5.DelegateProperty = true;
			this._txtBIGO5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBIGO5.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtBIGO5.Location = new System.Drawing.Point(93, 111);
			this._txtBIGO5.Name = "_txtBIGO5";
			this._txtBIGO5.Size = new System.Drawing.Size(130, 20);
			this._txtBIGO5.TabIndex = 1100;
			this._txtBIGO5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBIGO5.ValidationGroup = null;
			this._txtBIGO5.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBIGO5.WaterMarkText = "";
			// 
			// _btnClose
			// 
			this._btnClose.DelegateProperty = true;
			this._btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this._btnClose.Image = global::DemoClient.Properties.Resources.red_62690;
			this._btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.Location = new System.Drawing.Point(378, 168);
			this._btnClose.Name = "_btnClose";
			this._btnClose.Size = new System.Drawing.Size(75, 27);
			this._btnClose.TabIndex = 505;
			this._btnClose.Text = "      닫   기";
			this._btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.UseVisualStyleBackColor = true;
			this._btnClose.ValidationGroup = null;
			this._btnClose.Click += new System.EventHandler(this._btnClose_Click);
			// 
			// _btnSave
			// 
			this._btnSave.ButtonConfirm = true;
			this._btnSave.DelegateProperty = true;
			this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.Location = new System.Drawing.Point(297, 168);
			this._btnSave.Name = "_btnSave";
			this._btnSave.Size = new System.Drawing.Size(75, 27);
			this._btnSave.TabIndex = 504;
			this._btnSave.Text = "      저   장";
			this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.UseVisualStyleBackColor = true;
			this._btnSave.ValidationGroup = "a";
			this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
			// 
			// BAS0520
			// 
			this.CancelButton = this._btnClose;
			this.ClientSize = new System.Drawing.Size(464, 206);
			this.Controls.Add(this._btnClose);
			this.Controls.Add(this._btnSave);
			this.Controls.Add(this.tableLayoutPanel2);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "BAS0520";
			this.Text = "상세코드등록:BAS0520";
			this.Load += new System.EventHandler(this.BAS0520_Load);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private BANANA.Windows.Controls.TextBox _txtBIGO6;
		private BANANA.Windows.Controls.TextBox _txtBIGO5;
		private BANANA.Windows.Controls.TextBox _txtBIGO4;
		private BANANA.Windows.Controls.TextBox _txtBIGO3;
		private BANANA.Windows.Controls.TextBox _txtBIGO2;
		private BANANA.Windows.Controls.TextBox _txtBIGO1;
		private BANANA.Windows.Controls.TextBox _txtORDERBY;
		private BANANA.Windows.Controls.TextBox _txtCODE_NAME;
		private BANANA.Windows.Controls.TextBox _txtMAIN_CODE;
		private BANANA.Windows.Controls.Label label14;
		private BANANA.Windows.Controls.Label label15;
		private BANANA.Windows.Controls.Label label16;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.Label label11;
		private BANANA.Windows.Controls.Label label8;
		private BANANA.Windows.Controls.Label label9;
		private BANANA.Windows.Controls.Label label5;
		private BANANA.Windows.Controls.Label label6;
		private BANANA.Windows.Controls.Label label7;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.RadioButton _rbDISPLAYY;
		private BANANA.Windows.Controls.RadioButton _rbDISPLAYN;
		private DemoClient.Controls.BananaButton _btnClose;
		private DemoClient.Controls.BananaButton _btnSave;
	}
}
