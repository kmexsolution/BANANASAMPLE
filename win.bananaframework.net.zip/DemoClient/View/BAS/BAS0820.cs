﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient.View.BAS
{
	public partial class BAS0820 : DemoClient.Controllers.BaseForm
	{
		public BAS0820()
		{
			InitializeComponent();
		}
	}
}
