﻿namespace DemoClient.View.BAS
{
	partial class BAS0741
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0741));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this._cmbINTEREST_AGT_CD = new BANANA.Windows.Controls.ComboBox();
			this._cmbCALCUL_AGT_CD = new BANANA.Windows.Controls.ComboBox();
			this._txtINTEREST6 = new BANANA.Windows.Controls.TextBox();
			this._txtCALCUL_CHRG6 = new BANANA.Windows.Controls.TextBox();
			this._txtINTEREST5 = new BANANA.Windows.Controls.TextBox();
			this._txtCALCUL_CHRG5 = new BANANA.Windows.Controls.TextBox();
			this._txtINTEREST4 = new BANANA.Windows.Controls.TextBox();
			this._txtCALCUL_CHRG4 = new BANANA.Windows.Controls.TextBox();
			this._txtINTEREST3 = new BANANA.Windows.Controls.TextBox();
			this._txtCALCUL_CHRG3 = new BANANA.Windows.Controls.TextBox();
			this._txtINTEREST2 = new BANANA.Windows.Controls.TextBox();
			this._txtCALCUL_CHRG2 = new BANANA.Windows.Controls.TextBox();
			this._txtINTEREST1 = new BANANA.Windows.Controls.TextBox();
			this._txtCALCUL_CHRG1 = new BANANA.Windows.Controls.TextBox();
			this._txtLOAN_INTEREST = new BANANA.Windows.Controls.TextBox();
			this._dtpSTRT_DT = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this._btnSave = new DemoClient.Controls.BananaButton();
			this._btnClose = new DemoClient.Controls.BananaButton();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel1);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(796, 250);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "수수료정보";
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 4;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
			this.tableLayoutPanel1.Controls.Add(this._cmbINTEREST_AGT_CD, 3, 7);
			this.tableLayoutPanel1.Controls.Add(this._cmbCALCUL_AGT_CD, 1, 7);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST6, 3, 6);
			this.tableLayoutPanel1.Controls.Add(this._txtCALCUL_CHRG6, 1, 6);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST5, 3, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtCALCUL_CHRG5, 1, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST4, 3, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtCALCUL_CHRG4, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST3, 3, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtCALCUL_CHRG3, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST2, 3, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtCALCUL_CHRG2, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtINTEREST1, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtCALCUL_CHRG1, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtLOAN_INTEREST, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this._dtpSTRT_DT, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label4, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.label5, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.label6, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.label7, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.label8, 2, 3);
			this.tableLayoutPanel1.Controls.Add(this.label9, 0, 4);
			this.tableLayoutPanel1.Controls.Add(this.label10, 2, 4);
			this.tableLayoutPanel1.Controls.Add(this.label11, 0, 5);
			this.tableLayoutPanel1.Controls.Add(this.label12, 2, 5);
			this.tableLayoutPanel1.Controls.Add(this.label13, 0, 6);
			this.tableLayoutPanel1.Controls.Add(this.label14, 2, 6);
			this.tableLayoutPanel1.Controls.Add(this.label15, 0, 7);
			this.tableLayoutPanel1.Controls.Add(this.label16, 2, 7);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 8;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(790, 218);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// _cmbINTEREST_AGT_CD
			// 
			this._cmbINTEREST_AGT_CD.DataSource = null;
			this._cmbINTEREST_AGT_CD.DelegateProperty = true;
			this._cmbINTEREST_AGT_CD.Location = new System.Drawing.Point(598, 192);
			this._cmbINTEREST_AGT_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbINTEREST_AGT_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbINTEREST_AGT_CD.Name = "_cmbINTEREST_AGT_CD";
			this._cmbINTEREST_AGT_CD.SelectedIndex = -1;
			this._cmbINTEREST_AGT_CD.SelectedItem = null;
			this._cmbINTEREST_AGT_CD.SelectedValue = null;
			this._cmbINTEREST_AGT_CD.Size = new System.Drawing.Size(189, 21);
			this._cmbINTEREST_AGT_CD.TabIndex = 1016;
			this._cmbINTEREST_AGT_CD.ValidationGroup = null;
			// 
			// _cmbCALCUL_AGT_CD
			// 
			this._cmbCALCUL_AGT_CD.DataSource = null;
			this._cmbCALCUL_AGT_CD.DelegateProperty = true;
			this._cmbCALCUL_AGT_CD.Location = new System.Drawing.Point(203, 192);
			this._cmbCALCUL_AGT_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCALCUL_AGT_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCALCUL_AGT_CD.Name = "_cmbCALCUL_AGT_CD";
			this._cmbCALCUL_AGT_CD.SelectedIndex = -1;
			this._cmbCALCUL_AGT_CD.SelectedItem = null;
			this._cmbCALCUL_AGT_CD.SelectedValue = null;
			this._cmbCALCUL_AGT_CD.Size = new System.Drawing.Size(189, 21);
			this._cmbCALCUL_AGT_CD.TabIndex = 1015;
			this._cmbCALCUL_AGT_CD.ValidationGroup = null;
			// 
			// _txtINTEREST6
			// 
			this._txtINTEREST6.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST6.DelegateProperty = true;
			this._txtINTEREST6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST6.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtINTEREST6.Location = new System.Drawing.Point(598, 165);
			this._txtINTEREST6.Name = "_txtINTEREST6";
			this._txtINTEREST6.Size = new System.Drawing.Size(189, 23);
			this._txtINTEREST6.TabIndex = 1014;
			this._txtINTEREST6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST6.ValidationGroup = null;
			this._txtINTEREST6.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST6.WaterMarkText = "";
			// 
			// _txtCALCUL_CHRG6
			// 
			this._txtCALCUL_CHRG6.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCALCUL_CHRG6.DelegateProperty = true;
			this._txtCALCUL_CHRG6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCALCUL_CHRG6.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCALCUL_CHRG6.Location = new System.Drawing.Point(203, 165);
			this._txtCALCUL_CHRG6.Name = "_txtCALCUL_CHRG6";
			this._txtCALCUL_CHRG6.Size = new System.Drawing.Size(189, 23);
			this._txtCALCUL_CHRG6.TabIndex = 1013;
			this._txtCALCUL_CHRG6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCALCUL_CHRG6.ValidationGroup = null;
			this._txtCALCUL_CHRG6.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCALCUL_CHRG6.WaterMarkText = "";
			// 
			// _txtINTEREST5
			// 
			this._txtINTEREST5.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST5.DelegateProperty = true;
			this._txtINTEREST5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST5.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtINTEREST5.Location = new System.Drawing.Point(598, 138);
			this._txtINTEREST5.Name = "_txtINTEREST5";
			this._txtINTEREST5.Size = new System.Drawing.Size(189, 23);
			this._txtINTEREST5.TabIndex = 1012;
			this._txtINTEREST5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST5.ValidationGroup = null;
			this._txtINTEREST5.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST5.WaterMarkText = "";
			// 
			// _txtCALCUL_CHRG5
			// 
			this._txtCALCUL_CHRG5.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCALCUL_CHRG5.DelegateProperty = true;
			this._txtCALCUL_CHRG5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCALCUL_CHRG5.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCALCUL_CHRG5.Location = new System.Drawing.Point(203, 138);
			this._txtCALCUL_CHRG5.Name = "_txtCALCUL_CHRG5";
			this._txtCALCUL_CHRG5.Size = new System.Drawing.Size(189, 23);
			this._txtCALCUL_CHRG5.TabIndex = 1011;
			this._txtCALCUL_CHRG5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCALCUL_CHRG5.ValidationGroup = null;
			this._txtCALCUL_CHRG5.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCALCUL_CHRG5.WaterMarkText = "";
			// 
			// _txtINTEREST4
			// 
			this._txtINTEREST4.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST4.DelegateProperty = true;
			this._txtINTEREST4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST4.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtINTEREST4.Location = new System.Drawing.Point(598, 111);
			this._txtINTEREST4.Name = "_txtINTEREST4";
			this._txtINTEREST4.Size = new System.Drawing.Size(189, 23);
			this._txtINTEREST4.TabIndex = 1010;
			this._txtINTEREST4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST4.ValidationGroup = null;
			this._txtINTEREST4.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST4.WaterMarkText = "";
			// 
			// _txtCALCUL_CHRG4
			// 
			this._txtCALCUL_CHRG4.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCALCUL_CHRG4.DelegateProperty = true;
			this._txtCALCUL_CHRG4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCALCUL_CHRG4.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCALCUL_CHRG4.Location = new System.Drawing.Point(203, 111);
			this._txtCALCUL_CHRG4.Name = "_txtCALCUL_CHRG4";
			this._txtCALCUL_CHRG4.Size = new System.Drawing.Size(189, 23);
			this._txtCALCUL_CHRG4.TabIndex = 1009;
			this._txtCALCUL_CHRG4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCALCUL_CHRG4.ValidationGroup = null;
			this._txtCALCUL_CHRG4.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCALCUL_CHRG4.WaterMarkText = "";
			// 
			// _txtINTEREST3
			// 
			this._txtINTEREST3.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST3.DelegateProperty = true;
			this._txtINTEREST3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST3.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtINTEREST3.Location = new System.Drawing.Point(598, 84);
			this._txtINTEREST3.Name = "_txtINTEREST3";
			this._txtINTEREST3.Size = new System.Drawing.Size(189, 23);
			this._txtINTEREST3.TabIndex = 1008;
			this._txtINTEREST3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST3.ValidationGroup = null;
			this._txtINTEREST3.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST3.WaterMarkText = "";
			// 
			// _txtCALCUL_CHRG3
			// 
			this._txtCALCUL_CHRG3.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCALCUL_CHRG3.DelegateProperty = true;
			this._txtCALCUL_CHRG3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCALCUL_CHRG3.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCALCUL_CHRG3.Location = new System.Drawing.Point(203, 84);
			this._txtCALCUL_CHRG3.Name = "_txtCALCUL_CHRG3";
			this._txtCALCUL_CHRG3.Size = new System.Drawing.Size(189, 23);
			this._txtCALCUL_CHRG3.TabIndex = 1007;
			this._txtCALCUL_CHRG3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCALCUL_CHRG3.ValidationGroup = null;
			this._txtCALCUL_CHRG3.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCALCUL_CHRG3.WaterMarkText = "";
			// 
			// _txtINTEREST2
			// 
			this._txtINTEREST2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST2.DelegateProperty = true;
			this._txtINTEREST2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST2.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtINTEREST2.Location = new System.Drawing.Point(598, 57);
			this._txtINTEREST2.Name = "_txtINTEREST2";
			this._txtINTEREST2.Size = new System.Drawing.Size(189, 23);
			this._txtINTEREST2.TabIndex = 1006;
			this._txtINTEREST2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST2.ValidationGroup = null;
			this._txtINTEREST2.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST2.WaterMarkText = "";
			// 
			// _txtCALCUL_CHRG2
			// 
			this._txtCALCUL_CHRG2.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCALCUL_CHRG2.DelegateProperty = true;
			this._txtCALCUL_CHRG2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCALCUL_CHRG2.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCALCUL_CHRG2.Location = new System.Drawing.Point(203, 57);
			this._txtCALCUL_CHRG2.Name = "_txtCALCUL_CHRG2";
			this._txtCALCUL_CHRG2.Size = new System.Drawing.Size(189, 23);
			this._txtCALCUL_CHRG2.TabIndex = 1005;
			this._txtCALCUL_CHRG2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCALCUL_CHRG2.ValidationGroup = null;
			this._txtCALCUL_CHRG2.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCALCUL_CHRG2.WaterMarkText = "";
			// 
			// _txtINTEREST1
			// 
			this._txtINTEREST1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtINTEREST1.DelegateProperty = true;
			this._txtINTEREST1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtINTEREST1.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtINTEREST1.Location = new System.Drawing.Point(598, 30);
			this._txtINTEREST1.Name = "_txtINTEREST1";
			this._txtINTEREST1.Size = new System.Drawing.Size(189, 23);
			this._txtINTEREST1.TabIndex = 1004;
			this._txtINTEREST1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtINTEREST1.ValidationGroup = null;
			this._txtINTEREST1.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtINTEREST1.WaterMarkText = "";
			// 
			// _txtCALCUL_CHRG1
			// 
			this._txtCALCUL_CHRG1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCALCUL_CHRG1.DelegateProperty = true;
			this._txtCALCUL_CHRG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCALCUL_CHRG1.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCALCUL_CHRG1.Location = new System.Drawing.Point(203, 30);
			this._txtCALCUL_CHRG1.Name = "_txtCALCUL_CHRG1";
			this._txtCALCUL_CHRG1.Size = new System.Drawing.Size(189, 23);
			this._txtCALCUL_CHRG1.TabIndex = 1003;
			this._txtCALCUL_CHRG1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCALCUL_CHRG1.ValidationGroup = null;
			this._txtCALCUL_CHRG1.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCALCUL_CHRG1.WaterMarkText = "";
			// 
			// _txtLOAN_INTEREST
			// 
			this._txtLOAN_INTEREST.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtLOAN_INTEREST.DelegateProperty = true;
			this._txtLOAN_INTEREST.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtLOAN_INTEREST.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtLOAN_INTEREST.Location = new System.Drawing.Point(598, 3);
			this._txtLOAN_INTEREST.Name = "_txtLOAN_INTEREST";
			this._txtLOAN_INTEREST.Size = new System.Drawing.Size(189, 23);
			this._txtLOAN_INTEREST.TabIndex = 1002;
			this._txtLOAN_INTEREST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtLOAN_INTEREST.ValidationGroup = null;
			this._txtLOAN_INTEREST.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtLOAN_INTEREST.WaterMarkText = "";
			// 
			// _dtpSTRT_DT
			// 
			this._dtpSTRT_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpSTRT_DT.Checked = false;
			this._dtpSTRT_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpSTRT_DT.DelegateProperty = true;
			this._dtpSTRT_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpSTRT_DT.Location = new System.Drawing.Point(203, 3);
			this._dtpSTRT_DT.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpSTRT_DT.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpSTRT_DT.Name = "_dtpSTRT_DT";
			this._dtpSTRT_DT.Size = new System.Drawing.Size(130, 21);
			this._dtpSTRT_DT.TabIndex = 1001;
			this._dtpSTRT_DT.ValidationGroup = "a";
			this._dtpSTRT_DT.Value = new System.DateTime(2016, 8, 9, 10, 53, 39, 936);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(130, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(67, 15);
			this.label1.TabIndex = 10;
			this.label1.Text = "등록일자";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(487, 6);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(105, 15);
			this.label2.TabIndex = 11;
			this.label2.Text = "비즈론이자(%)";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(21, 33);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(176, 15);
			this.label3.TabIndex = 12;
			this.label3.Text = "정산수수료(%) - 5억이하";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(431, 33);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(161, 15);
			this.label4.TabIndex = 13;
			this.label4.Text = "대출이자(%) - 5억이하";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(21, 60);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(176, 15);
			this.label5.TabIndex = 14;
			this.label5.Text = "정산수수료(%) - 5억초과";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(431, 60);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(161, 15);
			this.label6.TabIndex = 15;
			this.label6.Text = "대출이자(%) - 5억초과";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(13, 87);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(184, 15);
			this.label7.TabIndex = 16;
			this.label7.Text = "정산수수료(%) - 10억초과";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(423, 87);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(169, 15);
			this.label8.TabIndex = 17;
			this.label8.Text = "대출이자(%) - 10억초과";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(13, 114);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(184, 15);
			this.label9.TabIndex = 18;
			this.label9.Text = "정산수수료(%) - 15억초과";
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(423, 114);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(169, 15);
			this.label10.TabIndex = 19;
			this.label10.Text = "대출이자(%) - 15억초과";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(13, 141);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(184, 15);
			this.label11.TabIndex = 20;
			this.label11.Text = "정산수수료(%) - 20억초과";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(423, 141);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(169, 15);
			this.label12.TabIndex = 21;
			this.label12.Text = "대출이자(%) - 20억초과";
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(13, 168);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(184, 15);
			this.label13.TabIndex = 22;
			this.label13.Text = "정산수수료(%) - 30억초과";
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(423, 168);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(169, 15);
			this.label14.TabIndex = 23;
			this.label14.Text = "대출이자(%) - 30억초과";
			// 
			// label15
			// 
			this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(65, 196);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(132, 15);
			this.label15.TabIndex = 24;
			this.label15.Text = "정산수수료 대리점";
			// 
			// label16
			// 
			this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(425, 196);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(167, 15);
			this.label16.TabIndex = 25;
			this.label16.Text = "대출이자 수수료 대리점";
			// 
			// _btnSave
			// 
			this._btnSave.ButtonConfirm = true;
			this._btnSave.DelegateProperty = true;
			this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.Location = new System.Drawing.Point(628, 265);
			this._btnSave.Name = "_btnSave";
			this._btnSave.Size = new System.Drawing.Size(75, 27);
			this._btnSave.TabIndex = 1114;
			this._btnSave.Text = "      저   장";
			this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.UseVisualStyleBackColor = true;
			this._btnSave.ValidationGroup = "a";
			this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
			// 
			// _btnClose
			// 
			this._btnClose.DelegateProperty = true;
			this._btnClose.Image = global::DemoClient.Properties.Resources.red_62690;
			this._btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.Location = new System.Drawing.Point(709, 265);
			this._btnClose.Name = "_btnClose";
			this._btnClose.Size = new System.Drawing.Size(75, 27);
			this._btnClose.TabIndex = 1115;
			this._btnClose.Text = "      닫   기";
			this._btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.UseVisualStyleBackColor = true;
			this._btnClose.ValidationGroup = null;
			this._btnClose.Click += new System.EventHandler(this._btnClose_Click);
			// 
			// BAS0741
			// 
			this.ClientSize = new System.Drawing.Size(796, 304);
			this.Controls.Add(this._btnSave);
			this.Controls.Add(this._btnClose);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "BAS0741";
			this.Text = "대리점.영업수수료추가:BAS0741";
			this.Load += new System.EventHandler(this.BAS0741_Load);
			this.Shown += new System.EventHandler(this.BAS0741_Shown);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private BANANA.Windows.Controls.DateTimePicker _dtpSTRT_DT;
		private BANANA.Windows.Controls.TextBox _txtINTEREST6;
		private BANANA.Windows.Controls.TextBox _txtCALCUL_CHRG6;
		private BANANA.Windows.Controls.TextBox _txtINTEREST5;
		private BANANA.Windows.Controls.TextBox _txtCALCUL_CHRG5;
		private BANANA.Windows.Controls.TextBox _txtINTEREST4;
		private BANANA.Windows.Controls.TextBox _txtCALCUL_CHRG4;
		private BANANA.Windows.Controls.TextBox _txtINTEREST3;
		private BANANA.Windows.Controls.TextBox _txtCALCUL_CHRG3;
		private BANANA.Windows.Controls.TextBox _txtINTEREST2;
		private BANANA.Windows.Controls.TextBox _txtCALCUL_CHRG2;
		private BANANA.Windows.Controls.TextBox _txtINTEREST1;
		private BANANA.Windows.Controls.TextBox _txtCALCUL_CHRG1;
		private BANANA.Windows.Controls.TextBox _txtLOAN_INTEREST;
		private BANANA.Windows.Controls.ComboBox _cmbINTEREST_AGT_CD;
		private BANANA.Windows.Controls.ComboBox _cmbCALCUL_AGT_CD;
		private DemoClient.Controls.BananaButton _btnSave;
		private DemoClient.Controls.BananaButton _btnClose;
	}
}
