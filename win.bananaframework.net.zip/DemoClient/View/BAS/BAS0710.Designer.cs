﻿namespace DemoClient.View.BAS
{
	partial class BAS0710
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0710));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.panel4 = new System.Windows.Forms.Panel();
			this._chkAuto = new BANANA.Windows.Controls.CheckBox();
			this._txtAGT_CD = new BANANA.Windows.Controls.TextBox();
			this.labelmemo = new System.Windows.Forms.Label();
			this._txtADDR_DTL = new BANANA.Windows.Controls.TextBox();
			this._txtPRSNT_NM = new BANANA.Windows.Controls.TextBox();
			this._txtAGT_NM = new BANANA.Windows.Controls.TextBox();
			this.lblCOMPANY_CD = new BANANA.Windows.Controls.Label();
			this.lblUSR_ID = new BANANA.Windows.Controls.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lblUSR_PASS = new BANANA.Windows.Controls.Label();
			this.lblUSR_ROLL = new BANANA.Windows.Controls.Label();
			this._txtMEMO = new BANANA.Windows.Controls.TextBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this._btnFindZipCode01 = new DemoClient.Controls.BananaButton();
			this._txtZIP_NO = new BANANA.Windows.Controls.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this._txtTELNO = new BANANA.Windows.Controls.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this._txtADDR_BSC = new BANANA.Windows.Controls.TextBox();
			this._txtFAXNO = new BANANA.Windows.Controls.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.panel3 = new System.Windows.Forms.Panel();
			this._rbBI_SIMTAX_Y = new BANANA.Windows.Controls.RadioButton();
			this._rbBI_SIMTAX_N = new BANANA.Windows.Controls.RadioButton();
			this.label16 = new System.Windows.Forms.Label();
			this._txtBI_ADDR_BSC = new BANANA.Windows.Controls.TextBox();
			this._txtBI_BUBIN_NO = new BANANA.Windows.Controls.TextBox();
			this._txtBI_SAUP_NO = new BANANA.Windows.Controls.TextBox();
			this._txtBI_PRSNT_NM = new BANANA.Windows.Controls.TextBox();
			this.label6 = new BANANA.Windows.Controls.Label();
			this.label7 = new BANANA.Windows.Controls.Label();
			this.label8 = new BANANA.Windows.Controls.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new BANANA.Windows.Controls.Label();
			this._txtBI_COMPANY_NM = new BANANA.Windows.Controls.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this._txtBI_JONGMOK = new BANANA.Windows.Controls.TextBox();
			this._txtBI_ADDR_DTL = new BANANA.Windows.Controls.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this._txtBI_EMAIL = new BANANA.Windows.Controls.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this._btnFindZipCode02 = new DemoClient.Controls.BananaButton();
			this._txtBI_ZIP_NO = new BANANA.Windows.Controls.TextBox();
			this._cmbBI_BINF_CD = new BANANA.Windows.Controls.ComboBox();
			this._txtBI_UPTE = new BANANA.Windows.Controls.TextBox();
			this.label13 = new BANANA.Windows.Controls.Label();
			this._btnClose = new DemoClient.Controls.BananaButton();
			this._btnSave = new DemoClient.Controls.BananaButton();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
			this._txtPI_ADDR_BSC = new BANANA.Windows.Controls.TextBox();
			this._txtPI_CELLNO = new BANANA.Windows.Controls.TextBox();
			this._txtPI_TELNO = new BANANA.Windows.Controls.TextBox();
			this._txtPI_CNTZ_NO = new BANANA.Windows.Controls.TextBox();
			this.label18 = new BANANA.Windows.Controls.Label();
			this.label19 = new BANANA.Windows.Controls.Label();
			this.label20 = new BANANA.Windows.Controls.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this._txtPI_PRSNT_NM = new BANANA.Windows.Controls.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this._txtPI_ADDR_DTL = new BANANA.Windows.Controls.TextBox();
			this.panel5 = new System.Windows.Forms.Panel();
			this._btnFindZipCode03 = new DemoClient.Controls.BananaButton();
			this._txtPI_ZIP_NO = new BANANA.Windows.Controls.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this._txtPI_EMAIL = new BANANA.Windows.Controls.TextBox();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel2.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel1.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.tableLayoutPanel3.SuspendLayout();
			this.panel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel1);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(696, 247);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "기본정보";
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 6;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.labelmemo, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtADDR_DTL, 5, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtPRSNT_NM, 5, 0);
			this.tableLayoutPanel1.Controls.Add(this._txtAGT_NM, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblCOMPANY_CD, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.label2, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_PASS, 4, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_ROLL, 4, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtMEMO, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtTELNO, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.label4, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtADDR_BSC, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtFAXNO, 3, 2);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 4;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(690, 220);
			this.tableLayoutPanel1.TabIndex = 2;
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this._chkAuto);
			this.panel4.Controls.Add(this._txtAGT_CD);
			this.panel4.Location = new System.Drawing.Point(90, 0);
			this.panel4.Margin = new System.Windows.Forms.Padding(0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(140, 27);
			this.panel4.TabIndex = 100;
			// 
			// _chkAuto
			// 
			this._chkAuto.AutoSize = true;
			this._chkAuto.Checked = true;
			this._chkAuto.CheckState = System.Windows.Forms.CheckState.Checked;
			this._chkAuto.Location = new System.Drawing.Point(67, 6);
			this._chkAuto.Name = "_chkAuto";
			this._chkAuto.Size = new System.Drawing.Size(89, 19);
			this._chkAuto.TabIndex = 110;
			this._chkAuto.Text = "자동채번";
			this._chkAuto.UseVisualStyleBackColor = true;
			this._chkAuto.CheckedChanged += new System.EventHandler(this._chkAuto_CheckedChanged);
			// 
			// _txtAGT_CD
			// 
			this._txtAGT_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAGT_CD.DelegateProperty = true;
			this._txtAGT_CD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAGT_CD.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtAGT_CD.Location = new System.Drawing.Point(3, 4);
			this._txtAGT_CD.MaxLength = 10;
			this._txtAGT_CD.Name = "_txtAGT_CD";
			this._txtAGT_CD.ReadOnly = true;
			this._txtAGT_CD.Size = new System.Drawing.Size(60, 23);
			this._txtAGT_CD.TabIndex = 100;
			this._txtAGT_CD.ValidationGroup = null;
			this._txtAGT_CD.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAGT_CD.WaterMarkText = "";
			// 
			// labelmemo
			// 
			this.labelmemo.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.labelmemo.AutoSize = true;
			this.labelmemo.Location = new System.Drawing.Point(50, 143);
			this.labelmemo.Name = "labelmemo";
			this.labelmemo.Size = new System.Drawing.Size(37, 15);
			this.labelmemo.TabIndex = 38;
			this.labelmemo.Text = "메모";
			// 
			// _txtADDR_DTL
			// 
			this._txtADDR_DTL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtADDR_DTL.DelegateProperty = true;
			this._txtADDR_DTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtADDR_DTL.Location = new System.Drawing.Point(553, 30);
			this._txtADDR_DTL.Name = "_txtADDR_DTL";
			this._txtADDR_DTL.Size = new System.Drawing.Size(130, 23);
			this._txtADDR_DTL.TabIndex = 170;
			this._txtADDR_DTL.ValidationGroup = null;
			this._txtADDR_DTL.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtADDR_DTL.WaterMarkText = "";
			// 
			// _txtPRSNT_NM
			// 
			this._txtPRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPRSNT_NM.Compulsory = true;
			this._txtPRSNT_NM.DelegateProperty = true;
			this._txtPRSNT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPRSNT_NM.Location = new System.Drawing.Point(553, 3);
			this._txtPRSNT_NM.Name = "_txtPRSNT_NM";
			this._txtPRSNT_NM.Size = new System.Drawing.Size(130, 23);
			this._txtPRSNT_NM.TabIndex = 130;
			this._txtPRSNT_NM.ValidationGroup = "a";
			this._txtPRSNT_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPRSNT_NM.WaterMarkText = "";
			// 
			// _txtAGT_NM
			// 
			this._txtAGT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAGT_NM.Compulsory = true;
			this._txtAGT_NM.DelegateProperty = true;
			this._txtAGT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAGT_NM.Location = new System.Drawing.Point(323, 3);
			this._txtAGT_NM.Name = "_txtAGT_NM";
			this._txtAGT_NM.Size = new System.Drawing.Size(130, 23);
			this._txtAGT_NM.TabIndex = 120;
			this._txtAGT_NM.ValidationGroup = "a";
			this._txtAGT_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtAGT_NM.WaterMarkText = "";
			// 
			// lblCOMPANY_CD
			// 
			this.lblCOMPANY_CD.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblCOMPANY_CD.AutoSize = true;
			this.lblCOMPANY_CD.Location = new System.Drawing.Point(5, 6);
			this.lblCOMPANY_CD.Name = "lblCOMPANY_CD";
			this.lblCOMPANY_CD.Size = new System.Drawing.Size(82, 15);
			this.lblCOMPANY_CD.TabIndex = 0;
			this.lblCOMPANY_CD.Text = "대리점코드";
			// 
			// lblUSR_ID
			// 
			this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_ID.AutoSize = true;
			this.lblUSR_ID.Location = new System.Drawing.Point(20, 33);
			this.lblUSR_ID.Name = "lblUSR_ID";
			this.lblUSR_ID.Size = new System.Drawing.Size(67, 15);
			this.lblUSR_ID.TabIndex = 2;
			this.lblUSR_ID.Text = "우편번호";
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(250, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(67, 15);
			this.label1.TabIndex = 9;
			this.label1.Text = "대리점명";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(250, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 15);
			this.label2.TabIndex = 10;
			this.label2.Text = "기본주소";
			// 
			// lblUSR_PASS
			// 
			this.lblUSR_PASS.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_PASS.AutoSize = true;
			this.lblUSR_PASS.Location = new System.Drawing.Point(480, 6);
			this.lblUSR_PASS.Name = "lblUSR_PASS";
			this.lblUSR_PASS.Size = new System.Drawing.Size(67, 15);
			this.lblUSR_PASS.TabIndex = 8;
			this.lblUSR_PASS.Text = "대표자명";
			// 
			// lblUSR_ROLL
			// 
			this.lblUSR_ROLL.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_ROLL.AutoSize = true;
			this.lblUSR_ROLL.Location = new System.Drawing.Point(480, 33);
			this.lblUSR_ROLL.Name = "lblUSR_ROLL";
			this.lblUSR_ROLL.Size = new System.Drawing.Size(67, 15);
			this.lblUSR_ROLL.TabIndex = 7;
			this.lblUSR_ROLL.Text = "상세주소";
			// 
			// _txtMEMO
			// 
			this._txtMEMO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.tableLayoutPanel1.SetColumnSpan(this._txtMEMO, 5);
			this._txtMEMO.DelegateProperty = true;
			this._txtMEMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtMEMO.Location = new System.Drawing.Point(93, 86);
			this._txtMEMO.Multiline = true;
			this._txtMEMO.Name = "_txtMEMO";
			this._txtMEMO.Size = new System.Drawing.Size(590, 129);
			this._txtMEMO.TabIndex = 200;
			this._txtMEMO.ValidationGroup = null;
			this._txtMEMO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtMEMO.WaterMarkText = "";
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this._btnFindZipCode01);
			this.panel2.Controls.Add(this._txtZIP_NO);
			this.panel2.Location = new System.Drawing.Point(90, 27);
			this.panel2.Margin = new System.Windows.Forms.Padding(0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(140, 27);
			this.panel2.TabIndex = 140;
			this.panel2.TabStop = true;
			// 
			// _btnFindZipCode01
			// 
			this._btnFindZipCode01.DelegateProperty = true;
			this._btnFindZipCode01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnFindZipCode01.Location = new System.Drawing.Point(79, 3);
			this._btnFindZipCode01.Name = "_btnFindZipCode01";
			this._btnFindZipCode01.Size = new System.Drawing.Size(54, 21);
			this._btnFindZipCode01.TabIndex = 20;
			this._btnFindZipCode01.TabStop = false;
			this._btnFindZipCode01.Text = "검   색";
			this._btnFindZipCode01.UseVisualStyleBackColor = true;
			this._btnFindZipCode01.ValidationGroup = null;
			this._btnFindZipCode01.Click += new System.EventHandler(this._btnFindZipCode01_Click);
			// 
			// _txtZIP_NO
			// 
			this._txtZIP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtZIP_NO.DelegateProperty = true;
			this._txtZIP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtZIP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtZIP_NO.Location = new System.Drawing.Point(3, 4);
			this._txtZIP_NO.MaxLength = 7;
			this._txtZIP_NO.Name = "_txtZIP_NO";
			this._txtZIP_NO.Size = new System.Drawing.Size(70, 23);
			this._txtZIP_NO.TabIndex = 10;
			this._txtZIP_NO.ValidationGroup = null;
			this._txtZIP_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtZIP_NO.WaterMarkText = "";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(20, 60);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(67, 15);
			this.label3.TabIndex = 31;
			this.label3.Text = "전화번호";
			// 
			// _txtTELNO
			// 
			this._txtTELNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtTELNO.DelegateProperty = true;
			this._txtTELNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtTELNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtTELNO.Location = new System.Drawing.Point(93, 57);
			this._txtTELNO.Name = "_txtTELNO";
			this._txtTELNO.Size = new System.Drawing.Size(130, 23);
			this._txtTELNO.TabIndex = 180;
			this._txtTELNO.ValidationGroup = null;
			this._txtTELNO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtTELNO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(250, 60);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(67, 15);
			this.label4.TabIndex = 33;
			this.label4.Text = "팩스번호";
			// 
			// _txtADDR_BSC
			// 
			this._txtADDR_BSC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtADDR_BSC.DelegateProperty = true;
			this._txtADDR_BSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtADDR_BSC.Location = new System.Drawing.Point(323, 30);
			this._txtADDR_BSC.Name = "_txtADDR_BSC";
			this._txtADDR_BSC.Size = new System.Drawing.Size(130, 23);
			this._txtADDR_BSC.TabIndex = 160;
			this._txtADDR_BSC.ValidationGroup = null;
			this._txtADDR_BSC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtADDR_BSC.WaterMarkText = "";
			// 
			// _txtFAXNO
			// 
			this._txtFAXNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtFAXNO.DelegateProperty = true;
			this._txtFAXNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFAXNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtFAXNO.Location = new System.Drawing.Point(323, 57);
			this._txtFAXNO.Name = "_txtFAXNO";
			this._txtFAXNO.Size = new System.Drawing.Size(130, 23);
			this._txtFAXNO.TabIndex = 190;
			this._txtFAXNO.ValidationGroup = null;
			this._txtFAXNO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFAXNO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.tableLayoutPanel2);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox2.Location = new System.Drawing.Point(0, 247);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(696, 135);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "사업자등록정보";
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 6;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.Controls.Add(this.panel3, 5, 1);
			this.tableLayoutPanel2.Controls.Add(this.label16, 4, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_ADDR_BSC, 3, 2);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_BUBIN_NO, 3, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_SAUP_NO, 1, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_PRSNT_NM, 3, 0);
			this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.label8, 0, 2);
			this.tableLayoutPanel2.Controls.Add(this.label9, 2, 0);
			this.tableLayoutPanel2.Controls.Add(this.label10, 2, 1);
			this.tableLayoutPanel2.Controls.Add(this.label11, 2, 2);
			this.tableLayoutPanel2.Controls.Add(this.label12, 4, 0);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_COMPANY_NM, 1, 0);
			this.tableLayoutPanel2.Controls.Add(this.label5, 4, 2);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_JONGMOK, 3, 3);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_ADDR_DTL, 5, 2);
			this.tableLayoutPanel2.Controls.Add(this.label15, 2, 3);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_EMAIL, 5, 3);
			this.tableLayoutPanel2.Controls.Add(this.label14, 4, 3);
			this.tableLayoutPanel2.Controls.Add(this.panel1, 1, 2);
			this.tableLayoutPanel2.Controls.Add(this._cmbBI_BINF_CD, 5, 0);
			this.tableLayoutPanel2.Controls.Add(this._txtBI_UPTE, 1, 3);
			this.tableLayoutPanel2.Controls.Add(this.label13, 0, 3);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 4;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(690, 108);
			this.tableLayoutPanel2.TabIndex = 4;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this._rbBI_SIMTAX_Y);
			this.panel3.Controls.Add(this._rbBI_SIMTAX_N);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(553, 30);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(134, 21);
			this.panel3.TabIndex = 260;
			// 
			// _rbBI_SIMTAX_Y
			// 
			this._rbBI_SIMTAX_Y.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBI_SIMTAX_Y.AutoSize = true;
			this._rbBI_SIMTAX_Y.Enabled = false;
			this._rbBI_SIMTAX_Y.Location = new System.Drawing.Point(4, 2);
			this._rbBI_SIMTAX_Y.Name = "_rbBI_SIMTAX_Y";
			this._rbBI_SIMTAX_Y.Size = new System.Drawing.Size(36, 19);
			this._rbBI_SIMTAX_Y.TabIndex = 260;
			this._rbBI_SIMTAX_Y.Text = "Y";
			this._rbBI_SIMTAX_Y.UseVisualStyleBackColor = true;
			// 
			// _rbBI_SIMTAX_N
			// 
			this._rbBI_SIMTAX_N.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBI_SIMTAX_N.AutoSize = true;
			this._rbBI_SIMTAX_N.Checked = true;
			this._rbBI_SIMTAX_N.Enabled = false;
			this._rbBI_SIMTAX_N.Location = new System.Drawing.Point(43, 2);
			this._rbBI_SIMTAX_N.Name = "_rbBI_SIMTAX_N";
			this._rbBI_SIMTAX_N.Size = new System.Drawing.Size(37, 19);
			this._rbBI_SIMTAX_N.TabIndex = 270;
			this._rbBI_SIMTAX_N.TabStop = true;
			this._rbBI_SIMTAX_N.Text = "N";
			this._rbBI_SIMTAX_N.UseVisualStyleBackColor = true;
			// 
			// label16
			// 
			this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(465, 27);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(82, 27);
			this.label16.TabIndex = 11;
			this.label16.Text = "간이과세여부";
			// 
			// _txtBI_ADDR_BSC
			// 
			this._txtBI_ADDR_BSC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_ADDR_BSC.DelegateProperty = true;
			this._txtBI_ADDR_BSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_ADDR_BSC.Location = new System.Drawing.Point(323, 57);
			this._txtBI_ADDR_BSC.Name = "_txtBI_ADDR_BSC";
			this._txtBI_ADDR_BSC.Size = new System.Drawing.Size(130, 23);
			this._txtBI_ADDR_BSC.TabIndex = 300;
			this._txtBI_ADDR_BSC.ValidationGroup = null;
			this._txtBI_ADDR_BSC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_ADDR_BSC.WaterMarkText = "";
			// 
			// _txtBI_BUBIN_NO
			// 
			this._txtBI_BUBIN_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_BUBIN_NO.DelegateProperty = true;
			this._txtBI_BUBIN_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_BUBIN_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtBI_BUBIN_NO.Location = new System.Drawing.Point(323, 30);
			this._txtBI_BUBIN_NO.MaxLength = 14;
			this._txtBI_BUBIN_NO.Name = "_txtBI_BUBIN_NO";
			this._txtBI_BUBIN_NO.Size = new System.Drawing.Size(130, 23);
			this._txtBI_BUBIN_NO.TabIndex = 250;
			this._txtBI_BUBIN_NO.ValidationGroup = null;
			this._txtBI_BUBIN_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_BUBIN_NO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// _txtBI_SAUP_NO
			// 
			this._txtBI_SAUP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_SAUP_NO.DelegateProperty = true;
			this._txtBI_SAUP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_SAUP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtBI_SAUP_NO.Location = new System.Drawing.Point(93, 30);
			this._txtBI_SAUP_NO.MaxLength = 12;
			this._txtBI_SAUP_NO.Name = "_txtBI_SAUP_NO";
			this._txtBI_SAUP_NO.Size = new System.Drawing.Size(130, 23);
			this._txtBI_SAUP_NO.TabIndex = 240;
			this._txtBI_SAUP_NO.ValidationGroup = null;
			this._txtBI_SAUP_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_SAUP_NO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// _txtBI_PRSNT_NM
			// 
			this._txtBI_PRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_PRSNT_NM.DelegateProperty = true;
			this._txtBI_PRSNT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_PRSNT_NM.Location = new System.Drawing.Point(323, 3);
			this._txtBI_PRSNT_NM.Name = "_txtBI_PRSNT_NM";
			this._txtBI_PRSNT_NM.Size = new System.Drawing.Size(130, 23);
			this._txtBI_PRSNT_NM.TabIndex = 220;
			this._txtBI_PRSNT_NM.ValidationGroup = null;
			this._txtBI_PRSNT_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_PRSNT_NM.WaterMarkText = "";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(35, 6);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(52, 15);
			this.label6.TabIndex = 0;
			this.label6.Text = "법인명";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(5, 27);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(82, 27);
			this.label7.TabIndex = 2;
			this.label7.Text = "사업자등록번호";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(20, 60);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(67, 15);
			this.label8.TabIndex = 4;
			this.label8.Text = "우편번호";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(250, 6);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(67, 15);
			this.label9.TabIndex = 9;
			this.label9.Text = "대표자명";
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(235, 27);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(82, 27);
			this.label10.TabIndex = 10;
			this.label10.Text = "법인등록번호";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(250, 60);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(67, 15);
			this.label11.TabIndex = 11;
			this.label11.Text = "기본주소";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(465, 6);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(82, 15);
			this.label12.TabIndex = 8;
			this.label12.Text = "사업자구분";
			// 
			// _txtBI_COMPANY_NM
			// 
			this._txtBI_COMPANY_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_COMPANY_NM.DelegateProperty = true;
			this._txtBI_COMPANY_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_COMPANY_NM.Location = new System.Drawing.Point(93, 3);
			this._txtBI_COMPANY_NM.Name = "_txtBI_COMPANY_NM";
			this._txtBI_COMPANY_NM.Size = new System.Drawing.Size(130, 23);
			this._txtBI_COMPANY_NM.TabIndex = 210;
			this._txtBI_COMPANY_NM.ValidationGroup = null;
			this._txtBI_COMPANY_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_COMPANY_NM.WaterMarkText = "";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(480, 60);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(67, 15);
			this.label5.TabIndex = 20;
			this.label5.Text = "상세주소";
			// 
			// _txtBI_JONGMOK
			// 
			this._txtBI_JONGMOK.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_JONGMOK.DelegateProperty = true;
			this._txtBI_JONGMOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_JONGMOK.Location = new System.Drawing.Point(323, 84);
			this._txtBI_JONGMOK.Name = "_txtBI_JONGMOK";
			this._txtBI_JONGMOK.Size = new System.Drawing.Size(130, 23);
			this._txtBI_JONGMOK.TabIndex = 330;
			this._txtBI_JONGMOK.ValidationGroup = null;
			this._txtBI_JONGMOK.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_JONGMOK.WaterMarkText = "";
			// 
			// _txtBI_ADDR_DTL
			// 
			this._txtBI_ADDR_DTL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_ADDR_DTL.DelegateProperty = true;
			this._txtBI_ADDR_DTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_ADDR_DTL.Location = new System.Drawing.Point(553, 57);
			this._txtBI_ADDR_DTL.Name = "_txtBI_ADDR_DTL";
			this._txtBI_ADDR_DTL.Size = new System.Drawing.Size(130, 23);
			this._txtBI_ADDR_DTL.TabIndex = 310;
			this._txtBI_ADDR_DTL.ValidationGroup = null;
			this._txtBI_ADDR_DTL.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_ADDR_DTL.WaterMarkText = "";
			// 
			// label15
			// 
			this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(280, 87);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(37, 15);
			this.label15.TabIndex = 25;
			this.label15.Text = "종목";
			// 
			// _txtBI_EMAIL
			// 
			this._txtBI_EMAIL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_EMAIL.DelegateProperty = true;
			this._txtBI_EMAIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_EMAIL.Location = new System.Drawing.Point(553, 84);
			this._txtBI_EMAIL.Name = "_txtBI_EMAIL";
			this._txtBI_EMAIL.Size = new System.Drawing.Size(130, 23);
			this._txtBI_EMAIL.TabIndex = 340;
			this._txtBI_EMAIL.ValidationGroup = null;
			this._txtBI_EMAIL.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_EMAIL.WaterMarkText = "";
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(475, 81);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(72, 27);
			this.label14.TabIndex = 23;
			this.label14.Text = "계산서 이메일";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this._btnFindZipCode02);
			this.panel1.Controls.Add(this._txtBI_ZIP_NO);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(90, 54);
			this.panel1.Margin = new System.Windows.Forms.Padding(0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(140, 27);
			this.panel1.TabIndex = 280;
			this.panel1.TabStop = true;
			// 
			// _btnFindZipCode02
			// 
			this._btnFindZipCode02.DelegateProperty = true;
			this._btnFindZipCode02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnFindZipCode02.Location = new System.Drawing.Point(79, 3);
			this._btnFindZipCode02.Name = "_btnFindZipCode02";
			this._btnFindZipCode02.Size = new System.Drawing.Size(54, 21);
			this._btnFindZipCode02.TabIndex = 290;
			this._btnFindZipCode02.TabStop = false;
			this._btnFindZipCode02.Text = "검   색";
			this._btnFindZipCode02.UseVisualStyleBackColor = true;
			this._btnFindZipCode02.ValidationGroup = null;
			this._btnFindZipCode02.Click += new System.EventHandler(this._btnFindZipCode02_Click);
			// 
			// _txtBI_ZIP_NO
			// 
			this._txtBI_ZIP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_ZIP_NO.DelegateProperty = true;
			this._txtBI_ZIP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_ZIP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtBI_ZIP_NO.Location = new System.Drawing.Point(3, 4);
			this._txtBI_ZIP_NO.MaxLength = 7;
			this._txtBI_ZIP_NO.Name = "_txtBI_ZIP_NO";
			this._txtBI_ZIP_NO.Size = new System.Drawing.Size(70, 23);
			this._txtBI_ZIP_NO.TabIndex = 280;
			this._txtBI_ZIP_NO.ValidationGroup = null;
			this._txtBI_ZIP_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_ZIP_NO.WaterMarkText = "";
			// 
			// _cmbBI_BINF_CD
			// 
			this._cmbBI_BINF_CD.Compulsory = true;
			this._cmbBI_BINF_CD.DataSource = null;
			this._cmbBI_BINF_CD.DelegateProperty = true;
			this._cmbBI_BINF_CD.Location = new System.Drawing.Point(553, 3);
			this._cmbBI_BINF_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbBI_BINF_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbBI_BINF_CD.Name = "_cmbBI_BINF_CD";
			this._cmbBI_BINF_CD.SelectedIndex = -1;
			this._cmbBI_BINF_CD.SelectedItem = null;
			this._cmbBI_BINF_CD.SelectedValue = null;
			this._cmbBI_BINF_CD.Size = new System.Drawing.Size(130, 21);
			this._cmbBI_BINF_CD.TabIndex = 230;
			this._cmbBI_BINF_CD.ValidationGroup = null;
			this._cmbBI_BINF_CD.DropDownClosed += new System.EventHandler(this._cmbBI_BINF_CD_DropDownClosed);
			// 
			// _txtBI_UPTE
			// 
			this._txtBI_UPTE.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBI_UPTE.DelegateProperty = true;
			this._txtBI_UPTE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBI_UPTE.Location = new System.Drawing.Point(93, 84);
			this._txtBI_UPTE.Name = "_txtBI_UPTE";
			this._txtBI_UPTE.Size = new System.Drawing.Size(130, 23);
			this._txtBI_UPTE.TabIndex = 320;
			this._txtBI_UPTE.ValidationGroup = null;
			this._txtBI_UPTE.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBI_UPTE.WaterMarkText = "";
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(50, 87);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(37, 15);
			this.label13.TabIndex = 21;
			this.label13.Text = "업태";
			// 
			// _btnClose
			// 
			this._btnClose.DelegateProperty = true;
			this._btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this._btnClose.Image = global::DemoClient.Properties.Resources.red_62690;
			this._btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.Location = new System.Drawing.Point(611, 496);
			this._btnClose.Name = "_btnClose";
			this._btnClose.Size = new System.Drawing.Size(75, 27);
			this._btnClose.TabIndex = 1010;
			this._btnClose.Text = "      닫   기";
			this._btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.UseVisualStyleBackColor = true;
			this._btnClose.ValidationGroup = null;
			this._btnClose.Click += new System.EventHandler(this._btnClose_Click);
			// 
			// _btnSave
			// 
			this._btnSave.ButtonConfirm = true;
			this._btnSave.DelegateProperty = true;
			this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.Location = new System.Drawing.Point(530, 496);
			this._btnSave.Name = "_btnSave";
			this._btnSave.Size = new System.Drawing.Size(75, 27);
			this._btnSave.TabIndex = 1000;
			this._btnSave.Text = "      저   장";
			this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.UseVisualStyleBackColor = true;
			this._btnSave.ValidationGroup = "a";
			this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.tableLayoutPanel3);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox3.Location = new System.Drawing.Point(0, 382);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(696, 108);
			this.groupBox3.TabIndex = 504;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "대표자정보";
			// 
			// tableLayoutPanel3
			// 
			this.tableLayoutPanel3.ColumnCount = 6;
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel3.Controls.Add(this._txtPI_ADDR_BSC, 3, 2);
			this.tableLayoutPanel3.Controls.Add(this._txtPI_CELLNO, 3, 1);
			this.tableLayoutPanel3.Controls.Add(this._txtPI_TELNO, 1, 1);
			this.tableLayoutPanel3.Controls.Add(this._txtPI_CNTZ_NO, 3, 0);
			this.tableLayoutPanel3.Controls.Add(this.label18, 0, 0);
			this.tableLayoutPanel3.Controls.Add(this.label19, 0, 1);
			this.tableLayoutPanel3.Controls.Add(this.label20, 0, 2);
			this.tableLayoutPanel3.Controls.Add(this.label21, 2, 0);
			this.tableLayoutPanel3.Controls.Add(this.label22, 2, 1);
			this.tableLayoutPanel3.Controls.Add(this.label23, 2, 2);
			this.tableLayoutPanel3.Controls.Add(this._txtPI_PRSNT_NM, 1, 0);
			this.tableLayoutPanel3.Controls.Add(this.label25, 4, 2);
			this.tableLayoutPanel3.Controls.Add(this._txtPI_ADDR_DTL, 5, 2);
			this.tableLayoutPanel3.Controls.Add(this.panel5, 1, 2);
			this.tableLayoutPanel3.Controls.Add(this.label27, 4, 1);
			this.tableLayoutPanel3.Controls.Add(this._txtPI_EMAIL, 5, 1);
			this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel3.Name = "tableLayoutPanel3";
			this.tableLayoutPanel3.RowCount = 3;
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel3.Size = new System.Drawing.Size(690, 81);
			this.tableLayoutPanel3.TabIndex = 5;
			// 
			// _txtPI_ADDR_BSC
			// 
			this._txtPI_ADDR_BSC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_ADDR_BSC.DelegateProperty = true;
			this._txtPI_ADDR_BSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_ADDR_BSC.Location = new System.Drawing.Point(323, 57);
			this._txtPI_ADDR_BSC.Name = "_txtPI_ADDR_BSC";
			this._txtPI_ADDR_BSC.Size = new System.Drawing.Size(130, 23);
			this._txtPI_ADDR_BSC.TabIndex = 420;
			this._txtPI_ADDR_BSC.ValidationGroup = null;
			this._txtPI_ADDR_BSC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_ADDR_BSC.WaterMarkText = "";
			// 
			// _txtPI_CELLNO
			// 
			this._txtPI_CELLNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_CELLNO.DelegateProperty = true;
			this._txtPI_CELLNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_CELLNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtPI_CELLNO.Location = new System.Drawing.Point(323, 30);
			this._txtPI_CELLNO.Name = "_txtPI_CELLNO";
			this._txtPI_CELLNO.Size = new System.Drawing.Size(130, 23);
			this._txtPI_CELLNO.TabIndex = 380;
			this._txtPI_CELLNO.ValidationGroup = null;
			this._txtPI_CELLNO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_CELLNO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// _txtPI_TELNO
			// 
			this._txtPI_TELNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_TELNO.DelegateProperty = true;
			this._txtPI_TELNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_TELNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtPI_TELNO.Location = new System.Drawing.Point(93, 30);
			this._txtPI_TELNO.MaxLength = 12;
			this._txtPI_TELNO.Name = "_txtPI_TELNO";
			this._txtPI_TELNO.Size = new System.Drawing.Size(130, 23);
			this._txtPI_TELNO.TabIndex = 370;
			this._txtPI_TELNO.ValidationGroup = null;
			this._txtPI_TELNO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_TELNO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// _txtPI_CNTZ_NO
			// 
			this._txtPI_CNTZ_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_CNTZ_NO.DelegateProperty = true;
			this._txtPI_CNTZ_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_CNTZ_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtPI_CNTZ_NO.Location = new System.Drawing.Point(323, 3);
			this._txtPI_CNTZ_NO.MaxLength = 14;
			this._txtPI_CNTZ_NO.Name = "_txtPI_CNTZ_NO";
			this._txtPI_CNTZ_NO.Size = new System.Drawing.Size(130, 23);
			this._txtPI_CNTZ_NO.TabIndex = 360;
			this._txtPI_CNTZ_NO.ValidationGroup = null;
			this._txtPI_CNTZ_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_CNTZ_NO.WaterMarkText = "(숫자와 -기호만 사용)";
			// 
			// label18
			// 
			this.label18.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(20, 6);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(67, 15);
			this.label18.TabIndex = 0;
			this.label18.Text = "대표자명";
			// 
			// label19
			// 
			this.label19.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(20, 33);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(67, 15);
			this.label19.TabIndex = 2;
			this.label19.Text = "자택번호";
			// 
			// label20
			// 
			this.label20.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(15, 54);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(72, 27);
			this.label20.TabIndex = 4;
			this.label20.Text = "자택 우편번호";
			// 
			// label21
			// 
			this.label21.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(235, 0);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(82, 27);
			this.label21.TabIndex = 9;
			this.label21.Text = "주민등록번호";
			// 
			// label22
			// 
			this.label22.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(235, 33);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(82, 15);
			this.label22.TabIndex = 10;
			this.label22.Text = "휴대폰번호";
			// 
			// label23
			// 
			this.label23.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(245, 54);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(72, 27);
			this.label23.TabIndex = 11;
			this.label23.Text = "자택 기본주소";
			// 
			// _txtPI_PRSNT_NM
			// 
			this._txtPI_PRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_PRSNT_NM.DelegateProperty = true;
			this._txtPI_PRSNT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_PRSNT_NM.Location = new System.Drawing.Point(93, 3);
			this._txtPI_PRSNT_NM.Name = "_txtPI_PRSNT_NM";
			this._txtPI_PRSNT_NM.Size = new System.Drawing.Size(130, 23);
			this._txtPI_PRSNT_NM.TabIndex = 350;
			this._txtPI_PRSNT_NM.ValidationGroup = null;
			this._txtPI_PRSNT_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_PRSNT_NM.WaterMarkText = "";
			// 
			// label25
			// 
			this.label25.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(475, 54);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(72, 27);
			this.label25.TabIndex = 20;
			this.label25.Text = "자택 상세주소";
			// 
			// _txtPI_ADDR_DTL
			// 
			this._txtPI_ADDR_DTL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_ADDR_DTL.DelegateProperty = true;
			this._txtPI_ADDR_DTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_ADDR_DTL.Location = new System.Drawing.Point(553, 57);
			this._txtPI_ADDR_DTL.Name = "_txtPI_ADDR_DTL";
			this._txtPI_ADDR_DTL.Size = new System.Drawing.Size(130, 23);
			this._txtPI_ADDR_DTL.TabIndex = 430;
			this._txtPI_ADDR_DTL.ValidationGroup = null;
			this._txtPI_ADDR_DTL.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_ADDR_DTL.WaterMarkText = "";
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this._btnFindZipCode03);
			this.panel5.Controls.Add(this._txtPI_ZIP_NO);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel5.Location = new System.Drawing.Point(90, 54);
			this.panel5.Margin = new System.Windows.Forms.Padding(0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(140, 27);
			this.panel5.TabIndex = 400;
			this.panel5.TabStop = true;
			// 
			// _btnFindZipCode03
			// 
			this._btnFindZipCode03.DelegateProperty = true;
			this._btnFindZipCode03.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnFindZipCode03.Location = new System.Drawing.Point(79, 3);
			this._btnFindZipCode03.Name = "_btnFindZipCode03";
			this._btnFindZipCode03.Size = new System.Drawing.Size(54, 21);
			this._btnFindZipCode03.TabIndex = 410;
			this._btnFindZipCode03.TabStop = false;
			this._btnFindZipCode03.Text = "검   색";
			this._btnFindZipCode03.UseVisualStyleBackColor = true;
			this._btnFindZipCode03.ValidationGroup = null;
			this._btnFindZipCode03.Click += new System.EventHandler(this._btnFindZipCode03_Click);
			// 
			// _txtPI_ZIP_NO
			// 
			this._txtPI_ZIP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_ZIP_NO.DelegateProperty = true;
			this._txtPI_ZIP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_ZIP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtPI_ZIP_NO.Location = new System.Drawing.Point(3, 4);
			this._txtPI_ZIP_NO.MaxLength = 7;
			this._txtPI_ZIP_NO.Name = "_txtPI_ZIP_NO";
			this._txtPI_ZIP_NO.Size = new System.Drawing.Size(70, 23);
			this._txtPI_ZIP_NO.TabIndex = 400;
			this._txtPI_ZIP_NO.ValidationGroup = null;
			this._txtPI_ZIP_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_ZIP_NO.WaterMarkText = "";
			// 
			// label27
			// 
			this.label27.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(475, 27);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(72, 27);
			this.label27.TabIndex = 23;
			this.label27.Text = "대표자 이메일";
			// 
			// _txtPI_EMAIL
			// 
			this._txtPI_EMAIL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPI_EMAIL.DelegateProperty = true;
			this._txtPI_EMAIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPI_EMAIL.Location = new System.Drawing.Point(553, 30);
			this._txtPI_EMAIL.Name = "_txtPI_EMAIL";
			this._txtPI_EMAIL.Size = new System.Drawing.Size(130, 23);
			this._txtPI_EMAIL.TabIndex = 390;
			this._txtPI_EMAIL.ValidationGroup = null;
			this._txtPI_EMAIL.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPI_EMAIL.WaterMarkText = "";
			// 
			// BAS0710
			// 
			this.CancelButton = this._btnClose;
			this.ClientSize = new System.Drawing.Size(696, 533);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this._btnClose);
			this.Controls.Add(this._btnSave);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "BAS0710";
			this.Text = "대리점정보등록:BAS0710";
			this.Load += new System.EventHandler(this.BAS0710_Load);
			this.Shown += new System.EventHandler(this.BAS0710_Shown);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.tableLayoutPanel3.ResumeLayout(false);
			this.tableLayoutPanel3.PerformLayout();
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.BananaButton _btnClose;
		private DemoClient.Controls.BananaButton _btnSave;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
		private BANANA.Windows.Controls.TextBox _txtPI_ADDR_BSC;
		private BANANA.Windows.Controls.TextBox _txtPI_CELLNO;
		private BANANA.Windows.Controls.TextBox _txtPI_TELNO;
		private BANANA.Windows.Controls.TextBox _txtPI_CNTZ_NO;
		private BANANA.Windows.Controls.Label label18;
		private BANANA.Windows.Controls.Label label19;
		private BANANA.Windows.Controls.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private BANANA.Windows.Controls.TextBox _txtPI_PRSNT_NM;
		private System.Windows.Forms.Label label25;
		private BANANA.Windows.Controls.TextBox _txtPI_ADDR_DTL;
		private System.Windows.Forms.Panel panel5;
		private DemoClient.Controls.BananaButton _btnFindZipCode03;
		private BANANA.Windows.Controls.TextBox _txtPI_ZIP_NO;
		private System.Windows.Forms.Label label27;
		private BANANA.Windows.Controls.TextBox _txtPI_EMAIL;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Label labelmemo;
		private BANANA.Windows.Controls.TextBox _txtADDR_DTL;
		private BANANA.Windows.Controls.TextBox _txtPRSNT_NM;
		private BANANA.Windows.Controls.TextBox _txtAGT_NM;
		private BANANA.Windows.Controls.Label lblCOMPANY_CD;
		private BANANA.Windows.Controls.Label lblUSR_ID;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private BANANA.Windows.Controls.Label lblUSR_PASS;
		private BANANA.Windows.Controls.Label lblUSR_ROLL;
		private BANANA.Windows.Controls.TextBox _txtMEMO;
		private System.Windows.Forms.Panel panel2;
		private DemoClient.Controls.BananaButton _btnFindZipCode01;
		private BANANA.Windows.Controls.TextBox _txtZIP_NO;
		private System.Windows.Forms.Label label3;
		private BANANA.Windows.Controls.TextBox _txtTELNO;
		private System.Windows.Forms.Label label4;
		private BANANA.Windows.Controls.TextBox _txtADDR_BSC;
		private BANANA.Windows.Controls.TextBox _txtFAXNO;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.Panel panel3;
		private BANANA.Windows.Controls.RadioButton _rbBI_SIMTAX_Y;
		private BANANA.Windows.Controls.RadioButton _rbBI_SIMTAX_N;
		private System.Windows.Forms.Label label16;
		private BANANA.Windows.Controls.TextBox _txtBI_ADDR_BSC;
		private BANANA.Windows.Controls.TextBox _txtBI_BUBIN_NO;
		private BANANA.Windows.Controls.TextBox _txtBI_SAUP_NO;
		private BANANA.Windows.Controls.TextBox _txtBI_PRSNT_NM;
		private BANANA.Windows.Controls.Label label6;
		private BANANA.Windows.Controls.Label label7;
		private BANANA.Windows.Controls.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private BANANA.Windows.Controls.Label label12;
		private BANANA.Windows.Controls.TextBox _txtBI_COMPANY_NM;
		private System.Windows.Forms.Label label5;
		private BANANA.Windows.Controls.TextBox _txtBI_JONGMOK;
		private BANANA.Windows.Controls.TextBox _txtBI_ADDR_DTL;
		private System.Windows.Forms.Label label15;
		private BANANA.Windows.Controls.TextBox _txtBI_EMAIL;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Panel panel1;
		private DemoClient.Controls.BananaButton _btnFindZipCode02;
		private BANANA.Windows.Controls.TextBox _txtBI_ZIP_NO;
		private BANANA.Windows.Controls.ComboBox _cmbBI_BINF_CD;
		private BANANA.Windows.Controls.TextBox _txtBI_UPTE;
		private BANANA.Windows.Controls.Label label13;
		private System.Windows.Forms.Panel panel4;
		private BANANA.Windows.Controls.CheckBox _chkAuto;
		private BANANA.Windows.Controls.TextBox _txtAGT_CD;
	}
}
