﻿namespace DemoClient.View.BAS
{
    partial class mngPRCPNO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.p_no_old = new DevExpress.XtraGrid.Columns.GridColumn();
            this.proc_cd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.proc_nm = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.p_no = new DevExpress.XtraGrid.Columns.GridColumn();
            this.p_name = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.mes_scr = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.c_time = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit10 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.prt_yn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.prt_img = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.use_yn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.mdt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit9 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.mid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cdt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit10 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.cid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.line_cd_old = new DevExpress.XtraGrid.Columns.GridColumn();
            this.line_cd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.line_nm = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.tableLayoutPanel1 = new DemoClient.Controls.TableLayoutPanel();
            this.l_line_nm = new BANANA.Windows.Controls.Label();
            this._line_cd = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this._btnsave = new BANANA.Windows.Controls.Button();
            this._btnDel = new BANANA.Windows.Controls.Button();
            this._btnExcel = new DemoClient.Controls.BananaButton();
            this._btnprint = new BANANA.Windows.Controls.Button();
            this._use_yn = new DevExpress.XtraEditors.CheckEdit();
            this.l_use_yn = new BANANA.Windows.Controls.Label();
            this.l_proc_nm = new BANANA.Windows.Controls.Label();
            this._proc_cd = new BANANA.Windows.Controls.TextBox();
            this.l_p_name = new BANANA.Windows.Controls.Label();
            this._p_no = new BANANA.Windows.Controls.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit9.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit10.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._use_yn.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.gridControl2);
            this.groupControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl3.Location = new System.Drawing.Point(0, 0);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(886, 488);
            this.groupControl3.TabIndex = 0;
            this.groupControl3.Text = "PROCESS";
            // 
            // gridControl2
            // 
            this.gridControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl2.Location = new System.Drawing.Point(2, 21);
            this.gridControl2.MainView = this.gridView2;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2,
            this.repositoryItemLookUpEdit4,
            this.repositoryItemDateEdit10,
            this.repositoryItemDateEdit9,
            this.repositoryItemSpinEdit10,
            this.repositoryItemCheckEdit3,
            this.repositoryItemPictureEdit1,
            this.repositoryItemButtonEdit2,
            this.repositoryItemButtonEdit1,
            this.repositoryItemButtonEdit3});
            this.gridControl2.Size = new System.Drawing.Size(882, 465);
            this.gridControl2.TabIndex = 1;
            this.gridControl2.UseEmbeddedNavigator = true;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            this.gridControl2.Click += new System.EventHandler(this.gridControl2_Click);
            // 
            // gridView2
            // 
            this.gridView2.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView2.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.p_no_old,
            this.proc_cd,
            this.proc_nm,
            this.p_no,
            this.p_name,
            this.mes_scr,
            this.c_time,
            this.prt_yn,
            this.prt_img,
            this.use_yn,
            this.mdt,
            this.mid,
            this.cdt,
            this.cid});
            this.gridView2.GridControl = this.gridControl2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsClipboard.AllowCopy = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.AllowCsvFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.AllowExcelFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.AllowHtmlFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.AllowRtfFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.AllowTxtFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.ClipboardMode = DevExpress.Export.ClipboardMode.Formatted;
            this.gridView2.OptionsClipboard.CopyCollapsedData = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsClipboard.PasteMode = DevExpress.Export.PasteMode.Update;
            this.gridView2.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CellSelect;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            this.gridView2.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridView2_CellValueChanged);
            // 
            // p_no_old
            // 
            this.p_no_old.Caption = "p_no_old";
            this.p_no_old.FieldName = "p_no_old";
            this.p_no_old.Name = "p_no_old";
            // 
            // proc_cd
            // 
            this.proc_cd.AppearanceHeader.ForeColor = System.Drawing.Color.Blue;
            this.proc_cd.AppearanceHeader.Options.UseForeColor = true;
            this.proc_cd.Caption = "공정코드";
            this.proc_cd.FieldName = "proc_cd";
            this.proc_cd.Name = "proc_cd";
            this.proc_cd.Visible = true;
            this.proc_cd.VisibleIndex = 0;
            // 
            // proc_nm
            // 
            this.proc_nm.Caption = "공정명";
            this.proc_nm.ColumnEdit = this.repositoryItemButtonEdit2;
            this.proc_nm.FieldName = "proc_nm";
            this.proc_nm.Name = "proc_nm";
            this.proc_nm.Visible = true;
            this.proc_nm.VisibleIndex = 1;
            // 
            // repositoryItemButtonEdit2
            // 
            this.repositoryItemButtonEdit2.AutoHeight = false;
            this.repositoryItemButtonEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit2.Name = "repositoryItemButtonEdit2";
            this.repositoryItemButtonEdit2.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEdit2_ButtonClick);
            // 
            // p_no
            // 
            this.p_no.AppearanceHeader.ForeColor = System.Drawing.Color.Blue;
            this.p_no.AppearanceHeader.Options.UseForeColor = true;
            this.p_no.Caption = "품목코드";
            this.p_no.FieldName = "p_no";
            this.p_no.Name = "p_no";
            this.p_no.Visible = true;
            this.p_no.VisibleIndex = 2;
            // 
            // p_name
            // 
            this.p_name.Caption = "품목명";
            this.p_name.ColumnEdit = this.repositoryItemButtonEdit1;
            this.p_name.FieldName = "p_name";
            this.p_name.Name = "p_name";
            this.p_name.Visible = true;
            this.p_name.VisibleIndex = 3;
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEdit1_ButtonClick_1);
            // 
            // mes_scr
            // 
            this.mes_scr.Caption = "MES화면";
            this.mes_scr.ColumnEdit = this.repositoryItemLookUpEdit4;
            this.mes_scr.FieldName = "mes_scr";
            this.mes_scr.Name = "mes_scr";
            this.mes_scr.Visible = true;
            this.mes_scr.VisibleIndex = 4;
            // 
            // repositoryItemLookUpEdit4
            // 
            this.repositoryItemLookUpEdit4.AutoHeight = false;
            this.repositoryItemLookUpEdit4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit4.Name = "repositoryItemLookUpEdit4";
            this.repositoryItemLookUpEdit4.NullText = "";
            // 
            // c_time
            // 
            this.c_time.Caption = "사이클타임";
            this.c_time.ColumnEdit = this.repositoryItemSpinEdit10;
            this.c_time.DisplayFormat.FormatString = "{0:#,0.#####}";
            this.c_time.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.c_time.FieldName = "c_time";
            this.c_time.Name = "c_time";
            this.c_time.Visible = true;
            this.c_time.VisibleIndex = 5;
            // 
            // repositoryItemSpinEdit10
            // 
            this.repositoryItemSpinEdit10.AutoHeight = false;
            this.repositoryItemSpinEdit10.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit10.DisplayFormat.FormatString = "{0:#,0.#####}";
            this.repositoryItemSpinEdit10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemSpinEdit10.EditFormat.FormatString = "{0:#,0.#####}";
            this.repositoryItemSpinEdit10.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.repositoryItemSpinEdit10.Name = "repositoryItemSpinEdit10";
            this.repositoryItemSpinEdit10.NullText = "0";
            // 
            // prt_yn
            // 
            this.prt_yn.Caption = "출력여부";
            this.prt_yn.ColumnEdit = this.repositoryItemCheckEdit3;
            this.prt_yn.FieldName = "prt_yn";
            this.prt_yn.Name = "prt_yn";
            this.prt_yn.Visible = true;
            this.prt_yn.VisibleIndex = 6;
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            this.repositoryItemCheckEdit3.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit3.ValueChecked = "Y";
            this.repositoryItemCheckEdit3.ValueUnchecked = "N";
            // 
            // prt_img
            // 
            this.prt_img.Caption = "작업표준서";
            this.prt_img.ColumnEdit = this.repositoryItemPictureEdit1;
            this.prt_img.FieldName = "prt_img";
            this.prt_img.Name = "prt_img";
            this.prt_img.Visible = true;
            this.prt_img.VisibleIndex = 7;
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            // 
            // use_yn
            // 
            this.use_yn.Caption = "사용여부";
            this.use_yn.ColumnEdit = this.repositoryItemCheckEdit2;
            this.use_yn.FieldName = "use_yn";
            this.use_yn.Name = "use_yn";
            this.use_yn.Visible = true;
            this.use_yn.VisibleIndex = 8;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.repositoryItemCheckEdit2.ValueChecked = "Y";
            this.repositoryItemCheckEdit2.ValueUnchecked = "N";
            // 
            // mdt
            // 
            this.mdt.Caption = "수정일";
            this.mdt.ColumnEdit = this.repositoryItemDateEdit9;
            this.mdt.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.mdt.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.mdt.FieldName = "mdt";
            this.mdt.Name = "mdt";
            this.mdt.Visible = true;
            this.mdt.VisibleIndex = 9;
            // 
            // repositoryItemDateEdit9
            // 
            this.repositoryItemDateEdit9.AutoHeight = false;
            this.repositoryItemDateEdit9.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit9.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit9.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.repositoryItemDateEdit9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit9.EditFormat.FormatString = "yyyy-MM-dd";
            this.repositoryItemDateEdit9.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit9.Mask.EditMask = "yyyy-MM-dd";
            this.repositoryItemDateEdit9.MaxValue = new System.DateTime(9999, 12, 31, 0, 0, 0, 0);
            this.repositoryItemDateEdit9.Name = "repositoryItemDateEdit9";
            this.repositoryItemDateEdit9.NullDate = "";
            // 
            // mid
            // 
            this.mid.Caption = "수정자";
            this.mid.FieldName = "mid";
            this.mid.Name = "mid";
            this.mid.Visible = true;
            this.mid.VisibleIndex = 10;
            // 
            // cdt
            // 
            this.cdt.Caption = "등록일";
            this.cdt.ColumnEdit = this.repositoryItemDateEdit10;
            this.cdt.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.cdt.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.cdt.FieldName = "cdt";
            this.cdt.Name = "cdt";
            this.cdt.Visible = true;
            this.cdt.VisibleIndex = 11;
            // 
            // repositoryItemDateEdit10
            // 
            this.repositoryItemDateEdit10.AutoHeight = false;
            this.repositoryItemDateEdit10.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit10.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit10.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.repositoryItemDateEdit10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit10.EditFormat.FormatString = "yyyy-MM-dd";
            this.repositoryItemDateEdit10.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit10.Mask.EditMask = "yyyy-MM-dd";
            this.repositoryItemDateEdit10.MaxValue = new System.DateTime(9999, 12, 31, 0, 0, 0, 0);
            this.repositoryItemDateEdit10.Name = "repositoryItemDateEdit10";
            this.repositoryItemDateEdit10.NullDate = "";
            // 
            // cid
            // 
            this.cid.Caption = "등록자";
            this.cid.FieldName = "cid";
            this.cid.Name = "cid";
            this.cid.Visible = true;
            this.cid.VisibleIndex = 12;
            // 
            // repositoryItemButtonEdit3
            // 
            this.repositoryItemButtonEdit3.AutoHeight = false;
            this.repositoryItemButtonEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit3.Name = "repositoryItemButtonEdit3";
            this.repositoryItemButtonEdit3.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemButtonEdit3_ButtonClick);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupControl2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupControl3);
            this.splitContainer2.Size = new System.Drawing.Size(1158, 488);
            this.splitContainer2.SplitterDistance = 268;
            this.splitContainer2.TabIndex = 0;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.gridControl1);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl2.Location = new System.Drawing.Point(0, 0);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(268, 488);
            this.groupControl2.TabIndex = 0;
            this.groupControl2.Text = "LINE";
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.Location = new System.Drawing.Point(2, 21);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1});
            this.gridControl1.Size = new System.Drawing.Size(264, 465);
            this.gridControl1.TabIndex = 1;
            this.gridControl1.UseEmbeddedNavigator = true;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.line_cd_old,
            this.line_cd,
            this.line_nm});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.ReadOnly = true;
            this.gridView1.OptionsClipboard.AllowCopy = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowCsvFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowExcelFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowHtmlFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowRtfFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowTxtFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.ClipboardMode = DevExpress.Export.ClipboardMode.Formatted;
            this.gridView1.OptionsClipboard.CopyCollapsedData = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.PasteMode = DevExpress.Export.PasteMode.Update;
            this.gridView1.OptionsPrint.PrintFooter = false;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // line_cd_old
            // 
            this.line_cd_old.Caption = "line_cd_old";
            this.line_cd_old.FieldName = "line_cd_old";
            this.line_cd_old.Name = "line_cd_old";
            // 
            // line_cd
            // 
            this.line_cd.Caption = "작업장코드";
            this.line_cd.FieldName = "line_cd";
            this.line_cd.Name = "line_cd";
            // 
            // line_nm
            // 
            this.line_nm.Caption = "작업장명";
            this.line_nm.ColumnEdit = this.repositoryItemTextEdit1;
            this.line_nm.FieldName = "line_nm";
            this.line_nm.Name = "line_nm";
            this.line_nm.Visible = true;
            this.line_nm.VisibleIndex = 0;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            this.repositoryItemTextEdit1.Click += new System.EventHandler(this._btnSearch1_Click);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.tableLayoutPanel1);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl1.Location = new System.Drawing.Point(0, 0);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1158, 59);
            this.groupControl1.TabIndex = 1;
            this.groupControl1.Text = "Search";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 9;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 529F));
            this.tableLayoutPanel1.Controls.Add(this.l_line_nm, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this._line_cd, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this._use_yn, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_use_yn, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_proc_nm, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this._proc_cd, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_p_name, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this._p_no, 5, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 22);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1168, 36);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // l_line_nm
            // 
            this.l_line_nm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_line_nm.AutoSize = true;
            this.l_line_nm.Location = new System.Drawing.Point(16, 11);
            this.l_line_nm.Name = "l_line_nm";
            this.l_line_nm.Size = new System.Drawing.Size(49, 14);
            this.l_line_nm.TabIndex = 0;
            this.l_line_nm.Text = "line_nm";
            // 
            // _line_cd
            // 
            this._line_cd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._line_cd.Font = new System.Drawing.Font("굴림", 9F);
            this._line_cd.Location = new System.Drawing.Point(85, 7);
            this._line_cd.Name = "_line_cd";
            this._line_cd.Size = new System.Drawing.Size(94, 21);
            this._line_cd.TabIndex = 1;
            this._line_cd.ValidationGroup = null;
            this._line_cd.WaterMarkColor = System.Drawing.Color.Empty;
            this._line_cd.WaterMarkText = "";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel2.Controls.Add(this._btnSearch);
            this.flowLayoutPanel2.Controls.Add(this._btnsave);
            this.flowLayoutPanel2.Controls.Add(this._btnDel);
            this.flowLayoutPanel2.Controls.Add(this._btnExcel);
            this.flowLayoutPanel2.Controls.Add(this._btnprint);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(796, 1);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(395, 34);
            this.flowLayoutPanel2.TabIndex = 201;
            // 
            // _btnSearch
            // 
            this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(0, 5);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Reserved = "Search";
            this._btnSearch.Size = new System.Drawing.Size(75, 23);
            this._btnSearch.TabIndex = 10;
            this._btnSearch.Text = "Search";
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
            // 
            // _btnsave
            // 
            this._btnsave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnsave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnsave.Location = new System.Drawing.Point(78, 5);
            this._btnsave.Name = "_btnsave";
            this._btnsave.Reserved = "save";
            this._btnsave.Size = new System.Drawing.Size(75, 23);
            this._btnsave.TabIndex = 21;
            this._btnsave.Text = "save";
            this._btnsave.UseVisualStyleBackColor = true;
            this._btnsave.ValidationGroup = null;
            this._btnsave.Click += new System.EventHandler(this._btnsave_Click);
            // 
            // _btnDel
            // 
            this._btnDel.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel.Location = new System.Drawing.Point(159, 5);
            this._btnDel.Name = "_btnDel";
            this._btnDel.Reserved = "delete";
            this._btnDel.Size = new System.Drawing.Size(75, 23);
            this._btnDel.TabIndex = 22;
            this._btnDel.Text = "delete";
            this._btnDel.UseVisualStyleBackColor = true;
            this._btnDel.ValidationGroup = null;
            this._btnDel.Click += new System.EventHandler(this._btnDel_Click);
            // 
            // _btnExcel
            // 
            this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnExcel.DelegateProperty = true;
            this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
            this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.Location = new System.Drawing.Point(237, 5);
            this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
            this._btnExcel.Name = "_btnExcel";
            this._btnExcel.Reserved = "      엑   셀";
            this._btnExcel.Size = new System.Drawing.Size(75, 23);
            this._btnExcel.TabIndex = 20;
            this._btnExcel.Text = "      엑   셀";
            this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.UseVisualStyleBackColor = true;
            this._btnExcel.ValidationGroup = null;
            // 
            // _btnprint
            // 
            this._btnprint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnprint.Location = new System.Drawing.Point(315, 5);
            this._btnprint.Name = "_btnprint";
            this._btnprint.Reserved = "print";
            this._btnprint.Size = new System.Drawing.Size(75, 23);
            this._btnprint.TabIndex = 23;
            this._btnprint.Text = "print";
            this._btnprint.UseVisualStyleBackColor = true;
            this._btnprint.ValidationGroup = null;
            // 
            // _use_yn
            // 
            this._use_yn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._use_yn.EditValue = "Y";
            this._use_yn.Location = new System.Drawing.Point(640, 8);
            this._use_yn.Name = "_use_yn";
            this._use_yn.Properties.Caption = "use_yn";
            this._use_yn.Properties.ValueChecked = "Y";
            this._use_yn.Properties.ValueGrayed = "";
            this._use_yn.Properties.ValueUnchecked = "N";
            this._use_yn.Size = new System.Drawing.Size(75, 19);
            this._use_yn.TabIndex = 210;
            // 
            // l_use_yn
            // 
            this.l_use_yn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_use_yn.AutoSize = true;
            this.l_use_yn.Location = new System.Drawing.Point(564, 11);
            this.l_use_yn.Name = "l_use_yn";
            this.l_use_yn.Size = new System.Drawing.Size(46, 14);
            this.l_use_yn.TabIndex = 211;
            this.l_use_yn.Text = "use_yn";
            // 
            // l_proc_nm
            // 
            this.l_proc_nm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_proc_nm.AutoSize = true;
            this.l_proc_nm.Location = new System.Drawing.Point(195, 11);
            this.l_proc_nm.Name = "l_proc_nm";
            this.l_proc_nm.Size = new System.Drawing.Size(55, 14);
            this.l_proc_nm.TabIndex = 212;
            this.l_proc_nm.Text = "proc_nm";
            // 
            // _proc_cd
            // 
            this._proc_cd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._proc_cd.Font = new System.Drawing.Font("굴림", 9F);
            this._proc_cd.Location = new System.Drawing.Point(267, 7);
            this._proc_cd.Name = "_proc_cd";
            this._proc_cd.Size = new System.Drawing.Size(94, 21);
            this._proc_cd.TabIndex = 213;
            this._proc_cd.ValidationGroup = null;
            this._proc_cd.WaterMarkColor = System.Drawing.Color.Empty;
            this._proc_cd.WaterMarkText = "";
            // 
            // l_p_name
            // 
            this.l_p_name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_p_name.AutoSize = true;
            this.l_p_name.Location = new System.Drawing.Point(379, 11);
            this.l_p_name.Name = "l_p_name";
            this.l_p_name.Size = new System.Drawing.Size(51, 14);
            this.l_p_name.TabIndex = 214;
            this.l_p_name.Text = "p_name";
            // 
            // _p_no
            // 
            this._p_no.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._p_no.Font = new System.Drawing.Font("굴림", 9F);
            this._p_no.Location = new System.Drawing.Point(449, 7);
            this._p_no.Name = "_p_no";
            this._p_no.Size = new System.Drawing.Size(94, 21);
            this._p_no.TabIndex = 215;
            this._p_no.ValidationGroup = null;
            this._p_no.WaterMarkColor = System.Drawing.Color.Empty;
            this._p_no.WaterMarkText = "";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1158, 551);
            this.splitContainer1.SplitterDistance = 59;
            this.splitContainer1.TabIndex = 3;
            // 
            // mngPRCPNO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 551);
            this.Controls.Add(this.splitContainer1);
            this.Name = "mngPRCPNO";
            this.Text = "mngPRCPNO";
            this.Load += new System.EventHandler(this.mngPRCPNO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit9.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit10.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._use_yn.Properties)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private Controls.TableLayoutPanel tableLayoutPanel1;
        private BANANA.Windows.Controls.Label l_line_nm;
        private BANANA.Windows.Controls.TextBox _line_cd;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Controls.BananaButton _btnSearch;
        private BANANA.Windows.Controls.Button _btnsave;
        private BANANA.Windows.Controls.Button _btnDel;
        private Controls.BananaButton _btnExcel;
        private BANANA.Windows.Controls.Button _btnprint;
        private BANANA.Windows.Controls.Label l_use_yn;
        private DevExpress.XtraEditors.CheckEdit _use_yn;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn proc_cd;
        private DevExpress.XtraGrid.Columns.GridColumn proc_nm;
        private DevExpress.XtraGrid.Columns.GridColumn p_no;
        private DevExpress.XtraGrid.Columns.GridColumn use_yn;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn mes_scr;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn c_time;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit10;
        private DevExpress.XtraGrid.Columns.GridColumn prt_img;
        private DevExpress.XtraGrid.Columns.GridColumn mdt;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit9;
        private DevExpress.XtraGrid.Columns.GridColumn mid;
        private DevExpress.XtraGrid.Columns.GridColumn cdt;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit10;
        private DevExpress.XtraGrid.Columns.GridColumn cid;
        private DevExpress.XtraGrid.Columns.GridColumn line_cd_old;
        private DevExpress.XtraGrid.Columns.GridColumn line_cd;
        private DevExpress.XtraGrid.Columns.GridColumn line_nm;
        private DevExpress.XtraGrid.Columns.GridColumn prt_yn;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private BANANA.Windows.Controls.Label l_proc_nm;
        private BANANA.Windows.Controls.TextBox _proc_cd;
        private BANANA.Windows.Controls.Label l_p_name;
        private BANANA.Windows.Controls.TextBox _p_no;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn p_name;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn p_no_old;
    }
}