﻿namespace DemoClient.View.BAS
{
    partial class mngEQUMST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new BANANA.Windows.Controls.GroupBox();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.tableLayoutPanel1 = new DemoClient.Controls.TableLayoutPanel();
            this.equ_gblookup = new DevExpress.XtraEditors.LookUpEdit();
            this.equ_mdlpelookup = new DevExpress.XtraEditors.LookUpEdit();
            this.equ_tylookup = new DevExpress.XtraEditors.LookUpEdit();
            this.l_equ_gb = new BANANA.Windows.Controls.Label();
            this.l_equ_mdl = new BANANA.Windows.Controls.Label();
            this.l_equ_ty = new BANANA.Windows.Controls.Label();
            this.l_equ_nm = new BANANA.Windows.Controls.Label();
            this._equ_cd = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this._btnsave = new BANANA.Windows.Controls.Button();
            this._btnDel = new BANANA.Windows.Controls.Button();
            this._btnExcel = new DemoClient.Controls.BananaButton();
            this._btnprint = new BANANA.Windows.Controls.Button();
            this.groupBox2 = new BANANA.Windows.Controls.GroupBox();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.equ_cd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.equ_nm = new DevExpress.XtraGrid.Columns.GridColumn();
            this.equ_ty = new DevExpress.XtraGrid.Columns.GridColumn();
            this.equ_pri = new DevExpress.XtraGrid.Columns.GridColumn();
            this.equ_stat = new DevExpress.XtraGrid.Columns.GridColumn();
            this.line_cd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.equ_gb = new DevExpress.XtraGrid.Columns.GridColumn();
            this.drv_sorc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.equ_ton = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.rbt_cd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.rbt_yn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.cust_cd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.crt_dt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.str_dt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.end_dt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cust_md = new DevExpress.XtraGrid.Columns.GridColumn();
            this.md_ph = new DevExpress.XtraGrid.Columns.GridColumn();
            this.use_yn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rmks = new DevExpress.XtraGrid.Columns.GridColumn();
            this.mdt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.mid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cdt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.equ_gblookup.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equ_mdlpelookup.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equ_tylookup.Properties)).BeginInit();
            this.flowLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit5)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupControl1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1157, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.tableLayoutPanel1);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl1.Location = new System.Drawing.Point(3, 17);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1151, 80);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Search";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 9;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 450F));
            this.tableLayoutPanel1.Controls.Add(this.equ_gblookup, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.equ_mdlpelookup, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.equ_tylookup, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_equ_gb, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_equ_mdl, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_equ_ty, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.l_equ_nm, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this._equ_cd, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 8, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1141, 36);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // equ_gblookup
            // 
            this.equ_gblookup.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.equ_gblookup.Location = new System.Drawing.Point(631, 8);
            this.equ_gblookup.Name = "equ_gblookup";
            this.equ_gblookup.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.equ_gblookup.Properties.NullText = "";
            this.equ_gblookup.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.equ_gblookup.Size = new System.Drawing.Size(94, 20);
            this.equ_gblookup.TabIndex = 207;
            // 
            // equ_mdlpelookup
            // 
            this.equ_mdlpelookup.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.equ_mdlpelookup.Location = new System.Drawing.Point(449, 8);
            this.equ_mdlpelookup.Name = "equ_mdlpelookup";
            this.equ_mdlpelookup.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.equ_mdlpelookup.Properties.NullText = "";
            this.equ_mdlpelookup.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.equ_mdlpelookup.Size = new System.Drawing.Size(94, 20);
            this.equ_mdlpelookup.TabIndex = 206;
            // 
            // equ_tylookup
            // 
            this.equ_tylookup.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.equ_tylookup.Location = new System.Drawing.Point(267, 8);
            this.equ_tylookup.Name = "equ_tylookup";
            this.equ_tylookup.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.equ_tylookup.Properties.NullText = "";
            this.equ_tylookup.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.equ_tylookup.Size = new System.Drawing.Size(94, 20);
            this.equ_tylookup.TabIndex = 205;
            // 
            // l_equ_gb
            // 
            this.l_equ_gb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_equ_gb.AutoSize = true;
            this.l_equ_gb.Location = new System.Drawing.Point(562, 11);
            this.l_equ_gb.Name = "l_equ_gb";
            this.l_equ_gb.Size = new System.Drawing.Size(49, 14);
            this.l_equ_gb.TabIndex = 6;
            this.l_equ_gb.Text = "equ_gb";
            // 
            // l_equ_mdl
            // 
            this.l_equ_mdl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_equ_mdl.AutoSize = true;
            this.l_equ_mdl.Location = new System.Drawing.Point(378, 11);
            this.l_equ_mdl.Name = "l_equ_mdl";
            this.l_equ_mdl.Size = new System.Drawing.Size(54, 14);
            this.l_equ_mdl.TabIndex = 4;
            this.l_equ_mdl.Text = "equ_mdl";
            // 
            // l_equ_ty
            // 
            this.l_equ_ty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_equ_ty.AutoSize = true;
            this.l_equ_ty.Location = new System.Drawing.Point(200, 11);
            this.l_equ_ty.Name = "l_equ_ty";
            this.l_equ_ty.Size = new System.Drawing.Size(46, 14);
            this.l_equ_ty.TabIndex = 2;
            this.l_equ_ty.Text = "equ_ty";
            // 
            // l_equ_nm
            // 
            this.l_equ_nm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l_equ_nm.AutoSize = true;
            this.l_equ_nm.Location = new System.Drawing.Point(15, 11);
            this.l_equ_nm.Name = "l_equ_nm";
            this.l_equ_nm.Size = new System.Drawing.Size(52, 14);
            this.l_equ_nm.TabIndex = 0;
            this.l_equ_nm.Text = "equ_nm";
            // 
            // _equ_cd
            // 
            this._equ_cd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._equ_cd.Font = new System.Drawing.Font("굴림", 9F);
            this._equ_cd.Location = new System.Drawing.Point(85, 7);
            this._equ_cd.Name = "_equ_cd";
            this._equ_cd.Size = new System.Drawing.Size(94, 21);
            this._equ_cd.TabIndex = 1;
            this._equ_cd.ValidationGroup = null;
            this._equ_cd.WaterMarkColor = System.Drawing.Color.Empty;
            this._equ_cd.WaterMarkText = "";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel2.Controls.Add(this._btnSearch);
            this.flowLayoutPanel2.Controls.Add(this._btnsave);
            this.flowLayoutPanel2.Controls.Add(this._btnDel);
            this.flowLayoutPanel2.Controls.Add(this._btnExcel);
            this.flowLayoutPanel2.Controls.Add(this._btnprint);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(756, 1);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(395, 34);
            this.flowLayoutPanel2.TabIndex = 201;
            // 
            // _btnSearch
            // 
            this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(0, 5);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Reserved = "Search";
            this._btnSearch.Size = new System.Drawing.Size(75, 23);
            this._btnSearch.TabIndex = 10;
            this._btnSearch.Text = "Search";
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            // 
            // _btnsave
            // 
            this._btnsave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnsave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnsave.Location = new System.Drawing.Point(78, 5);
            this._btnsave.Name = "_btnsave";
            this._btnsave.Reserved = "save";
            this._btnsave.Size = new System.Drawing.Size(75, 23);
            this._btnsave.TabIndex = 21;
            this._btnsave.Text = "save";
            this._btnsave.UseVisualStyleBackColor = true;
            this._btnsave.ValidationGroup = null;
            // 
            // _btnDel
            // 
            this._btnDel.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel.Location = new System.Drawing.Point(159, 5);
            this._btnDel.Name = "_btnDel";
            this._btnDel.Reserved = "delete";
            this._btnDel.Size = new System.Drawing.Size(75, 23);
            this._btnDel.TabIndex = 22;
            this._btnDel.Text = "delete";
            this._btnDel.UseVisualStyleBackColor = true;
            this._btnDel.ValidationGroup = null;
            // 
            // _btnExcel
            // 
            this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnExcel.DelegateProperty = true;
            this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
            this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.Location = new System.Drawing.Point(237, 5);
            this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
            this._btnExcel.Name = "_btnExcel";
            this._btnExcel.Reserved = "      엑   셀";
            this._btnExcel.Size = new System.Drawing.Size(75, 23);
            this._btnExcel.TabIndex = 20;
            this._btnExcel.Text = "      엑   셀";
            this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.UseVisualStyleBackColor = true;
            this._btnExcel.ValidationGroup = null;
            // 
            // _btnprint
            // 
            this._btnprint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnprint.Location = new System.Drawing.Point(315, 5);
            this._btnprint.Name = "_btnprint";
            this._btnprint.Reserved = "print";
            this._btnprint.Size = new System.Drawing.Size(75, 23);
            this._btnprint.TabIndex = 23;
            this._btnprint.Text = "print";
            this._btnprint.UseVisualStyleBackColor = true;
            this._btnprint.ValidationGroup = null;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupControl2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1157, 531);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.gridControl1);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl2.Location = new System.Drawing.Point(3, 17);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(1151, 511);
            this.groupControl2.TabIndex = 0;
            this.groupControl2.Text = "Detail";
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.Location = new System.Drawing.Point(2, 21);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSpinEdit1,
            this.repositoryItemSpinEdit2,
            this.repositoryItemSpinEdit3,
            this.repositoryItemSpinEdit4,
            this.repositoryItemSpinEdit5});
            this.gridControl1.Size = new System.Drawing.Size(1147, 488);
            this.gridControl1.TabIndex = 0;
            this.gridControl1.UseEmbeddedNavigator = true;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.equ_cd,
            this.equ_nm,
            this.equ_ty,
            this.equ_pri,
            this.equ_stat,
            this.line_cd,
            this.equ_gb,
            this.drv_sorc,
            this.equ_ton,
            this.rbt_cd,
            this.rbt_yn,
            this.cust_cd,
            this.crt_dt,
            this.str_dt,
            this.end_dt,
            this.cust_md,
            this.md_ph,
            this.use_yn,
            this.rmks,
            this.mdt,
            this.mid,
            this.cdt,
            this.cid});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsClipboard.AllowCopy = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowCsvFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowExcelFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowHtmlFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowRtfFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.AllowTxtFormat = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.ClipboardMode = DevExpress.Export.ClipboardMode.Formatted;
            this.gridView1.OptionsClipboard.CopyCollapsedData = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsClipboard.PasteMode = DevExpress.Export.PasteMode.Update;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // equ_cd
            // 
            this.equ_cd.AppearanceHeader.ForeColor = System.Drawing.Color.Blue;
            this.equ_cd.AppearanceHeader.Options.UseForeColor = true;
            this.equ_cd.Caption = "설비코드";
            this.equ_cd.FieldName = "equ_cd";
            this.equ_cd.Name = "equ_cd";
            this.equ_cd.Visible = true;
            this.equ_cd.VisibleIndex = 0;
            // 
            // equ_nm
            // 
            this.equ_nm.Caption = "설비명";
            this.equ_nm.FieldName = "equ_nm";
            this.equ_nm.Name = "equ_nm";
            this.equ_nm.Visible = true;
            this.equ_nm.VisibleIndex = 1;
            // 
            // equ_ty
            // 
            this.equ_ty.Caption = "설비타입";
            this.equ_ty.FieldName = "equ_ty";
            this.equ_ty.Name = "equ_ty";
            this.equ_ty.Visible = true;
            this.equ_ty.VisibleIndex = 2;
            // 
            // equ_pri
            // 
            this.equ_pri.Caption = "설비금액";
            this.equ_pri.FieldName = "equ_pri";
            this.equ_pri.Name = "equ_pri";
            this.equ_pri.Visible = true;
            this.equ_pri.VisibleIndex = 3;
            // 
            // equ_stat
            // 
            this.equ_stat.Caption = "설비상태";
            this.equ_stat.FieldName = "equ_stat";
            this.equ_stat.Name = "equ_stat";
            this.equ_stat.Visible = true;
            this.equ_stat.VisibleIndex = 4;
            // 
            // line_cd
            // 
            this.line_cd.Caption = "작업장";
            this.line_cd.FieldName = "line_cd";
            this.line_cd.Name = "line_cd";
            this.line_cd.Visible = true;
            this.line_cd.VisibleIndex = 5;
            // 
            // equ_gb
            // 
            this.equ_gb.Caption = "설비구분";
            this.equ_gb.FieldName = "equ_gb";
            this.equ_gb.Name = "equ_gb";
            this.equ_gb.Visible = true;
            this.equ_gb.VisibleIndex = 6;
            // 
            // drv_sorc
            // 
            this.drv_sorc.Caption = "구동원";
            this.drv_sorc.ColumnEdit = this.repositoryItemSpinEdit1;
            this.drv_sorc.DisplayFormat.FormatString = "{0:#,0.#####}";
            this.drv_sorc.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.drv_sorc.FieldName = "mol_hori";
            this.drv_sorc.Name = "drv_sorc";
            this.drv_sorc.Visible = true;
            this.drv_sorc.VisibleIndex = 7;
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // equ_ton
            // 
            this.equ_ton.Caption = "톤수";
            this.equ_ton.ColumnEdit = this.repositoryItemSpinEdit2;
            this.equ_ton.DisplayFormat.FormatString = "{0:#,0.#####}";
            this.equ_ton.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.equ_ton.FieldName = "equ_ton";
            this.equ_ton.Name = "equ_ton";
            this.equ_ton.Visible = true;
            this.equ_ton.VisibleIndex = 8;
            // 
            // repositoryItemSpinEdit2
            // 
            this.repositoryItemSpinEdit2.AutoHeight = false;
            this.repositoryItemSpinEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit2.Name = "repositoryItemSpinEdit2";
            // 
            // rbt_cd
            // 
            this.rbt_cd.Caption = "적용 로보트";
            this.rbt_cd.ColumnEdit = this.repositoryItemSpinEdit3;
            this.rbt_cd.DisplayFormat.FormatString = "{0:#,0.#####}";
            this.rbt_cd.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.rbt_cd.FieldName = "rbt_cd";
            this.rbt_cd.Name = "rbt_cd";
            this.rbt_cd.Visible = true;
            this.rbt_cd.VisibleIndex = 9;
            // 
            // repositoryItemSpinEdit3
            // 
            this.repositoryItemSpinEdit3.AutoHeight = false;
            this.repositoryItemSpinEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit3.Name = "repositoryItemSpinEdit3";
            // 
            // rbt_yn
            // 
            this.rbt_yn.Caption = "로보트 사용유무";
            this.rbt_yn.ColumnEdit = this.repositoryItemSpinEdit4;
            this.rbt_yn.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.rbt_yn.FieldName = "mol_wht";
            this.rbt_yn.Name = "rbt_yn";
            this.rbt_yn.Visible = true;
            this.rbt_yn.VisibleIndex = 10;
            // 
            // repositoryItemSpinEdit4
            // 
            this.repositoryItemSpinEdit4.AutoHeight = false;
            this.repositoryItemSpinEdit4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit4.Name = "repositoryItemSpinEdit4";
            // 
            // cust_cd
            // 
            this.cust_cd.Caption = "제작업체";
            this.cust_cd.FieldName = "cust_cd";
            this.cust_cd.Name = "cust_cd";
            this.cust_cd.Visible = true;
            this.cust_cd.VisibleIndex = 11;
            // 
            // crt_dt
            // 
            this.crt_dt.Caption = "제작일";
            this.crt_dt.ColumnEdit = this.repositoryItemSpinEdit5;
            this.crt_dt.DisplayFormat.FormatString = "d";
            this.crt_dt.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.crt_dt.FieldName = "crt_dt";
            this.crt_dt.Name = "crt_dt";
            this.crt_dt.Visible = true;
            this.crt_dt.VisibleIndex = 12;
            // 
            // repositoryItemSpinEdit5
            // 
            this.repositoryItemSpinEdit5.AutoHeight = false;
            this.repositoryItemSpinEdit5.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit5.Name = "repositoryItemSpinEdit5";
            // 
            // str_dt
            // 
            this.str_dt.Caption = "도입일자";
            this.str_dt.FieldName = "str_dt";
            this.str_dt.Name = "str_dt";
            this.str_dt.Visible = true;
            this.str_dt.VisibleIndex = 13;
            // 
            // end_dt
            // 
            this.end_dt.Caption = "폐기일자";
            this.end_dt.FieldName = "end_dt";
            this.end_dt.Name = "end_dt";
            this.end_dt.Visible = true;
            this.end_dt.VisibleIndex = 14;
            // 
            // cust_md
            // 
            this.cust_md.Caption = "업체담당자";
            this.cust_md.FieldName = "cust_md";
            this.cust_md.Name = "cust_md";
            this.cust_md.Visible = true;
            this.cust_md.VisibleIndex = 15;
            // 
            // md_ph
            // 
            this.md_ph.Caption = "담당자연락처";
            this.md_ph.FieldName = "md_ph";
            this.md_ph.Name = "md_ph";
            this.md_ph.Visible = true;
            this.md_ph.VisibleIndex = 16;
            // 
            // use_yn
            // 
            this.use_yn.Caption = "사용여부";
            this.use_yn.FieldName = "use_yn";
            this.use_yn.Name = "use_yn";
            this.use_yn.Visible = true;
            this.use_yn.VisibleIndex = 17;
            // 
            // rmks
            // 
            this.rmks.Caption = "비고";
            this.rmks.FieldName = "rmks";
            this.rmks.Name = "rmks";
            this.rmks.Visible = true;
            this.rmks.VisibleIndex = 18;
            // 
            // mdt
            // 
            this.mdt.Caption = "수정일";
            this.mdt.FieldName = "mdt";
            this.mdt.Name = "mdt";
            this.mdt.Visible = true;
            this.mdt.VisibleIndex = 19;
            // 
            // mid
            // 
            this.mid.Caption = "수정자";
            this.mid.FieldName = "mid";
            this.mid.Name = "mid";
            this.mid.Visible = true;
            this.mid.VisibleIndex = 20;
            // 
            // cdt
            // 
            this.cdt.Caption = "등록일";
            this.cdt.FieldName = "cdt";
            this.cdt.Name = "cdt";
            this.cdt.Visible = true;
            this.cdt.VisibleIndex = 21;
            // 
            // cid
            // 
            this.cid.Caption = "등록자";
            this.cid.FieldName = "cid";
            this.cid.Name = "cid";
            this.cid.Visible = true;
            this.cid.VisibleIndex = 22;
            // 
            // mngEQUMST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1157, 631);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "mngEQUMST";
            this.Text = "mngEQUMST";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.equ_gblookup.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equ_mdlpelookup.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equ_tylookup.Properties)).EndInit();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BANANA.Windows.Controls.GroupBox groupBox1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private Controls.TableLayoutPanel tableLayoutPanel1;
        private DevExpress.XtraEditors.LookUpEdit equ_gblookup;
        private DevExpress.XtraEditors.LookUpEdit equ_mdlpelookup;
        private DevExpress.XtraEditors.LookUpEdit equ_tylookup;
        private BANANA.Windows.Controls.Label l_equ_gb;
        private BANANA.Windows.Controls.Label l_equ_mdl;
        private BANANA.Windows.Controls.Label l_equ_ty;
        private BANANA.Windows.Controls.Label l_equ_nm;
        private BANANA.Windows.Controls.TextBox _equ_cd;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Controls.BananaButton _btnSearch;
        private BANANA.Windows.Controls.Button _btnsave;
        private BANANA.Windows.Controls.Button _btnDel;
        private Controls.BananaButton _btnExcel;
        private BANANA.Windows.Controls.Button _btnprint;
        private BANANA.Windows.Controls.GroupBox groupBox2;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn equ_cd;
        private DevExpress.XtraGrid.Columns.GridColumn equ_nm;
        private DevExpress.XtraGrid.Columns.GridColumn equ_ty;
        private DevExpress.XtraGrid.Columns.GridColumn equ_pri;
        private DevExpress.XtraGrid.Columns.GridColumn equ_stat;
        private DevExpress.XtraGrid.Columns.GridColumn line_cd;
        private DevExpress.XtraGrid.Columns.GridColumn equ_gb;
        private DevExpress.XtraGrid.Columns.GridColumn drv_sorc;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn equ_ton;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn rbt_cd;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn rbt_yn;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn cust_cd;
        private DevExpress.XtraGrid.Columns.GridColumn crt_dt;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit5;
        private DevExpress.XtraGrid.Columns.GridColumn str_dt;
        private DevExpress.XtraGrid.Columns.GridColumn end_dt;
        private DevExpress.XtraGrid.Columns.GridColumn cust_md;
        private DevExpress.XtraGrid.Columns.GridColumn md_ph;
        private DevExpress.XtraGrid.Columns.GridColumn use_yn;
        private DevExpress.XtraGrid.Columns.GridColumn rmks;
        private DevExpress.XtraGrid.Columns.GridColumn mdt;
        private DevExpress.XtraGrid.Columns.GridColumn mid;
        private DevExpress.XtraGrid.Columns.GridColumn cdt;
        private DevExpress.XtraGrid.Columns.GridColumn cid;
    }
}