﻿namespace DemoClient.View.BAS
{
	partial class BAS0700
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0700));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
            this._cmbBI_BINF_CD_S = new BANANA.Windows.Controls.ComboBox();
            this._txtBI_SAUP_NO_S = new BANANA.Windows.Controls.TextBox();
            this._txtADDR_BSC_S = new BANANA.Windows.Controls.TextBox();
            this._txtPRSNT_NM_S = new BANANA.Windows.Controls.TextBox();
            this._txtAGT_CD_S = new BANANA.Windows.Controls.TextBox();
            this._txtAGT_NM_S = new BANANA.Windows.Controls.TextBox();
            this.label40 = new BANANA.Windows.Controls.Label();
            this.label35 = new BANANA.Windows.Controls.Label();
            this.label39 = new BANANA.Windows.Controls.Label();
            this.label36 = new BANANA.Windows.Controls.Label();
            this.label38 = new BANANA.Windows.Controls.Label();
            this.label37 = new BANANA.Windows.Controls.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gridView1 = new DemoClient.Controls.GridView();
            this.AGT_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AGT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRSNT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ADDR_BSC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TELNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FAXNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BI_COMPANY_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BI_PRSNT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BI_BINF_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BI_SIMTAX_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BI_SAUP_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PI_PRSNT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PI_TELNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PI_CELLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_CNTR_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_CNTR_END_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MO_LOGIN_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MO_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MO_PAUSED = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this._btnSave01 = new DemoClient.Controls.BananaButton();
            this._btnDel01 = new DemoClient.Controls.BananaButton();
            this._btnAdd01 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.labelmemo = new System.Windows.Forms.Label();
            this._txtADDR_DTL = new BANANA.Windows.Controls.TextBox();
            this._txtPRSNT_NM = new BANANA.Windows.Controls.TextBox();
            this._txtAGT_NM = new BANANA.Windows.Controls.TextBox();
            this.lblCOMPANY_CD = new BANANA.Windows.Controls.Label();
            this.lblUSR_ID = new BANANA.Windows.Controls.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUSR_PASS = new BANANA.Windows.Controls.Label();
            this.lblUSR_ROLL = new BANANA.Windows.Controls.Label();
            this._txtAGT_CD = new BANANA.Windows.Controls.TextBox();
            this._txtMEMO = new BANANA.Windows.Controls.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this._btnFindZipCode01 = new DemoClient.Controls.BananaButton();
            this._txtZIP_NO = new BANANA.Windows.Controls.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this._txtTELNO = new BANANA.Windows.Controls.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this._txtADDR_BSC = new BANANA.Windows.Controls.TextBox();
            this._txtFAXNO = new BANANA.Windows.Controls.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this._btnSave02 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this._rbBI_SIMTAX_Y = new BANANA.Windows.Controls.RadioButton();
            this._rbBI_SIMTAX_N = new BANANA.Windows.Controls.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this._txtBI_ADDR_BSC = new BANANA.Windows.Controls.TextBox();
            this._txtBI_BUBIN_NO = new BANANA.Windows.Controls.TextBox();
            this._txtBI_SAUP_NO = new BANANA.Windows.Controls.TextBox();
            this._txtBI_PRSNT_NM = new BANANA.Windows.Controls.TextBox();
            this.label6 = new BANANA.Windows.Controls.Label();
            this.label7 = new BANANA.Windows.Controls.Label();
            this.label8 = new BANANA.Windows.Controls.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new BANANA.Windows.Controls.Label();
            this._txtBI_COMPANY_NM = new BANANA.Windows.Controls.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this._txtBI_JONGMOK = new BANANA.Windows.Controls.TextBox();
            this._txtBI_ADDR_DTL = new BANANA.Windows.Controls.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this._txtBI_EMAIL = new BANANA.Windows.Controls.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this._btnFindZipCode02 = new DemoClient.Controls.BananaButton();
            this._txtBI_ZIP_NO = new BANANA.Windows.Controls.TextBox();
            this._cmbBI_BINF_CD = new BANANA.Windows.Controls.ComboBox();
            this._txtBI_UPTE = new BANANA.Windows.Controls.TextBox();
            this.label13 = new BANANA.Windows.Controls.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this._btnSave03 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this._txtPI_ADDR_BSC = new BANANA.Windows.Controls.TextBox();
            this._txtPI_CELLNO = new BANANA.Windows.Controls.TextBox();
            this._txtPI_TELNO = new BANANA.Windows.Controls.TextBox();
            this._txtPI_CNTZ_NO = new BANANA.Windows.Controls.TextBox();
            this.label18 = new BANANA.Windows.Controls.Label();
            this.label19 = new BANANA.Windows.Controls.Label();
            this.label20 = new BANANA.Windows.Controls.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this._txtPI_PRSNT_NM = new BANANA.Windows.Controls.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this._txtPI_ADDR_DTL = new BANANA.Windows.Controls.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this._btnFindZipCode03 = new DemoClient.Controls.BananaButton();
            this._txtPI_ZIP_NO = new BANANA.Windows.Controls.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this._txtPI_EMAIL = new BANANA.Windows.Controls.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this._btnSave04 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this._dtpCI_CNTR_END_DT = new BANANA.Windows.Controls.DateTimePicker();
            this._cmbCI_BNK_CD = new BANANA.Windows.Controls.ComboBox();
            this._txtCI_ACCT_NO = new BANANA.Windows.Controls.TextBox();
            this.label17 = new BANANA.Windows.Controls.Label();
            this.label24 = new BANANA.Windows.Controls.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this._txtCI_ACCT_NM = new BANANA.Windows.Controls.TextBox();
            this._dtpCI_CNTR_STRT_DT = new BANANA.Windows.Controls.DateTimePicker();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this._btnSave05 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new BANANA.Windows.Controls.Label();
            this._dtpMO_STRT_DT = new BANANA.Windows.Controls.DateTimePicker();
            this.label31 = new System.Windows.Forms.Label();
            this._txtMO_LOGIN_ID = new BANANA.Windows.Controls.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this._txtMO_LOGIN_PW = new BANANA.Windows.Controls.TextBox();
            this._chkMO_PAUSED = new BANANA.Windows.Controls.CheckBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.gridView2 = new DemoClient.Controls.GridView();
            this.IDX2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOC_GUBUN_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOC_FILE_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOC_FILE_SIZE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DownLoad = new System.Windows.Forms.DataGridViewImageColumn();
            this.MEMO2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOC_FILE_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this._btnDel02 = new DemoClient.Controls.BananaButton();
            this._btnAdd02 = new DemoClient.Controls.BananaButton();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.gridView3 = new DemoClient.Controls.GridView();
            this.IDX3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CALL_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CALL_DT_STRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CALL_DT_END = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel6 = new System.Windows.Forms.Panel();
            this._btnDel03 = new DemoClient.Controls.BananaButton();
            this._btnAdd03 = new DemoClient.Controls.BananaButton();
            this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
            this._iglDocuments = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.panel4.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel6);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1184, 76);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "검색 조건";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel6.ColumnCount = 7;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this._cmbBI_BINF_CD_S, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this._txtBI_SAUP_NO_S, 5, 1);
            this.tableLayoutPanel6.Controls.Add(this._txtADDR_BSC_S, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this._txtPRSNT_NM_S, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this._txtAGT_CD_S, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this._txtAGT_NM_S, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label40, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label39, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.label38, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 6, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1178, 56);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // _cmbBI_BINF_CD_S
            // 
            this._cmbBI_BINF_CD_S.DataSource = null;
            this._cmbBI_BINF_CD_S.DelegateProperty = true;
            this._cmbBI_BINF_CD_S.DroppedDown = false;
            this._cmbBI_BINF_CD_S.Location = new System.Drawing.Point(317, 32);
            this._cmbBI_BINF_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbBI_BINF_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbBI_BINF_CD_S.Name = "_cmbBI_BINF_CD_S";
            this._cmbBI_BINF_CD_S.SelectedIndex = -1;
            this._cmbBI_BINF_CD_S.SelectedItem = null;
            this._cmbBI_BINF_CD_S.SelectedValue = null;
            this._cmbBI_BINF_CD_S.Size = new System.Drawing.Size(124, 21);
            this._cmbBI_BINF_CD_S.TabIndex = 140;
            this._cmbBI_BINF_CD_S.ValidationGroup = null;
            // 
            // _txtBI_SAUP_NO_S
            // 
            this._txtBI_SAUP_NO_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_SAUP_NO_S.DelegateProperty = true;
            this._txtBI_SAUP_NO_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_SAUP_NO_S.Location = new System.Drawing.Point(549, 32);
            this._txtBI_SAUP_NO_S.Name = "_txtBI_SAUP_NO_S";
            this._txtBI_SAUP_NO_S.Size = new System.Drawing.Size(124, 20);
            this._txtBI_SAUP_NO_S.TabIndex = 150;
            this._txtBI_SAUP_NO_S.ValidationGroup = null;
            this._txtBI_SAUP_NO_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_SAUP_NO_S.WaterMarkText = "";
            // 
            // _txtADDR_BSC_S
            // 
            this._txtADDR_BSC_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtADDR_BSC_S.DelegateProperty = true;
            this._txtADDR_BSC_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtADDR_BSC_S.Location = new System.Drawing.Point(95, 32);
            this._txtADDR_BSC_S.Name = "_txtADDR_BSC_S";
            this._txtADDR_BSC_S.Size = new System.Drawing.Size(124, 20);
            this._txtADDR_BSC_S.TabIndex = 130;
            this._txtADDR_BSC_S.ValidationGroup = null;
            this._txtADDR_BSC_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtADDR_BSC_S.WaterMarkText = "";
            // 
            // _txtPRSNT_NM_S
            // 
            this._txtPRSNT_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPRSNT_NM_S.DelegateProperty = true;
            this._txtPRSNT_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPRSNT_NM_S.Location = new System.Drawing.Point(549, 4);
            this._txtPRSNT_NM_S.Name = "_txtPRSNT_NM_S";
            this._txtPRSNT_NM_S.Size = new System.Drawing.Size(124, 20);
            this._txtPRSNT_NM_S.TabIndex = 120;
            this._txtPRSNT_NM_S.ValidationGroup = null;
            this._txtPRSNT_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPRSNT_NM_S.WaterMarkText = "";
            // 
            // _txtAGT_CD_S
            // 
            this._txtAGT_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtAGT_CD_S.DelegateProperty = true;
            this._txtAGT_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtAGT_CD_S.Location = new System.Drawing.Point(317, 4);
            this._txtAGT_CD_S.Name = "_txtAGT_CD_S";
            this._txtAGT_CD_S.Size = new System.Drawing.Size(124, 20);
            this._txtAGT_CD_S.TabIndex = 110;
            this._txtAGT_CD_S.ValidationGroup = null;
            this._txtAGT_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtAGT_CD_S.WaterMarkText = "";
            // 
            // _txtAGT_NM_S
            // 
            this._txtAGT_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtAGT_NM_S.DelegateProperty = true;
            this._txtAGT_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtAGT_NM_S.Location = new System.Drawing.Point(95, 4);
            this._txtAGT_NM_S.Name = "_txtAGT_NM_S";
            this._txtAGT_NM_S.Size = new System.Drawing.Size(124, 20);
            this._txtAGT_NM_S.TabIndex = 100;
            this._txtAGT_NM_S.ValidationGroup = null;
            this._txtAGT_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtAGT_NM_S.WaterMarkText = "";
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(453, 36);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(89, 12);
            this.label40.TabIndex = 1119;
            this.label40.Text = "사업자등록번호";
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(35, 8);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 1114;
            this.label35.Text = "대리점명";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(245, 36);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 1118;
            this.label39.Text = "사업자구분";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(245, 8);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(65, 12);
            this.label36.TabIndex = 1115;
            this.label36.Text = "대리점코드";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(59, 36);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 1117;
            this.label38.Text = "주소";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(489, 8);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 12);
            this.label37.TabIndex = 1116;
            this.label37.Text = "대표자명";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this._btnSearch);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(677, 1);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(508, 27);
            this.flowLayoutPanel2.TabIndex = 1120;
            // 
            // _btnSearch
            // 
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(0, 2);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Reserved = "      검   색";
            this._btnSearch.Size = new System.Drawing.Size(75, 23);
            this._btnSearch.TabIndex = 160;
            this._btnSearch.Text = "      검   색";
            this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gridView1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 76);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(473, 657);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "검색 결과";
            // 
            // gridView1
            // 
            this.gridView1.AutoSelectRowWithRightButton = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView1.ColumnHeadersHeight = 50;
            this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AGT_CD,
            this.AGT_NM,
            this.PRSNT_NM,
            this.ADDR_BSC,
            this.TELNO,
            this.FAXNO,
            this.BI_COMPANY_NM,
            this.BI_PRSNT_NM,
            this.BI_BINF_NM,
            this.BI_SIMTAX_YN,
            this.BI_SAUP_NO,
            this.PI_PRSNT_NM,
            this.PI_TELNO,
            this.PI_CELLNO,
            this.CI_CNTR_STRT_DT,
            this.CI_CNTR_END_DT,
            this.MO_LOGIN_ID,
            this.MO_STRT_DT,
            this.MO_PAUSED,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME});
            this.gridView1.DelegateProperty = true;
            this.gridView1.Location = new System.Drawing.Point(3, 17);
            this.gridView1.Name = "gridView1";
            this.gridView1.ReadOnly = true;
            this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView1.Size = new System.Drawing.Size(467, 637);
            this.gridView1.TabIndex = 0;
            this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
            this.gridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellDoubleClick);
            // 
            // AGT_CD
            // 
            this.AGT_CD.DataPropertyName = "AGT_CD";
            this.AGT_CD.Frozen = true;
            this.AGT_CD.HeaderText = "대리점코드";
            this.AGT_CD.Name = "AGT_CD";
            this.AGT_CD.ReadOnly = true;
            this.AGT_CD.Width = 87;
            // 
            // AGT_NM
            // 
            this.AGT_NM.DataPropertyName = "AGT_NM";
            this.AGT_NM.Frozen = true;
            this.AGT_NM.HeaderText = "대리점명";
            this.AGT_NM.Name = "AGT_NM";
            this.AGT_NM.ReadOnly = true;
            this.AGT_NM.Width = 76;
            // 
            // PRSNT_NM
            // 
            this.PRSNT_NM.DataPropertyName = "PRSNT_NM";
            this.PRSNT_NM.Frozen = true;
            this.PRSNT_NM.HeaderText = "대표자명";
            this.PRSNT_NM.Name = "PRSNT_NM";
            this.PRSNT_NM.ReadOnly = true;
            this.PRSNT_NM.Width = 76;
            // 
            // ADDR_BSC
            // 
            this.ADDR_BSC.DataPropertyName = "ADDR_BSC";
            this.ADDR_BSC.HeaderText = "기본주소";
            this.ADDR_BSC.Name = "ADDR_BSC";
            this.ADDR_BSC.ReadOnly = true;
            this.ADDR_BSC.Width = 76;
            // 
            // TELNO
            // 
            this.TELNO.DataPropertyName = "TELNO";
            this.TELNO.HeaderText = "전화번호";
            this.TELNO.Name = "TELNO";
            this.TELNO.ReadOnly = true;
            this.TELNO.Width = 76;
            // 
            // FAXNO
            // 
            this.FAXNO.DataPropertyName = "FAXNO";
            this.FAXNO.HeaderText = "팩스번호";
            this.FAXNO.Name = "FAXNO";
            this.FAXNO.ReadOnly = true;
            this.FAXNO.Width = 76;
            // 
            // BI_COMPANY_NM
            // 
            this.BI_COMPANY_NM.DataPropertyName = "BI_COMPANY_NM";
            this.BI_COMPANY_NM.HeaderText = "법인명";
            this.BI_COMPANY_NM.Name = "BI_COMPANY_NM";
            this.BI_COMPANY_NM.ReadOnly = true;
            this.BI_COMPANY_NM.Width = 65;
            // 
            // BI_PRSNT_NM
            // 
            this.BI_PRSNT_NM.DataPropertyName = "BI_PRSNT_NM";
            this.BI_PRSNT_NM.HeaderText = "대표자명";
            this.BI_PRSNT_NM.Name = "BI_PRSNT_NM";
            this.BI_PRSNT_NM.ReadOnly = true;
            this.BI_PRSNT_NM.Width = 76;
            // 
            // BI_BINF_NM
            // 
            this.BI_BINF_NM.DataPropertyName = "BI_BINF_NM";
            this.BI_BINF_NM.HeaderText = "사업자구분";
            this.BI_BINF_NM.Name = "BI_BINF_NM";
            this.BI_BINF_NM.ReadOnly = true;
            this.BI_BINF_NM.Width = 87;
            // 
            // BI_SIMTAX_YN
            // 
            this.BI_SIMTAX_YN.DataPropertyName = "BI_SIMTAX_YN";
            this.BI_SIMTAX_YN.HeaderText = "간이과세여부";
            this.BI_SIMTAX_YN.Name = "BI_SIMTAX_YN";
            this.BI_SIMTAX_YN.ReadOnly = true;
            this.BI_SIMTAX_YN.Width = 98;
            // 
            // BI_SAUP_NO
            // 
            this.BI_SAUP_NO.DataPropertyName = "BI_SAUP_NO";
            this.BI_SAUP_NO.HeaderText = "사업자등록번호";
            this.BI_SAUP_NO.Name = "BI_SAUP_NO";
            this.BI_SAUP_NO.ReadOnly = true;
            this.BI_SAUP_NO.Width = 109;
            // 
            // PI_PRSNT_NM
            // 
            this.PI_PRSNT_NM.DataPropertyName = "PI_PRSNT_NM";
            this.PI_PRSNT_NM.HeaderText = "대표자명";
            this.PI_PRSNT_NM.Name = "PI_PRSNT_NM";
            this.PI_PRSNT_NM.ReadOnly = true;
            this.PI_PRSNT_NM.Width = 76;
            // 
            // PI_TELNO
            // 
            this.PI_TELNO.DataPropertyName = "PI_TELNO";
            this.PI_TELNO.HeaderText = "자택번호";
            this.PI_TELNO.Name = "PI_TELNO";
            this.PI_TELNO.ReadOnly = true;
            this.PI_TELNO.Width = 76;
            // 
            // PI_CELLNO
            // 
            this.PI_CELLNO.DataPropertyName = "PI_CELLNO";
            this.PI_CELLNO.HeaderText = "휴대폰번호";
            this.PI_CELLNO.Name = "PI_CELLNO";
            this.PI_CELLNO.ReadOnly = true;
            this.PI_CELLNO.Width = 87;
            // 
            // CI_CNTR_STRT_DT
            // 
            this.CI_CNTR_STRT_DT.DataPropertyName = "CI_CNTR_STRT_DT";
            this.CI_CNTR_STRT_DT.HeaderText = "계약일자";
            this.CI_CNTR_STRT_DT.Name = "CI_CNTR_STRT_DT";
            this.CI_CNTR_STRT_DT.ReadOnly = true;
            this.CI_CNTR_STRT_DT.Width = 76;
            // 
            // CI_CNTR_END_DT
            // 
            this.CI_CNTR_END_DT.DataPropertyName = "CI_CNTR_END_DT";
            this.CI_CNTR_END_DT.HeaderText = "해지일자";
            this.CI_CNTR_END_DT.Name = "CI_CNTR_END_DT";
            this.CI_CNTR_END_DT.ReadOnly = true;
            this.CI_CNTR_END_DT.Width = 76;
            // 
            // MO_LOGIN_ID
            // 
            this.MO_LOGIN_ID.DataPropertyName = "MO_LOGIN_ID";
            this.MO_LOGIN_ID.HeaderText = "로그인ID";
            this.MO_LOGIN_ID.Name = "MO_LOGIN_ID";
            this.MO_LOGIN_ID.ReadOnly = true;
            this.MO_LOGIN_ID.Width = 76;
            // 
            // MO_STRT_DT
            // 
            this.MO_STRT_DT.DataPropertyName = "MO_STRT_DT";
            this.MO_STRT_DT.HeaderText = "로그인 가능 일자";
            this.MO_STRT_DT.Name = "MO_STRT_DT";
            this.MO_STRT_DT.ReadOnly = true;
            this.MO_STRT_DT.Width = 117;
            // 
            // MO_PAUSED
            // 
            this.MO_PAUSED.DataPropertyName = "MO_PAUSED";
            this.MO_PAUSED.HeaderText = "일시중지여부";
            this.MO_PAUSED.Name = "MO_PAUSED";
            this.MO_PAUSED.ReadOnly = true;
            this.MO_PAUSED.Width = 98;
            // 
            // SYSREGDATE
            // 
            this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE.HeaderText = "시스템등록일";
            this.SYSREGDATE.Name = "SYSREGDATE";
            this.SYSREGDATE.ReadOnly = true;
            this.SYSREGDATE.Width = 98;
            // 
            // SYSREGNAME
            // 
            this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME.HeaderText = "시스템등록자";
            this.SYSREGNAME.Name = "SYSREGNAME";
            this.SYSREGNAME.ReadOnly = true;
            this.SYSREGNAME.Width = 98;
            // 
            // SYSMODDATE
            // 
            this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE.HeaderText = "시스템수정일";
            this.SYSMODDATE.Name = "SYSMODDATE";
            this.SYSMODDATE.ReadOnly = true;
            this.SYSMODDATE.Width = 98;
            // 
            // SYSMODNAME
            // 
            this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME.HeaderText = "시스템수정자";
            this.SYSMODNAME.Name = "SYSMODNAME";
            this.SYSMODNAME.ReadOnly = true;
            this.SYSMODNAME.Width = 98;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Right;
            this.tabControl1.Location = new System.Drawing.Point(481, 76);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(703, 657);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this._btnSave01);
            this.tabPage1.Controls.Add(this._btnDel01);
            this.tabPage1.Controls.Add(this._btnAdd01);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(695, 631);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "기본정보";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // _btnSave01
            // 
            this._btnSave01.ButtonConfirm = true;
            this._btnSave01.DelegateProperty = true;
            this._btnSave01.Enabled = false;
            this._btnSave01.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave01.Location = new System.Drawing.Point(530, 229);
            this._btnSave01.Name = "_btnSave01";
            this._btnSave01.Reserved = "      저   장";
            this._btnSave01.Size = new System.Drawing.Size(75, 27);
            this._btnSave01.TabIndex = 1100;
            this._btnSave01.Text = "      저   장";
            this._btnSave01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave01.UseVisualStyleBackColor = true;
            this._btnSave01.ValidationGroup = "a";
            this._btnSave01.Click += new System.EventHandler(this._btnSave01_Click);
            // 
            // _btnDel01
            // 
            this._btnDel01.ButtonConfirm = true;
            this._btnDel01.DelegateProperty = true;
            this._btnDel01.Enabled = false;
            this._btnDel01.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel01.Location = new System.Drawing.Point(611, 229);
            this._btnDel01.Name = "_btnDel01";
            this._btnDel01.Reserved = "      삭   제";
            this._btnDel01.Size = new System.Drawing.Size(75, 27);
            this._btnDel01.TabIndex = 1110;
            this._btnDel01.Text = "      삭   제";
            this._btnDel01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel01.UseVisualStyleBackColor = true;
            this._btnDel01.ValidationGroup = null;
            // 
            // _btnAdd01
            // 
            this._btnAdd01.DelegateProperty = true;
            this._btnAdd01.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.Location = new System.Drawing.Point(449, 229);
            this._btnAdd01.Name = "_btnAdd01";
            this._btnAdd01.Reserved = "      추   가";
            this._btnAdd01.Size = new System.Drawing.Size(75, 27);
            this._btnAdd01.TabIndex = 1090;
            this._btnAdd01.Text = "      추   가";
            this._btnAdd01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.UseVisualStyleBackColor = true;
            this._btnAdd01.ValidationGroup = null;
            this._btnAdd01.Click += new System.EventHandler(this._btnAdd01_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.Controls.Add(this.labelmemo, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this._txtADDR_DTL, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtPRSNT_NM, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this._txtAGT_NM, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblCOMPANY_CD, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblUSR_PASS, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblUSR_ROLL, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtAGT_CD, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this._txtMEMO, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtTELNO, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtADDR_BSC, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtFAXNO, 3, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(689, 220);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // labelmemo
            // 
            this.labelmemo.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.labelmemo.AutoSize = true;
            this.labelmemo.Location = new System.Drawing.Point(58, 144);
            this.labelmemo.Name = "labelmemo";
            this.labelmemo.Size = new System.Drawing.Size(29, 12);
            this.labelmemo.TabIndex = 38;
            this.labelmemo.Text = "메모";
            // 
            // _txtADDR_DTL
            // 
            this._txtADDR_DTL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtADDR_DTL.DelegateProperty = true;
            this._txtADDR_DTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtADDR_DTL.Location = new System.Drawing.Point(553, 30);
            this._txtADDR_DTL.Name = "_txtADDR_DTL";
            this._txtADDR_DTL.ReadOnly = true;
            this._txtADDR_DTL.Size = new System.Drawing.Size(130, 20);
            this._txtADDR_DTL.TabIndex = 1050;
            this._txtADDR_DTL.ValidationGroup = null;
            this._txtADDR_DTL.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtADDR_DTL.WaterMarkText = "";
            // 
            // _txtPRSNT_NM
            // 
            this._txtPRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPRSNT_NM.Compulsory = true;
            this._txtPRSNT_NM.DelegateProperty = true;
            this._txtPRSNT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPRSNT_NM.Location = new System.Drawing.Point(553, 3);
            this._txtPRSNT_NM.Name = "_txtPRSNT_NM";
            this._txtPRSNT_NM.ReadOnly = true;
            this._txtPRSNT_NM.Size = new System.Drawing.Size(130, 20);
            this._txtPRSNT_NM.TabIndex = 1020;
            this._txtPRSNT_NM.ValidationGroup = "a";
            this._txtPRSNT_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPRSNT_NM.WaterMarkText = "";
            // 
            // _txtAGT_NM
            // 
            this._txtAGT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtAGT_NM.Compulsory = true;
            this._txtAGT_NM.DelegateProperty = true;
            this._txtAGT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtAGT_NM.Location = new System.Drawing.Point(323, 3);
            this._txtAGT_NM.Name = "_txtAGT_NM";
            this._txtAGT_NM.ReadOnly = true;
            this._txtAGT_NM.Size = new System.Drawing.Size(130, 20);
            this._txtAGT_NM.TabIndex = 1010;
            this._txtAGT_NM.ValidationGroup = "a";
            this._txtAGT_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtAGT_NM.WaterMarkText = "";
            // 
            // lblCOMPANY_CD
            // 
            this.lblCOMPANY_CD.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblCOMPANY_CD.AutoSize = true;
            this.lblCOMPANY_CD.Location = new System.Drawing.Point(22, 7);
            this.lblCOMPANY_CD.Name = "lblCOMPANY_CD";
            this.lblCOMPANY_CD.Size = new System.Drawing.Size(65, 12);
            this.lblCOMPANY_CD.TabIndex = 0;
            this.lblCOMPANY_CD.Text = "대리점코드";
            // 
            // lblUSR_ID
            // 
            this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblUSR_ID.AutoSize = true;
            this.lblUSR_ID.Location = new System.Drawing.Point(34, 34);
            this.lblUSR_ID.Name = "lblUSR_ID";
            this.lblUSR_ID.Size = new System.Drawing.Size(53, 12);
            this.lblUSR_ID.TabIndex = 2;
            this.lblUSR_ID.Text = "우편번호";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(264, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "대리점명";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "기본주소";
            // 
            // lblUSR_PASS
            // 
            this.lblUSR_PASS.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblUSR_PASS.AutoSize = true;
            this.lblUSR_PASS.Location = new System.Drawing.Point(494, 7);
            this.lblUSR_PASS.Name = "lblUSR_PASS";
            this.lblUSR_PASS.Size = new System.Drawing.Size(53, 12);
            this.lblUSR_PASS.TabIndex = 8;
            this.lblUSR_PASS.Text = "대표자명";
            // 
            // lblUSR_ROLL
            // 
            this.lblUSR_ROLL.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblUSR_ROLL.AutoSize = true;
            this.lblUSR_ROLL.Location = new System.Drawing.Point(494, 34);
            this.lblUSR_ROLL.Name = "lblUSR_ROLL";
            this.lblUSR_ROLL.Size = new System.Drawing.Size(53, 12);
            this.lblUSR_ROLL.TabIndex = 7;
            this.lblUSR_ROLL.Text = "상세주소";
            // 
            // _txtAGT_CD
            // 
            this._txtAGT_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtAGT_CD.DelegateProperty = true;
            this._txtAGT_CD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtAGT_CD.Location = new System.Drawing.Point(93, 3);
            this._txtAGT_CD.Name = "_txtAGT_CD";
            this._txtAGT_CD.ReadOnly = true;
            this._txtAGT_CD.Size = new System.Drawing.Size(130, 20);
            this._txtAGT_CD.TabIndex = 1000;
            this._txtAGT_CD.ValidationGroup = null;
            this._txtAGT_CD.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtAGT_CD.WaterMarkText = "";
            // 
            // _txtMEMO
            // 
            this._txtMEMO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tableLayoutPanel1.SetColumnSpan(this._txtMEMO, 5);
            this._txtMEMO.DelegateProperty = true;
            this._txtMEMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtMEMO.Location = new System.Drawing.Point(93, 86);
            this._txtMEMO.Multiline = true;
            this._txtMEMO.Name = "_txtMEMO";
            this._txtMEMO.ReadOnly = true;
            this._txtMEMO.Size = new System.Drawing.Size(590, 129);
            this._txtMEMO.TabIndex = 1080;
            this._txtMEMO.ValidationGroup = null;
            this._txtMEMO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtMEMO.WaterMarkText = "";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this._btnFindZipCode01);
            this.panel2.Controls.Add(this._txtZIP_NO);
            this.panel2.Location = new System.Drawing.Point(90, 27);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(140, 27);
            this.panel2.TabIndex = 1030;
            this.panel2.TabStop = true;
            // 
            // _btnFindZipCode01
            // 
            this._btnFindZipCode01.DelegateProperty = true;
            this._btnFindZipCode01.Enabled = false;
            this._btnFindZipCode01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnFindZipCode01.Location = new System.Drawing.Point(79, 3);
            this._btnFindZipCode01.Name = "_btnFindZipCode01";
            this._btnFindZipCode01.Reserved = "검   색";
            this._btnFindZipCode01.Size = new System.Drawing.Size(54, 21);
            this._btnFindZipCode01.TabIndex = 401;
            this._btnFindZipCode01.TabStop = false;
            this._btnFindZipCode01.Text = "검   색";
            this._btnFindZipCode01.UseVisualStyleBackColor = true;
            this._btnFindZipCode01.ValidationGroup = null;
            this._btnFindZipCode01.Click += new System.EventHandler(this._btnFindZipCode01_Click);
            // 
            // _txtZIP_NO
            // 
            this._txtZIP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtZIP_NO.DelegateProperty = true;
            this._txtZIP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtZIP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtZIP_NO.Location = new System.Drawing.Point(3, 4);
            this._txtZIP_NO.MaxLength = 7;
            this._txtZIP_NO.Name = "_txtZIP_NO";
            this._txtZIP_NO.ReadOnly = true;
            this._txtZIP_NO.Size = new System.Drawing.Size(70, 20);
            this._txtZIP_NO.TabIndex = 1030;
            this._txtZIP_NO.ValidationGroup = null;
            this._txtZIP_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtZIP_NO.WaterMarkText = "";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 31;
            this.label3.Text = "전화번호";
            // 
            // _txtTELNO
            // 
            this._txtTELNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTELNO.DelegateProperty = true;
            this._txtTELNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTELNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtTELNO.Location = new System.Drawing.Point(93, 57);
            this._txtTELNO.Name = "_txtTELNO";
            this._txtTELNO.ReadOnly = true;
            this._txtTELNO.Size = new System.Drawing.Size(130, 20);
            this._txtTELNO.TabIndex = 1060;
            this._txtTELNO.ValidationGroup = null;
            this._txtTELNO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTELNO.WaterMarkText = "";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(264, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 33;
            this.label4.Text = "팩스번호";
            // 
            // _txtADDR_BSC
            // 
            this._txtADDR_BSC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtADDR_BSC.DelegateProperty = true;
            this._txtADDR_BSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtADDR_BSC.Location = new System.Drawing.Point(323, 30);
            this._txtADDR_BSC.Name = "_txtADDR_BSC";
            this._txtADDR_BSC.ReadOnly = true;
            this._txtADDR_BSC.Size = new System.Drawing.Size(130, 20);
            this._txtADDR_BSC.TabIndex = 1040;
            this._txtADDR_BSC.ValidationGroup = null;
            this._txtADDR_BSC.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtADDR_BSC.WaterMarkText = "";
            // 
            // _txtFAXNO
            // 
            this._txtFAXNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtFAXNO.DelegateProperty = true;
            this._txtFAXNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtFAXNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtFAXNO.Location = new System.Drawing.Point(323, 57);
            this._txtFAXNO.Name = "_txtFAXNO";
            this._txtFAXNO.ReadOnly = true;
            this._txtFAXNO.Size = new System.Drawing.Size(130, 20);
            this._txtFAXNO.TabIndex = 1070;
            this._txtFAXNO.ValidationGroup = null;
            this._txtFAXNO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtFAXNO.WaterMarkText = "";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this._btnSave02);
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(695, 631);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "사업자등록증정보";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // _btnSave02
            // 
            this._btnSave02.ButtonConfirm = true;
            this._btnSave02.DelegateProperty = true;
            this._btnSave02.Enabled = false;
            this._btnSave02.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave02.Location = new System.Drawing.Point(611, 117);
            this._btnSave02.Name = "_btnSave02";
            this._btnSave02.Reserved = "      저   장";
            this._btnSave02.Size = new System.Drawing.Size(75, 27);
            this._btnSave02.TabIndex = 1240;
            this._btnSave02.Text = "      저   장";
            this._btnSave02.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave02.UseVisualStyleBackColor = true;
            this._btnSave02.ValidationGroup = "a";
            this._btnSave02.Click += new System.EventHandler(this._btnSave01_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 6;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.Controls.Add(this.panel3, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.label16, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_ADDR_BSC, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_BUBIN_NO, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_SAUP_NO, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_PRSNT_NM, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label9, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label10, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label11, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label12, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_COMPANY_NM, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_JONGMOK, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_ADDR_DTL, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.label15, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_EMAIL, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.label14, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.panel1, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this._cmbBI_BINF_CD, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this._txtBI_UPTE, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 3);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(689, 108);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this._rbBI_SIMTAX_Y);
            this.panel3.Controls.Add(this._rbBI_SIMTAX_N);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(553, 30);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(134, 21);
            this.panel3.TabIndex = 1170;
            // 
            // _rbBI_SIMTAX_Y
            // 
            this._rbBI_SIMTAX_Y.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._rbBI_SIMTAX_Y.AutoSize = true;
            this._rbBI_SIMTAX_Y.DelegateProperty = true;
            this._rbBI_SIMTAX_Y.Enabled = false;
            this._rbBI_SIMTAX_Y.Location = new System.Drawing.Point(4, 2);
            this._rbBI_SIMTAX_Y.Name = "_rbBI_SIMTAX_Y";
            this._rbBI_SIMTAX_Y.Size = new System.Drawing.Size(31, 16);
            this._rbBI_SIMTAX_Y.TabIndex = 3;
            this._rbBI_SIMTAX_Y.Text = "Y";
            this._rbBI_SIMTAX_Y.UseVisualStyleBackColor = true;
            // 
            // _rbBI_SIMTAX_N
            // 
            this._rbBI_SIMTAX_N.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._rbBI_SIMTAX_N.AutoSize = true;
            this._rbBI_SIMTAX_N.Checked = true;
            this._rbBI_SIMTAX_N.DelegateProperty = true;
            this._rbBI_SIMTAX_N.Enabled = false;
            this._rbBI_SIMTAX_N.Location = new System.Drawing.Point(43, 2);
            this._rbBI_SIMTAX_N.Name = "_rbBI_SIMTAX_N";
            this._rbBI_SIMTAX_N.Size = new System.Drawing.Size(32, 16);
            this._rbBI_SIMTAX_N.TabIndex = 4;
            this._rbBI_SIMTAX_N.TabStop = true;
            this._rbBI_SIMTAX_N.Text = "N";
            this._rbBI_SIMTAX_N.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(470, 34);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 11;
            this.label16.Text = "간이과세여부";
            // 
            // _txtBI_ADDR_BSC
            // 
            this._txtBI_ADDR_BSC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_ADDR_BSC.DelegateProperty = true;
            this._txtBI_ADDR_BSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_ADDR_BSC.Location = new System.Drawing.Point(323, 57);
            this._txtBI_ADDR_BSC.Name = "_txtBI_ADDR_BSC";
            this._txtBI_ADDR_BSC.ReadOnly = true;
            this._txtBI_ADDR_BSC.Size = new System.Drawing.Size(130, 20);
            this._txtBI_ADDR_BSC.TabIndex = 1190;
            this._txtBI_ADDR_BSC.ValidationGroup = null;
            this._txtBI_ADDR_BSC.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_ADDR_BSC.WaterMarkText = "";
            // 
            // _txtBI_BUBIN_NO
            // 
            this._txtBI_BUBIN_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_BUBIN_NO.DelegateProperty = true;
            this._txtBI_BUBIN_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_BUBIN_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtBI_BUBIN_NO.Location = new System.Drawing.Point(323, 30);
            this._txtBI_BUBIN_NO.MaxLength = 14;
            this._txtBI_BUBIN_NO.Name = "_txtBI_BUBIN_NO";
            this._txtBI_BUBIN_NO.ReadOnly = true;
            this._txtBI_BUBIN_NO.Size = new System.Drawing.Size(130, 20);
            this._txtBI_BUBIN_NO.TabIndex = 1160;
            this._txtBI_BUBIN_NO.ValidationGroup = null;
            this._txtBI_BUBIN_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_BUBIN_NO.WaterMarkText = "";
            // 
            // _txtBI_SAUP_NO
            // 
            this._txtBI_SAUP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_SAUP_NO.DelegateProperty = true;
            this._txtBI_SAUP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_SAUP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtBI_SAUP_NO.Location = new System.Drawing.Point(93, 30);
            this._txtBI_SAUP_NO.MaxLength = 12;
            this._txtBI_SAUP_NO.Name = "_txtBI_SAUP_NO";
            this._txtBI_SAUP_NO.ReadOnly = true;
            this._txtBI_SAUP_NO.Size = new System.Drawing.Size(130, 20);
            this._txtBI_SAUP_NO.TabIndex = 1150;
            this._txtBI_SAUP_NO.ValidationGroup = null;
            this._txtBI_SAUP_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_SAUP_NO.WaterMarkText = "";
            // 
            // _txtBI_PRSNT_NM
            // 
            this._txtBI_PRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_PRSNT_NM.DelegateProperty = true;
            this._txtBI_PRSNT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_PRSNT_NM.Location = new System.Drawing.Point(323, 3);
            this._txtBI_PRSNT_NM.Name = "_txtBI_PRSNT_NM";
            this._txtBI_PRSNT_NM.ReadOnly = true;
            this._txtBI_PRSNT_NM.Size = new System.Drawing.Size(130, 20);
            this._txtBI_PRSNT_NM.TabIndex = 1130;
            this._txtBI_PRSNT_NM.ValidationGroup = null;
            this._txtBI_PRSNT_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_PRSNT_NM.WaterMarkText = "";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "법인명";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "사업자등록번호";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 4;
            this.label8.Text = "우편번호";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(264, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "대표자명";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(240, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 10;
            this.label10.Text = "법인등록번호";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(264, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 11;
            this.label11.Text = "기본주소";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(482, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 8;
            this.label12.Text = "사업자구분";
            // 
            // _txtBI_COMPANY_NM
            // 
            this._txtBI_COMPANY_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_COMPANY_NM.DelegateProperty = true;
            this._txtBI_COMPANY_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_COMPANY_NM.Location = new System.Drawing.Point(93, 3);
            this._txtBI_COMPANY_NM.Name = "_txtBI_COMPANY_NM";
            this._txtBI_COMPANY_NM.ReadOnly = true;
            this._txtBI_COMPANY_NM.Size = new System.Drawing.Size(130, 20);
            this._txtBI_COMPANY_NM.TabIndex = 1120;
            this._txtBI_COMPANY_NM.ValidationGroup = null;
            this._txtBI_COMPANY_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_COMPANY_NM.WaterMarkText = "";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(494, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 20;
            this.label5.Text = "상세주소";
            // 
            // _txtBI_JONGMOK
            // 
            this._txtBI_JONGMOK.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_JONGMOK.DelegateProperty = true;
            this._txtBI_JONGMOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_JONGMOK.Location = new System.Drawing.Point(323, 84);
            this._txtBI_JONGMOK.Name = "_txtBI_JONGMOK";
            this._txtBI_JONGMOK.ReadOnly = true;
            this._txtBI_JONGMOK.Size = new System.Drawing.Size(130, 20);
            this._txtBI_JONGMOK.TabIndex = 1220;
            this._txtBI_JONGMOK.ValidationGroup = null;
            this._txtBI_JONGMOK.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_JONGMOK.WaterMarkText = "";
            // 
            // _txtBI_ADDR_DTL
            // 
            this._txtBI_ADDR_DTL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_ADDR_DTL.DelegateProperty = true;
            this._txtBI_ADDR_DTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_ADDR_DTL.Location = new System.Drawing.Point(553, 57);
            this._txtBI_ADDR_DTL.Name = "_txtBI_ADDR_DTL";
            this._txtBI_ADDR_DTL.ReadOnly = true;
            this._txtBI_ADDR_DTL.Size = new System.Drawing.Size(130, 20);
            this._txtBI_ADDR_DTL.TabIndex = 1200;
            this._txtBI_ADDR_DTL.ValidationGroup = null;
            this._txtBI_ADDR_DTL.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_ADDR_DTL.WaterMarkText = "";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(288, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 25;
            this.label15.Text = "종목";
            // 
            // _txtBI_EMAIL
            // 
            this._txtBI_EMAIL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_EMAIL.DelegateProperty = true;
            this._txtBI_EMAIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_EMAIL.Location = new System.Drawing.Point(553, 84);
            this._txtBI_EMAIL.Name = "_txtBI_EMAIL";
            this._txtBI_EMAIL.ReadOnly = true;
            this._txtBI_EMAIL.Size = new System.Drawing.Size(130, 20);
            this._txtBI_EMAIL.TabIndex = 1230;
            this._txtBI_EMAIL.ValidationGroup = null;
            this._txtBI_EMAIL.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_EMAIL.WaterMarkText = "";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(466, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 12);
            this.label14.TabIndex = 23;
            this.label14.Text = "계산서 이메일";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this._btnFindZipCode02);
            this.panel1.Controls.Add(this._txtBI_ZIP_NO);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(90, 54);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(140, 27);
            this.panel1.TabIndex = 1180;
            this.panel1.TabStop = true;
            // 
            // _btnFindZipCode02
            // 
            this._btnFindZipCode02.DelegateProperty = true;
            this._btnFindZipCode02.Enabled = false;
            this._btnFindZipCode02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnFindZipCode02.Location = new System.Drawing.Point(79, 3);
            this._btnFindZipCode02.Name = "_btnFindZipCode02";
            this._btnFindZipCode02.Reserved = "검   색";
            this._btnFindZipCode02.Size = new System.Drawing.Size(54, 21);
            this._btnFindZipCode02.TabIndex = 401;
            this._btnFindZipCode02.TabStop = false;
            this._btnFindZipCode02.Text = "검   색";
            this._btnFindZipCode02.UseVisualStyleBackColor = true;
            this._btnFindZipCode02.ValidationGroup = null;
            this._btnFindZipCode02.Click += new System.EventHandler(this._btnFindZipCode02_Click);
            // 
            // _txtBI_ZIP_NO
            // 
            this._txtBI_ZIP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_ZIP_NO.DelegateProperty = true;
            this._txtBI_ZIP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_ZIP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtBI_ZIP_NO.Location = new System.Drawing.Point(3, 4);
            this._txtBI_ZIP_NO.Name = "_txtBI_ZIP_NO";
            this._txtBI_ZIP_NO.ReadOnly = true;
            this._txtBI_ZIP_NO.Size = new System.Drawing.Size(70, 20);
            this._txtBI_ZIP_NO.TabIndex = 1180;
            this._txtBI_ZIP_NO.ValidationGroup = null;
            this._txtBI_ZIP_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_ZIP_NO.WaterMarkText = "";
            // 
            // _cmbBI_BINF_CD
            // 
            this._cmbBI_BINF_CD.DataSource = null;
            this._cmbBI_BINF_CD.DelegateProperty = true;
            this._cmbBI_BINF_CD.DroppedDown = false;
            this._cmbBI_BINF_CD.Enabled = false;
            this._cmbBI_BINF_CD.Location = new System.Drawing.Point(553, 3);
            this._cmbBI_BINF_CD.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbBI_BINF_CD.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbBI_BINF_CD.Name = "_cmbBI_BINF_CD";
            this._cmbBI_BINF_CD.SelectedIndex = -1;
            this._cmbBI_BINF_CD.SelectedItem = null;
            this._cmbBI_BINF_CD.SelectedValue = null;
            this._cmbBI_BINF_CD.Size = new System.Drawing.Size(130, 21);
            this._cmbBI_BINF_CD.TabIndex = 1140;
            this._cmbBI_BINF_CD.ValidationGroup = null;
            this._cmbBI_BINF_CD.DropDownClosed += new System.EventHandler(this._cmbBI_BINF_CD_DropDownClosed);
            // 
            // _txtBI_UPTE
            // 
            this._txtBI_UPTE.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBI_UPTE.DelegateProperty = true;
            this._txtBI_UPTE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBI_UPTE.Location = new System.Drawing.Point(93, 84);
            this._txtBI_UPTE.Name = "_txtBI_UPTE";
            this._txtBI_UPTE.ReadOnly = true;
            this._txtBI_UPTE.Size = new System.Drawing.Size(130, 20);
            this._txtBI_UPTE.TabIndex = 1210;
            this._txtBI_UPTE.ValidationGroup = null;
            this._txtBI_UPTE.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtBI_UPTE.WaterMarkText = "";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(58, 88);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "업태";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this._btnSave03);
            this.tabPage3.Controls.Add(this.tableLayoutPanel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(695, 631);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "대표자정보";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // _btnSave03
            // 
            this._btnSave03.ButtonConfirm = true;
            this._btnSave03.DelegateProperty = true;
            this._btnSave03.Enabled = false;
            this._btnSave03.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave03.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave03.Location = new System.Drawing.Point(611, 90);
            this._btnSave03.Name = "_btnSave03";
            this._btnSave03.Reserved = "      저   장";
            this._btnSave03.Size = new System.Drawing.Size(75, 27);
            this._btnSave03.TabIndex = 1330;
            this._btnSave03.Text = "      저   장";
            this._btnSave03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave03.UseVisualStyleBackColor = true;
            this._btnSave03.ValidationGroup = "a";
            this._btnSave03.Click += new System.EventHandler(this._btnSave01_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel3.Controls.Add(this._txtPI_ADDR_BSC, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this._txtPI_CELLNO, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this._txtPI_TELNO, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this._txtPI_CNTZ_NO, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label19, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label20, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label21, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label22, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label23, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this._txtPI_PRSNT_NM, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label25, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this._txtPI_ADDR_DTL, 5, 2);
            this.tableLayoutPanel3.Controls.Add(this.panel5, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label27, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this._txtPI_EMAIL, 5, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(689, 81);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // _txtPI_ADDR_BSC
            // 
            this._txtPI_ADDR_BSC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_ADDR_BSC.DelegateProperty = true;
            this._txtPI_ADDR_BSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_ADDR_BSC.Location = new System.Drawing.Point(323, 57);
            this._txtPI_ADDR_BSC.Name = "_txtPI_ADDR_BSC";
            this._txtPI_ADDR_BSC.ReadOnly = true;
            this._txtPI_ADDR_BSC.Size = new System.Drawing.Size(130, 20);
            this._txtPI_ADDR_BSC.TabIndex = 1310;
            this._txtPI_ADDR_BSC.ValidationGroup = null;
            this._txtPI_ADDR_BSC.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_ADDR_BSC.WaterMarkText = "";
            // 
            // _txtPI_CELLNO
            // 
            this._txtPI_CELLNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_CELLNO.DelegateProperty = true;
            this._txtPI_CELLNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_CELLNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtPI_CELLNO.Location = new System.Drawing.Point(323, 30);
            this._txtPI_CELLNO.Name = "_txtPI_CELLNO";
            this._txtPI_CELLNO.ReadOnly = true;
            this._txtPI_CELLNO.Size = new System.Drawing.Size(130, 20);
            this._txtPI_CELLNO.TabIndex = 1280;
            this._txtPI_CELLNO.ValidationGroup = null;
            this._txtPI_CELLNO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_CELLNO.WaterMarkText = "";
            // 
            // _txtPI_TELNO
            // 
            this._txtPI_TELNO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_TELNO.DelegateProperty = true;
            this._txtPI_TELNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_TELNO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtPI_TELNO.Location = new System.Drawing.Point(93, 30);
            this._txtPI_TELNO.MaxLength = 12;
            this._txtPI_TELNO.Name = "_txtPI_TELNO";
            this._txtPI_TELNO.ReadOnly = true;
            this._txtPI_TELNO.Size = new System.Drawing.Size(130, 20);
            this._txtPI_TELNO.TabIndex = 1270;
            this._txtPI_TELNO.ValidationGroup = null;
            this._txtPI_TELNO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_TELNO.WaterMarkText = "";
            // 
            // _txtPI_CNTZ_NO
            // 
            this._txtPI_CNTZ_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_CNTZ_NO.DelegateProperty = true;
            this._txtPI_CNTZ_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_CNTZ_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtPI_CNTZ_NO.Location = new System.Drawing.Point(323, 3);
            this._txtPI_CNTZ_NO.MaxLength = 14;
            this._txtPI_CNTZ_NO.Name = "_txtPI_CNTZ_NO";
            this._txtPI_CNTZ_NO.ReadOnly = true;
            this._txtPI_CNTZ_NO.Size = new System.Drawing.Size(130, 20);
            this._txtPI_CNTZ_NO.TabIndex = 1260;
            this._txtPI_CNTZ_NO.ValidationGroup = null;
            this._txtPI_CNTZ_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_CNTZ_NO.WaterMarkText = "";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(34, 7);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "대표자명";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(34, 34);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "자택번호";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 61);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(81, 12);
            this.label20.TabIndex = 4;
            this.label20.Text = "자택 우편번호";
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(240, 7);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 12);
            this.label21.TabIndex = 9;
            this.label21.Text = "주민등록번호";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(252, 34);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 10;
            this.label22.Text = "휴대폰번호";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(236, 61);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 12);
            this.label23.TabIndex = 11;
            this.label23.Text = "자택 기본주소";
            // 
            // _txtPI_PRSNT_NM
            // 
            this._txtPI_PRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_PRSNT_NM.DelegateProperty = true;
            this._txtPI_PRSNT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_PRSNT_NM.Location = new System.Drawing.Point(93, 3);
            this._txtPI_PRSNT_NM.Name = "_txtPI_PRSNT_NM";
            this._txtPI_PRSNT_NM.ReadOnly = true;
            this._txtPI_PRSNT_NM.Size = new System.Drawing.Size(130, 20);
            this._txtPI_PRSNT_NM.TabIndex = 1250;
            this._txtPI_PRSNT_NM.ValidationGroup = null;
            this._txtPI_PRSNT_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_PRSNT_NM.WaterMarkText = "";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(466, 61);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(81, 12);
            this.label25.TabIndex = 20;
            this.label25.Text = "자택 상세주소";
            // 
            // _txtPI_ADDR_DTL
            // 
            this._txtPI_ADDR_DTL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_ADDR_DTL.DelegateProperty = true;
            this._txtPI_ADDR_DTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_ADDR_DTL.Location = new System.Drawing.Point(553, 57);
            this._txtPI_ADDR_DTL.Name = "_txtPI_ADDR_DTL";
            this._txtPI_ADDR_DTL.ReadOnly = true;
            this._txtPI_ADDR_DTL.Size = new System.Drawing.Size(130, 20);
            this._txtPI_ADDR_DTL.TabIndex = 1320;
            this._txtPI_ADDR_DTL.ValidationGroup = null;
            this._txtPI_ADDR_DTL.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_ADDR_DTL.WaterMarkText = "";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this._btnFindZipCode03);
            this.panel5.Controls.Add(this._txtPI_ZIP_NO);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(90, 54);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(140, 27);
            this.panel5.TabIndex = 1300;
            this.panel5.TabStop = true;
            // 
            // _btnFindZipCode03
            // 
            this._btnFindZipCode03.DelegateProperty = true;
            this._btnFindZipCode03.Enabled = false;
            this._btnFindZipCode03.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnFindZipCode03.Location = new System.Drawing.Point(79, 3);
            this._btnFindZipCode03.Name = "_btnFindZipCode03";
            this._btnFindZipCode03.Reserved = "검   색";
            this._btnFindZipCode03.Size = new System.Drawing.Size(54, 21);
            this._btnFindZipCode03.TabIndex = 401;
            this._btnFindZipCode03.TabStop = false;
            this._btnFindZipCode03.Text = "검   색";
            this._btnFindZipCode03.UseVisualStyleBackColor = true;
            this._btnFindZipCode03.ValidationGroup = null;
            this._btnFindZipCode03.Click += new System.EventHandler(this._btnFindZipCode03_Click);
            // 
            // _txtPI_ZIP_NO
            // 
            this._txtPI_ZIP_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_ZIP_NO.DelegateProperty = true;
            this._txtPI_ZIP_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_ZIP_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtPI_ZIP_NO.Location = new System.Drawing.Point(3, 4);
            this._txtPI_ZIP_NO.Name = "_txtPI_ZIP_NO";
            this._txtPI_ZIP_NO.ReadOnly = true;
            this._txtPI_ZIP_NO.Size = new System.Drawing.Size(70, 20);
            this._txtPI_ZIP_NO.TabIndex = 1300;
            this._txtPI_ZIP_NO.ValidationGroup = null;
            this._txtPI_ZIP_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_ZIP_NO.WaterMarkText = "";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(466, 34);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(81, 12);
            this.label27.TabIndex = 23;
            this.label27.Text = "대표자 이메일";
            // 
            // _txtPI_EMAIL
            // 
            this._txtPI_EMAIL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtPI_EMAIL.DelegateProperty = true;
            this._txtPI_EMAIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtPI_EMAIL.Location = new System.Drawing.Point(553, 30);
            this._txtPI_EMAIL.Name = "_txtPI_EMAIL";
            this._txtPI_EMAIL.ReadOnly = true;
            this._txtPI_EMAIL.Size = new System.Drawing.Size(130, 20);
            this._txtPI_EMAIL.TabIndex = 1290;
            this._txtPI_EMAIL.ValidationGroup = null;
            this._txtPI_EMAIL.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtPI_EMAIL.WaterMarkText = "";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this._btnSave04);
            this.tabPage4.Controls.Add(this.tableLayoutPanel4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(695, 631);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "정산/계약정보";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // _btnSave04
            // 
            this._btnSave04.ButtonConfirm = true;
            this._btnSave04.DelegateProperty = true;
            this._btnSave04.Enabled = false;
            this._btnSave04.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave04.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave04.Location = new System.Drawing.Point(611, 63);
            this._btnSave04.Name = "_btnSave04";
            this._btnSave04.Reserved = "      저   장";
            this._btnSave04.Size = new System.Drawing.Size(75, 27);
            this._btnSave04.TabIndex = 1390;
            this._btnSave04.Text = "      저   장";
            this._btnSave04.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave04.UseVisualStyleBackColor = true;
            this._btnSave04.ValidationGroup = "a";
            this._btnSave04.Click += new System.EventHandler(this._btnSave01_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel4.Controls.Add(this._dtpCI_CNTR_END_DT, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this._cmbCI_BNK_CD, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this._txtCI_ACCT_NO, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label24, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label28, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label29, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label32, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this._txtCI_ACCT_NM, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this._dtpCI_CNTR_STRT_DT, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(689, 54);
            this.tableLayoutPanel4.TabIndex = 5;
            // 
            // _dtpCI_CNTR_END_DT
            // 
            this._dtpCI_CNTR_END_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_CNTR_END_DT.Checked = false;
            this._dtpCI_CNTR_END_DT.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_CNTR_END_DT.DelegateProperty = true;
            this._dtpCI_CNTR_END_DT.Enabled = false;
            this._dtpCI_CNTR_END_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_CNTR_END_DT.Location = new System.Drawing.Point(323, 3);
            this._dtpCI_CNTR_END_DT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpCI_CNTR_END_DT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpCI_CNTR_END_DT.Name = "_dtpCI_CNTR_END_DT";
            this._dtpCI_CNTR_END_DT.ShowCheckBox = true;
            this._dtpCI_CNTR_END_DT.Size = new System.Drawing.Size(130, 20);
            this._dtpCI_CNTR_END_DT.TabIndex = 1350;
            this._dtpCI_CNTR_END_DT.ValidationGroup = null;
            this._dtpCI_CNTR_END_DT.Value = new System.DateTime(2014, 7, 25, 12, 25, 24, 700);
            // 
            // _cmbCI_BNK_CD
            // 
            this._cmbCI_BNK_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._cmbCI_BNK_CD.DataSource = null;
            this._cmbCI_BNK_CD.DelegateProperty = true;
            this._cmbCI_BNK_CD.DroppedDown = false;
            this._cmbCI_BNK_CD.Enabled = false;
            this._cmbCI_BNK_CD.Location = new System.Drawing.Point(93, 30);
            this._cmbCI_BNK_CD.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbCI_BNK_CD.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbCI_BNK_CD.Name = "_cmbCI_BNK_CD";
            this._cmbCI_BNK_CD.SelectedIndex = -1;
            this._cmbCI_BNK_CD.SelectedItem = null;
            this._cmbCI_BNK_CD.SelectedValue = null;
            this._cmbCI_BNK_CD.Size = new System.Drawing.Size(130, 21);
            this._cmbCI_BNK_CD.TabIndex = 1360;
            this._cmbCI_BNK_CD.ValidationGroup = null;
            // 
            // _txtCI_ACCT_NO
            // 
            this._txtCI_ACCT_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_ACCT_NO.DelegateProperty = true;
            this._txtCI_ACCT_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_ACCT_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtCI_ACCT_NO.Location = new System.Drawing.Point(323, 30);
            this._txtCI_ACCT_NO.Name = "_txtCI_ACCT_NO";
            this._txtCI_ACCT_NO.ReadOnly = true;
            this._txtCI_ACCT_NO.Size = new System.Drawing.Size(130, 20);
            this._txtCI_ACCT_NO.TabIndex = 1370;
            this._txtCI_ACCT_NO.ValidationGroup = null;
            this._txtCI_ACCT_NO.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_ACCT_NO.WaterMarkText = "";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(34, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "계약일자";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(34, 34);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 2;
            this.label24.Text = "입금은행";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(264, 7);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 9;
            this.label28.Text = "해지일자";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(264, 34);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 12);
            this.label29.TabIndex = 10;
            this.label29.Text = "계좌번호";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(506, 34);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 12);
            this.label32.TabIndex = 23;
            this.label32.Text = "예금주";
            // 
            // _txtCI_ACCT_NM
            // 
            this._txtCI_ACCT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_ACCT_NM.DelegateProperty = true;
            this._txtCI_ACCT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_ACCT_NM.Location = new System.Drawing.Point(553, 30);
            this._txtCI_ACCT_NM.Name = "_txtCI_ACCT_NM";
            this._txtCI_ACCT_NM.ReadOnly = true;
            this._txtCI_ACCT_NM.Size = new System.Drawing.Size(130, 20);
            this._txtCI_ACCT_NM.TabIndex = 1380;
            this._txtCI_ACCT_NM.ValidationGroup = null;
            this._txtCI_ACCT_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_ACCT_NM.WaterMarkText = "";
            // 
            // _dtpCI_CNTR_STRT_DT
            // 
            this._dtpCI_CNTR_STRT_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_CNTR_STRT_DT.Checked = false;
            this._dtpCI_CNTR_STRT_DT.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_CNTR_STRT_DT.DelegateProperty = true;
            this._dtpCI_CNTR_STRT_DT.Enabled = false;
            this._dtpCI_CNTR_STRT_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_CNTR_STRT_DT.Location = new System.Drawing.Point(93, 3);
            this._dtpCI_CNTR_STRT_DT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpCI_CNTR_STRT_DT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpCI_CNTR_STRT_DT.Name = "_dtpCI_CNTR_STRT_DT";
            this._dtpCI_CNTR_STRT_DT.ShowCheckBox = true;
            this._dtpCI_CNTR_STRT_DT.Size = new System.Drawing.Size(130, 20);
            this._dtpCI_CNTR_STRT_DT.TabIndex = 1340;
            this._dtpCI_CNTR_STRT_DT.ValidationGroup = null;
            this._dtpCI_CNTR_STRT_DT.Value = new System.DateTime(2014, 7, 25, 12, 25, 24, 728);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this._btnSave05);
            this.tabPage5.Controls.Add(this.tableLayoutPanel5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(695, 631);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "마이오피스정보";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(93, 64);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(541, 24);
            this.label34.TabIndex = 1116;
            this.label34.Text = "시스템점검중에 체크 하시면, \"시스템 점검 중이므로 일시적으로 사용할 수 없습니다.\"라는 메시지를\r\n띄우고 로그인을 할 수 없습니다.";
            // 
            // _btnSave05
            // 
            this._btnSave05.ButtonConfirm = true;
            this._btnSave05.DelegateProperty = true;
            this._btnSave05.Enabled = false;
            this._btnSave05.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave05.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave05.Location = new System.Drawing.Point(611, 91);
            this._btnSave05.Name = "_btnSave05";
            this._btnSave05.Reserved = "      저   장";
            this._btnSave05.Size = new System.Drawing.Size(75, 27);
            this._btnSave05.TabIndex = 1440;
            this._btnSave05.Text = "      저   장";
            this._btnSave05.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave05.UseVisualStyleBackColor = true;
            this._btnSave05.ValidationGroup = "a";
            this._btnSave05.Click += new System.EventHandler(this._btnSave01_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 6;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel5.Controls.Add(this.label30, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label26, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this._dtpMO_STRT_DT, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.label31, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this._txtMO_LOGIN_ID, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label33, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this._txtMO_LOGIN_PW, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this._chkMO_PAUSED, 1, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(689, 54);
            this.tableLayoutPanel5.TabIndex = 6;
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(34, 34);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(53, 12);
            this.label30.TabIndex = 1115;
            this.label30.Text = "일시중지";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(35, 7);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "로그인ID";
            // 
            // _dtpMO_STRT_DT
            // 
            this._dtpMO_STRT_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpMO_STRT_DT.Checked = false;
            this._dtpMO_STRT_DT.CustomFormat = "yyyy-MM-dd";
            this._dtpMO_STRT_DT.DelegateProperty = true;
            this._dtpMO_STRT_DT.Enabled = false;
            this._dtpMO_STRT_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpMO_STRT_DT.Location = new System.Drawing.Point(553, 3);
            this._dtpMO_STRT_DT.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpMO_STRT_DT.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpMO_STRT_DT.Name = "_dtpMO_STRT_DT";
            this._dtpMO_STRT_DT.ShowCheckBox = true;
            this._dtpMO_STRT_DT.Size = new System.Drawing.Size(130, 21);
            this._dtpMO_STRT_DT.TabIndex = 1420;
            this._dtpMO_STRT_DT.ValidationGroup = null;
            this._dtpMO_STRT_DT.Value = new System.DateTime(2014, 7, 25, 12, 25, 24, 758);
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(466, 7);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(81, 12);
            this.label31.TabIndex = 9;
            this.label31.Text = "로그인 가능일";
            // 
            // _txtMO_LOGIN_ID
            // 
            this._txtMO_LOGIN_ID.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtMO_LOGIN_ID.DelegateProperty = true;
            this._txtMO_LOGIN_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtMO_LOGIN_ID.Location = new System.Drawing.Point(93, 3);
            this._txtMO_LOGIN_ID.Name = "_txtMO_LOGIN_ID";
            this._txtMO_LOGIN_ID.ReadOnly = true;
            this._txtMO_LOGIN_ID.Size = new System.Drawing.Size(130, 20);
            this._txtMO_LOGIN_ID.TabIndex = 1400;
            this._txtMO_LOGIN_ID.ValidationGroup = null;
            this._txtMO_LOGIN_ID.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtMO_LOGIN_ID.WaterMarkText = "";
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(264, 7);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 12);
            this.label33.TabIndex = 10;
            this.label33.Text = "비밀번호";
            // 
            // _txtMO_LOGIN_PW
            // 
            this._txtMO_LOGIN_PW.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtMO_LOGIN_PW.DelegateProperty = true;
            this._txtMO_LOGIN_PW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtMO_LOGIN_PW.Location = new System.Drawing.Point(323, 3);
            this._txtMO_LOGIN_PW.Name = "_txtMO_LOGIN_PW";
            this._txtMO_LOGIN_PW.PasswordChar = '⊙';
            this._txtMO_LOGIN_PW.ReadOnly = true;
            this._txtMO_LOGIN_PW.Size = new System.Drawing.Size(130, 20);
            this._txtMO_LOGIN_PW.TabIndex = 1410;
            this._txtMO_LOGIN_PW.ValidationGroup = null;
            this._txtMO_LOGIN_PW.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtMO_LOGIN_PW.WaterMarkText = "";
            // 
            // _chkMO_PAUSED
            // 
            this._chkMO_PAUSED.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._chkMO_PAUSED.AutoSize = true;
            this._chkMO_PAUSED.DelegateProperty = true;
            this._chkMO_PAUSED.Enabled = false;
            this._chkMO_PAUSED.Location = new System.Drawing.Point(93, 32);
            this._chkMO_PAUSED.Name = "_chkMO_PAUSED";
            this._chkMO_PAUSED.Size = new System.Drawing.Size(96, 16);
            this._chkMO_PAUSED.TabIndex = 1430;
            this._chkMO_PAUSED.Text = "시스템점검중";
            this._chkMO_PAUSED.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.progressBar1);
            this.tabPage6.Controls.Add(this.gridView2);
            this.tabPage6.Controls.Add(this.panel4);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(695, 631);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "구비서류";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(298, 285);
            this.progressBar1.MarqueeAnimationSpeed = 10;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(171, 13);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 2;
            this.progressBar1.Visible = false;
            // 
            // gridView2
            // 
            this.gridView2.AutoSelectRowWithRightButton = false;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX2,
            this.DOC_GUBUN_NM,
            this.DOC_FILE_NAME,
            this.DOC_FILE_SIZE,
            this.DownLoad,
            this.MEMO2,
            this.SYSREGDATE2,
            this.SYSREGNAME2,
            this.SYSMODDATE2,
            this.SYSMODNAME2,
            this.DOC_FILE_TYPE});
            this.gridView2.DelegateProperty = true;
            this.gridView2.Location = new System.Drawing.Point(3, 3);
            this.gridView2.Name = "gridView2";
            this.gridView2.ReadOnly = true;
            this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView2.Size = new System.Drawing.Size(689, 584);
            this.gridView2.TabIndex = 1;
            this.gridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView2_CellContentClick);
            this.gridView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView2_CellDoubleClick);
            this.gridView2.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView2_DataBindingComplete);
            // 
            // IDX2
            // 
            this.IDX2.DataPropertyName = "IDX";
            this.IDX2.HeaderText = "일련번호";
            this.IDX2.Name = "IDX2";
            this.IDX2.ReadOnly = true;
            this.IDX2.Width = 78;
            // 
            // DOC_GUBUN_NM
            // 
            this.DOC_GUBUN_NM.DataPropertyName = "DOC_GUBUN_NM";
            this.DOC_GUBUN_NM.HeaderText = "구비서류항목";
            this.DOC_GUBUN_NM.Name = "DOC_GUBUN_NM";
            this.DOC_GUBUN_NM.ReadOnly = true;
            this.DOC_GUBUN_NM.Width = 102;
            // 
            // DOC_FILE_NAME
            // 
            this.DOC_FILE_NAME.DataPropertyName = "DOC_FILE_NAME";
            this.DOC_FILE_NAME.HeaderText = "파일명";
            this.DOC_FILE_NAME.Name = "DOC_FILE_NAME";
            this.DOC_FILE_NAME.ReadOnly = true;
            this.DOC_FILE_NAME.Width = 66;
            // 
            // DOC_FILE_SIZE
            // 
            this.DOC_FILE_SIZE.DataPropertyName = "DOC_FILE_SIZE";
            this.DOC_FILE_SIZE.HeaderText = "파일크기(kb)";
            this.DOC_FILE_SIZE.Name = "DOC_FILE_SIZE";
            this.DOC_FILE_SIZE.ReadOnly = true;
            this.DOC_FILE_SIZE.Width = 101;
            // 
            // DownLoad
            // 
            this.DownLoad.HeaderText = "다운로드";
            this.DownLoad.Name = "DownLoad";
            this.DownLoad.ReadOnly = true;
            this.DownLoad.Width = 59;
            // 
            // MEMO2
            // 
            this.MEMO2.DataPropertyName = "MEMO";
            this.MEMO2.HeaderText = "메모";
            this.MEMO2.Name = "MEMO2";
            this.MEMO2.ReadOnly = true;
            this.MEMO2.Width = 54;
            // 
            // SYSREGDATE2
            // 
            this.SYSREGDATE2.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE2.HeaderText = "시스템등록일";
            this.SYSREGDATE2.Name = "SYSREGDATE2";
            this.SYSREGDATE2.ReadOnly = true;
            this.SYSREGDATE2.Width = 102;
            // 
            // SYSREGNAME2
            // 
            this.SYSREGNAME2.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME2.HeaderText = "시스템등록자";
            this.SYSREGNAME2.Name = "SYSREGNAME2";
            this.SYSREGNAME2.ReadOnly = true;
            this.SYSREGNAME2.Width = 102;
            // 
            // SYSMODDATE2
            // 
            this.SYSMODDATE2.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE2.HeaderText = "시스템수정일";
            this.SYSMODDATE2.Name = "SYSMODDATE2";
            this.SYSMODDATE2.ReadOnly = true;
            this.SYSMODDATE2.Width = 102;
            // 
            // SYSMODNAME2
            // 
            this.SYSMODNAME2.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME2.HeaderText = "시스템수정자";
            this.SYSMODNAME2.Name = "SYSMODNAME2";
            this.SYSMODNAME2.ReadOnly = true;
            this.SYSMODNAME2.Width = 102;
            // 
            // DOC_FILE_TYPE
            // 
            this.DOC_FILE_TYPE.DataPropertyName = "DOC_FILE_TYPE";
            this.DOC_FILE_TYPE.HeaderText = "파일종류";
            this.DOC_FILE_TYPE.Name = "DOC_FILE_TYPE";
            this.DOC_FILE_TYPE.ReadOnly = true;
            this.DOC_FILE_TYPE.Visible = false;
            this.DOC_FILE_TYPE.Width = 76;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this._btnDel02);
            this.panel4.Controls.Add(this._btnAdd02);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 587);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(689, 41);
            this.panel4.TabIndex = 0;
            // 
            // _btnDel02
            // 
            this._btnDel02.ButtonConfirm = true;
            this._btnDel02.DelegateProperty = true;
            this._btnDel02.Enabled = false;
            this._btnDel02.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel02.Location = new System.Drawing.Point(609, 6);
            this._btnDel02.Name = "_btnDel02";
            this._btnDel02.Reserved = "      삭   제";
            this._btnDel02.Size = new System.Drawing.Size(75, 27);
            this._btnDel02.TabIndex = 1460;
            this._btnDel02.Text = "      삭   제";
            this._btnDel02.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel02.UseVisualStyleBackColor = true;
            this._btnDel02.ValidationGroup = null;
            this._btnDel02.Click += new System.EventHandler(this._btnDel02_Click);
            // 
            // _btnAdd02
            // 
            this._btnAdd02.DelegateProperty = true;
            this._btnAdd02.Enabled = false;
            this._btnAdd02.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd02.Location = new System.Drawing.Point(528, 6);
            this._btnAdd02.Name = "_btnAdd02";
            this._btnAdd02.Reserved = "      추   가";
            this._btnAdd02.Size = new System.Drawing.Size(75, 27);
            this._btnAdd02.TabIndex = 1450;
            this._btnAdd02.Text = "      추   가";
            this._btnAdd02.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd02.UseVisualStyleBackColor = true;
            this._btnAdd02.ValidationGroup = null;
            this._btnAdd02.Click += new System.EventHandler(this._btnAdd02_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.gridView3);
            this.tabPage7.Controls.Add(this.panel6);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(695, 631);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "통화내역";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // gridView3
            // 
            this.gridView3.AutoSelectRowWithRightButton = false;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.gridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX3,
            this.CALL_NM,
            this.CALL_DT_STRT,
            this.CALL_DT_END,
            this.MEMO,
            this.SYSREGDATE3,
            this.SYSREGNAME3,
            this.SYSMODDATE3,
            this.SYSMODNAME3});
            this.gridView3.DelegateProperty = true;
            this.gridView3.Location = new System.Drawing.Point(3, 3);
            this.gridView3.Name = "gridView3";
            this.gridView3.ReadOnly = true;
            this.gridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView3.Size = new System.Drawing.Size(689, 584);
            this.gridView3.TabIndex = 3;
            this.gridView3.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView3_CellDoubleClick);
            // 
            // IDX3
            // 
            this.IDX3.DataPropertyName = "IDX";
            this.IDX3.HeaderText = "순번";
            this.IDX3.Name = "IDX3";
            this.IDX3.ReadOnly = true;
            this.IDX3.Width = 54;
            // 
            // CALL_NM
            // 
            this.CALL_NM.DataPropertyName = "CALL_NM";
            this.CALL_NM.HeaderText = "통화상대명";
            this.CALL_NM.Name = "CALL_NM";
            this.CALL_NM.ReadOnly = true;
            this.CALL_NM.Width = 90;
            // 
            // CALL_DT_STRT
            // 
            this.CALL_DT_STRT.DataPropertyName = "CALL_DT_STRT";
            this.CALL_DT_STRT.HeaderText = "시작시각";
            this.CALL_DT_STRT.Name = "CALL_DT_STRT";
            this.CALL_DT_STRT.ReadOnly = true;
            this.CALL_DT_STRT.Width = 78;
            // 
            // CALL_DT_END
            // 
            this.CALL_DT_END.DataPropertyName = "CALL_DT_END";
            this.CALL_DT_END.HeaderText = "종료시각";
            this.CALL_DT_END.Name = "CALL_DT_END";
            this.CALL_DT_END.ReadOnly = true;
            this.CALL_DT_END.Width = 78;
            // 
            // MEMO
            // 
            this.MEMO.DataPropertyName = "MEMO";
            this.MEMO.HeaderText = "메모";
            this.MEMO.Name = "MEMO";
            this.MEMO.ReadOnly = true;
            this.MEMO.Width = 54;
            // 
            // SYSREGDATE3
            // 
            this.SYSREGDATE3.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE3.HeaderText = "시스템등록일";
            this.SYSREGDATE3.Name = "SYSREGDATE3";
            this.SYSREGDATE3.ReadOnly = true;
            this.SYSREGDATE3.Width = 102;
            // 
            // SYSREGNAME3
            // 
            this.SYSREGNAME3.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME3.HeaderText = "시스템등록자";
            this.SYSREGNAME3.Name = "SYSREGNAME3";
            this.SYSREGNAME3.ReadOnly = true;
            this.SYSREGNAME3.Width = 102;
            // 
            // SYSMODDATE3
            // 
            this.SYSMODDATE3.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE3.HeaderText = "시스템수정일";
            this.SYSMODDATE3.Name = "SYSMODDATE3";
            this.SYSMODDATE3.ReadOnly = true;
            this.SYSMODDATE3.Width = 102;
            // 
            // SYSMODNAME3
            // 
            this.SYSMODNAME3.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME3.HeaderText = "시스템수정자";
            this.SYSMODNAME3.Name = "SYSMODNAME3";
            this.SYSMODNAME3.ReadOnly = true;
            this.SYSMODNAME3.Width = 102;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this._btnDel03);
            this.panel6.Controls.Add(this._btnAdd03);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(3, 587);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(689, 41);
            this.panel6.TabIndex = 1;
            // 
            // _btnDel03
            // 
            this._btnDel03.ButtonConfirm = true;
            this._btnDel03.DelegateProperty = true;
            this._btnDel03.Enabled = false;
            this._btnDel03.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel03.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel03.Location = new System.Drawing.Point(609, 6);
            this._btnDel03.Name = "_btnDel03";
            this._btnDel03.Reserved = "      삭   제";
            this._btnDel03.Size = new System.Drawing.Size(75, 27);
            this._btnDel03.TabIndex = 1480;
            this._btnDel03.Text = "      삭   제";
            this._btnDel03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel03.UseVisualStyleBackColor = true;
            this._btnDel03.ValidationGroup = null;
            this._btnDel03.Click += new System.EventHandler(this._btnDel03_Click);
            // 
            // _btnAdd03
            // 
            this._btnAdd03.DelegateProperty = true;
            this._btnAdd03.Enabled = false;
            this._btnAdd03.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd03.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd03.Location = new System.Drawing.Point(528, 6);
            this._btnAdd03.Name = "_btnAdd03";
            this._btnAdd03.Reserved = "      추   가";
            this._btnAdd03.Size = new System.Drawing.Size(75, 27);
            this._btnAdd03.TabIndex = 1470;
            this._btnAdd03.Text = "      추   가";
            this._btnAdd03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd03.UseVisualStyleBackColor = true;
            this._btnAdd03.ValidationGroup = null;
            this._btnAdd03.Click += new System.EventHandler(this._btnAdd03_Click);
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.AnimationDelay = 20;
            this.collapsibleSplitter1.AnimationStep = 20;
            this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter1.ControlToHide = this.tabControl1;
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.collapsibleSplitter1.ExpandParentForm = false;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(473, 76);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.TabIndex = 3;
            this.collapsibleSplitter1.TabStop = false;
            this.collapsibleSplitter1.UseAnimations = false;
            this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
            // 
            // _iglDocuments
            // 
            this._iglDocuments.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("_iglDocuments.ImageStream")));
            this._iglDocuments.TransparentColor = System.Drawing.Color.Transparent;
            this._iglDocuments.Images.SetKeyName(0, "EXCEL_257.ico");
            this._iglDocuments.Images.SetKeyName(1, "POWERPNT_1300.ico");
            this._iglDocuments.Images.SetKeyName(2, "WINWORD_1.ico");
            this._iglDocuments.Images.SetKeyName(3, "Hwp_1228.ico");
            this._iglDocuments.Images.SetKeyName(4, "Acrobat_1.ico");
            this._iglDocuments.Images.SetKeyName(5, "JPG.ico");
            this._iglDocuments.Images.SetKeyName(6, "PNG.ico");
            this._iglDocuments.Images.SetKeyName(7, "GIF.ico");
            this._iglDocuments.Images.SetKeyName(8, "BMP.ico");
            // 
            // BAS0700
            // 
            this.ClientSize = new System.Drawing.Size(1184, 733);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.collapsibleSplitter1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BAS0700";
            this.Text = "대리점정보관리:BAS0700";
            this.Load += new System.EventHandler(this.BAS0700_Load);
            this.Shown += new System.EventHandler(this.BAS0700_Shown);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.TabPage tabPage6;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Label labelmemo;
		private BANANA.Windows.Controls.TextBox _txtADDR_DTL;
		private BANANA.Windows.Controls.TextBox _txtPRSNT_NM;
		private BANANA.Windows.Controls.TextBox _txtAGT_NM;
		private BANANA.Windows.Controls.Label lblCOMPANY_CD;
		private BANANA.Windows.Controls.Label lblUSR_ID;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private BANANA.Windows.Controls.Label lblUSR_PASS;
		private BANANA.Windows.Controls.Label lblUSR_ROLL;
		private BANANA.Windows.Controls.TextBox _txtAGT_CD;
		private BANANA.Windows.Controls.TextBox _txtMEMO;
		private System.Windows.Forms.Panel panel2;
		private DemoClient.Controls.BananaButton _btnFindZipCode01;
		private BANANA.Windows.Controls.TextBox _txtZIP_NO;
		private System.Windows.Forms.Label label3;
		private BANANA.Windows.Controls.TextBox _txtTELNO;
		private System.Windows.Forms.Label label4;
		private BANANA.Windows.Controls.TextBox _txtADDR_BSC;
		private BANANA.Windows.Controls.TextBox _txtFAXNO;
		private System.Windows.Forms.TabPage tabPage7;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.Panel panel3;
		private BANANA.Windows.Controls.RadioButton _rbBI_SIMTAX_Y;
		private BANANA.Windows.Controls.RadioButton _rbBI_SIMTAX_N;
		private System.Windows.Forms.Label label16;
		private BANANA.Windows.Controls.TextBox _txtBI_ADDR_BSC;
		private BANANA.Windows.Controls.TextBox _txtBI_BUBIN_NO;
		private BANANA.Windows.Controls.TextBox _txtBI_SAUP_NO;
		private BANANA.Windows.Controls.TextBox _txtBI_PRSNT_NM;
		private BANANA.Windows.Controls.Label label6;
		private BANANA.Windows.Controls.Label label7;
		private BANANA.Windows.Controls.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private BANANA.Windows.Controls.Label label12;
		private BANANA.Windows.Controls.TextBox _txtBI_COMPANY_NM;
		private System.Windows.Forms.Label label5;
		private BANANA.Windows.Controls.TextBox _txtBI_JONGMOK;
		private BANANA.Windows.Controls.TextBox _txtBI_ADDR_DTL;
		private System.Windows.Forms.Label label15;
		private BANANA.Windows.Controls.TextBox _txtBI_EMAIL;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Panel panel1;
		private DemoClient.Controls.BananaButton _btnFindZipCode02;
		private BANANA.Windows.Controls.TextBox _txtBI_ZIP_NO;
		private BANANA.Windows.Controls.ComboBox _cmbBI_BINF_CD;
		private BANANA.Windows.Controls.TextBox _txtBI_UPTE;
		private BANANA.Windows.Controls.Label label13;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
		private BANANA.Windows.Controls.TextBox _txtPI_ADDR_BSC;
		private BANANA.Windows.Controls.TextBox _txtPI_CELLNO;
		private BANANA.Windows.Controls.TextBox _txtPI_TELNO;
		private BANANA.Windows.Controls.TextBox _txtPI_CNTZ_NO;
		private BANANA.Windows.Controls.Label label18;
		private BANANA.Windows.Controls.Label label19;
		private BANANA.Windows.Controls.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private BANANA.Windows.Controls.TextBox _txtPI_PRSNT_NM;
		private System.Windows.Forms.Label label25;
		private BANANA.Windows.Controls.TextBox _txtPI_ADDR_DTL;
		private System.Windows.Forms.Panel panel5;
		private DemoClient.Controls.BananaButton _btnFindZipCode03;
		private BANANA.Windows.Controls.TextBox _txtPI_ZIP_NO;
		private System.Windows.Forms.Label label27;
		private BANANA.Windows.Controls.TextBox _txtPI_EMAIL;
		private DemoClient.Controls.BananaButton _btnSave01;
		private DemoClient.Controls.BananaButton _btnDel01;
		private DemoClient.Controls.BananaButton _btnAdd01;
		private DemoClient.Controls.BananaButton _btnSave02;
		private DemoClient.Controls.BananaButton _btnSave03;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
		private BANANA.Windows.Controls.TextBox _txtCI_ACCT_NO;
		private BANANA.Windows.Controls.Label label17;
		private BANANA.Windows.Controls.Label label24;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label32;
		private BANANA.Windows.Controls.TextBox _txtCI_ACCT_NM;
		private BANANA.Windows.Controls.ComboBox _cmbCI_BNK_CD;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_STRT_DT;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_END_DT;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
		private BANANA.Windows.Controls.Label label26;
		private BANANA.Windows.Controls.DateTimePicker _dtpMO_STRT_DT;
		private System.Windows.Forms.Label label31;
		private BANANA.Windows.Controls.TextBox _txtMO_LOGIN_ID;
		private System.Windows.Forms.Label label33;
		private BANANA.Windows.Controls.TextBox _txtMO_LOGIN_PW;
		private DemoClient.Controls.BananaButton _btnSave04;
		private DemoClient.Controls.BananaButton _btnSave05;
		private DemoClient.Controls.GridView gridView2;
		private System.Windows.Forms.Panel panel4;
		private DemoClient.Controls.BananaButton _btnDel02;
		private DemoClient.Controls.BananaButton _btnAdd02;
		private System.Windows.Forms.Panel panel6;
		private DemoClient.Controls.BananaButton _btnDel03;
		private DemoClient.Controls.BananaButton _btnAdd03;
		private System.Windows.Forms.Label label30;
		private BANANA.Windows.Controls.CheckBox _chkMO_PAUSED;
		private System.Windows.Forms.Label label34;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label37;
		private BANANA.Windows.Controls.Label label40;
		private BANANA.Windows.Controls.Label label39;
		private BANANA.Windows.Controls.Label label38;
		private BANANA.Windows.Controls.TextBox _txtAGT_NM_S;
		private BANANA.Windows.Controls.ComboBox _cmbBI_BINF_CD_S;
		private BANANA.Windows.Controls.TextBox _txtBI_SAUP_NO_S;
		private BANANA.Windows.Controls.TextBox _txtADDR_BSC_S;
		private BANANA.Windows.Controls.TextBox _txtPRSNT_NM_S;
		private BANANA.Windows.Controls.TextBox _txtAGT_CD_S;
		private System.Windows.Forms.DataGridViewTextBoxColumn AGT_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn AGT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn PRSNT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn ADDR_BSC;
		private System.Windows.Forms.DataGridViewTextBoxColumn TELNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn FAXNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn BI_COMPANY_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn BI_PRSNT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn BI_BINF_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn BI_SIMTAX_YN;
		private System.Windows.Forms.DataGridViewTextBoxColumn BI_SAUP_NO;
		private System.Windows.Forms.DataGridViewTextBoxColumn PI_PRSNT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn PI_TELNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn PI_CELLNO;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_CNTR_STRT_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_CNTR_END_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MO_LOGIN_ID;
		private System.Windows.Forms.DataGridViewTextBoxColumn MO_STRT_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MO_PAUSED;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private DemoClient.Controls.BananaButton _btnSearch;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.ImageList _iglDocuments;
		private DemoClient.Controls.GridView gridView3;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDX3;
		private System.Windows.Forms.DataGridViewTextBoxColumn CALL_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CALL_DT_STRT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CALL_DT_END;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE3;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME3;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE3;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME3;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDX2;
		private System.Windows.Forms.DataGridViewTextBoxColumn DOC_GUBUN_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn DOC_FILE_NAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn DOC_FILE_SIZE;
		private System.Windows.Forms.DataGridViewImageColumn DownLoad;
		private System.Windows.Forms.DataGridViewTextBoxColumn MEMO2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE2;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME2;
		private System.Windows.Forms.DataGridViewTextBoxColumn DOC_FILE_TYPE;
	}
}
