﻿namespace DemoClient.View.BAS
{
	partial class BAS0815
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0815));
            this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this._txtDPST_AMT_S_S = new BANANA.Windows.Controls.TextBox();
            this.label11 = new BANANA.Windows.Controls.Label();
            this._txtDPST_AMT_E_S = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this._btnExcel = new DemoClient.Controls.BananaButton();
            this._cmbDPST_CAL_CD_S = new BANANA.Windows.Controls.ComboBox();
            this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
            this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
            this.label40 = new BANANA.Windows.Controls.Label();
            this.label35 = new BANANA.Windows.Controls.Label();
            this.label39 = new BANANA.Windows.Controls.Label();
            this.label36 = new BANANA.Windows.Controls.Label();
            this.label38 = new BANANA.Windows.Controls.Label();
            this.label37 = new BANANA.Windows.Controls.Label();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this._dtpDPST_STRT_DT_S_S = new BANANA.Windows.Controls.DateTimePicker();
            this.label10 = new BANANA.Windows.Controls.Label();
            this._dtpDPST_STRT_DT_E_S = new BANANA.Windows.Controls.DateTimePicker();
            this._cmbDPST_GIJUN_CD_S = new BANANA.Windows.Controls.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new BANANA.Windows.Controls.GroupBox();
            this.gridView2 = new DemoClient.Controls.GridView();
            this.IDX2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EXCPT_DT_STRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EXCPT_DT_END = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MEMO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._btnSave01 = new DemoClient.Controls.BananaButton();
            this._btnDel01 = new DemoClient.Controls.BananaButton();
            this._btnAdd01 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this._txtDPST_AMT = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this._txtDPST_PER = new BANANA.Windows.Controls.TextBox();
            this._lblDPST_CAL_CD = new BANANA.Windows.Controls.Label();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this._rbDPST_INTST_Y = new BANANA.Windows.Controls.RadioButton();
            this._rbDPST_INTST_N = new BANANA.Windows.Controls.RadioButton();
            this._cmbDPST_CAL_CD = new BANANA.Windows.Controls.ComboBox();
            this._cmbDPST_GIJUN_CD = new BANANA.Windows.Controls.ComboBox();
            this.label5 = new BANANA.Windows.Controls.Label();
            this.label3 = new BANANA.Windows.Controls.Label();
            this.label2 = new BANANA.Windows.Controls.Label();
            this._txtSTR_NM = new BANANA.Windows.Controls.TextBox();
            this._txtSTR_CD = new BANANA.Windows.Controls.TextBox();
            this.label1 = new BANANA.Windows.Controls.Label();
            this.label4 = new BANANA.Windows.Controls.Label();
            this.label6 = new BANANA.Windows.Controls.Label();
            this.label7 = new BANANA.Windows.Controls.Label();
            this.label8 = new BANANA.Windows.Controls.Label();
            this.label9 = new BANANA.Windows.Controls.Label();
            this._dtpDPST_STRT_DT = new BANANA.Windows.Controls.DateTimePicker();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this._rbDPST_USE_Y = new BANANA.Windows.Controls.RadioButton();
            this._rbDPST_USE_N = new BANANA.Windows.Controls.RadioButton();
            this.collapsibleSplitter2 = new DemoClient.Controls.CollapsibleSplitter();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.gridView1 = new DemoClient.Controls.GridView();
            this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_USE_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_GIJUN_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_CAL_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_INTST_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_PER = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DPST_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.AnimationDelay = 20;
            this.collapsibleSplitter1.AnimationStep = 20;
            this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter1.ControlToHide = null;
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.collapsibleSplitter1.ExpandParentForm = false;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(1104, 0);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.TabIndex = 11;
            this.collapsibleSplitter1.TabStop = false;
            this.collapsibleSplitter1.UseAnimations = false;
            this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel6);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1104, 76);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "검색 조건";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel6.ColumnCount = 7;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 260F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel6, 5, 1);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 6, 0);
            this.tableLayoutPanel6.Controls.Add(this._cmbDPST_CAL_CD_S, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label40, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label39, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.label38, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel5, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this._cmbDPST_GIJUN_CD_S, 1, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1098, 56);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this._txtDPST_AMT_S_S);
            this.flowLayoutPanel6.Controls.Add(this.label11);
            this.flowLayoutPanel6.Controls.Add(this._txtDPST_AMT_E_S);
            this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(536, 29);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(260, 27);
            this.flowLayoutPanel6.TabIndex = 150;
            // 
            // _txtDPST_AMT_S_S
            // 
            this._txtDPST_AMT_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtDPST_AMT_S_S.DelegateProperty = true;
            this._txtDPST_AMT_S_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtDPST_AMT_S_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtDPST_AMT_S_S.Location = new System.Drawing.Point(3, 3);
            this._txtDPST_AMT_S_S.Name = "_txtDPST_AMT_S_S";
            this._txtDPST_AMT_S_S.Size = new System.Drawing.Size(110, 20);
            this._txtDPST_AMT_S_S.TabIndex = 10;
            this._txtDPST_AMT_S_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtDPST_AMT_S_S.ValidationGroup = "A";
            this._txtDPST_AMT_S_S.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtDPST_AMT_S_S.WaterMarkText = "";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(119, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 12);
            this.label11.TabIndex = 1116;
            this.label11.Text = "~";
            // 
            // _txtDPST_AMT_E_S
            // 
            this._txtDPST_AMT_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtDPST_AMT_E_S.DelegateProperty = true;
            this._txtDPST_AMT_E_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtDPST_AMT_E_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtDPST_AMT_E_S.Location = new System.Drawing.Point(139, 3);
            this._txtDPST_AMT_E_S.Name = "_txtDPST_AMT_E_S";
            this._txtDPST_AMT_E_S.Size = new System.Drawing.Size(110, 20);
            this._txtDPST_AMT_E_S.TabIndex = 20;
            this._txtDPST_AMT_E_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtDPST_AMT_E_S.ValidationGroup = "A";
            this._txtDPST_AMT_E_S.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtDPST_AMT_E_S.WaterMarkText = "";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this._btnSearch);
            this.flowLayoutPanel2.Controls.Add(this._btnExcel);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(797, 1);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(243, 27);
            this.flowLayoutPanel2.TabIndex = 160;
            // 
            // _btnSearch
            // 
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(0, 2);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Size = new System.Drawing.Size(75, 23);
            this._btnSearch.TabIndex = 10;
            this._btnSearch.Text = "      검   색";
            this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            // 
            // _btnExcel
            // 
            this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnExcel.DelegateProperty = true;
            this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
            this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.Location = new System.Drawing.Point(75, 2);
            this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
            this._btnExcel.Name = "_btnExcel";
            this._btnExcel.Size = new System.Drawing.Size(75, 23);
            this._btnExcel.TabIndex = 20;
            this._btnExcel.Text = "      엑   셀";
            this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.UseVisualStyleBackColor = true;
            this._btnExcel.ValidationGroup = null;
            // 
            // _cmbDPST_CAL_CD_S
            // 
            this._cmbDPST_CAL_CD_S.DataSource = null;
            this._cmbDPST_CAL_CD_S.DelegateProperty = true;
            this._cmbDPST_CAL_CD_S.Location = new System.Drawing.Point(317, 32);
            this._cmbDPST_CAL_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbDPST_CAL_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbDPST_CAL_CD_S.Name = "_cmbDPST_CAL_CD_S";
            this._cmbDPST_CAL_CD_S.SelectedIndex = -1;
            this._cmbDPST_CAL_CD_S.SelectedItem = null;
            this._cmbDPST_CAL_CD_S.SelectedValue = null;
            this._cmbDPST_CAL_CD_S.Size = new System.Drawing.Size(124, 21);
            this._cmbDPST_CAL_CD_S.TabIndex = 140;
            this._cmbDPST_CAL_CD_S.ValidationGroup = null;
            // 
            // _txtSTR_CD_S
            // 
            this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_CD_S.AutoTab = false;
            this._txtSTR_CD_S.DelegateProperty = true;
            this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_CD_S.Location = new System.Drawing.Point(317, 4);
            this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
            this._txtSTR_CD_S.Size = new System.Drawing.Size(124, 20);
            this._txtSTR_CD_S.TabIndex = 110;
            this._txtSTR_CD_S.ValidationGroup = null;
            this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSTR_CD_S.WaterMarkText = "";
            // 
            // _txtSTR_NM_S
            // 
            this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_NM_S.AutoTab = false;
            this._txtSTR_NM_S.DelegateProperty = true;
            this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 4);
            this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
            this._txtSTR_NM_S.Size = new System.Drawing.Size(124, 20);
            this._txtSTR_NM_S.TabIndex = 100;
            this._txtSTR_NM_S.ValidationGroup = null;
            this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSTR_NM_S.WaterMarkText = "";
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(455, 36);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 12);
            this.label40.TabIndex = 1119;
            this.label40.Text = "보증한도금액";
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(35, 8);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 1114;
            this.label35.Text = "가맹점명";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(257, 36);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 12);
            this.label39.TabIndex = 1118;
            this.label39.Text = "계산방법";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(245, 8);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(65, 12);
            this.label36.TabIndex = 1115;
            this.label36.Text = "가맹점코드";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(35, 36);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(53, 12);
            this.label38.TabIndex = 1117;
            this.label38.Text = "차감기준";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(467, 8);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 12);
            this.label37.TabIndex = 1116;
            this.label37.Text = "적용시작일";
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Controls.Add(this._dtpDPST_STRT_DT_S_S);
            this.flowLayoutPanel5.Controls.Add(this.label10);
            this.flowLayoutPanel5.Controls.Add(this._dtpDPST_STRT_DT_E_S);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(536, 1);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(260, 27);
            this.flowLayoutPanel5.TabIndex = 120;
            // 
            // _dtpDPST_STRT_DT_S_S
            // 
            this._dtpDPST_STRT_DT_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpDPST_STRT_DT_S_S.Checked = false;
            this._dtpDPST_STRT_DT_S_S.CustomFormat = "yyyy-MM-dd";
            this._dtpDPST_STRT_DT_S_S.DelegateProperty = true;
            this._dtpDPST_STRT_DT_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpDPST_STRT_DT_S_S.Location = new System.Drawing.Point(3, 3);
            this._dtpDPST_STRT_DT_S_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpDPST_STRT_DT_S_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpDPST_STRT_DT_S_S.Name = "_dtpDPST_STRT_DT_S_S";
            this._dtpDPST_STRT_DT_S_S.ShowCheckBox = true;
            this._dtpDPST_STRT_DT_S_S.Size = new System.Drawing.Size(110, 21);
            this._dtpDPST_STRT_DT_S_S.TabIndex = 10;
            this._dtpDPST_STRT_DT_S_S.ValidationGroup = "A";
            this._dtpDPST_STRT_DT_S_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(119, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 12);
            this.label10.TabIndex = 1115;
            this.label10.Text = "~";
            // 
            // _dtpDPST_STRT_DT_E_S
            // 
            this._dtpDPST_STRT_DT_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpDPST_STRT_DT_E_S.Checked = false;
            this._dtpDPST_STRT_DT_E_S.CustomFormat = "yyyy-MM-dd";
            this._dtpDPST_STRT_DT_E_S.DelegateProperty = true;
            this._dtpDPST_STRT_DT_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpDPST_STRT_DT_E_S.Location = new System.Drawing.Point(139, 3);
            this._dtpDPST_STRT_DT_E_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpDPST_STRT_DT_E_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpDPST_STRT_DT_E_S.Name = "_dtpDPST_STRT_DT_E_S";
            this._dtpDPST_STRT_DT_E_S.ShowCheckBox = true;
            this._dtpDPST_STRT_DT_E_S.Size = new System.Drawing.Size(110, 21);
            this._dtpDPST_STRT_DT_E_S.TabIndex = 20;
            this._dtpDPST_STRT_DT_E_S.ValidationGroup = "A";
            this._dtpDPST_STRT_DT_E_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // _cmbDPST_GIJUN_CD_S
            // 
            this._cmbDPST_GIJUN_CD_S.DataSource = null;
            this._cmbDPST_GIJUN_CD_S.DelegateProperty = true;
            this._cmbDPST_GIJUN_CD_S.Location = new System.Drawing.Point(95, 32);
            this._cmbDPST_GIJUN_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbDPST_GIJUN_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbDPST_GIJUN_CD_S.Name = "_cmbDPST_GIJUN_CD_S";
            this._cmbDPST_GIJUN_CD_S.SelectedIndex = -1;
            this._cmbDPST_GIJUN_CD_S.SelectedItem = null;
            this._cmbDPST_GIJUN_CD_S.SelectedValue = null;
            this._cmbDPST_GIJUN_CD_S.Size = new System.Drawing.Size(124, 21);
            this._cmbDPST_GIJUN_CD_S.TabIndex = 130;
            this._cmbDPST_GIJUN_CD_S.ValidationGroup = null;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this._btnSave01);
            this.groupBox2.Controls.Add(this._btnDel01);
            this.groupBox2.Controls.Add(this._btnAdd01);
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.Location = new System.Drawing.Point(636, 76);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(468, 618);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "상세 정보";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.gridView2);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox4.Location = new System.Drawing.Point(-3, 152);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(468, 463);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "예외기간";
            // 
            // gridView2
            // 
            this.gridView2.AllowUserToAddRows = false;
            this.gridView2.AutoSelectRowWithRightButton = false;
            this.gridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridView2.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX2,
            this.EXCPT_DT_STRT,
            this.EXCPT_DT_END,
            this.MEMO,
            this.SYSREGDATE2,
            this.SYSREGNAME2,
            this.SYSMODDATE2,
            this.SYSMODNAME2});
            this.gridView2.DelegateProperty = true;
            this.gridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridView2.Location = new System.Drawing.Point(3, 17);
            this.gridView2.Name = "gridView2";
            this.gridView2.ReadOnly = true;
            this.gridView2.RowTemplate.Height = 23;
            this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView2.Size = new System.Drawing.Size(462, 443);
            this.gridView2.TabIndex = 1;
            this.gridView2.ShowHeaderCheckBox = false;
            // 
            // IDX2
            // 
            this.IDX2.DataPropertyName = "IDX";
            this.IDX2.HeaderText = "일련번호";
            this.IDX2.Name = "IDX2";
            this.IDX2.ReadOnly = true;
            this.IDX2.Width = 78;
            // 
            // EXCPT_DT_STRT
            // 
            this.EXCPT_DT_STRT.DataPropertyName = "EXCPT_DT_STRT";
            this.EXCPT_DT_STRT.HeaderText = "예외시작일";
            this.EXCPT_DT_STRT.Name = "EXCPT_DT_STRT";
            this.EXCPT_DT_STRT.ReadOnly = true;
            this.EXCPT_DT_STRT.Width = 90;
            // 
            // EXCPT_DT_END
            // 
            this.EXCPT_DT_END.DataPropertyName = "EXCPT_DT_END";
            this.EXCPT_DT_END.HeaderText = "예외종료일";
            this.EXCPT_DT_END.Name = "EXCPT_DT_END";
            this.EXCPT_DT_END.ReadOnly = true;
            this.EXCPT_DT_END.Width = 90;
            // 
            // MEMO
            // 
            this.MEMO.DataPropertyName = "MEMO";
            this.MEMO.HeaderText = "메모";
            this.MEMO.Name = "MEMO";
            this.MEMO.ReadOnly = true;
            this.MEMO.Width = 54;
            // 
            // SYSREGDATE2
            // 
            this.SYSREGDATE2.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE2.HeaderText = "시스템등록일";
            this.SYSREGDATE2.Name = "SYSREGDATE2";
            this.SYSREGDATE2.ReadOnly = true;
            this.SYSREGDATE2.Width = 102;
            // 
            // SYSREGNAME2
            // 
            this.SYSREGNAME2.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME2.HeaderText = "시스템등록자";
            this.SYSREGNAME2.Name = "SYSREGNAME2";
            this.SYSREGNAME2.ReadOnly = true;
            this.SYSREGNAME2.Width = 102;
            // 
            // SYSMODDATE2
            // 
            this.SYSMODDATE2.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE2.HeaderText = "시스템수정일";
            this.SYSMODDATE2.Name = "SYSMODDATE2";
            this.SYSMODDATE2.ReadOnly = true;
            this.SYSMODDATE2.Width = 102;
            // 
            // SYSMODNAME2
            // 
            this.SYSMODNAME2.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME2.HeaderText = "시스템수정자";
            this.SYSMODNAME2.Name = "SYSMODNAME2";
            this.SYSMODNAME2.ReadOnly = true;
            this.SYSMODNAME2.Width = 102;
            // 
            // _btnSave01
            // 
            this._btnSave01.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._btnSave01.ButtonConfirm = true;
            this._btnSave01.DelegateProperty = true;
            this._btnSave01.Enabled = false;
            this._btnSave01.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave01.Location = new System.Drawing.Point(300, 157);
            this._btnSave01.Name = "_btnSave01";
            this._btnSave01.Size = new System.Drawing.Size(75, 27);
            this._btnSave01.TabIndex = 1100;
            this._btnSave01.Text = "      저   장";
            this._btnSave01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave01.UseVisualStyleBackColor = true;
            this._btnSave01.ValidationGroup = "A";
            // 
            // _btnDel01
            // 
            this._btnDel01.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._btnDel01.ButtonConfirm = true;
            this._btnDel01.DelegateProperty = true;
            this._btnDel01.Enabled = false;
            this._btnDel01.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel01.Location = new System.Drawing.Point(381, 157);
            this._btnDel01.Name = "_btnDel01";
            this._btnDel01.Size = new System.Drawing.Size(75, 27);
            this._btnDel01.TabIndex = 1110;
            this._btnDel01.Text = "      삭   제";
            this._btnDel01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel01.UseVisualStyleBackColor = true;
            this._btnDel01.ValidationGroup = null;
            // 
            // _btnAdd01
            // 
            this._btnAdd01.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._btnAdd01.DelegateProperty = true;
            this._btnAdd01.Enabled = false;
            this._btnAdd01.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.Location = new System.Drawing.Point(219, 157);
            this._btnAdd01.Name = "_btnAdd01";
            this._btnAdd01.Size = new System.Drawing.Size(75, 27);
            this._btnAdd01.TabIndex = 1090;
            this._btnAdd01.Text = "      추   가";
            this._btnAdd01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.UseVisualStyleBackColor = true;
            this._btnAdd01.ValidationGroup = null;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.Controls.Add(this._txtDPST_AMT, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel4, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this._cmbDPST_CAL_CD, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this._cmbDPST_GIJUN_CD, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this._txtSTR_NM, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this._txtSTR_CD, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this._dtpDPST_STRT_DT, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 3, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(462, 135);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // _txtDPST_AMT
            // 
            this._txtDPST_AMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtDPST_AMT.Compulsory = true;
            this._txtDPST_AMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtDPST_AMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtDPST_AMT.Location = new System.Drawing.Point(93, 111);
            this._txtDPST_AMT.Name = "_txtDPST_AMT";
            this._txtDPST_AMT.Size = new System.Drawing.Size(130, 20);
            this._txtDPST_AMT.TabIndex = 1080;
            this._txtDPST_AMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtDPST_AMT.ValidationGroup = "A";
            this._txtDPST_AMT.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtDPST_AMT.WaterMarkText = "";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this._txtDPST_PER);
            this.flowLayoutPanel4.Controls.Add(this._lblDPST_CAL_CD);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(320, 81);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(142, 27);
            this.flowLayoutPanel4.TabIndex = 1070;
            // 
            // _txtDPST_PER
            // 
            this._txtDPST_PER.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtDPST_PER.Compulsory = true;
            this._txtDPST_PER.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtDPST_PER.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
            this._txtDPST_PER.Location = new System.Drawing.Point(3, 3);
            this._txtDPST_PER.Name = "_txtDPST_PER";
            this._txtDPST_PER.Size = new System.Drawing.Size(100, 20);
            this._txtDPST_PER.TabIndex = 1030;
            this._txtDPST_PER.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtDPST_PER.ValidationGroup = "A";
            this._txtDPST_PER.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtDPST_PER.WaterMarkText = "";
            // 
            // _lblDPST_CAL_CD
            // 
            this._lblDPST_CAL_CD.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this._lblDPST_CAL_CD.AutoSize = true;
            this._lblDPST_CAL_CD.Location = new System.Drawing.Point(109, 7);
            this._lblDPST_CAL_CD.Name = "_lblDPST_CAL_CD";
            this._lblDPST_CAL_CD.Size = new System.Drawing.Size(17, 12);
            this._lblDPST_CAL_CD.TabIndex = 1119;
            this._lblDPST_CAL_CD.Text = "원";
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this._rbDPST_INTST_Y);
            this.flowLayoutPanel3.Controls.Add(this._rbDPST_INTST_N);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(90, 81);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(140, 27);
            this.flowLayoutPanel3.TabIndex = 1060;
            // 
            // _rbDPST_INTST_Y
            // 
            this._rbDPST_INTST_Y.AutoSize = true;
            this._rbDPST_INTST_Y.Checked = true;
            this._rbDPST_INTST_Y.Location = new System.Drawing.Point(3, 3);
            this._rbDPST_INTST_Y.Name = "_rbDPST_INTST_Y";
            this._rbDPST_INTST_Y.Size = new System.Drawing.Size(31, 16);
            this._rbDPST_INTST_Y.TabIndex = 10;
            this._rbDPST_INTST_Y.TabStop = true;
            this._rbDPST_INTST_Y.Text = "Y";
            this._rbDPST_INTST_Y.UseVisualStyleBackColor = true;
            // 
            // _rbDPST_INTST_N
            // 
            this._rbDPST_INTST_N.AutoSize = true;
            this._rbDPST_INTST_N.Location = new System.Drawing.Point(40, 3);
            this._rbDPST_INTST_N.Name = "_rbDPST_INTST_N";
            this._rbDPST_INTST_N.Size = new System.Drawing.Size(32, 16);
            this._rbDPST_INTST_N.TabIndex = 20;
            this._rbDPST_INTST_N.Text = "N";
            this._rbDPST_INTST_N.UseVisualStyleBackColor = true;
            // 
            // _cmbDPST_CAL_CD
            // 
            this._cmbDPST_CAL_CD.DataSource = null;
            this._cmbDPST_CAL_CD.DelegateProperty = true;
            this._cmbDPST_CAL_CD.Location = new System.Drawing.Point(323, 57);
            this._cmbDPST_CAL_CD.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbDPST_CAL_CD.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbDPST_CAL_CD.Name = "_cmbDPST_CAL_CD";
            this._cmbDPST_CAL_CD.SelectedIndex = -1;
            this._cmbDPST_CAL_CD.SelectedItem = null;
            this._cmbDPST_CAL_CD.SelectedValue = null;
            this._cmbDPST_CAL_CD.Size = new System.Drawing.Size(130, 21);
            this._cmbDPST_CAL_CD.TabIndex = 1050;
            this._cmbDPST_CAL_CD.ValidationGroup = null;
            // 
            // _cmbDPST_GIJUN_CD
            // 
            this._cmbDPST_GIJUN_CD.DataSource = null;
            this._cmbDPST_GIJUN_CD.DelegateProperty = true;
            this._cmbDPST_GIJUN_CD.Enabled = false;
            this._cmbDPST_GIJUN_CD.Location = new System.Drawing.Point(93, 57);
            this._cmbDPST_GIJUN_CD.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbDPST_GIJUN_CD.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbDPST_GIJUN_CD.Name = "_cmbDPST_GIJUN_CD";
            this._cmbDPST_GIJUN_CD.SelectedIndex = -1;
            this._cmbDPST_GIJUN_CD.SelectedItem = null;
            this._cmbDPST_GIJUN_CD.SelectedValue = null;
            this._cmbDPST_GIJUN_CD.Size = new System.Drawing.Size(130, 21);
            this._cmbDPST_GIJUN_CD.TabIndex = 1040;
            this._cmbDPST_GIJUN_CD.ValidationGroup = null;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 1118;
            this.label5.Text = "차감기준";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 1117;
            this.label3.Text = "적용시작일";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1116;
            this.label2.Text = "가맹점명";
            // 
            // _txtSTR_NM
            // 
            this._txtSTR_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_NM.Location = new System.Drawing.Point(323, 3);
            this._txtSTR_NM.Name = "_txtSTR_NM";
            this._txtSTR_NM.ReadOnly = true;
            this._txtSTR_NM.Size = new System.Drawing.Size(130, 20);
            this._txtSTR_NM.TabIndex = 1010;
            this._txtSTR_NM.ValidationGroup = null;
            this._txtSTR_NM.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtSTR_NM.WaterMarkText = "";
            // 
            // _txtSTR_CD
            // 
            this._txtSTR_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_CD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_CD.Location = new System.Drawing.Point(93, 3);
            this._txtSTR_CD.Name = "_txtSTR_CD";
            this._txtSTR_CD.ReadOnly = true;
            this._txtSTR_CD.Size = new System.Drawing.Size(130, 20);
            this._txtSTR_CD.TabIndex = 1000;
            this._txtSTR_CD.ValidationGroup = null;
            this._txtSTR_CD.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtSTR_CD.WaterMarkText = "";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 1115;
            this.label1.Text = "가맹점코드";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(264, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 1118;
            this.label4.Text = "사용여부";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(264, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 1119;
            this.label6.Text = "계산방법";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 1120;
            this.label7.Text = "미차감이자";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(264, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 1121;
            this.label8.Text = "차감수치";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 1122;
            this.label9.Text = "보증한도금액";
            // 
            // _dtpDPST_STRT_DT
            // 
            this._dtpDPST_STRT_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpDPST_STRT_DT.Checked = false;
            this._dtpDPST_STRT_DT.Compulsory = true;
            this._dtpDPST_STRT_DT.CustomFormat = "yyyy-MM-dd";
            this._dtpDPST_STRT_DT.DelegateProperty = true;
            this._dtpDPST_STRT_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpDPST_STRT_DT.Location = new System.Drawing.Point(93, 30);
            this._dtpDPST_STRT_DT.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpDPST_STRT_DT.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpDPST_STRT_DT.Name = "_dtpDPST_STRT_DT";
            this._dtpDPST_STRT_DT.ShowCheckBox = true;
            this._dtpDPST_STRT_DT.Size = new System.Drawing.Size(130, 21);
            this._dtpDPST_STRT_DT.TabIndex = 1020;
            this._dtpDPST_STRT_DT.ValidationGroup = "A";
            this._dtpDPST_STRT_DT.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this._rbDPST_USE_Y);
            this.flowLayoutPanel1.Controls.Add(this._rbDPST_USE_N);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(320, 27);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(142, 27);
            this.flowLayoutPanel1.TabIndex = 1030;
            // 
            // _rbDPST_USE_Y
            // 
            this._rbDPST_USE_Y.AutoSize = true;
            this._rbDPST_USE_Y.Checked = true;
            this._rbDPST_USE_Y.Location = new System.Drawing.Point(3, 3);
            this._rbDPST_USE_Y.Name = "_rbDPST_USE_Y";
            this._rbDPST_USE_Y.Size = new System.Drawing.Size(31, 16);
            this._rbDPST_USE_Y.TabIndex = 10;
            this._rbDPST_USE_Y.TabStop = true;
            this._rbDPST_USE_Y.Text = "Y";
            this._rbDPST_USE_Y.UseVisualStyleBackColor = true;
            // 
            // _rbDPST_USE_N
            // 
            this._rbDPST_USE_N.AutoSize = true;
            this._rbDPST_USE_N.Location = new System.Drawing.Point(40, 3);
            this._rbDPST_USE_N.Name = "_rbDPST_USE_N";
            this._rbDPST_USE_N.Size = new System.Drawing.Size(32, 16);
            this._rbDPST_USE_N.TabIndex = 20;
            this._rbDPST_USE_N.Text = "N";
            this._rbDPST_USE_N.UseVisualStyleBackColor = true;
            // 
            // collapsibleSplitter2
            // 
            this.collapsibleSplitter2.AnimationDelay = 20;
            this.collapsibleSplitter2.AnimationStep = 20;
            this.collapsibleSplitter2.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter2.ControlToHide = null;
            this.collapsibleSplitter2.Dock = System.Windows.Forms.DockStyle.Right;
            this.collapsibleSplitter2.ExpandParentForm = false;
            this.collapsibleSplitter2.Location = new System.Drawing.Point(628, 76);
            this.collapsibleSplitter2.Name = "collapsibleSplitter1";
            this.collapsibleSplitter2.TabIndex = 14;
            this.collapsibleSplitter2.TabStop = false;
            this.collapsibleSplitter2.UseAnimations = false;
            this.collapsibleSplitter2.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.gridView1);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 76);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(628, 618);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "검색 결과";
            // 
            // gridView1
            // 
            this.gridView1.AllowUserToAddRows = false;
            this.gridView1.AutoSelectRowWithRightButton = false;
            this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STR_CD,
            this.STR_NM,
            this.DPST_STRT_DT,
            this.DPST_USE_YN,
            this.DPST_GIJUN_NM,
            this.DPST_CAL_NM,
            this.DPST_INTST_YN,
            this.DPST_PER,
            this.DPST_AMT,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME});
            this.gridView1.DelegateProperty = true;
            this.gridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridView1.Location = new System.Drawing.Point(3, 17);
            this.gridView1.Name = "gridView1";
            this.gridView1.ReadOnly = true;
            this.gridView1.RowTemplate.Height = 23;
            this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView1.Size = new System.Drawing.Size(622, 598);
            this.gridView1.TabIndex = 0;
            this.gridView1.ShowHeaderCheckBox = false;
            // 
            // STR_CD
            // 
            this.STR_CD.DataPropertyName = "STR_CD";
            this.STR_CD.HeaderText = "가맹점코드";
            this.STR_CD.Name = "STR_CD";
            this.STR_CD.ReadOnly = true;
            this.STR_CD.Width = 90;
            // 
            // STR_NM
            // 
            this.STR_NM.DataPropertyName = "STR_NM";
            this.STR_NM.HeaderText = "가맹점명";
            this.STR_NM.Name = "STR_NM";
            this.STR_NM.ReadOnly = true;
            this.STR_NM.Width = 78;
            // 
            // DPST_STRT_DT
            // 
            this.DPST_STRT_DT.DataPropertyName = "DPST_STRT_DT";
            this.DPST_STRT_DT.HeaderText = "적용시작일";
            this.DPST_STRT_DT.Name = "DPST_STRT_DT";
            this.DPST_STRT_DT.ReadOnly = true;
            this.DPST_STRT_DT.Width = 90;
            // 
            // DPST_USE_YN
            // 
            this.DPST_USE_YN.DataPropertyName = "DPST_USE_YN";
            this.DPST_USE_YN.HeaderText = "사용여부";
            this.DPST_USE_YN.Name = "DPST_USE_YN";
            this.DPST_USE_YN.ReadOnly = true;
            this.DPST_USE_YN.Width = 78;
            // 
            // DPST_GIJUN_NM
            // 
            this.DPST_GIJUN_NM.DataPropertyName = "DPST_GIJUN_NM";
            this.DPST_GIJUN_NM.HeaderText = "차감기준";
            this.DPST_GIJUN_NM.Name = "DPST_GIJUN_NM";
            this.DPST_GIJUN_NM.ReadOnly = true;
            this.DPST_GIJUN_NM.Width = 78;
            // 
            // DPST_CAL_NM
            // 
            this.DPST_CAL_NM.DataPropertyName = "DPST_CAL_NM";
            this.DPST_CAL_NM.HeaderText = "계산방법";
            this.DPST_CAL_NM.Name = "DPST_CAL_NM";
            this.DPST_CAL_NM.ReadOnly = true;
            this.DPST_CAL_NM.Width = 78;
            // 
            // DPST_INTST_YN
            // 
            this.DPST_INTST_YN.DataPropertyName = "DPST_INTST_YN";
            this.DPST_INTST_YN.HeaderText = "미차감이자";
            this.DPST_INTST_YN.Name = "DPST_INTST_YN";
            this.DPST_INTST_YN.ReadOnly = true;
            this.DPST_INTST_YN.Width = 90;
            // 
            // DPST_PER
            // 
            this.DPST_PER.DataPropertyName = "DPST_PER";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.DPST_PER.DefaultCellStyle = dataGridViewCellStyle3;
            this.DPST_PER.HeaderText = "차감수치";
            this.DPST_PER.Name = "DPST_PER";
            this.DPST_PER.ReadOnly = true;
            this.DPST_PER.Width = 78;
            // 
            // DPST_AMT
            // 
            this.DPST_AMT.DataPropertyName = "DPST_AMT";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.DPST_AMT.DefaultCellStyle = dataGridViewCellStyle4;
            this.DPST_AMT.HeaderText = "보증한도금액";
            this.DPST_AMT.Name = "DPST_AMT";
            this.DPST_AMT.ReadOnly = true;
            this.DPST_AMT.Width = 102;
            // 
            // SYSREGDATE
            // 
            this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE.HeaderText = "시스템등록일";
            this.SYSREGDATE.Name = "SYSREGDATE";
            this.SYSREGDATE.ReadOnly = true;
            this.SYSREGDATE.Width = 102;
            // 
            // SYSREGNAME
            // 
            this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME.HeaderText = "시스템등록자";
            this.SYSREGNAME.Name = "SYSREGNAME";
            this.SYSREGNAME.ReadOnly = true;
            this.SYSREGNAME.Width = 102;
            // 
            // SYSMODDATE
            // 
            this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE.HeaderText = "시스템수정일";
            this.SYSMODDATE.Name = "SYSMODDATE";
            this.SYSMODDATE.ReadOnly = true;
            this.SYSMODDATE.Width = 102;
            // 
            // SYSMODNAME
            // 
            this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME.HeaderText = "시스템수정자";
            this.SYSMODNAME.Name = "SYSMODNAME";
            this.SYSMODNAME.ReadOnly = true;
            this.SYSMODNAME.Width = 102;
            // 
            // BAS0815
            // 
            this.ClientSize = new System.Drawing.Size(1112, 694);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.collapsibleSplitter2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.collapsibleSplitter1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BAS0815";
            this.Text = "가맹점.보증보험관리:BAS0815";
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel6.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

        private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
        private System.Windows.Forms.GroupBox groupBox1;
        private Controls.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private BANANA.Windows.Controls.TextBox _txtDPST_AMT_S_S;
        private BANANA.Windows.Controls.Label label11;
        private BANANA.Windows.Controls.TextBox _txtDPST_AMT_E_S;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private DemoClient.Controls.BananaButton _btnSearch;
        private DemoClient.Controls.BananaButton _btnExcel;
        private BANANA.Windows.Controls.ComboBox _cmbDPST_CAL_CD_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private BANANA.Windows.Controls.Label label40;
        private BANANA.Windows.Controls.Label label35;
        private BANANA.Windows.Controls.Label label39;
        private BANANA.Windows.Controls.Label label36;
        private BANANA.Windows.Controls.Label label38;
        private BANANA.Windows.Controls.Label label37;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private BANANA.Windows.Controls.DateTimePicker _dtpDPST_STRT_DT_S_S;
        private BANANA.Windows.Controls.Label label10;
        private BANANA.Windows.Controls.DateTimePicker _dtpDPST_STRT_DT_E_S;
        private BANANA.Windows.Controls.ComboBox _cmbDPST_GIJUN_CD_S;
        private System.Windows.Forms.GroupBox groupBox2;
        private BANANA.Windows.Controls.GroupBox groupBox4;
        private DemoClient.Controls.GridView gridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDX2;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXCPT_DT_STRT;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXCPT_DT_END;
        private System.Windows.Forms.DataGridViewTextBoxColumn MEMO;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME2;
        private DemoClient.Controls.BananaButton _btnSave01;
        private DemoClient.Controls.BananaButton _btnDel01;
        private DemoClient.Controls.BananaButton _btnAdd01;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private BANANA.Windows.Controls.TextBox _txtDPST_AMT;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private BANANA.Windows.Controls.TextBox _txtDPST_PER;
        private BANANA.Windows.Controls.Label _lblDPST_CAL_CD;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private BANANA.Windows.Controls.RadioButton _rbDPST_INTST_Y;
        private BANANA.Windows.Controls.RadioButton _rbDPST_INTST_N;
        private BANANA.Windows.Controls.ComboBox _cmbDPST_CAL_CD;
        private BANANA.Windows.Controls.ComboBox _cmbDPST_GIJUN_CD;
        private BANANA.Windows.Controls.Label label5;
        private BANANA.Windows.Controls.Label label3;
        private BANANA.Windows.Controls.Label label2;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM;
        private BANANA.Windows.Controls.TextBox _txtSTR_CD;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.Label label4;
        private BANANA.Windows.Controls.Label label6;
        private BANANA.Windows.Controls.Label label7;
        private BANANA.Windows.Controls.Label label8;
        private BANANA.Windows.Controls.Label label9;
        private BANANA.Windows.Controls.DateTimePicker _dtpDPST_STRT_DT;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.RadioButton _rbDPST_USE_Y;
        private BANANA.Windows.Controls.RadioButton _rbDPST_USE_N;
        private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter2;
        private System.Windows.Forms.GroupBox groupBox5;
        private DemoClient.Controls.GridView gridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_STRT_DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_USE_YN;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_GIJUN_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_CAL_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_INTST_YN;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_PER;
        private System.Windows.Forms.DataGridViewTextBoxColumn DPST_AMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
	}
}
