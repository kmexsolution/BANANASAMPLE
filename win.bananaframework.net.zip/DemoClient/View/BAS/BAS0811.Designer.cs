﻿namespace DemoClient.View.BAS
{
	partial class BAS0811
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0811));
			this.groupBox1 = new BANANA.Windows.Controls.GroupBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.label14 = new System.Windows.Forms.Label();
			this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_FR = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_FR = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_KB = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_KB = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_HD = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_HD = new BANANA.Windows.Controls.RadioButton();
			this._txtBY_DAYS_BC = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_SH = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_HD = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_KB = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_LT = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_SS = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_SH = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_LT = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_SS = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_LT = new BANANA.Windows.Controls.TextBox();
			this.label13 = new BANANA.Windows.Controls.Label();
			this.lblUSR_ID = new BANANA.Windows.Controls.Label();
			this.label3 = new BANANA.Windows.Controls.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new BANANA.Windows.Controls.Label();
			this.label10 = new BANANA.Windows.Controls.Label();
			this.label11 = new BANANA.Windows.Controls.Label();
			this.label12 = new BANANA.Windows.Controls.Label();
			this._txtFEE_CHK_BC = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_SS = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_SH = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_HD = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_KB = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_SK = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_NH = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CHK_FR = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_BC = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_HD = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_SH = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_KB = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_SK = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_NH = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_CRD_FR = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_BC = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_HD = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_KB = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_SK = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_NH = new BANANA.Windows.Controls.TextBox();
			this._txtFEE_OVR_FR = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_LT = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_SS = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_SK = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_NH = new BANANA.Windows.Controls.TextBox();
			this._txtBY_DAYS_FR = new BANANA.Windows.Controls.TextBox();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_SS = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_SS = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_BC = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_BC = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_LT = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_LT = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_SH = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_SH = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_SK = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_SK = new BANANA.Windows.Controls.RadioButton();
			this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbBY_USE_Y_NH = new BANANA.Windows.Controls.RadioButton();
			this._rbBY_USE_N_NH = new BANANA.Windows.Controls.RadioButton();
			this._txtMEMO = new BANANA.Windows.Controls.TextBox();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.label16 = new BANANA.Windows.Controls.Label();
			this.label15 = new BANANA.Windows.Controls.Label();
			this._dtpBY_APP_DT = new BANANA.Windows.Controls.DateTimePicker();
			this._btnDel = new DemoClient.Controls.BananaButton();
			this._btnClose = new DemoClient.Controls.BananaButton();
			this._btnSave = new DemoClient.Controls.BananaButton();
			this._btnAdd = new DemoClient.Controls.BananaButton();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BY_APP_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_BC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_LT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_SS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_SH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_HD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_KB = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_SK = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_NH = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CHK_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CRD_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DY_FR = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel7.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel3.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel5.SuspendLayout();
			this.flowLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel8.SuspendLayout();
			this.flowLayoutPanel9.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel1);
			this.groupBox1.Controls.Add(this.tableLayoutPanel2);
			this.groupBox1.Controls.Add(this._btnDel);
			this.groupBox1.Controls.Add(this._btnClose);
			this.groupBox1.Controls.Add(this._btnSave);
			this.groupBox1.Controls.Add(this._btnAdd);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox1.Location = new System.Drawing.Point(0, 169);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(583, 434);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "상세 정보";
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 6;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
			this.tableLayoutPanel1.Controls.Add(this.label14, 0, 10);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel7, 5, 9);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel4, 5, 6);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel3, 5, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_BC, 4, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_SH, 4, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_HD, 4, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_KB, 4, 6);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_LT, 3, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_SS, 3, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_SH, 3, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_LT, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_SS, 2, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_LT, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.label13, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.label1, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.label7, 0, 4);
			this.tableLayoutPanel1.Controls.Add(this.label8, 0, 5);
			this.tableLayoutPanel1.Controls.Add(this.label9, 0, 6);
			this.tableLayoutPanel1.Controls.Add(this.label2, 0, 7);
			this.tableLayoutPanel1.Controls.Add(this.label4, 0, 8);
			this.tableLayoutPanel1.Controls.Add(this.label6, 0, 9);
			this.tableLayoutPanel1.Controls.Add(this.label5, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label10, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this.label11, 4, 0);
			this.tableLayoutPanel1.Controls.Add(this.label12, 5, 0);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_BC, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_SS, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_SH, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_HD, 1, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_KB, 1, 6);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_SK, 1, 7);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_NH, 1, 8);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CHK_FR, 1, 9);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_BC, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_HD, 2, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_SH, 2, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_KB, 2, 6);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_SK, 2, 7);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_NH, 2, 8);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_CRD_FR, 2, 9);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_BC, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_HD, 3, 5);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_KB, 3, 6);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_SK, 3, 7);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_NH, 3, 8);
			this.tableLayoutPanel1.Controls.Add(this._txtFEE_OVR_FR, 3, 9);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_LT, 4, 2);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_SS, 4, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_SK, 4, 7);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_NH, 4, 8);
			this.tableLayoutPanel1.Controls.Add(this._txtBY_DAYS_FR, 4, 9);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 5, 3);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 5, 1);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel5, 5, 2);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel6, 5, 4);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel8, 5, 7);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel9, 5, 8);
			this.tableLayoutPanel1.Controls.Add(this._txtMEMO, 1, 10);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 43);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 11;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(577, 350);
			this.tableLayoutPanel1.TabIndex = 4;
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(58, 303);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(29, 13);
			this.label14.TabIndex = 591;
			this.label14.Text = "메모";
			// 
			// flowLayoutPanel7
			// 
			this.flowLayoutPanel7.Controls.Add(this._rbBY_USE_Y_FR);
			this.flowLayoutPanel7.Controls.Add(this._rbBY_USE_N_FR);
			this.flowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel7.Location = new System.Drawing.Point(490, 243);
			this.flowLayoutPanel7.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel7.Name = "flowLayoutPanel7";
			this.flowLayoutPanel7.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel7.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel7.TabIndex = 550;
			// 
			// _rbBY_USE_Y_FR
			// 
			this._rbBY_USE_Y_FR.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_FR.AutoSize = true;
			this._rbBY_USE_Y_FR.Checked = true;
			this._rbBY_USE_Y_FR.DelegateProperty = true;
			this._rbBY_USE_Y_FR.Enabled = false;
			this._rbBY_USE_Y_FR.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_FR.Name = "_rbBY_USE_Y_FR";
			this._rbBY_USE_Y_FR.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_FR.TabIndex = 10;
			this._rbBY_USE_Y_FR.TabStop = true;
			this._rbBY_USE_Y_FR.Text = "Y";
			this._rbBY_USE_Y_FR.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_FR.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_FR_CheckedChanged);
			// 
			// _rbBY_USE_N_FR
			// 
			this._rbBY_USE_N_FR.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_FR.AutoSize = true;
			this._rbBY_USE_N_FR.DelegateProperty = true;
			this._rbBY_USE_N_FR.Enabled = false;
			this._rbBY_USE_N_FR.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_FR.Name = "_rbBY_USE_N_FR";
			this._rbBY_USE_N_FR.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_FR.TabIndex = 20;
			this._rbBY_USE_N_FR.Text = "N";
			this._rbBY_USE_N_FR.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_FR.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_FR_CheckedChanged);
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._rbBY_USE_Y_KB);
			this.flowLayoutPanel4.Controls.Add(this._rbBY_USE_N_KB);
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(490, 162);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel4.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel4.TabIndex = 400;
			// 
			// _rbBY_USE_Y_KB
			// 
			this._rbBY_USE_Y_KB.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_KB.AutoSize = true;
			this._rbBY_USE_Y_KB.Checked = true;
			this._rbBY_USE_Y_KB.DelegateProperty = true;
			this._rbBY_USE_Y_KB.Enabled = false;
			this._rbBY_USE_Y_KB.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_KB.Name = "_rbBY_USE_Y_KB";
			this._rbBY_USE_Y_KB.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_KB.TabIndex = 10;
			this._rbBY_USE_Y_KB.TabStop = true;
			this._rbBY_USE_Y_KB.Text = "Y";
			this._rbBY_USE_Y_KB.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_KB.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_KB_CheckedChanged);
			// 
			// _rbBY_USE_N_KB
			// 
			this._rbBY_USE_N_KB.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_KB.AutoSize = true;
			this._rbBY_USE_N_KB.DelegateProperty = true;
			this._rbBY_USE_N_KB.Enabled = false;
			this._rbBY_USE_N_KB.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_KB.Name = "_rbBY_USE_N_KB";
			this._rbBY_USE_N_KB.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_KB.TabIndex = 20;
			this._rbBY_USE_N_KB.Text = "N";
			this._rbBY_USE_N_KB.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_KB.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_KB_CheckedChanged);
			// 
			// flowLayoutPanel3
			// 
			this.flowLayoutPanel3.Controls.Add(this._rbBY_USE_Y_HD);
			this.flowLayoutPanel3.Controls.Add(this._rbBY_USE_N_HD);
			this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel3.Location = new System.Drawing.Point(490, 135);
			this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel3.Name = "flowLayoutPanel3";
			this.flowLayoutPanel3.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel3.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel3.TabIndex = 350;
			// 
			// _rbBY_USE_Y_HD
			// 
			this._rbBY_USE_Y_HD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_HD.AutoSize = true;
			this._rbBY_USE_Y_HD.Checked = true;
			this._rbBY_USE_Y_HD.DelegateProperty = true;
			this._rbBY_USE_Y_HD.Enabled = false;
			this._rbBY_USE_Y_HD.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_HD.Name = "_rbBY_USE_Y_HD";
			this._rbBY_USE_Y_HD.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_HD.TabIndex = 10;
			this._rbBY_USE_Y_HD.TabStop = true;
			this._rbBY_USE_Y_HD.Text = "Y";
			this._rbBY_USE_Y_HD.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_HD.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_HD_CheckedChanged);
			// 
			// _rbBY_USE_N_HD
			// 
			this._rbBY_USE_N_HD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_HD.AutoSize = true;
			this._rbBY_USE_N_HD.DelegateProperty = true;
			this._rbBY_USE_N_HD.Enabled = false;
			this._rbBY_USE_N_HD.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_HD.Name = "_rbBY_USE_N_HD";
			this._rbBY_USE_N_HD.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_HD.TabIndex = 20;
			this._rbBY_USE_N_HD.Text = "N";
			this._rbBY_USE_N_HD.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_HD.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_HD_CheckedChanged);
			// 
			// _txtBY_DAYS_BC
			// 
			this._txtBY_DAYS_BC.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_BC.DelegateProperty = true;
			this._txtBY_DAYS_BC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_BC.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_BC.Location = new System.Drawing.Point(397, 30);
			this._txtBY_DAYS_BC.Name = "_txtBY_DAYS_BC";
			this._txtBY_DAYS_BC.ReadOnly = true;
			this._txtBY_DAYS_BC.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_BC.TabIndex = 140;
			this._txtBY_DAYS_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_BC.ValidationGroup = null;
			this._txtBY_DAYS_BC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_BC.WaterMarkText = "";
			// 
			// _txtBY_DAYS_SH
			// 
			this._txtBY_DAYS_SH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_SH.DelegateProperty = true;
			this._txtBY_DAYS_SH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_SH.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_SH.Location = new System.Drawing.Point(397, 111);
			this._txtBY_DAYS_SH.Name = "_txtBY_DAYS_SH";
			this._txtBY_DAYS_SH.ReadOnly = true;
			this._txtBY_DAYS_SH.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_SH.TabIndex = 290;
			this._txtBY_DAYS_SH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_SH.ValidationGroup = null;
			this._txtBY_DAYS_SH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_SH.WaterMarkText = "";
			// 
			// _txtBY_DAYS_HD
			// 
			this._txtBY_DAYS_HD.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_HD.DelegateProperty = true;
			this._txtBY_DAYS_HD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_HD.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_HD.Location = new System.Drawing.Point(397, 138);
			this._txtBY_DAYS_HD.Name = "_txtBY_DAYS_HD";
			this._txtBY_DAYS_HD.ReadOnly = true;
			this._txtBY_DAYS_HD.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_HD.TabIndex = 340;
			this._txtBY_DAYS_HD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_HD.ValidationGroup = null;
			this._txtBY_DAYS_HD.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_HD.WaterMarkText = "";
			// 
			// _txtBY_DAYS_KB
			// 
			this._txtBY_DAYS_KB.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_KB.DelegateProperty = true;
			this._txtBY_DAYS_KB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_KB.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_KB.Location = new System.Drawing.Point(397, 165);
			this._txtBY_DAYS_KB.Name = "_txtBY_DAYS_KB";
			this._txtBY_DAYS_KB.ReadOnly = true;
			this._txtBY_DAYS_KB.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_KB.TabIndex = 390;
			this._txtBY_DAYS_KB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_KB.ValidationGroup = null;
			this._txtBY_DAYS_KB.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_KB.WaterMarkText = "";
			// 
			// _txtFEE_OVR_LT
			// 
			this._txtFEE_OVR_LT.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_LT.DelegateProperty = true;
			this._txtFEE_OVR_LT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_LT.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_LT.Location = new System.Drawing.Point(297, 57);
			this._txtFEE_OVR_LT.Name = "_txtFEE_OVR_LT";
			this._txtFEE_OVR_LT.ReadOnly = true;
			this._txtFEE_OVR_LT.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_LT.TabIndex = 180;
			this._txtFEE_OVR_LT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_LT.ValidationGroup = null;
			this._txtFEE_OVR_LT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_LT.WaterMarkText = "";
			// 
			// _txtFEE_OVR_SS
			// 
			this._txtFEE_OVR_SS.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_SS.DelegateProperty = true;
			this._txtFEE_OVR_SS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_SS.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_SS.Location = new System.Drawing.Point(297, 84);
			this._txtFEE_OVR_SS.Name = "_txtFEE_OVR_SS";
			this._txtFEE_OVR_SS.ReadOnly = true;
			this._txtFEE_OVR_SS.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_SS.TabIndex = 230;
			this._txtFEE_OVR_SS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_SS.ValidationGroup = null;
			this._txtFEE_OVR_SS.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_SS.WaterMarkText = "";
			// 
			// _txtFEE_OVR_SH
			// 
			this._txtFEE_OVR_SH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_SH.DelegateProperty = true;
			this._txtFEE_OVR_SH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_SH.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_SH.Location = new System.Drawing.Point(297, 111);
			this._txtFEE_OVR_SH.Name = "_txtFEE_OVR_SH";
			this._txtFEE_OVR_SH.ReadOnly = true;
			this._txtFEE_OVR_SH.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_SH.TabIndex = 280;
			this._txtFEE_OVR_SH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_SH.ValidationGroup = null;
			this._txtFEE_OVR_SH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_SH.WaterMarkText = "";
			// 
			// _txtFEE_CRD_LT
			// 
			this._txtFEE_CRD_LT.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_LT.DelegateProperty = true;
			this._txtFEE_CRD_LT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_LT.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_LT.Location = new System.Drawing.Point(197, 57);
			this._txtFEE_CRD_LT.Name = "_txtFEE_CRD_LT";
			this._txtFEE_CRD_LT.ReadOnly = true;
			this._txtFEE_CRD_LT.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_LT.TabIndex = 170;
			this._txtFEE_CRD_LT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_LT.ValidationGroup = null;
			this._txtFEE_CRD_LT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_LT.WaterMarkText = "";
			// 
			// _txtFEE_CRD_SS
			// 
			this._txtFEE_CRD_SS.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_SS.DelegateProperty = true;
			this._txtFEE_CRD_SS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_SS.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_SS.Location = new System.Drawing.Point(197, 84);
			this._txtFEE_CRD_SS.Name = "_txtFEE_CRD_SS";
			this._txtFEE_CRD_SS.ReadOnly = true;
			this._txtFEE_CRD_SS.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_SS.TabIndex = 220;
			this._txtFEE_CRD_SS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_SS.ValidationGroup = null;
			this._txtFEE_CRD_SS.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_SS.WaterMarkText = "";
			// 
			// _txtFEE_CHK_LT
			// 
			this._txtFEE_CHK_LT.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_LT.DelegateProperty = true;
			this._txtFEE_CHK_LT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_LT.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_LT.Location = new System.Drawing.Point(97, 57);
			this._txtFEE_CHK_LT.Name = "_txtFEE_CHK_LT";
			this._txtFEE_CHK_LT.ReadOnly = true;
			this._txtFEE_CHK_LT.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_LT.TabIndex = 160;
			this._txtFEE_CHK_LT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_LT.ValidationGroup = null;
			this._txtFEE_CHK_LT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_LT.WaterMarkText = "";
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(211, 7);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(76, 13);
			this.label13.TabIndex = 8;
			this.label13.Text = "신용수수료(%)";
			// 
			// lblUSR_ID
			// 
			this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_ID.AutoSize = true;
			this.lblUSR_ID.Location = new System.Drawing.Point(36, 34);
			this.lblUSR_ID.Name = "lblUSR_ID";
			this.lblUSR_ID.Size = new System.Drawing.Size(51, 13);
			this.lblUSR_ID.TabIndex = 2;
			this.lblUSR_ID.Text = "비씨카드";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(36, 61);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(51, 13);
			this.label3.TabIndex = 1102;
			this.label3.Text = "롯데카드";
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(36, 88);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(51, 13);
			this.label1.TabIndex = 9;
			this.label1.Text = "삼성카드";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(36, 115);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(51, 13);
			this.label7.TabIndex = 13;
			this.label7.Text = "신한카드";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(36, 142);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(51, 13);
			this.label8.TabIndex = 14;
			this.label8.Text = "현대카드";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(22, 169);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(65, 13);
			this.label9.TabIndex = 15;
			this.label9.Text = "KB국민카드";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(22, 196);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(65, 13);
			this.label2.TabIndex = 10;
			this.label2.Text = "하나SK카드";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(20, 223);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(67, 13);
			this.label4.TabIndex = 11;
			this.label4.Text = "NH농협은행";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(36, 250);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(51, 13);
			this.label6.TabIndex = 12;
			this.label6.Text = "외환카드";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(111, 7);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(76, 13);
			this.label5.TabIndex = 1103;
			this.label5.Text = "체크수수료(%)";
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(311, 7);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(76, 13);
			this.label10.TabIndex = 1104;
			this.label10.Text = "해외수수료(%)";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(419, 7);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(68, 13);
			this.label11.TabIndex = 1105;
			this.label11.Text = "매입주기(일)";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(493, 7);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(51, 13);
			this.label12.TabIndex = 1106;
			this.label12.Text = "매입여부";
			// 
			// _txtFEE_CHK_BC
			// 
			this._txtFEE_CHK_BC.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_BC.DelegateProperty = true;
			this._txtFEE_CHK_BC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_BC.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_BC.Location = new System.Drawing.Point(97, 30);
			this._txtFEE_CHK_BC.Name = "_txtFEE_CHK_BC";
			this._txtFEE_CHK_BC.ReadOnly = true;
			this._txtFEE_CHK_BC.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_BC.TabIndex = 110;
			this._txtFEE_CHK_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_BC.ValidationGroup = null;
			this._txtFEE_CHK_BC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_BC.WaterMarkText = "";
			// 
			// _txtFEE_CHK_SS
			// 
			this._txtFEE_CHK_SS.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_SS.DelegateProperty = true;
			this._txtFEE_CHK_SS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_SS.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_SS.Location = new System.Drawing.Point(97, 84);
			this._txtFEE_CHK_SS.Name = "_txtFEE_CHK_SS";
			this._txtFEE_CHK_SS.ReadOnly = true;
			this._txtFEE_CHK_SS.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_SS.TabIndex = 210;
			this._txtFEE_CHK_SS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_SS.ValidationGroup = null;
			this._txtFEE_CHK_SS.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_SS.WaterMarkText = "";
			// 
			// _txtFEE_CHK_SH
			// 
			this._txtFEE_CHK_SH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_SH.DelegateProperty = true;
			this._txtFEE_CHK_SH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_SH.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_SH.Location = new System.Drawing.Point(97, 111);
			this._txtFEE_CHK_SH.Name = "_txtFEE_CHK_SH";
			this._txtFEE_CHK_SH.ReadOnly = true;
			this._txtFEE_CHK_SH.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_SH.TabIndex = 260;
			this._txtFEE_CHK_SH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_SH.ValidationGroup = null;
			this._txtFEE_CHK_SH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_SH.WaterMarkText = "";
			// 
			// _txtFEE_CHK_HD
			// 
			this._txtFEE_CHK_HD.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_HD.DelegateProperty = true;
			this._txtFEE_CHK_HD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_HD.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_HD.Location = new System.Drawing.Point(97, 138);
			this._txtFEE_CHK_HD.Name = "_txtFEE_CHK_HD";
			this._txtFEE_CHK_HD.ReadOnly = true;
			this._txtFEE_CHK_HD.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_HD.TabIndex = 310;
			this._txtFEE_CHK_HD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_HD.ValidationGroup = null;
			this._txtFEE_CHK_HD.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_HD.WaterMarkText = "";
			// 
			// _txtFEE_CHK_KB
			// 
			this._txtFEE_CHK_KB.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_KB.DelegateProperty = true;
			this._txtFEE_CHK_KB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_KB.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_KB.Location = new System.Drawing.Point(97, 165);
			this._txtFEE_CHK_KB.Name = "_txtFEE_CHK_KB";
			this._txtFEE_CHK_KB.ReadOnly = true;
			this._txtFEE_CHK_KB.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_KB.TabIndex = 360;
			this._txtFEE_CHK_KB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_KB.ValidationGroup = null;
			this._txtFEE_CHK_KB.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_KB.WaterMarkText = "";
			// 
			// _txtFEE_CHK_SK
			// 
			this._txtFEE_CHK_SK.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_SK.DelegateProperty = true;
			this._txtFEE_CHK_SK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_SK.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_SK.Location = new System.Drawing.Point(97, 192);
			this._txtFEE_CHK_SK.Name = "_txtFEE_CHK_SK";
			this._txtFEE_CHK_SK.ReadOnly = true;
			this._txtFEE_CHK_SK.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_SK.TabIndex = 410;
			this._txtFEE_CHK_SK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_SK.ValidationGroup = null;
			this._txtFEE_CHK_SK.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_SK.WaterMarkText = "";
			// 
			// _txtFEE_CHK_NH
			// 
			this._txtFEE_CHK_NH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_NH.DelegateProperty = true;
			this._txtFEE_CHK_NH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_NH.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_NH.Location = new System.Drawing.Point(97, 219);
			this._txtFEE_CHK_NH.Name = "_txtFEE_CHK_NH";
			this._txtFEE_CHK_NH.ReadOnly = true;
			this._txtFEE_CHK_NH.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_NH.TabIndex = 460;
			this._txtFEE_CHK_NH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_NH.ValidationGroup = null;
			this._txtFEE_CHK_NH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_NH.WaterMarkText = "";
			// 
			// _txtFEE_CHK_FR
			// 
			this._txtFEE_CHK_FR.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CHK_FR.DelegateProperty = true;
			this._txtFEE_CHK_FR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CHK_FR.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CHK_FR.Location = new System.Drawing.Point(97, 246);
			this._txtFEE_CHK_FR.Name = "_txtFEE_CHK_FR";
			this._txtFEE_CHK_FR.ReadOnly = true;
			this._txtFEE_CHK_FR.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CHK_FR.TabIndex = 510;
			this._txtFEE_CHK_FR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CHK_FR.ValidationGroup = null;
			this._txtFEE_CHK_FR.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CHK_FR.WaterMarkText = "";
			// 
			// _txtFEE_CRD_BC
			// 
			this._txtFEE_CRD_BC.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_BC.DelegateProperty = true;
			this._txtFEE_CRD_BC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_BC.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_BC.Location = new System.Drawing.Point(197, 30);
			this._txtFEE_CRD_BC.Name = "_txtFEE_CRD_BC";
			this._txtFEE_CRD_BC.ReadOnly = true;
			this._txtFEE_CRD_BC.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_BC.TabIndex = 120;
			this._txtFEE_CRD_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_BC.ValidationGroup = null;
			this._txtFEE_CRD_BC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_BC.WaterMarkText = "";
			// 
			// _txtFEE_CRD_HD
			// 
			this._txtFEE_CRD_HD.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_HD.DelegateProperty = true;
			this._txtFEE_CRD_HD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_HD.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_HD.Location = new System.Drawing.Point(197, 138);
			this._txtFEE_CRD_HD.Name = "_txtFEE_CRD_HD";
			this._txtFEE_CRD_HD.ReadOnly = true;
			this._txtFEE_CRD_HD.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_HD.TabIndex = 320;
			this._txtFEE_CRD_HD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_HD.ValidationGroup = null;
			this._txtFEE_CRD_HD.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_HD.WaterMarkText = "";
			// 
			// _txtFEE_CRD_SH
			// 
			this._txtFEE_CRD_SH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_SH.DelegateProperty = true;
			this._txtFEE_CRD_SH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_SH.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_SH.Location = new System.Drawing.Point(197, 111);
			this._txtFEE_CRD_SH.Name = "_txtFEE_CRD_SH";
			this._txtFEE_CRD_SH.ReadOnly = true;
			this._txtFEE_CRD_SH.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_SH.TabIndex = 270;
			this._txtFEE_CRD_SH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_SH.ValidationGroup = null;
			this._txtFEE_CRD_SH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_SH.WaterMarkText = "";
			// 
			// _txtFEE_CRD_KB
			// 
			this._txtFEE_CRD_KB.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_KB.DelegateProperty = true;
			this._txtFEE_CRD_KB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_KB.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_KB.Location = new System.Drawing.Point(197, 165);
			this._txtFEE_CRD_KB.Name = "_txtFEE_CRD_KB";
			this._txtFEE_CRD_KB.ReadOnly = true;
			this._txtFEE_CRD_KB.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_KB.TabIndex = 370;
			this._txtFEE_CRD_KB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_KB.ValidationGroup = null;
			this._txtFEE_CRD_KB.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_KB.WaterMarkText = "";
			// 
			// _txtFEE_CRD_SK
			// 
			this._txtFEE_CRD_SK.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_SK.DelegateProperty = true;
			this._txtFEE_CRD_SK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_SK.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_SK.Location = new System.Drawing.Point(197, 192);
			this._txtFEE_CRD_SK.Name = "_txtFEE_CRD_SK";
			this._txtFEE_CRD_SK.ReadOnly = true;
			this._txtFEE_CRD_SK.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_SK.TabIndex = 420;
			this._txtFEE_CRD_SK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_SK.ValidationGroup = null;
			this._txtFEE_CRD_SK.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_SK.WaterMarkText = "";
			// 
			// _txtFEE_CRD_NH
			// 
			this._txtFEE_CRD_NH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_NH.DelegateProperty = true;
			this._txtFEE_CRD_NH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_NH.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_NH.Location = new System.Drawing.Point(197, 219);
			this._txtFEE_CRD_NH.Name = "_txtFEE_CRD_NH";
			this._txtFEE_CRD_NH.ReadOnly = true;
			this._txtFEE_CRD_NH.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_NH.TabIndex = 470;
			this._txtFEE_CRD_NH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_NH.ValidationGroup = null;
			this._txtFEE_CRD_NH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_NH.WaterMarkText = "";
			// 
			// _txtFEE_CRD_FR
			// 
			this._txtFEE_CRD_FR.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_CRD_FR.DelegateProperty = true;
			this._txtFEE_CRD_FR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_CRD_FR.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_CRD_FR.Location = new System.Drawing.Point(197, 246);
			this._txtFEE_CRD_FR.Name = "_txtFEE_CRD_FR";
			this._txtFEE_CRD_FR.ReadOnly = true;
			this._txtFEE_CRD_FR.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_CRD_FR.TabIndex = 520;
			this._txtFEE_CRD_FR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_CRD_FR.ValidationGroup = null;
			this._txtFEE_CRD_FR.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_CRD_FR.WaterMarkText = "";
			// 
			// _txtFEE_OVR_BC
			// 
			this._txtFEE_OVR_BC.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_BC.DelegateProperty = true;
			this._txtFEE_OVR_BC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_BC.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_BC.Location = new System.Drawing.Point(297, 30);
			this._txtFEE_OVR_BC.Name = "_txtFEE_OVR_BC";
			this._txtFEE_OVR_BC.ReadOnly = true;
			this._txtFEE_OVR_BC.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_BC.TabIndex = 130;
			this._txtFEE_OVR_BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_BC.ValidationGroup = null;
			this._txtFEE_OVR_BC.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_BC.WaterMarkText = "";
			// 
			// _txtFEE_OVR_HD
			// 
			this._txtFEE_OVR_HD.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_HD.DelegateProperty = true;
			this._txtFEE_OVR_HD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_HD.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_HD.Location = new System.Drawing.Point(297, 138);
			this._txtFEE_OVR_HD.Name = "_txtFEE_OVR_HD";
			this._txtFEE_OVR_HD.ReadOnly = true;
			this._txtFEE_OVR_HD.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_HD.TabIndex = 330;
			this._txtFEE_OVR_HD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_HD.ValidationGroup = null;
			this._txtFEE_OVR_HD.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_HD.WaterMarkText = "";
			// 
			// _txtFEE_OVR_KB
			// 
			this._txtFEE_OVR_KB.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_KB.DelegateProperty = true;
			this._txtFEE_OVR_KB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_KB.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_KB.Location = new System.Drawing.Point(297, 165);
			this._txtFEE_OVR_KB.Name = "_txtFEE_OVR_KB";
			this._txtFEE_OVR_KB.ReadOnly = true;
			this._txtFEE_OVR_KB.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_KB.TabIndex = 380;
			this._txtFEE_OVR_KB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_KB.ValidationGroup = null;
			this._txtFEE_OVR_KB.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_KB.WaterMarkText = "";
			// 
			// _txtFEE_OVR_SK
			// 
			this._txtFEE_OVR_SK.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_SK.DelegateProperty = true;
			this._txtFEE_OVR_SK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_SK.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_SK.Location = new System.Drawing.Point(297, 192);
			this._txtFEE_OVR_SK.Name = "_txtFEE_OVR_SK";
			this._txtFEE_OVR_SK.ReadOnly = true;
			this._txtFEE_OVR_SK.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_SK.TabIndex = 430;
			this._txtFEE_OVR_SK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_SK.ValidationGroup = null;
			this._txtFEE_OVR_SK.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_SK.WaterMarkText = "";
			// 
			// _txtFEE_OVR_NH
			// 
			this._txtFEE_OVR_NH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_NH.DelegateProperty = true;
			this._txtFEE_OVR_NH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_NH.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_NH.Location = new System.Drawing.Point(297, 219);
			this._txtFEE_OVR_NH.Name = "_txtFEE_OVR_NH";
			this._txtFEE_OVR_NH.ReadOnly = true;
			this._txtFEE_OVR_NH.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_NH.TabIndex = 480;
			this._txtFEE_OVR_NH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_NH.ValidationGroup = null;
			this._txtFEE_OVR_NH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_NH.WaterMarkText = "";
			// 
			// _txtFEE_OVR_FR
			// 
			this._txtFEE_OVR_FR.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtFEE_OVR_FR.DelegateProperty = true;
			this._txtFEE_OVR_FR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtFEE_OVR_FR.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtFEE_OVR_FR.Location = new System.Drawing.Point(297, 246);
			this._txtFEE_OVR_FR.Name = "_txtFEE_OVR_FR";
			this._txtFEE_OVR_FR.ReadOnly = true;
			this._txtFEE_OVR_FR.Size = new System.Drawing.Size(90, 20);
			this._txtFEE_OVR_FR.TabIndex = 530;
			this._txtFEE_OVR_FR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtFEE_OVR_FR.ValidationGroup = null;
			this._txtFEE_OVR_FR.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtFEE_OVR_FR.WaterMarkText = "";
			// 
			// _txtBY_DAYS_LT
			// 
			this._txtBY_DAYS_LT.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_LT.DelegateProperty = true;
			this._txtBY_DAYS_LT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_LT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_LT.Location = new System.Drawing.Point(397, 57);
			this._txtBY_DAYS_LT.Name = "_txtBY_DAYS_LT";
			this._txtBY_DAYS_LT.ReadOnly = true;
			this._txtBY_DAYS_LT.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_LT.TabIndex = 190;
			this._txtBY_DAYS_LT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_LT.ValidationGroup = null;
			this._txtBY_DAYS_LT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_LT.WaterMarkText = "";
			// 
			// _txtBY_DAYS_SS
			// 
			this._txtBY_DAYS_SS.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_SS.DelegateProperty = true;
			this._txtBY_DAYS_SS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_SS.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_SS.Location = new System.Drawing.Point(397, 84);
			this._txtBY_DAYS_SS.Name = "_txtBY_DAYS_SS";
			this._txtBY_DAYS_SS.ReadOnly = true;
			this._txtBY_DAYS_SS.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_SS.TabIndex = 240;
			this._txtBY_DAYS_SS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_SS.ValidationGroup = null;
			this._txtBY_DAYS_SS.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_SS.WaterMarkText = "";
			// 
			// _txtBY_DAYS_SK
			// 
			this._txtBY_DAYS_SK.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_SK.DelegateProperty = true;
			this._txtBY_DAYS_SK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_SK.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_SK.Location = new System.Drawing.Point(397, 192);
			this._txtBY_DAYS_SK.Name = "_txtBY_DAYS_SK";
			this._txtBY_DAYS_SK.ReadOnly = true;
			this._txtBY_DAYS_SK.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_SK.TabIndex = 440;
			this._txtBY_DAYS_SK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_SK.ValidationGroup = null;
			this._txtBY_DAYS_SK.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_SK.WaterMarkText = "";
			// 
			// _txtBY_DAYS_NH
			// 
			this._txtBY_DAYS_NH.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_NH.DelegateProperty = true;
			this._txtBY_DAYS_NH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_NH.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_NH.Location = new System.Drawing.Point(397, 219);
			this._txtBY_DAYS_NH.Name = "_txtBY_DAYS_NH";
			this._txtBY_DAYS_NH.ReadOnly = true;
			this._txtBY_DAYS_NH.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_NH.TabIndex = 490;
			this._txtBY_DAYS_NH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_NH.ValidationGroup = null;
			this._txtBY_DAYS_NH.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_NH.WaterMarkText = "";
			// 
			// _txtBY_DAYS_FR
			// 
			this._txtBY_DAYS_FR.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this._txtBY_DAYS_FR.DelegateProperty = true;
			this._txtBY_DAYS_FR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBY_DAYS_FR.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBY_DAYS_FR.Location = new System.Drawing.Point(397, 246);
			this._txtBY_DAYS_FR.Name = "_txtBY_DAYS_FR";
			this._txtBY_DAYS_FR.ReadOnly = true;
			this._txtBY_DAYS_FR.Size = new System.Drawing.Size(90, 20);
			this._txtBY_DAYS_FR.TabIndex = 540;
			this._txtBY_DAYS_FR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBY_DAYS_FR.ValidationGroup = null;
			this._txtBY_DAYS_FR.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtBY_DAYS_FR.WaterMarkText = "";
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._rbBY_USE_Y_SS);
			this.flowLayoutPanel1.Controls.Add(this._rbBY_USE_N_SS);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(490, 81);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel1.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel1.TabIndex = 250;
			// 
			// _rbBY_USE_Y_SS
			// 
			this._rbBY_USE_Y_SS.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_SS.AutoSize = true;
			this._rbBY_USE_Y_SS.Checked = true;
			this._rbBY_USE_Y_SS.DelegateProperty = true;
			this._rbBY_USE_Y_SS.Enabled = false;
			this._rbBY_USE_Y_SS.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_SS.Name = "_rbBY_USE_Y_SS";
			this._rbBY_USE_Y_SS.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_SS.TabIndex = 10;
			this._rbBY_USE_Y_SS.TabStop = true;
			this._rbBY_USE_Y_SS.Text = "Y";
			this._rbBY_USE_Y_SS.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_SS.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_SS_CheckedChanged);
			// 
			// _rbBY_USE_N_SS
			// 
			this._rbBY_USE_N_SS.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_SS.AutoSize = true;
			this._rbBY_USE_N_SS.DelegateProperty = true;
			this._rbBY_USE_N_SS.Enabled = false;
			this._rbBY_USE_N_SS.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_SS.Name = "_rbBY_USE_N_SS";
			this._rbBY_USE_N_SS.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_SS.TabIndex = 20;
			this._rbBY_USE_N_SS.Text = "N";
			this._rbBY_USE_N_SS.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_SS.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_SS_CheckedChanged);
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._rbBY_USE_Y_BC);
			this.flowLayoutPanel2.Controls.Add(this._rbBY_USE_N_BC);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(490, 27);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel2.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel2.TabIndex = 150;
			// 
			// _rbBY_USE_Y_BC
			// 
			this._rbBY_USE_Y_BC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_BC.AutoSize = true;
			this._rbBY_USE_Y_BC.Checked = true;
			this._rbBY_USE_Y_BC.DelegateProperty = true;
			this._rbBY_USE_Y_BC.Enabled = false;
			this._rbBY_USE_Y_BC.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_BC.Name = "_rbBY_USE_Y_BC";
			this._rbBY_USE_Y_BC.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_BC.TabIndex = 10;
			this._rbBY_USE_Y_BC.TabStop = true;
			this._rbBY_USE_Y_BC.Text = "Y";
			this._rbBY_USE_Y_BC.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_BC.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_BC_CheckedChanged);
			// 
			// _rbBY_USE_N_BC
			// 
			this._rbBY_USE_N_BC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_BC.AutoSize = true;
			this._rbBY_USE_N_BC.DelegateProperty = true;
			this._rbBY_USE_N_BC.Enabled = false;
			this._rbBY_USE_N_BC.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_BC.Name = "_rbBY_USE_N_BC";
			this._rbBY_USE_N_BC.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_BC.TabIndex = 20;
			this._rbBY_USE_N_BC.Text = "N";
			this._rbBY_USE_N_BC.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_BC.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_BC_CheckedChanged);
			// 
			// flowLayoutPanel5
			// 
			this.flowLayoutPanel5.Controls.Add(this._rbBY_USE_Y_LT);
			this.flowLayoutPanel5.Controls.Add(this._rbBY_USE_N_LT);
			this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel5.Location = new System.Drawing.Point(490, 54);
			this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel5.Name = "flowLayoutPanel5";
			this.flowLayoutPanel5.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel5.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel5.TabIndex = 200;
			// 
			// _rbBY_USE_Y_LT
			// 
			this._rbBY_USE_Y_LT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_LT.AutoSize = true;
			this._rbBY_USE_Y_LT.Checked = true;
			this._rbBY_USE_Y_LT.DelegateProperty = true;
			this._rbBY_USE_Y_LT.Enabled = false;
			this._rbBY_USE_Y_LT.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_LT.Name = "_rbBY_USE_Y_LT";
			this._rbBY_USE_Y_LT.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_LT.TabIndex = 10;
			this._rbBY_USE_Y_LT.TabStop = true;
			this._rbBY_USE_Y_LT.Text = "Y";
			this._rbBY_USE_Y_LT.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_LT.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_LT_CheckedChanged);
			// 
			// _rbBY_USE_N_LT
			// 
			this._rbBY_USE_N_LT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_LT.AutoSize = true;
			this._rbBY_USE_N_LT.DelegateProperty = true;
			this._rbBY_USE_N_LT.Enabled = false;
			this._rbBY_USE_N_LT.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_LT.Name = "_rbBY_USE_N_LT";
			this._rbBY_USE_N_LT.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_LT.TabIndex = 20;
			this._rbBY_USE_N_LT.Text = "N";
			this._rbBY_USE_N_LT.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_LT.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_LT_CheckedChanged);
			// 
			// flowLayoutPanel6
			// 
			this.flowLayoutPanel6.Controls.Add(this._rbBY_USE_Y_SH);
			this.flowLayoutPanel6.Controls.Add(this._rbBY_USE_N_SH);
			this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel6.Location = new System.Drawing.Point(490, 108);
			this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel6.Name = "flowLayoutPanel6";
			this.flowLayoutPanel6.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel6.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel6.TabIndex = 300;
			// 
			// _rbBY_USE_Y_SH
			// 
			this._rbBY_USE_Y_SH.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_SH.AutoSize = true;
			this._rbBY_USE_Y_SH.Checked = true;
			this._rbBY_USE_Y_SH.DelegateProperty = true;
			this._rbBY_USE_Y_SH.Enabled = false;
			this._rbBY_USE_Y_SH.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_SH.Name = "_rbBY_USE_Y_SH";
			this._rbBY_USE_Y_SH.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_SH.TabIndex = 10;
			this._rbBY_USE_Y_SH.TabStop = true;
			this._rbBY_USE_Y_SH.Text = "Y";
			this._rbBY_USE_Y_SH.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_SH.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_SH_CheckedChanged);
			// 
			// _rbBY_USE_N_SH
			// 
			this._rbBY_USE_N_SH.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_SH.AutoSize = true;
			this._rbBY_USE_N_SH.DelegateProperty = true;
			this._rbBY_USE_N_SH.Enabled = false;
			this._rbBY_USE_N_SH.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_SH.Name = "_rbBY_USE_N_SH";
			this._rbBY_USE_N_SH.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_SH.TabIndex = 20;
			this._rbBY_USE_N_SH.Text = "N";
			this._rbBY_USE_N_SH.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_SH.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_SH_CheckedChanged);
			// 
			// flowLayoutPanel8
			// 
			this.flowLayoutPanel8.Controls.Add(this._rbBY_USE_Y_SK);
			this.flowLayoutPanel8.Controls.Add(this._rbBY_USE_N_SK);
			this.flowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel8.Location = new System.Drawing.Point(490, 189);
			this.flowLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel8.Name = "flowLayoutPanel8";
			this.flowLayoutPanel8.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel8.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel8.TabIndex = 450;
			// 
			// _rbBY_USE_Y_SK
			// 
			this._rbBY_USE_Y_SK.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_SK.AutoSize = true;
			this._rbBY_USE_Y_SK.Checked = true;
			this._rbBY_USE_Y_SK.DelegateProperty = true;
			this._rbBY_USE_Y_SK.Enabled = false;
			this._rbBY_USE_Y_SK.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_SK.Name = "_rbBY_USE_Y_SK";
			this._rbBY_USE_Y_SK.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_SK.TabIndex = 10;
			this._rbBY_USE_Y_SK.TabStop = true;
			this._rbBY_USE_Y_SK.Text = "Y";
			this._rbBY_USE_Y_SK.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_SK.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_SK_CheckedChanged);
			// 
			// _rbBY_USE_N_SK
			// 
			this._rbBY_USE_N_SK.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_SK.AutoSize = true;
			this._rbBY_USE_N_SK.DelegateProperty = true;
			this._rbBY_USE_N_SK.Enabled = false;
			this._rbBY_USE_N_SK.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_SK.Name = "_rbBY_USE_N_SK";
			this._rbBY_USE_N_SK.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_SK.TabIndex = 20;
			this._rbBY_USE_N_SK.Text = "N";
			this._rbBY_USE_N_SK.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_SK.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_SK_CheckedChanged);
			// 
			// flowLayoutPanel9
			// 
			this.flowLayoutPanel9.Controls.Add(this._rbBY_USE_Y_NH);
			this.flowLayoutPanel9.Controls.Add(this._rbBY_USE_N_NH);
			this.flowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel9.Location = new System.Drawing.Point(490, 216);
			this.flowLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel9.Name = "flowLayoutPanel9";
			this.flowLayoutPanel9.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel9.Size = new System.Drawing.Size(87, 27);
			this.flowLayoutPanel9.TabIndex = 500;
			// 
			// _rbBY_USE_Y_NH
			// 
			this._rbBY_USE_Y_NH.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_Y_NH.AutoSize = true;
			this._rbBY_USE_Y_NH.Checked = true;
			this._rbBY_USE_Y_NH.DelegateProperty = true;
			this._rbBY_USE_Y_NH.Enabled = false;
			this._rbBY_USE_Y_NH.Location = new System.Drawing.Point(3, 6);
			this._rbBY_USE_Y_NH.Name = "_rbBY_USE_Y_NH";
			this._rbBY_USE_Y_NH.Size = new System.Drawing.Size(32, 17);
			this._rbBY_USE_Y_NH.TabIndex = 10;
			this._rbBY_USE_Y_NH.TabStop = true;
			this._rbBY_USE_Y_NH.Text = "Y";
			this._rbBY_USE_Y_NH.UseVisualStyleBackColor = true;
			this._rbBY_USE_Y_NH.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_NH_CheckedChanged);
			// 
			// _rbBY_USE_N_NH
			// 
			this._rbBY_USE_N_NH.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbBY_USE_N_NH.AutoSize = true;
			this._rbBY_USE_N_NH.DelegateProperty = true;
			this._rbBY_USE_N_NH.Enabled = false;
			this._rbBY_USE_N_NH.Location = new System.Drawing.Point(41, 6);
			this._rbBY_USE_N_NH.Name = "_rbBY_USE_N_NH";
			this._rbBY_USE_N_NH.Size = new System.Drawing.Size(33, 17);
			this._rbBY_USE_N_NH.TabIndex = 20;
			this._rbBY_USE_N_NH.Text = "N";
			this._rbBY_USE_N_NH.UseVisualStyleBackColor = true;
			this._rbBY_USE_N_NH.CheckedChanged += new System.EventHandler(this._rbBY_USE_Y_NH_CheckedChanged);
			// 
			// _txtMEMO
			// 
			this.tableLayoutPanel1.SetColumnSpan(this._txtMEMO, 5);
			this._txtMEMO.DelegateProperty = true;
			this._txtMEMO.Dock = System.Windows.Forms.DockStyle.Fill;
			this._txtMEMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtMEMO.Location = new System.Drawing.Point(93, 273);
			this._txtMEMO.Multiline = true;
			this._txtMEMO.Name = "_txtMEMO";
			this._txtMEMO.ReadOnly = true;
			this._txtMEMO.Size = new System.Drawing.Size(481, 74);
			this._txtMEMO.TabIndex = 555;
			this._txtMEMO.ValidationGroup = null;
			this._txtMEMO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtMEMO.WaterMarkText = "";
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 2;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.Controls.Add(this.label16, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.label15, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this._dtpBY_APP_DT, 1, 0);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 2;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(577, 27);
			this.tableLayoutPanel2.TabIndex = 591;
			// 
			// label16
			// 
			this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(3, 30);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(0, 13);
			this.label16.TabIndex = 10;
			// 
			// label15
			// 
			this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(25, 7);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(62, 13);
			this.label15.TabIndex = 1426;
			this.label15.Text = "적용시작일";
			// 
			// _dtpBY_APP_DT
			// 
			this._dtpBY_APP_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpBY_APP_DT.Checked = false;
			this._dtpBY_APP_DT.Compulsory = true;
			this._dtpBY_APP_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpBY_APP_DT.DelegateProperty = true;
			this._dtpBY_APP_DT.Enabled = false;
			this._dtpBY_APP_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpBY_APP_DT.Location = new System.Drawing.Point(93, 3);
			this._dtpBY_APP_DT.Name = "_dtpBY_APP_DT";
			this._dtpBY_APP_DT.ShowCheckBox = true;
			this._dtpBY_APP_DT.Size = new System.Drawing.Size(130, 20);
			this._dtpBY_APP_DT.TabIndex = 1000;
			this._dtpBY_APP_DT.ValidationGroup = "a";
			// 
			// _btnDel
			// 
			this._btnDel.ButtonConfirm = true;
			this._btnDel.DelegateProperty = true;
			this._btnDel.Enabled = false;
			this._btnDel.Image = global::DemoClient.Properties.Resources.red_62690;
			this._btnDel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnDel.Location = new System.Drawing.Point(421, 400);
			this._btnDel.Name = "_btnDel";
			this._btnDel.Size = new System.Drawing.Size(75, 27);
			this._btnDel.TabIndex = 580;
			this._btnDel.Text = "      삭   제";
			this._btnDel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnDel.UseVisualStyleBackColor = true;
			this._btnDel.ValidationGroup = null;
			this._btnDel.Click += new System.EventHandler(this._btnDel_Click);
			// 
			// _btnClose
			// 
			this._btnClose.DelegateProperty = true;
			this._btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this._btnClose.Image = global::DemoClient.Properties.Resources.red_62690;
			this._btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.Location = new System.Drawing.Point(502, 400);
			this._btnClose.Name = "_btnClose";
			this._btnClose.Size = new System.Drawing.Size(75, 27);
			this._btnClose.TabIndex = 590;
			this._btnClose.Text = "      닫   기";
			this._btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnClose.UseVisualStyleBackColor = true;
			this._btnClose.ValidationGroup = null;
			this._btnClose.Click += new System.EventHandler(this._btnClose_Click);
			// 
			// _btnSave
			// 
			this._btnSave.ButtonConfirm = true;
			this._btnSave.DelegateProperty = true;
			this._btnSave.Enabled = false;
			this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.Location = new System.Drawing.Point(340, 400);
			this._btnSave.Name = "_btnSave";
			this._btnSave.Size = new System.Drawing.Size(75, 27);
			this._btnSave.TabIndex = 570;
			this._btnSave.Text = "      저   장";
			this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave.UseVisualStyleBackColor = true;
			this._btnSave.ValidationGroup = "a";
			this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
			// 
			// _btnAdd
			// 
			this._btnAdd.DelegateProperty = true;
			this._btnAdd.Image = global::DemoClient.Properties.Resources._1377801089_62655;
			this._btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnAdd.Location = new System.Drawing.Point(259, 400);
			this._btnAdd.Name = "_btnAdd";
			this._btnAdd.Size = new System.Drawing.Size(75, 27);
			this._btnAdd.TabIndex = 560;
			this._btnAdd.Text = "      추   가";
			this._btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnAdd.UseVisualStyleBackColor = true;
			this._btnAdd.ValidationGroup = null;
			this._btnAdd.Click += new System.EventHandler(this._btnAdd_Click);
			// 
			// gridView1
			// 
			this.gridView1.AllowUserToAddRows = false;
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.gridView1.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX,
            this.BY_APP_DT,
            this.CHK_BC,
            this.CRD_BC,
            this.DY_BC,
            this.CHK_LT,
            this.CRD_LT,
            this.DY_LT,
            this.CHK_SS,
            this.CRD_SS,
            this.DY_SS,
            this.CHK_SH,
            this.CRD_SH,
            this.DY_SH,
            this.CHK_HD,
            this.CRD_HD,
            this.DY_HD,
            this.CHK_KB,
            this.CRD_KB,
            this.DY_KB,
            this.CHK_SK,
            this.CRD_SK,
            this.DY_SK,
            this.CHK_NH,
            this.CRD_NH,
            this.DY_NH,
            this.CHK_FR,
            this.CRD_FR,
            this.DY_FR,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gridView1.Location = new System.Drawing.Point(0, 0);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(583, 169);
			this.gridView1.TabIndex = 100;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			// 
			// IDX
			// 
			this.IDX.DataPropertyName = "IDX";
			this.IDX.HeaderText = "일련번호";
			this.IDX.Name = "IDX";
			this.IDX.ReadOnly = true;
			this.IDX.Visible = false;
			this.IDX.Width = 76;
			// 
			// BY_APP_DT
			// 
			this.BY_APP_DT.DataPropertyName = "BY_APP_DT";
			this.BY_APP_DT.HeaderText = "적용시작일";
			this.BY_APP_DT.Name = "BY_APP_DT";
			this.BY_APP_DT.ReadOnly = true;
			this.BY_APP_DT.Width = 87;
			// 
			// CHK_BC
			// 
			this.CHK_BC.DataPropertyName = "CHK_BC";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_BC.DefaultCellStyle = dataGridViewCellStyle2;
			this.CHK_BC.HeaderText = "체크";
			this.CHK_BC.Name = "CHK_BC";
			this.CHK_BC.ReadOnly = true;
			this.CHK_BC.Width = 54;
			// 
			// CRD_BC
			// 
			this.CRD_BC.DataPropertyName = "CRD_BC";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_BC.DefaultCellStyle = dataGridViewCellStyle3;
			this.CRD_BC.HeaderText = "신용";
			this.CRD_BC.Name = "CRD_BC";
			this.CRD_BC.ReadOnly = true;
			this.CRD_BC.Width = 54;
			// 
			// DY_BC
			// 
			this.DY_BC.DataPropertyName = "DY_BC";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_BC.DefaultCellStyle = dataGridViewCellStyle4;
			this.DY_BC.HeaderText = "주기";
			this.DY_BC.Name = "DY_BC";
			this.DY_BC.ReadOnly = true;
			this.DY_BC.Width = 54;
			// 
			// CHK_LT
			// 
			this.CHK_LT.DataPropertyName = "CHK_LT";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_LT.DefaultCellStyle = dataGridViewCellStyle5;
			this.CHK_LT.HeaderText = "체크";
			this.CHK_LT.Name = "CHK_LT";
			this.CHK_LT.ReadOnly = true;
			this.CHK_LT.Width = 54;
			// 
			// CRD_LT
			// 
			this.CRD_LT.DataPropertyName = "CRD_LT";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_LT.DefaultCellStyle = dataGridViewCellStyle6;
			this.CRD_LT.HeaderText = "신용";
			this.CRD_LT.Name = "CRD_LT";
			this.CRD_LT.ReadOnly = true;
			this.CRD_LT.Width = 54;
			// 
			// DY_LT
			// 
			this.DY_LT.DataPropertyName = "DY_LT";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_LT.DefaultCellStyle = dataGridViewCellStyle7;
			this.DY_LT.HeaderText = "주기";
			this.DY_LT.Name = "DY_LT";
			this.DY_LT.ReadOnly = true;
			this.DY_LT.Width = 54;
			// 
			// CHK_SS
			// 
			this.CHK_SS.DataPropertyName = "CHK_SS";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_SS.DefaultCellStyle = dataGridViewCellStyle8;
			this.CHK_SS.HeaderText = "체크";
			this.CHK_SS.Name = "CHK_SS";
			this.CHK_SS.ReadOnly = true;
			this.CHK_SS.Width = 54;
			// 
			// CRD_SS
			// 
			this.CRD_SS.DataPropertyName = "CRD_SS";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_SS.DefaultCellStyle = dataGridViewCellStyle9;
			this.CRD_SS.HeaderText = "신용";
			this.CRD_SS.Name = "CRD_SS";
			this.CRD_SS.ReadOnly = true;
			this.CRD_SS.Width = 54;
			// 
			// DY_SS
			// 
			this.DY_SS.DataPropertyName = "DY_SS";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_SS.DefaultCellStyle = dataGridViewCellStyle10;
			this.DY_SS.HeaderText = "주기";
			this.DY_SS.Name = "DY_SS";
			this.DY_SS.ReadOnly = true;
			this.DY_SS.Width = 54;
			// 
			// CHK_SH
			// 
			this.CHK_SH.DataPropertyName = "CHK_SH";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_SH.DefaultCellStyle = dataGridViewCellStyle11;
			this.CHK_SH.HeaderText = "체크";
			this.CHK_SH.Name = "CHK_SH";
			this.CHK_SH.ReadOnly = true;
			this.CHK_SH.Width = 54;
			// 
			// CRD_SH
			// 
			this.CRD_SH.DataPropertyName = "CRD_SH";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_SH.DefaultCellStyle = dataGridViewCellStyle12;
			this.CRD_SH.HeaderText = "신용";
			this.CRD_SH.Name = "CRD_SH";
			this.CRD_SH.ReadOnly = true;
			this.CRD_SH.Width = 54;
			// 
			// DY_SH
			// 
			this.DY_SH.DataPropertyName = "DY_SH";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_SH.DefaultCellStyle = dataGridViewCellStyle13;
			this.DY_SH.HeaderText = "주기";
			this.DY_SH.Name = "DY_SH";
			this.DY_SH.ReadOnly = true;
			this.DY_SH.Width = 54;
			// 
			// CHK_HD
			// 
			this.CHK_HD.DataPropertyName = "CHK_HD";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_HD.DefaultCellStyle = dataGridViewCellStyle14;
			this.CHK_HD.HeaderText = "체크";
			this.CHK_HD.Name = "CHK_HD";
			this.CHK_HD.ReadOnly = true;
			this.CHK_HD.Width = 54;
			// 
			// CRD_HD
			// 
			this.CRD_HD.DataPropertyName = "CRD_HD";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_HD.DefaultCellStyle = dataGridViewCellStyle15;
			this.CRD_HD.HeaderText = "신용";
			this.CRD_HD.Name = "CRD_HD";
			this.CRD_HD.ReadOnly = true;
			this.CRD_HD.Width = 54;
			// 
			// DY_HD
			// 
			this.DY_HD.DataPropertyName = "DY_HD";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_HD.DefaultCellStyle = dataGridViewCellStyle16;
			this.DY_HD.HeaderText = "주기";
			this.DY_HD.Name = "DY_HD";
			this.DY_HD.ReadOnly = true;
			this.DY_HD.Width = 54;
			// 
			// CHK_KB
			// 
			this.CHK_KB.DataPropertyName = "CHK_KB";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_KB.DefaultCellStyle = dataGridViewCellStyle17;
			this.CHK_KB.HeaderText = "체크";
			this.CHK_KB.Name = "CHK_KB";
			this.CHK_KB.ReadOnly = true;
			this.CHK_KB.Width = 54;
			// 
			// CRD_KB
			// 
			this.CRD_KB.DataPropertyName = "CRD_KB";
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_KB.DefaultCellStyle = dataGridViewCellStyle18;
			this.CRD_KB.HeaderText = "신용";
			this.CRD_KB.Name = "CRD_KB";
			this.CRD_KB.ReadOnly = true;
			this.CRD_KB.Width = 54;
			// 
			// DY_KB
			// 
			this.DY_KB.DataPropertyName = "DY_KB";
			dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_KB.DefaultCellStyle = dataGridViewCellStyle19;
			this.DY_KB.HeaderText = "주기";
			this.DY_KB.Name = "DY_KB";
			this.DY_KB.ReadOnly = true;
			this.DY_KB.Width = 54;
			// 
			// CHK_SK
			// 
			this.CHK_SK.DataPropertyName = "CHK_SK";
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_SK.DefaultCellStyle = dataGridViewCellStyle20;
			this.CHK_SK.HeaderText = "체크";
			this.CHK_SK.Name = "CHK_SK";
			this.CHK_SK.ReadOnly = true;
			this.CHK_SK.Width = 54;
			// 
			// CRD_SK
			// 
			this.CRD_SK.DataPropertyName = "CRD_SK";
			dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_SK.DefaultCellStyle = dataGridViewCellStyle21;
			this.CRD_SK.HeaderText = "신용";
			this.CRD_SK.Name = "CRD_SK";
			this.CRD_SK.ReadOnly = true;
			this.CRD_SK.Width = 54;
			// 
			// DY_SK
			// 
			this.DY_SK.DataPropertyName = "DY_SK";
			dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_SK.DefaultCellStyle = dataGridViewCellStyle22;
			this.DY_SK.HeaderText = "주기";
			this.DY_SK.Name = "DY_SK";
			this.DY_SK.ReadOnly = true;
			this.DY_SK.Width = 54;
			// 
			// CHK_NH
			// 
			this.CHK_NH.DataPropertyName = "CHK_NH";
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_NH.DefaultCellStyle = dataGridViewCellStyle23;
			this.CHK_NH.HeaderText = "체크";
			this.CHK_NH.Name = "CHK_NH";
			this.CHK_NH.ReadOnly = true;
			this.CHK_NH.Width = 54;
			// 
			// CRD_NH
			// 
			this.CRD_NH.DataPropertyName = "CRD_NH";
			dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_NH.DefaultCellStyle = dataGridViewCellStyle24;
			this.CRD_NH.HeaderText = "신용";
			this.CRD_NH.Name = "CRD_NH";
			this.CRD_NH.ReadOnly = true;
			this.CRD_NH.Width = 54;
			// 
			// DY_NH
			// 
			this.DY_NH.DataPropertyName = "DY_NH";
			dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_NH.DefaultCellStyle = dataGridViewCellStyle25;
			this.DY_NH.HeaderText = "주기";
			this.DY_NH.Name = "DY_NH";
			this.DY_NH.ReadOnly = true;
			this.DY_NH.Width = 54;
			// 
			// CHK_FR
			// 
			this.CHK_FR.DataPropertyName = "CHK_FR";
			dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CHK_FR.DefaultCellStyle = dataGridViewCellStyle26;
			this.CHK_FR.HeaderText = "체크";
			this.CHK_FR.Name = "CHK_FR";
			this.CHK_FR.ReadOnly = true;
			this.CHK_FR.Width = 54;
			// 
			// CRD_FR
			// 
			this.CRD_FR.DataPropertyName = "CRD_FR";
			dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.CRD_FR.DefaultCellStyle = dataGridViewCellStyle27;
			this.CRD_FR.HeaderText = "신용";
			this.CRD_FR.Name = "CRD_FR";
			this.CRD_FR.ReadOnly = true;
			this.CRD_FR.Width = 54;
			// 
			// DY_FR
			// 
			this.DY_FR.DataPropertyName = "DY_FR";
			dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			this.DY_FR.DefaultCellStyle = dataGridViewCellStyle28;
			this.DY_FR.HeaderText = "주기";
			this.DY_FR.Name = "DY_FR";
			this.DY_FR.ReadOnly = true;
			this.DY_FR.Width = 54;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 98;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 98;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 98;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 98;
			// 
			// BAS0811
			// 
			this.CancelButton = this._btnClose;
			this.ClientSize = new System.Drawing.Size(583, 603);
			this.Controls.Add(this.gridView1);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "BAS0811";
			this.Text = "수수료율조정:BAS0811";
			this.Load += new System.EventHandler(this.BAS0811_Load);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.flowLayoutPanel7.ResumeLayout(false);
			this.flowLayoutPanel7.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel4.PerformLayout();
			this.flowLayoutPanel3.ResumeLayout(false);
			this.flowLayoutPanel3.PerformLayout();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			this.flowLayoutPanel5.ResumeLayout(false);
			this.flowLayoutPanel5.PerformLayout();
			this.flowLayoutPanel6.ResumeLayout(false);
			this.flowLayoutPanel6.PerformLayout();
			this.flowLayoutPanel8.ResumeLayout(false);
			this.flowLayoutPanel8.PerformLayout();
			this.flowLayoutPanel9.ResumeLayout(false);
			this.flowLayoutPanel9.PerformLayout();
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private BANANA.Windows.Controls.GroupBox groupBox1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_FR;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_FR;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_KB;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_KB;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_HD;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_HD;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_BC;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_SH;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_HD;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_KB;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_LT;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_SS;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_SH;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_LT;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_SS;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_LT;
		private BANANA.Windows.Controls.Label label13;
		private BANANA.Windows.Controls.Label lblUSR_ID;
		private BANANA.Windows.Controls.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label6;
		private BANANA.Windows.Controls.Label label5;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.Label label11;
		private BANANA.Windows.Controls.Label label12;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_BC;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_SS;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_SH;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_HD;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_KB;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_SK;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_NH;
		private BANANA.Windows.Controls.TextBox _txtFEE_CHK_FR;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_BC;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_HD;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_SH;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_KB;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_SK;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_NH;
		private BANANA.Windows.Controls.TextBox _txtFEE_CRD_FR;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_BC;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_HD;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_KB;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_SK;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_NH;
		private BANANA.Windows.Controls.TextBox _txtFEE_OVR_FR;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_LT;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_SS;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_SK;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_NH;
		private BANANA.Windows.Controls.TextBox _txtBY_DAYS_FR;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_SS;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_SS;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_BC;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_BC;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_LT;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_LT;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_SH;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_SH;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_SK;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_SK;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_Y_NH;
		private BANANA.Windows.Controls.RadioButton _rbBY_USE_N_NH;
		private DemoClient.Controls.BananaButton _btnDel;
		private DemoClient.Controls.BananaButton _btnClose;
		private DemoClient.Controls.BananaButton _btnSave;
		private DemoClient.Controls.BananaButton _btnAdd;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn BY_APP_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_BC;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_LT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_SS;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_SH;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_HD;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_KB;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_SK;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_NH;
		private System.Windows.Forms.DataGridViewTextBoxColumn CHK_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn CRD_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn DY_FR;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.Label label14;
		private BANANA.Windows.Controls.TextBox _txtMEMO;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private BANANA.Windows.Controls.Label label16;
		private BANANA.Windows.Controls.Label label15;
		private BANANA.Windows.Controls.DateTimePicker _dtpBY_APP_DT;
	}
}
