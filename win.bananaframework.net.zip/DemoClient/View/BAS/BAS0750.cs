﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient.View.BAS
{
	public partial class BAS0750 : DemoClient.Controllers.BaseForm
	{
		public BAS0750()
		{
			InitializeComponent();
		}

        private void BAS0750_Load(object sender, EventArgs e)
        {

        }
	}
}
