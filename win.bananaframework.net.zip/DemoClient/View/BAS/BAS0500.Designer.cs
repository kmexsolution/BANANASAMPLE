﻿namespace DemoClient.View.BAS
{
	partial class BAS0500
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0500));
            this.panel1 = new BANANA.Windows.Controls.Panel();
            this.groupBox2 = new BANANA.Windows.Controls.GroupBox();
            this.gridView01 = new DemoClient.Controls.GridView();
            this.MAIN_CODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CODE_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSTEMYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.삭제ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new BANANA.Windows.Controls.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this._txtCODE_NAME_S = new BANANA.Windows.Controls.TextBox();
            this._txtMAIN_CODE_S = new BANANA.Windows.Controls.TextBox();
            this.label1 = new BANANA.Windows.Controls.Label();
            this.label18 = new BANANA.Windows.Controls.Label();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this._txtCODE_NAME_S2 = new BANANA.Windows.Controls.TextBox();
            this._txtTOTAL_CODE_S = new BANANA.Windows.Controls.TextBox();
            this.label2 = new BANANA.Windows.Controls.Label();
            this.label3 = new BANANA.Windows.Controls.Label();
            this._btnSearch2 = new DemoClient.Controls.BananaButton();
            this.groupBox4 = new BANANA.Windows.Controls.GroupBox();
            this._lblInfo = new BANANA.Windows.Controls.Label();
            this._btnAdd02 = new DemoClient.Controls.BananaButton();
            this._btnSave = new DemoClient.Controls.BananaButton();
            this._btnDel = new DemoClient.Controls.BananaButton();
            this._btnAdd01 = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this._txtBIGO6 = new BANANA.Windows.Controls.TextBox();
            this._txtBIGO5 = new BANANA.Windows.Controls.TextBox();
            this._txtBIGO4 = new BANANA.Windows.Controls.TextBox();
            this._txtBIGO3 = new BANANA.Windows.Controls.TextBox();
            this._txtBIGO2 = new BANANA.Windows.Controls.TextBox();
            this._txtBIGO1 = new BANANA.Windows.Controls.TextBox();
            this._txtORDERBY = new BANANA.Windows.Controls.TextBox();
            this._txtCODE_NAME = new BANANA.Windows.Controls.TextBox();
            this._txtSUB_CODE = new BANANA.Windows.Controls.TextBox();
            this._txtMAIN_CODE = new BANANA.Windows.Controls.TextBox();
            this.label14 = new BANANA.Windows.Controls.Label();
            this.label15 = new BANANA.Windows.Controls.Label();
            this.label16 = new BANANA.Windows.Controls.Label();
            this._txtTOTAL_CODE = new BANANA.Windows.Controls.TextBox();
            this.label4 = new BANANA.Windows.Controls.Label();
            this.label10 = new BANANA.Windows.Controls.Label();
            this.label11 = new BANANA.Windows.Controls.Label();
            this.label8 = new BANANA.Windows.Controls.Label();
            this.label9 = new BANANA.Windows.Controls.Label();
            this.label5 = new BANANA.Windows.Controls.Label();
            this.label6 = new BANANA.Windows.Controls.Label();
            this.label12 = new BANANA.Windows.Controls.Label();
            this.label7 = new BANANA.Windows.Controls.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this._rbDISPLAYY = new BANANA.Windows.Controls.RadioButton();
            this._rbDISPLAYN = new BANANA.Windows.Controls.RadioButton();
            this.groupBox5 = new BANANA.Windows.Controls.GroupBox();
            this.gridView2 = new DemoClient.Controls.GridView();
            this.TOTAL_CODE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CODE_NAME2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DISPLAYYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ORDERBY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
            this.collapsibleSplitter2 = new DemoClient.Controls.CollapsibleSplitter();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView01)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 631);
            this.panel1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gridView01);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(10, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(308, 546);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "메인코드 검색 결과";
            // 
            // gridView01
            // 
            this.gridView01.AutoSelectRowWithRightButton = false;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView01.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridView01.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAIN_CODE,
            this.CODE_NAME,
            this.SYSTEMYN});
            this.gridView01.ContextMenuStrip = this.contextMenuStrip1;
            this.gridView01.DelegateProperty = true;
            this.gridView01.Location = new System.Drawing.Point(3, 17);
            this.gridView01.Name = "gridView01";
            this.gridView01.ReadOnly = true;
            this.gridView01.RowTemplate.Height = 23;
            this.gridView01.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView01.Size = new System.Drawing.Size(302, 526);
            this.gridView01.TabIndex = 0;
            this.gridView01.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
            this.gridView01.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridView1_CellMouseDown);
            // 
            // MAIN_CODE
            // 
            this.MAIN_CODE.DataPropertyName = "MAIN_CODE";
            this.MAIN_CODE.HeaderText = "메인코드";
            this.MAIN_CODE.Name = "MAIN_CODE";
            this.MAIN_CODE.ReadOnly = true;
            this.MAIN_CODE.Width = 78;
            // 
            // CODE_NAME
            // 
            this.CODE_NAME.DataPropertyName = "CODE_NAME";
            this.CODE_NAME.HeaderText = "코드명";
            this.CODE_NAME.Name = "CODE_NAME";
            this.CODE_NAME.ReadOnly = true;
            this.CODE_NAME.Width = 66;
            // 
            // SYSTEMYN
            // 
            this.SYSTEMYN.DataPropertyName = "SYSTEMYN";
            this.SYSTEMYN.HeaderText = "시스템이용여부";
            this.SYSTEMYN.Name = "SYSTEMYN";
            this.SYSTEMYN.ReadOnly = true;
            this.SYSTEMYN.Visible = false;
            this.SYSTEMYN.Width = 109;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.삭제ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(99, 26);
            // 
            // 삭제ToolStripMenuItem
            // 
            this.삭제ToolStripMenuItem.Name = "삭제ToolStripMenuItem";
            this.삭제ToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.삭제ToolStripMenuItem.Text = "삭제";
            this.삭제ToolStripMenuItem.Click += new System.EventHandler(this.삭제ToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(10, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(308, 75);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "메인코드 검색 조건";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this._txtCODE_NAME_S, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this._txtMAIN_CODE_S, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label18, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this._btnSearch, 2, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(302, 55);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // _txtCODE_NAME_S
            // 
            this._txtCODE_NAME_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCODE_NAME_S.AutoTab = false;
            this._txtCODE_NAME_S.DelegateProperty = true;
            this._txtCODE_NAME_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCODE_NAME_S.Location = new System.Drawing.Point(93, 31);
            this._txtCODE_NAME_S.Name = "_txtCODE_NAME_S";
            this._txtCODE_NAME_S.Size = new System.Drawing.Size(130, 20);
            this._txtCODE_NAME_S.TabIndex = 110;
            this._txtCODE_NAME_S.ValidationGroup = null;
            this._txtCODE_NAME_S.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtCODE_NAME_S.WaterMarkText = "";
            this._txtCODE_NAME_S.KeyDown += new System.Windows.Forms.KeyEventHandler(this._txtMAIN_CODE_S_KeyDown);
            // 
            // _txtMAIN_CODE_S
            // 
            this._txtMAIN_CODE_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtMAIN_CODE_S.AutoTab = false;
            this._txtMAIN_CODE_S.DelegateProperty = true;
            this._txtMAIN_CODE_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtMAIN_CODE_S.Location = new System.Drawing.Point(93, 3);
            this._txtMAIN_CODE_S.Name = "_txtMAIN_CODE_S";
            this._txtMAIN_CODE_S.Size = new System.Drawing.Size(130, 20);
            this._txtMAIN_CODE_S.TabIndex = 100;
            this._txtMAIN_CODE_S.ValidationGroup = null;
            this._txtMAIN_CODE_S.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtMAIN_CODE_S.WaterMarkText = "";
            this._txtMAIN_CODE_S.KeyDown += new System.Windows.Forms.KeyEventHandler(this._txtMAIN_CODE_S_KeyDown);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "메인코드";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(46, 35);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 303;
            this.label18.Text = "코드명";
            // 
            // _btnSearch
            // 
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(230, 2);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Reserved = "      검   색";
            this.tableLayoutPanel3.SetRowSpan(this._btnSearch, 2);
            this._btnSearch.Size = new System.Drawing.Size(75, 23);
            this._btnSearch.TabIndex = 120;
            this._btnSearch.Text = "      검   색";
            this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(336, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(821, 75);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "상세코드 검색 조건";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this._txtCODE_NAME_S2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtTOTAL_CODE_S, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this._btnSearch2, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(815, 55);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // _txtCODE_NAME_S2
            // 
            this._txtCODE_NAME_S2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCODE_NAME_S2.AutoTab = false;
            this._txtCODE_NAME_S2.DelegateProperty = true;
            this._txtCODE_NAME_S2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCODE_NAME_S2.Location = new System.Drawing.Point(93, 31);
            this._txtCODE_NAME_S2.Name = "_txtCODE_NAME_S2";
            this._txtCODE_NAME_S2.ReadOnly = true;
            this._txtCODE_NAME_S2.Size = new System.Drawing.Size(130, 20);
            this._txtCODE_NAME_S2.TabIndex = 110;
            this._txtCODE_NAME_S2.ValidationGroup = null;
            this._txtCODE_NAME_S2.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtCODE_NAME_S2.WaterMarkText = "";
            this._txtCODE_NAME_S2.KeyDown += new System.Windows.Forms.KeyEventHandler(this._txtTOTAL_CODE_S_KeyDown);
            // 
            // _txtTOTAL_CODE_S
            // 
            this._txtTOTAL_CODE_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTOTAL_CODE_S.AutoTab = false;
            this._txtTOTAL_CODE_S.DelegateProperty = true;
            this._txtTOTAL_CODE_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTOTAL_CODE_S.Location = new System.Drawing.Point(93, 3);
            this._txtTOTAL_CODE_S.Name = "_txtTOTAL_CODE_S";
            this._txtTOTAL_CODE_S.ReadOnly = true;
            this._txtTOTAL_CODE_S.Size = new System.Drawing.Size(130, 20);
            this._txtTOTAL_CODE_S.TabIndex = 100;
            this._txtTOTAL_CODE_S.ValidationGroup = null;
            this._txtTOTAL_CODE_S.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtTOTAL_CODE_S.WaterMarkText = "";
            this._txtTOTAL_CODE_S.KeyDown += new System.Windows.Forms.KeyEventHandler(this._txtTOTAL_CODE_S_KeyDown);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "공통코드";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 303;
            this.label3.Text = "코드명";
            // 
            // _btnSearch2
            // 
            this._btnSearch2.DelegateProperty = true;
            this._btnSearch2.Enabled = false;
            this._btnSearch2.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch2.Location = new System.Drawing.Point(230, 2);
            this._btnSearch2.Margin = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this._btnSearch2.Name = "_btnSearch2";
            this._btnSearch2.Reserved = "      검   색";
            this.tableLayoutPanel1.SetRowSpan(this._btnSearch2, 2);
            this._btnSearch2.Size = new System.Drawing.Size(75, 23);
            this._btnSearch2.TabIndex = 120;
            this._btnSearch2.Text = "      검   색";
            this._btnSearch2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch2.UseVisualStyleBackColor = true;
            this._btnSearch2.ValidationGroup = null;
            this._btnSearch2.Click += new System.EventHandler(this._btnSearch2_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this._lblInfo);
            this.groupBox4.Controls.Add(this._btnAdd02);
            this.groupBox4.Controls.Add(this._btnSave);
            this.groupBox4.Controls.Add(this._btnDel);
            this.groupBox4.Controls.Add(this._btnAdd01);
            this.groupBox4.Controls.Add(this.tableLayoutPanel2);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox4.Location = new System.Drawing.Point(689, 75);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(468, 556);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "상세 정보";
            // 
            // _lblInfo
            // 
            this._lblInfo.AutoSize = true;
            this._lblInfo.Location = new System.Drawing.Point(6, 224);
            this._lblInfo.Name = "_lblInfo";
            this._lblInfo.Size = new System.Drawing.Size(469, 12);
            this._lblInfo.TabIndex = 1142;
            this._lblInfo.Text = "시스템에서 사용하는 공통코드의 경우에는 저장 및 삭제 버튼이 활성화 되지 않습니다.";
            this._lblInfo.Visible = false;
            // 
            // _btnAdd02
            // 
            this._btnAdd02.DelegateProperty = true;
            this._btnAdd02.Enabled = false;
            this._btnAdd02.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd02.Location = new System.Drawing.Point(190, 184);
            this._btnAdd02.Name = "_btnAdd02";
            this._btnAdd02.Reserved = "      상세코드 추가";
            this._btnAdd02.Size = new System.Drawing.Size(104, 27);
            this._btnAdd02.TabIndex = 1141;
            this._btnAdd02.Text = "      상세코드 추가";
            this._btnAdd02.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd02.UseVisualStyleBackColor = true;
            this._btnAdd02.ValidationGroup = null;
            this._btnAdd02.Click += new System.EventHandler(this._btnAdd02_Click);
            // 
            // _btnSave
            // 
            this._btnSave.ButtonConfirm = true;
            this._btnSave.DelegateProperty = true;
            this._btnSave.Enabled = false;
            this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave.Location = new System.Drawing.Point(300, 184);
            this._btnSave.Name = "_btnSave";
            this._btnSave.Reserved = "      저   장";
            this._btnSave.Size = new System.Drawing.Size(75, 27);
            this._btnSave.TabIndex = 1130;
            this._btnSave.Text = "      저   장";
            this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave.UseVisualStyleBackColor = true;
            this._btnSave.ValidationGroup = "a";
            this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
            // 
            // _btnDel
            // 
            this._btnDel.ButtonConfirm = true;
            this._btnDel.DelegateProperty = true;
            this._btnDel.Enabled = false;
            this._btnDel.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel.Location = new System.Drawing.Point(381, 184);
            this._btnDel.Name = "_btnDel";
            this._btnDel.Reserved = "      삭   제";
            this._btnDel.Size = new System.Drawing.Size(75, 27);
            this._btnDel.TabIndex = 1140;
            this._btnDel.Text = "      삭   제";
            this._btnDel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel.UseVisualStyleBackColor = true;
            this._btnDel.ValidationGroup = null;
            this._btnDel.Click += new System.EventHandler(this._btnDel_Click);
            // 
            // _btnAdd01
            // 
            this._btnAdd01.DelegateProperty = true;
            this._btnAdd01.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.Location = new System.Drawing.Point(80, 184);
            this._btnAdd01.Name = "_btnAdd01";
            this._btnAdd01.Reserved = "      메인코드 추가";
            this._btnAdd01.Size = new System.Drawing.Size(104, 27);
            this._btnAdd01.TabIndex = 1120;
            this._btnAdd01.Text = "      메인코드 추가";
            this._btnAdd01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.UseVisualStyleBackColor = true;
            this._btnAdd01.ValidationGroup = null;
            this._btnAdd01.Click += new System.EventHandler(this._btnAdd01_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel2.Controls.Add(this._txtBIGO6, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this._txtBIGO5, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this._txtBIGO4, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this._txtBIGO3, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this._txtBIGO2, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this._txtBIGO1, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this._txtORDERBY, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this._txtCODE_NAME, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this._txtSUB_CODE, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this._txtMAIN_CODE, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.label15, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label16, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this._txtTOTAL_CODE, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label10, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label9, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label5, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label7, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel1, 1, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(462, 162);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // _txtBIGO6
            // 
            this._txtBIGO6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBIGO6.DelegateProperty = true;
            this._txtBIGO6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBIGO6.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
            this._txtBIGO6.Location = new System.Drawing.Point(323, 138);
            this._txtBIGO6.Name = "_txtBIGO6";
            this._txtBIGO6.ReadOnly = true;
            this._txtBIGO6.Size = new System.Drawing.Size(130, 20);
            this._txtBIGO6.TabIndex = 1110;
            this._txtBIGO6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtBIGO6.ValidationGroup = null;
            this._txtBIGO6.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtBIGO6.WaterMarkText = "";
            // 
            // _txtBIGO5
            // 
            this._txtBIGO5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBIGO5.DelegateProperty = true;
            this._txtBIGO5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBIGO5.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
            this._txtBIGO5.Location = new System.Drawing.Point(93, 138);
            this._txtBIGO5.Name = "_txtBIGO5";
            this._txtBIGO5.ReadOnly = true;
            this._txtBIGO5.Size = new System.Drawing.Size(130, 20);
            this._txtBIGO5.TabIndex = 1100;
            this._txtBIGO5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtBIGO5.ValidationGroup = null;
            this._txtBIGO5.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtBIGO5.WaterMarkText = "";
            // 
            // _txtBIGO4
            // 
            this._txtBIGO4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBIGO4.DelegateProperty = true;
            this._txtBIGO4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBIGO4.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
            this._txtBIGO4.Location = new System.Drawing.Point(323, 111);
            this._txtBIGO4.Name = "_txtBIGO4";
            this._txtBIGO4.ReadOnly = true;
            this._txtBIGO4.Size = new System.Drawing.Size(130, 20);
            this._txtBIGO4.TabIndex = 1090;
            this._txtBIGO4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtBIGO4.ValidationGroup = null;
            this._txtBIGO4.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtBIGO4.WaterMarkText = "";
            // 
            // _txtBIGO3
            // 
            this._txtBIGO3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBIGO3.DelegateProperty = true;
            this._txtBIGO3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBIGO3.Location = new System.Drawing.Point(93, 111);
            this._txtBIGO3.Name = "_txtBIGO3";
            this._txtBIGO3.ReadOnly = true;
            this._txtBIGO3.Size = new System.Drawing.Size(130, 20);
            this._txtBIGO3.TabIndex = 1080;
            this._txtBIGO3.ValidationGroup = null;
            this._txtBIGO3.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtBIGO3.WaterMarkText = "";
            // 
            // _txtBIGO2
            // 
            this._txtBIGO2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBIGO2.DelegateProperty = true;
            this._txtBIGO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBIGO2.Location = new System.Drawing.Point(323, 84);
            this._txtBIGO2.Name = "_txtBIGO2";
            this._txtBIGO2.ReadOnly = true;
            this._txtBIGO2.Size = new System.Drawing.Size(130, 20);
            this._txtBIGO2.TabIndex = 1070;
            this._txtBIGO2.ValidationGroup = null;
            this._txtBIGO2.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtBIGO2.WaterMarkText = "";
            // 
            // _txtBIGO1
            // 
            this._txtBIGO1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtBIGO1.DelegateProperty = true;
            this._txtBIGO1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtBIGO1.Location = new System.Drawing.Point(93, 84);
            this._txtBIGO1.Name = "_txtBIGO1";
            this._txtBIGO1.ReadOnly = true;
            this._txtBIGO1.Size = new System.Drawing.Size(130, 20);
            this._txtBIGO1.TabIndex = 1060;
            this._txtBIGO1.ValidationGroup = null;
            this._txtBIGO1.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtBIGO1.WaterMarkText = "";
            // 
            // _txtORDERBY
            // 
            this._txtORDERBY.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtORDERBY.DelegateProperty = true;
            this._txtORDERBY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtORDERBY.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtORDERBY.Location = new System.Drawing.Point(323, 57);
            this._txtORDERBY.Name = "_txtORDERBY";
            this._txtORDERBY.ReadOnly = true;
            this._txtORDERBY.Size = new System.Drawing.Size(130, 20);
            this._txtORDERBY.TabIndex = 1050;
            this._txtORDERBY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtORDERBY.ValidationGroup = null;
            this._txtORDERBY.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtORDERBY.WaterMarkText = "";
            // 
            // _txtCODE_NAME
            // 
            this._txtCODE_NAME.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCODE_NAME.Compulsory = true;
            this._txtCODE_NAME.DelegateProperty = true;
            this._txtCODE_NAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCODE_NAME.Location = new System.Drawing.Point(323, 30);
            this._txtCODE_NAME.Name = "_txtCODE_NAME";
            this._txtCODE_NAME.ReadOnly = true;
            this._txtCODE_NAME.Size = new System.Drawing.Size(130, 20);
            this._txtCODE_NAME.TabIndex = 1030;
            this._txtCODE_NAME.ValidationGroup = "a";
            this._txtCODE_NAME.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCODE_NAME.WaterMarkText = "";
            // 
            // _txtSUB_CODE
            // 
            this._txtSUB_CODE.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSUB_CODE.DelegateProperty = true;
            this._txtSUB_CODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSUB_CODE.Location = new System.Drawing.Point(93, 30);
            this._txtSUB_CODE.Name = "_txtSUB_CODE";
            this._txtSUB_CODE.ReadOnly = true;
            this._txtSUB_CODE.Size = new System.Drawing.Size(130, 20);
            this._txtSUB_CODE.TabIndex = 1020;
            this._txtSUB_CODE.TabStop = false;
            this._txtSUB_CODE.ValidationGroup = null;
            this._txtSUB_CODE.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtSUB_CODE.WaterMarkText = "";
            // 
            // _txtMAIN_CODE
            // 
            this._txtMAIN_CODE.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtMAIN_CODE.DelegateProperty = true;
            this._txtMAIN_CODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtMAIN_CODE.Location = new System.Drawing.Point(323, 3);
            this._txtMAIN_CODE.Name = "_txtMAIN_CODE";
            this._txtMAIN_CODE.ReadOnly = true;
            this._txtMAIN_CODE.Size = new System.Drawing.Size(130, 20);
            this._txtMAIN_CODE.TabIndex = 1010;
            this._txtMAIN_CODE.TabStop = false;
            this._txtMAIN_CODE.ValidationGroup = null;
            this._txtMAIN_CODE.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtMAIN_CODE.WaterMarkText = "";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(282, 142);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 20;
            this.label14.Text = "비고6";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(52, 142);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 12);
            this.label15.TabIndex = 21;
            this.label15.Text = "비고5";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(264, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 22;
            this.label16.Text = "메인코드";
            // 
            // _txtTOTAL_CODE
            // 
            this._txtTOTAL_CODE.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTOTAL_CODE.DelegateProperty = true;
            this._txtTOTAL_CODE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTOTAL_CODE.Location = new System.Drawing.Point(93, 3);
            this._txtTOTAL_CODE.Name = "_txtTOTAL_CODE";
            this._txtTOTAL_CODE.ReadOnly = true;
            this._txtTOTAL_CODE.Size = new System.Drawing.Size(130, 20);
            this._txtTOTAL_CODE.TabIndex = 1000;
            this._txtTOTAL_CODE.TabStop = false;
            this._txtTOTAL_CODE.ValidationGroup = null;
            this._txtTOTAL_CODE.WaterMarkColor = System.Drawing.Color.Empty;
            this._txtTOTAL_CODE.WaterMarkText = "";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "공통코드";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(282, 115);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 16;
            this.label10.Text = "비고4";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 17;
            this.label11.Text = "사용여부";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(52, 115);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "비고3";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(288, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 15;
            this.label9.Text = "순서";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(282, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "비고2";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(52, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "비고1";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 18;
            this.label12.Text = "서브코드";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(276, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 13;
            this.label7.Text = "코드명";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this._rbDISPLAYY);
            this.flowLayoutPanel1.Controls.Add(this._rbDISPLAYN);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(90, 54);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(140, 27);
            this.flowLayoutPanel1.TabIndex = 1040;
            // 
            // _rbDISPLAYY
            // 
            this._rbDISPLAYY.AutoSize = true;
            this._rbDISPLAYY.Checked = true;
            this._rbDISPLAYY.DelegateProperty = true;
            this._rbDISPLAYY.Enabled = false;
            this._rbDISPLAYY.Location = new System.Drawing.Point(3, 6);
            this._rbDISPLAYY.Name = "_rbDISPLAYY";
            this._rbDISPLAYY.Size = new System.Drawing.Size(31, 16);
            this._rbDISPLAYY.TabIndex = 10;
            this._rbDISPLAYY.TabStop = true;
            this._rbDISPLAYY.Text = "Y";
            this._rbDISPLAYY.UseVisualStyleBackColor = true;
            // 
            // _rbDISPLAYN
            // 
            this._rbDISPLAYN.AutoSize = true;
            this._rbDISPLAYN.DelegateProperty = true;
            this._rbDISPLAYN.Enabled = false;
            this._rbDISPLAYN.Location = new System.Drawing.Point(40, 6);
            this._rbDISPLAYN.Name = "_rbDISPLAYN";
            this._rbDISPLAYN.Size = new System.Drawing.Size(32, 16);
            this._rbDISPLAYN.TabIndex = 20;
            this._rbDISPLAYN.Text = "N";
            this._rbDISPLAYN.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.gridView2);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(336, 75);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(345, 556);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "상세코드 검색 결과";
            // 
            // gridView2
            // 
            this.gridView2.AutoSelectRowWithRightButton = false;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TOTAL_CODE,
            this.CODE_NAME2,
            this.DISPLAYYN,
            this.ORDERBY,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME});
            this.gridView2.DelegateProperty = true;
            this.gridView2.Location = new System.Drawing.Point(3, 17);
            this.gridView2.Name = "gridView2";
            this.gridView2.ReadOnly = true;
            this.gridView2.RowTemplate.Height = 23;
            this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView2.Size = new System.Drawing.Size(339, 536);
            this.gridView2.TabIndex = 1;
            this.gridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView2_CellClick);
            // 
            // TOTAL_CODE
            // 
            this.TOTAL_CODE.DataPropertyName = "TOTAL_CODE";
            this.TOTAL_CODE.HeaderText = "공통코드";
            this.TOTAL_CODE.Name = "TOTAL_CODE";
            this.TOTAL_CODE.ReadOnly = true;
            this.TOTAL_CODE.Width = 78;
            // 
            // CODE_NAME2
            // 
            this.CODE_NAME2.DataPropertyName = "CODE_NAME";
            this.CODE_NAME2.HeaderText = "코드명";
            this.CODE_NAME2.Name = "CODE_NAME2";
            this.CODE_NAME2.ReadOnly = true;
            this.CODE_NAME2.Width = 66;
            // 
            // DISPLAYYN
            // 
            this.DISPLAYYN.DataPropertyName = "DISPLAYYN";
            this.DISPLAYYN.HeaderText = "사용여부";
            this.DISPLAYYN.Name = "DISPLAYYN";
            this.DISPLAYYN.ReadOnly = true;
            this.DISPLAYYN.Width = 78;
            // 
            // ORDERBY
            // 
            this.ORDERBY.DataPropertyName = "ORDERBY";
            this.ORDERBY.HeaderText = "순서";
            this.ORDERBY.Name = "ORDERBY";
            this.ORDERBY.ReadOnly = true;
            this.ORDERBY.Width = 54;
            // 
            // SYSREGDATE
            // 
            this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE.HeaderText = "시스템등록일";
            this.SYSREGDATE.Name = "SYSREGDATE";
            this.SYSREGDATE.ReadOnly = true;
            this.SYSREGDATE.Width = 102;
            // 
            // SYSREGNAME
            // 
            this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME.HeaderText = "시스템등록자";
            this.SYSREGNAME.Name = "SYSREGNAME";
            this.SYSREGNAME.ReadOnly = true;
            this.SYSREGNAME.Width = 102;
            // 
            // SYSMODDATE
            // 
            this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE.HeaderText = "시스템수정일";
            this.SYSMODDATE.Name = "SYSMODDATE";
            this.SYSMODDATE.ReadOnly = true;
            this.SYSMODDATE.Width = 102;
            // 
            // SYSMODNAME
            // 
            this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME.HeaderText = "시스템수정자";
            this.SYSMODNAME.Name = "SYSMODNAME";
            this.SYSMODNAME.ReadOnly = true;
            this.SYSMODNAME.Width = 102;
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.AnimationDelay = 20;
            this.collapsibleSplitter1.AnimationStep = 20;
            this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter1.ControlToHide = this.groupBox4;
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.collapsibleSplitter1.ExpandParentForm = false;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(681, 75);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.TabIndex = 4;
            this.collapsibleSplitter1.TabStop = false;
            this.collapsibleSplitter1.UseAnimations = false;
            this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
            // 
            // collapsibleSplitter2
            // 
            this.collapsibleSplitter2.AnimationDelay = 20;
            this.collapsibleSplitter2.AnimationStep = 20;
            this.collapsibleSplitter2.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter2.ControlToHide = this.panel1;
            this.collapsibleSplitter2.ExpandParentForm = false;
            this.collapsibleSplitter2.Location = new System.Drawing.Point(328, 0);
            this.collapsibleSplitter2.Name = "collapsibleSplitter2";
            this.collapsibleSplitter2.TabIndex = 6;
            this.collapsibleSplitter2.TabStop = false;
            this.collapsibleSplitter2.UseAnimations = false;
            this.collapsibleSplitter2.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            this.collapsibleSplitter2.DoubleClick += new System.EventHandler(this.collapsibleSplitter2_DoubleClick);
            // 
            // BAS0500
            // 
            this.ClientSize = new System.Drawing.Size(1157, 631);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.collapsibleSplitter1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.collapsibleSplitter2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BAS0500";
            this.Text = "공통코드관리:BAS0500";
            this.Load += new System.EventHandler(this.BAS0500_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView01)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private BANANA.Windows.Controls.Panel panel1;
		private BANANA.Windows.Controls.GroupBox groupBox1;
		private BANANA.Windows.Controls.GroupBox groupBox2;
		private BANANA.Windows.Controls.GroupBox groupBox3;
		private BANANA.Windows.Controls.GroupBox groupBox4;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
		private BANANA.Windows.Controls.GroupBox groupBox5;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter2;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
		private BANANA.Windows.Controls.Label label1;
		private BANANA.Windows.Controls.Label label18;
		private DemoClient.Controls.BananaButton _btnSearch;
		private BANANA.Windows.Controls.TextBox _txtCODE_NAME_S;
		private BANANA.Windows.Controls.TextBox _txtMAIN_CODE_S;
		private DemoClient.Controls.GridView gridView2;
		private System.Windows.Forms.DataGridViewTextBoxColumn TOTAL_CODE;
		private System.Windows.Forms.DataGridViewTextBoxColumn CODE_NAME2;
		private System.Windows.Forms.DataGridViewTextBoxColumn DISPLAYYN;
		private System.Windows.Forms.DataGridViewTextBoxColumn ORDERBY;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private BANANA.Windows.Controls.TextBox _txtCODE_NAME_S2;
		private BANANA.Windows.Controls.TextBox _txtTOTAL_CODE_S;
		private BANANA.Windows.Controls.Label label2;
		private BANANA.Windows.Controls.Label label3;
		private DemoClient.Controls.BananaButton _btnSearch2;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private BANANA.Windows.Controls.TextBox _txtTOTAL_CODE;
		private BANANA.Windows.Controls.Label label4;
		private BANANA.Windows.Controls.Label label16;
		private BANANA.Windows.Controls.Label label15;
		private BANANA.Windows.Controls.Label label14;
		private BANANA.Windows.Controls.Label label12;
		private BANANA.Windows.Controls.Label label11;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.Label label9;
		private BANANA.Windows.Controls.Label label8;
		private BANANA.Windows.Controls.Label label7;
		private BANANA.Windows.Controls.Label label6;
		private BANANA.Windows.Controls.Label label5;
		private BANANA.Windows.Controls.TextBox _txtBIGO6;
		private BANANA.Windows.Controls.TextBox _txtBIGO5;
		private BANANA.Windows.Controls.TextBox _txtBIGO4;
		private BANANA.Windows.Controls.TextBox _txtBIGO3;
		private BANANA.Windows.Controls.TextBox _txtBIGO2;
		private BANANA.Windows.Controls.TextBox _txtBIGO1;
		private BANANA.Windows.Controls.TextBox _txtORDERBY;
		private BANANA.Windows.Controls.TextBox _txtCODE_NAME;
		private BANANA.Windows.Controls.TextBox _txtSUB_CODE;
		private BANANA.Windows.Controls.TextBox _txtMAIN_CODE;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.RadioButton _rbDISPLAYY;
		private BANANA.Windows.Controls.RadioButton _rbDISPLAYN;
		private DemoClient.Controls.BananaButton _btnSave;
		private DemoClient.Controls.BananaButton _btnDel;
		private DemoClient.Controls.BananaButton _btnAdd01;
		private DemoClient.Controls.BananaButton _btnAdd02;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem 삭제ToolStripMenuItem;
		private BANANA.Windows.Controls.Label _lblInfo;
        private Controls.GridView gridView01;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAIN_CODE;
        private System.Windows.Forms.DataGridViewTextBoxColumn CODE_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSTEMYN;
    }
}
