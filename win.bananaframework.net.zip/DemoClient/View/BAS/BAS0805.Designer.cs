﻿namespace DemoClient.View.BAS
{
	partial class BAS0805
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0805));
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.PRSNT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_CNTR_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_CNTR_END_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_WTHR_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_SVC_STAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_WTHR_STAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_UNIT_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_DAILY_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_TOT_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_LN_RATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_LN_OVD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LIVEWDRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_AGT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_APP_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band01 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CI_RDM_BNK_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_RDM_ACCT_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_RDM_ACCT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Band02 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CI_PAY_BNK_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_PAY_ACCT_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_PAY_ACCT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
			this.panel1 = new BANANA.Windows.Controls.Panel();
			this.groupBox4 = new BANANA.Windows.Controls.GroupBox();
			this._btnSave02 = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.label22 = new BANANA.Windows.Controls.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new BANANA.Windows.Controls.Label();
			this.label20 = new BANANA.Windows.Controls.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.label27 = new BANANA.Windows.Controls.Label();
			this._cmbCI_RDM_BNK_CD = new BANANA.Windows.Controls.ComboBox();
			this._cmbCI_PAY_BNK_CD = new BANANA.Windows.Controls.ComboBox();
			this._txtCI_RDM_ACCT_NO = new BANANA.Windows.Controls.TextBox();
			this._txtCI_PAY_ACCT_NO = new BANANA.Windows.Controls.TextBox();
			this._txtCI_RDM_ACCT_NM = new BANANA.Windows.Controls.TextBox();
			this._txtCI_PAY_ACCT_NM = new BANANA.Windows.Controls.TextBox();
			this.groupBox5 = new BANANA.Windows.Controls.GroupBox();
			this._btnSave03 = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._txtCI_LN_OVD = new BANANA.Windows.Controls.TextBox();
			this.label18 = new BANANA.Windows.Controls.Label();
			this.label16 = new BANANA.Windows.Controls.Label();
			this._dtpCI_APP_DT = new BANANA.Windows.Controls.DateTimePicker();
			this.label11 = new BANANA.Windows.Controls.Label();
			this.label13 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this._txtCI_LN_RATE = new BANANA.Windows.Controls.TextBox();
			this.label6 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbCI_LN_GUBUN01 = new BANANA.Windows.Controls.RadioButton();
			this._rbCI_LN_GUBUN02 = new BANANA.Windows.Controls.RadioButton();
			this.label10 = new BANANA.Windows.Controls.Label();
			this._cmbCI_LNR_CD = new BANANA.Windows.Controls.ComboBox();
			this.label9 = new BANANA.Windows.Controls.Label();
			this.label12 = new BANANA.Windows.Controls.Label();
			this._cmbCI_AGT_CD = new BANANA.Windows.Controls.ComboBox();
			this._btnRate = new DemoClient.Controls.BananaButton();
			this.groupBox6 = new BANANA.Windows.Controls.GroupBox();
			this._btnLimit = new DemoClient.Controls.BananaButton();
			this._btnSave04 = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
			this._dtpCI_LMT_APP_DT = new BANANA.Windows.Controls.DateTimePicker();
			this._txtCI_TOT_LMT = new BANANA.Windows.Controls.TextBox();
			this.label19 = new BANANA.Windows.Controls.Label();
			this.label21 = new BANANA.Windows.Controls.Label();
			this.label25 = new BANANA.Windows.Controls.Label();
			this.label4 = new System.Windows.Forms.Label();
			this._txtCI_DAILY_LMT = new BANANA.Windows.Controls.TextBox();
			this._txtCI_UNIT_LMT = new BANANA.Windows.Controls.TextBox();
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this._btnSave01 = new DemoClient.Controls.BananaButton();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
			this._rbCI_WTHR_TYPE_Y = new BANANA.Windows.Controls.RadioButton();
			this._rbCI_WTHR_TYPE_T = new BANANA.Windows.Controls.RadioButton();
			this._rbCI_WTHR_TYPE_E = new BANANA.Windows.Controls.RadioButton();
			this.label15 = new BANANA.Windows.Controls.Label();
			this._txtCI_ACCOUNT_FEE = new BANANA.Windows.Controls.TextBox();
			this.label14 = new BANANA.Windows.Controls.Label();
			this._txtCI_BZL_PER = new BANANA.Windows.Controls.TextBox();
			this.label28 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._chkCI_USE_INSRNC = new BANANA.Windows.Controls.CheckBox();
			this._chkCI_USE_BLNC = new BANANA.Windows.Controls.CheckBox();
			this._chkCI_USE_SRT = new BANANA.Windows.Controls.CheckBox();
			this.label3 = new BANANA.Windows.Controls.Label();
			this._txtPRSNT_NM = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM = new BANANA.Windows.Controls.TextBox();
			this.label8 = new BANANA.Windows.Controls.Label();
			this.label7 = new BANANA.Windows.Controls.Label();
			this._txtSTR_CD = new BANANA.Windows.Controls.TextBox();
			this.label5 = new BANANA.Windows.Controls.Label();
			this.lblUSR_ID = new BANANA.Windows.Controls.Label();
			this._cmbCI_SVC_STAT = new BANANA.Windows.Controls.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this._cmbCI_WTHR_STAT = new BANANA.Windows.Controls.ComboBox();
			this.lblCOMPANY_CD = new BANANA.Windows.Controls.Label();
			this._dtpCI_CNTR_STRT_DT = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new System.Windows.Forms.Label();
			this._dtpCI_CNTR_END_DT = new BANANA.Windows.Controls.DateTimePicker();
			this.lblUSR_PASS = new BANANA.Windows.Controls.Label();
			this._dtpCI_WTHR_STRT_DT = new BANANA.Windows.Controls.DateTimePicker();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
			this._cmbCI_SVC_STAT_S = new BANANA.Windows.Controls.ComboBox();
			this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._cmbCI_WTHR_STAT_S = new BANANA.Windows.Controls.ComboBox();
			this._txtPRSNT_NM_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label39 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this.label38 = new BANANA.Windows.Controls.Label();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.panel1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.tableLayoutPanel3.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel3.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.tableLayoutPanel4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.gridView1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.Location = new System.Drawing.Point(0, 76);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(636, 657);
			this.groupBox2.TabIndex = 6;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STR_CD,
            this.STR_NM,
            this.PRSNT_NM,
            this.CI_CNTR_STRT_DT,
            this.CI_CNTR_END_DT,
            this.CI_WTHR_STRT_DT,
            this.CI_SVC_STAT,
            this.CI_WTHR_STAT,
            this.CI_UNIT_LMT,
            this.CI_DAILY_LMT,
            this.CI_TOT_LMT,
            this.CI_LN_RATE,
            this.CI_LN_OVD,
            this.LIVEWDRAMT,
            this.CI_AGT_NM,
            this.CI_APP_DT,
            this.Band01,
            this.CI_RDM_BNK_NM,
            this.CI_RDM_ACCT_NO,
            this.CI_RDM_ACCT_NM,
            this.Band02,
            this.CI_PAY_BNK_NM,
            this.CI_PAY_ACCT_NO,
            this.CI_PAY_ACCT_NM,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 21);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(630, 633);
			this.gridView1.TabIndex = 1;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			this.gridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellDoubleClick);
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.Frozen = true;
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 108;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 94;
			// 
			// PRSNT_NM
			// 
			this.PRSNT_NM.DataPropertyName = "PRSNT_NM";
			this.PRSNT_NM.Frozen = true;
			this.PRSNT_NM.HeaderText = "대표자명";
			this.PRSNT_NM.Name = "PRSNT_NM";
			this.PRSNT_NM.ReadOnly = true;
			this.PRSNT_NM.Width = 94;
			// 
			// CI_CNTR_STRT_DT
			// 
			this.CI_CNTR_STRT_DT.DataPropertyName = "CI_CNTR_STRT_DT";
			this.CI_CNTR_STRT_DT.HeaderText = "계약일자";
			this.CI_CNTR_STRT_DT.Name = "CI_CNTR_STRT_DT";
			this.CI_CNTR_STRT_DT.ReadOnly = true;
			this.CI_CNTR_STRT_DT.Width = 94;
			// 
			// CI_CNTR_END_DT
			// 
			this.CI_CNTR_END_DT.DataPropertyName = "CI_CNTR_END_DT";
			this.CI_CNTR_END_DT.HeaderText = "해지일자";
			this.CI_CNTR_END_DT.Name = "CI_CNTR_END_DT";
			this.CI_CNTR_END_DT.ReadOnly = true;
			this.CI_CNTR_END_DT.Width = 94;
			// 
			// CI_WTHR_STRT_DT
			// 
			this.CI_WTHR_STRT_DT.DataPropertyName = "CI_WTHR_STRT_DT";
			this.CI_WTHR_STRT_DT.HeaderText = "출금시작일자";
			this.CI_WTHR_STRT_DT.Name = "CI_WTHR_STRT_DT";
			this.CI_WTHR_STRT_DT.ReadOnly = true;
			this.CI_WTHR_STRT_DT.Width = 122;
			// 
			// CI_SVC_STAT
			// 
			this.CI_SVC_STAT.DataPropertyName = "CI_SVC_STAT";
			this.CI_SVC_STAT.HeaderText = "서비스상태";
			this.CI_SVC_STAT.Name = "CI_SVC_STAT";
			this.CI_SVC_STAT.ReadOnly = true;
			this.CI_SVC_STAT.Width = 108;
			// 
			// CI_WTHR_STAT
			// 
			this.CI_WTHR_STAT.DataPropertyName = "CI_WTHR_STAT";
			this.CI_WTHR_STAT.HeaderText = "출금상태";
			this.CI_WTHR_STAT.Name = "CI_WTHR_STAT";
			this.CI_WTHR_STAT.ReadOnly = true;
			this.CI_WTHR_STAT.Width = 94;
			// 
			// CI_UNIT_LMT
			// 
			this.CI_UNIT_LMT.DataPropertyName = "CI_UNIT_LMT";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.Format = "N0";
			dataGridViewCellStyle2.NullValue = "0";
			this.CI_UNIT_LMT.DefaultCellStyle = dataGridViewCellStyle2;
			this.CI_UNIT_LMT.HeaderText = "건별대출한도";
			this.CI_UNIT_LMT.Name = "CI_UNIT_LMT";
			this.CI_UNIT_LMT.ReadOnly = true;
			this.CI_UNIT_LMT.Width = 122;
			// 
			// CI_DAILY_LMT
			// 
			this.CI_DAILY_LMT.DataPropertyName = "CI_DAILY_LMT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			dataGridViewCellStyle3.NullValue = "0";
			this.CI_DAILY_LMT.DefaultCellStyle = dataGridViewCellStyle3;
			this.CI_DAILY_LMT.HeaderText = "1일대출한도";
			this.CI_DAILY_LMT.Name = "CI_DAILY_LMT";
			this.CI_DAILY_LMT.ReadOnly = true;
			this.CI_DAILY_LMT.Width = 116;
			// 
			// CI_TOT_LMT
			// 
			this.CI_TOT_LMT.DataPropertyName = "CI_TOT_LMT";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = "0";
			this.CI_TOT_LMT.DefaultCellStyle = dataGridViewCellStyle4;
			this.CI_TOT_LMT.HeaderText = "총대출한도";
			this.CI_TOT_LMT.Name = "CI_TOT_LMT";
			this.CI_TOT_LMT.ReadOnly = true;
			this.CI_TOT_LMT.Width = 108;
			// 
			// CI_LN_RATE
			// 
			this.CI_LN_RATE.DataPropertyName = "CI_LN_RATE";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.NullValue = "0";
			this.CI_LN_RATE.DefaultCellStyle = dataGridViewCellStyle5;
			this.CI_LN_RATE.HeaderText = "대출이자율";
			this.CI_LN_RATE.Name = "CI_LN_RATE";
			this.CI_LN_RATE.ReadOnly = true;
			this.CI_LN_RATE.Width = 108;
			// 
			// CI_LN_OVD
			// 
			this.CI_LN_OVD.DataPropertyName = "CI_LN_OVD";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.NullValue = "0";
			this.CI_LN_OVD.DefaultCellStyle = dataGridViewCellStyle6;
			this.CI_LN_OVD.HeaderText = "연체이자율";
			this.CI_LN_OVD.Name = "CI_LN_OVD";
			this.CI_LN_OVD.ReadOnly = true;
			this.CI_LN_OVD.Width = 108;
			// 
			// LIVEWDRAMT
			// 
			this.LIVEWDRAMT.DataPropertyName = "LIVEWDRAMT";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			this.LIVEWDRAMT.DefaultCellStyle = dataGridViewCellStyle7;
			this.LIVEWDRAMT.HeaderText = "잔여한도";
			this.LIVEWDRAMT.Name = "LIVEWDRAMT";
			this.LIVEWDRAMT.ReadOnly = true;
			this.LIVEWDRAMT.Width = 94;
			// 
			// CI_AGT_NM
			// 
			this.CI_AGT_NM.DataPropertyName = "CI_AGT_NM";
			this.CI_AGT_NM.HeaderText = "수익대리점";
			this.CI_AGT_NM.Name = "CI_AGT_NM";
			this.CI_AGT_NM.ReadOnly = true;
			this.CI_AGT_NM.Width = 108;
			// 
			// CI_APP_DT
			// 
			this.CI_APP_DT.DataPropertyName = "CI_APP_DT";
			this.CI_APP_DT.HeaderText = "적용시작일";
			this.CI_APP_DT.Name = "CI_APP_DT";
			this.CI_APP_DT.ReadOnly = true;
			this.CI_APP_DT.Width = 108;
			// 
			// Band01
			// 
			this.Band01.HeaderText = "상환계좌정보";
			this.Band01.Name = "Band01";
			this.Band01.ReadOnly = true;
			this.Band01.TargetColumnss.Add("CI_RDM_BNK_NM");
			this.Band01.TargetColumnss.Add("CI_RDM_ACCT_NO");
			this.Band01.TargetColumnss.Add("CI_RDM_ACCT_NM");
			this.Band01.Width = 99;
			// 
			// CI_RDM_BNK_NM
			// 
			this.CI_RDM_BNK_NM.DataPropertyName = "CI_RDM_BNK_NM";
			this.CI_RDM_BNK_NM.HeaderText = "은행";
			this.CI_RDM_BNK_NM.Name = "CI_RDM_BNK_NM";
			this.CI_RDM_BNK_NM.ReadOnly = true;
			this.CI_RDM_BNK_NM.Width = 66;
			// 
			// CI_RDM_ACCT_NO
			// 
			this.CI_RDM_ACCT_NO.DataPropertyName = "CI_RDM_ACCT_NO";
			this.CI_RDM_ACCT_NO.HeaderText = "계좌번호";
			this.CI_RDM_ACCT_NO.Name = "CI_RDM_ACCT_NO";
			this.CI_RDM_ACCT_NO.ReadOnly = true;
			this.CI_RDM_ACCT_NO.Width = 94;
			// 
			// CI_RDM_ACCT_NM
			// 
			this.CI_RDM_ACCT_NM.DataPropertyName = "CI_RDM_ACCT_NM";
			this.CI_RDM_ACCT_NM.HeaderText = "예금주";
			this.CI_RDM_ACCT_NM.Name = "CI_RDM_ACCT_NM";
			this.CI_RDM_ACCT_NM.ReadOnly = true;
			this.CI_RDM_ACCT_NM.Width = 80;
			// 
			// Band02
			// 
			this.Band02.HeaderText = "지급계좌정보";
			this.Band02.Name = "Band02";
			this.Band02.ReadOnly = true;
			this.Band02.TargetColumnss.Add("CI_PAY_BNK_NM");
			this.Band02.TargetColumnss.Add("CI_PAY_ACCT_NO");
			this.Band02.TargetColumnss.Add("CI_PAY_ACCT_NM");
			this.Band02.Width = 99;
			// 
			// CI_PAY_BNK_NM
			// 
			this.CI_PAY_BNK_NM.DataPropertyName = "CI_PAY_BNK_NM";
			this.CI_PAY_BNK_NM.HeaderText = "은행";
			this.CI_PAY_BNK_NM.Name = "CI_PAY_BNK_NM";
			this.CI_PAY_BNK_NM.ReadOnly = true;
			this.CI_PAY_BNK_NM.Width = 66;
			// 
			// CI_PAY_ACCT_NO
			// 
			this.CI_PAY_ACCT_NO.DataPropertyName = "CI_PAY_ACCT_NO";
			this.CI_PAY_ACCT_NO.HeaderText = "계좌번호";
			this.CI_PAY_ACCT_NO.Name = "CI_PAY_ACCT_NO";
			this.CI_PAY_ACCT_NO.ReadOnly = true;
			this.CI_PAY_ACCT_NO.Width = 94;
			// 
			// CI_PAY_ACCT_NM
			// 
			this.CI_PAY_ACCT_NM.DataPropertyName = "CI_PAY_ACCT_NM";
			this.CI_PAY_ACCT_NM.HeaderText = "예금주";
			this.CI_PAY_ACCT_NM.Name = "CI_PAY_ACCT_NM";
			this.CI_PAY_ACCT_NM.ReadOnly = true;
			this.CI_PAY_ACCT_NM.Width = 80;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 122;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 122;
			// 
			// SYSMODDATE
			// 
			this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
			this.SYSMODDATE.HeaderText = "시스템수정일";
			this.SYSMODDATE.Name = "SYSMODDATE";
			this.SYSMODDATE.ReadOnly = true;
			this.SYSMODDATE.Width = 122;
			// 
			// SYSMODNAME
			// 
			this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
			this.SYSMODNAME.HeaderText = "시스템수정자";
			this.SYSMODNAME.Name = "SYSMODNAME";
			this.SYSMODNAME.ReadOnly = true;
			this.SYSMODNAME.Width = 122;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.panel1;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(636, 76);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 4;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.groupBox4);
			this.panel1.Controls.Add(this.groupBox5);
			this.panel1.Controls.Add(this.groupBox6);
			this.panel1.Controls.Add(this.groupBox3);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(644, 76);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(710, 657);
			this.panel1.TabIndex = 3;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this._btnSave02);
			this.groupBox4.Controls.Add(this.tableLayoutPanel2);
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox4.Location = new System.Drawing.Point(10, 427);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(690, 138);
			this.groupBox4.TabIndex = 1;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "계좌정보";
			// 
			// _btnSave02
			// 
			this._btnSave02.ButtonConfirm = true;
			this._btnSave02.DelegateProperty = true;
			this._btnSave02.Enabled = false;
			this._btnSave02.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave02.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave02.Location = new System.Drawing.Point(611, 103);
			this._btnSave02.Name = "_btnSave02";
			this._btnSave02.Reserved = "      저   장";
			this._btnSave02.Size = new System.Drawing.Size(75, 27);
			this._btnSave02.TabIndex = 1210;
			this._btnSave02.Text = "      저   장";
			this._btnSave02.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave02.UseVisualStyleBackColor = true;
			this._btnSave02.ValidationGroup = null;
			this._btnSave02.Click += new System.EventHandler(this._btnSave01_Click);
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 6;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel2.Controls.Add(this.label22, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.label23, 2, 0);
			this.tableLayoutPanel2.Controls.Add(this.label24, 4, 0);
			this.tableLayoutPanel2.Controls.Add(this.label20, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.label26, 2, 1);
			this.tableLayoutPanel2.Controls.Add(this.label27, 4, 1);
			this.tableLayoutPanel2.Controls.Add(this._cmbCI_RDM_BNK_CD, 1, 0);
			this.tableLayoutPanel2.Controls.Add(this._cmbCI_PAY_BNK_CD, 1, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtCI_RDM_ACCT_NO, 3, 0);
			this.tableLayoutPanel2.Controls.Add(this._txtCI_PAY_ACCT_NO, 3, 1);
			this.tableLayoutPanel2.Controls.Add(this._txtCI_RDM_ACCT_NM, 5, 0);
			this.tableLayoutPanel2.Controls.Add(this._txtCI_PAY_ACCT_NM, 5, 1);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 3;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(684, 81);
			this.tableLayoutPanel2.TabIndex = 3;
			// 
			// label22
			// 
			this.label22.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(15, 6);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(72, 15);
			this.label22.TabIndex = 0;
			this.label22.Text = "상환.은행";
			// 
			// label23
			// 
			this.label23.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(245, 0);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(72, 27);
			this.label23.TabIndex = 9;
			this.label23.Text = "상환.계좌번호";
			// 
			// label24
			// 
			this.label24.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(475, 0);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(72, 27);
			this.label24.TabIndex = 8;
			this.label24.Text = "상환.예금주";
			// 
			// label20
			// 
			this.label20.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(15, 33);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(72, 15);
			this.label20.TabIndex = 1201;
			this.label20.Text = "지급.은행";
			// 
			// label26
			// 
			this.label26.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(245, 27);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(72, 27);
			this.label26.TabIndex = 1203;
			this.label26.Text = "지급.계좌번호";
			// 
			// label27
			// 
			this.label27.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(475, 27);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(72, 27);
			this.label27.TabIndex = 1205;
			this.label27.Text = "지급.예금주";
			// 
			// _cmbCI_RDM_BNK_CD
			// 
			this._cmbCI_RDM_BNK_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCI_RDM_BNK_CD.DataSource = null;
			this._cmbCI_RDM_BNK_CD.DelegateProperty = true;
			this._cmbCI_RDM_BNK_CD.DroppedDown = false;
			this._cmbCI_RDM_BNK_CD.Enabled = false;
			this._cmbCI_RDM_BNK_CD.Location = new System.Drawing.Point(93, 3);
			this._cmbCI_RDM_BNK_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_RDM_BNK_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_RDM_BNK_CD.Name = "_cmbCI_RDM_BNK_CD";
			this._cmbCI_RDM_BNK_CD.SelectedIndex = -1;
			this._cmbCI_RDM_BNK_CD.SelectedItem = null;
			this._cmbCI_RDM_BNK_CD.SelectedValue = null;
			this._cmbCI_RDM_BNK_CD.Size = new System.Drawing.Size(130, 23);
			this._cmbCI_RDM_BNK_CD.TabIndex = 1180;
			this._cmbCI_RDM_BNK_CD.ValidationGroup = null;
			// 
			// _cmbCI_PAY_BNK_CD
			// 
			this._cmbCI_PAY_BNK_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCI_PAY_BNK_CD.DataSource = null;
			this._cmbCI_PAY_BNK_CD.DelegateProperty = true;
			this._cmbCI_PAY_BNK_CD.DroppedDown = false;
			this._cmbCI_PAY_BNK_CD.Enabled = false;
			this._cmbCI_PAY_BNK_CD.Location = new System.Drawing.Point(93, 30);
			this._cmbCI_PAY_BNK_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_PAY_BNK_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_PAY_BNK_CD.Name = "_cmbCI_PAY_BNK_CD";
			this._cmbCI_PAY_BNK_CD.SelectedIndex = -1;
			this._cmbCI_PAY_BNK_CD.SelectedItem = null;
			this._cmbCI_PAY_BNK_CD.SelectedValue = null;
			this._cmbCI_PAY_BNK_CD.Size = new System.Drawing.Size(130, 23);
			this._cmbCI_PAY_BNK_CD.TabIndex = 1202;
			this._cmbCI_PAY_BNK_CD.ValidationGroup = null;
			// 
			// _txtCI_RDM_ACCT_NO
			// 
			this._txtCI_RDM_ACCT_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_RDM_ACCT_NO.DelegateProperty = true;
			this._txtCI_RDM_ACCT_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_RDM_ACCT_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtCI_RDM_ACCT_NO.Location = new System.Drawing.Point(323, 3);
			this._txtCI_RDM_ACCT_NO.Name = "_txtCI_RDM_ACCT_NO";
			this._txtCI_RDM_ACCT_NO.ReadOnly = true;
			this._txtCI_RDM_ACCT_NO.Size = new System.Drawing.Size(130, 23);
			this._txtCI_RDM_ACCT_NO.TabIndex = 1190;
			this._txtCI_RDM_ACCT_NO.ValidationGroup = null;
			this._txtCI_RDM_ACCT_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_RDM_ACCT_NO.WaterMarkText = "";
			// 
			// _txtCI_PAY_ACCT_NO
			// 
			this._txtCI_PAY_ACCT_NO.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_PAY_ACCT_NO.DelegateProperty = true;
			this._txtCI_PAY_ACCT_NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_PAY_ACCT_NO.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
			this._txtCI_PAY_ACCT_NO.Location = new System.Drawing.Point(323, 30);
			this._txtCI_PAY_ACCT_NO.Name = "_txtCI_PAY_ACCT_NO";
			this._txtCI_PAY_ACCT_NO.ReadOnly = true;
			this._txtCI_PAY_ACCT_NO.Size = new System.Drawing.Size(130, 23);
			this._txtCI_PAY_ACCT_NO.TabIndex = 1204;
			this._txtCI_PAY_ACCT_NO.ValidationGroup = null;
			this._txtCI_PAY_ACCT_NO.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_PAY_ACCT_NO.WaterMarkText = "";
			// 
			// _txtCI_RDM_ACCT_NM
			// 
			this._txtCI_RDM_ACCT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_RDM_ACCT_NM.DelegateProperty = true;
			this._txtCI_RDM_ACCT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_RDM_ACCT_NM.Location = new System.Drawing.Point(553, 3);
			this._txtCI_RDM_ACCT_NM.Name = "_txtCI_RDM_ACCT_NM";
			this._txtCI_RDM_ACCT_NM.ReadOnly = true;
			this._txtCI_RDM_ACCT_NM.Size = new System.Drawing.Size(130, 23);
			this._txtCI_RDM_ACCT_NM.TabIndex = 1200;
			this._txtCI_RDM_ACCT_NM.ValidationGroup = null;
			this._txtCI_RDM_ACCT_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_RDM_ACCT_NM.WaterMarkText = "";
			// 
			// _txtCI_PAY_ACCT_NM
			// 
			this._txtCI_PAY_ACCT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_PAY_ACCT_NM.DelegateProperty = true;
			this._txtCI_PAY_ACCT_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_PAY_ACCT_NM.Location = new System.Drawing.Point(553, 30);
			this._txtCI_PAY_ACCT_NM.Name = "_txtCI_PAY_ACCT_NM";
			this._txtCI_PAY_ACCT_NM.ReadOnly = true;
			this._txtCI_PAY_ACCT_NM.Size = new System.Drawing.Size(130, 23);
			this._txtCI_PAY_ACCT_NM.TabIndex = 1206;
			this._txtCI_PAY_ACCT_NM.ValidationGroup = null;
			this._txtCI_PAY_ACCT_NM.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_PAY_ACCT_NM.WaterMarkText = "";
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this._btnSave03);
			this.groupBox5.Controls.Add(this.tableLayoutPanel3);
			this.groupBox5.Controls.Add(this._btnRate);
			this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox5.Location = new System.Drawing.Point(10, 311);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(690, 116);
			this.groupBox5.TabIndex = 2;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "대출이자정보";
			// 
			// _btnSave03
			// 
			this._btnSave03.ButtonConfirm = true;
			this._btnSave03.DelegateProperty = true;
			this._btnSave03.Enabled = false;
			this._btnSave03.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave03.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave03.Location = new System.Drawing.Point(611, 76);
			this._btnSave03.Name = "_btnSave03";
			this._btnSave03.Reserved = "      저   장";
			this._btnSave03.Size = new System.Drawing.Size(75, 27);
			this._btnSave03.TabIndex = 1140;
			this._btnSave03.Text = "      저   장";
			this._btnSave03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave03.UseVisualStyleBackColor = true;
			this._btnSave03.ValidationGroup = null;
			this._btnSave03.Click += new System.EventHandler(this._btnSave01_Click);
			// 
			// tableLayoutPanel3
			// 
			this.tableLayoutPanel3.ColumnCount = 6;
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
			this.tableLayoutPanel3.Controls.Add(this.flowLayoutPanel4, 3, 0);
			this.tableLayoutPanel3.Controls.Add(this.label16, 2, 0);
			this.tableLayoutPanel3.Controls.Add(this._dtpCI_APP_DT, 5, 0);
			this.tableLayoutPanel3.Controls.Add(this.label11, 4, 0);
			this.tableLayoutPanel3.Controls.Add(this.label13, 0, 0);
			this.tableLayoutPanel3.Controls.Add(this.flowLayoutPanel2, 1, 0);
			this.tableLayoutPanel3.Controls.Add(this.flowLayoutPanel3, 5, 1);
			this.tableLayoutPanel3.Controls.Add(this.label10, 4, 1);
			this.tableLayoutPanel3.Controls.Add(this._cmbCI_LNR_CD, 3, 1);
			this.tableLayoutPanel3.Controls.Add(this.label9, 2, 1);
			this.tableLayoutPanel3.Controls.Add(this.label12, 0, 1);
			this.tableLayoutPanel3.Controls.Add(this._cmbCI_AGT_CD, 1, 1);
			this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel3.Name = "tableLayoutPanel3";
			this.tableLayoutPanel3.RowCount = 2;
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel3.Size = new System.Drawing.Size(684, 54);
			this.tableLayoutPanel3.TabIndex = 1104;
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._txtCI_LN_OVD);
			this.flowLayoutPanel4.Controls.Add(this.label18);
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(320, 0);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(140, 27);
			this.flowLayoutPanel4.TabIndex = 1080;
			// 
			// _txtCI_LN_OVD
			// 
			this._txtCI_LN_OVD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_LN_OVD.DelegateProperty = true;
			this._txtCI_LN_OVD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_LN_OVD.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCI_LN_OVD.Location = new System.Drawing.Point(3, 3);
			this._txtCI_LN_OVD.Name = "_txtCI_LN_OVD";
			this._txtCI_LN_OVD.ReadOnly = true;
			this._txtCI_LN_OVD.Size = new System.Drawing.Size(90, 23);
			this._txtCI_LN_OVD.TabIndex = 10;
			this._txtCI_LN_OVD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_LN_OVD.ValidationGroup = null;
			this._txtCI_LN_OVD.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_LN_OVD.WaterMarkText = "";
			// 
			// label18
			// 
			this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(0, 29);
			this.label18.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(49, 15);
			this.label18.TabIndex = 10;
			this.label18.Text = "% / 년";
			// 
			// label16
			// 
			this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(235, 6);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(82, 15);
			this.label16.TabIndex = 1430;
			this.label16.Text = "연체이자율";
			// 
			// _dtpCI_APP_DT
			// 
			this._dtpCI_APP_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpCI_APP_DT.Checked = false;
			this._dtpCI_APP_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpCI_APP_DT.DelegateProperty = true;
			this._dtpCI_APP_DT.Enabled = false;
			this._dtpCI_APP_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpCI_APP_DT.Location = new System.Drawing.Point(553, 3);
			this._dtpCI_APP_DT.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpCI_APP_DT.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpCI_APP_DT.Name = "_dtpCI_APP_DT";
			this._dtpCI_APP_DT.ShowCheckBox = true;
			this._dtpCI_APP_DT.Size = new System.Drawing.Size(130, 21);
			this._dtpCI_APP_DT.TabIndex = 1090;
			this._dtpCI_APP_DT.ValidationGroup = null;
			this._dtpCI_APP_DT.Value = new System.DateTime(2014, 8, 7, 21, 32, 52, 413);
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(465, 6);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(82, 15);
			this.label11.TabIndex = 10;
			this.label11.Text = "적용시작일";
			// 
			// label13
			// 
			this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(5, 6);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(82, 15);
			this.label13.TabIndex = 9;
			this.label13.Text = "대출이자율";
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this._txtCI_LN_RATE);
			this.flowLayoutPanel2.Controls.Add(this.label6);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(90, 0);
			this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(140, 27);
			this.flowLayoutPanel2.TabIndex = 1070;
			// 
			// _txtCI_LN_RATE
			// 
			this._txtCI_LN_RATE.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_LN_RATE.DelegateProperty = true;
			this._txtCI_LN_RATE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_LN_RATE.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCI_LN_RATE.Location = new System.Drawing.Point(3, 3);
			this._txtCI_LN_RATE.Name = "_txtCI_LN_RATE";
			this._txtCI_LN_RATE.ReadOnly = true;
			this._txtCI_LN_RATE.Size = new System.Drawing.Size(90, 23);
			this._txtCI_LN_RATE.TabIndex = 10;
			this._txtCI_LN_RATE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_LN_RATE.ValidationGroup = null;
			this._txtCI_LN_RATE.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_LN_RATE.WaterMarkText = "";
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(0, 29);
			this.label6.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(49, 15);
			this.label6.TabIndex = 10;
			this.label6.Text = "% / 년";
			// 
			// flowLayoutPanel3
			// 
			this.flowLayoutPanel3.Controls.Add(this._rbCI_LN_GUBUN01);
			this.flowLayoutPanel3.Controls.Add(this._rbCI_LN_GUBUN02);
			this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel3.Location = new System.Drawing.Point(550, 27);
			this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel3.Name = "flowLayoutPanel3";
			this.flowLayoutPanel3.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel3.Size = new System.Drawing.Size(150, 27);
			this.flowLayoutPanel3.TabIndex = 1120;
			// 
			// _rbCI_LN_GUBUN01
			// 
			this._rbCI_LN_GUBUN01.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbCI_LN_GUBUN01.AutoSize = true;
			this._rbCI_LN_GUBUN01.Checked = true;
			this._rbCI_LN_GUBUN01.DelegateProperty = true;
			this._rbCI_LN_GUBUN01.Enabled = false;
			this._rbCI_LN_GUBUN01.Location = new System.Drawing.Point(3, 6);
			this._rbCI_LN_GUBUN01.Name = "_rbCI_LN_GUBUN01";
			this._rbCI_LN_GUBUN01.Size = new System.Drawing.Size(58, 19);
			this._rbCI_LN_GUBUN01.TabIndex = 10;
			this._rbCI_LN_GUBUN01.TabStop = true;
			this._rbCI_LN_GUBUN01.Text = "자동";
			this._rbCI_LN_GUBUN01.UseVisualStyleBackColor = true;
			this._rbCI_LN_GUBUN01.Visible = false;
			// 
			// _rbCI_LN_GUBUN02
			// 
			this._rbCI_LN_GUBUN02.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbCI_LN_GUBUN02.AutoSize = true;
			this._rbCI_LN_GUBUN02.DelegateProperty = true;
			this._rbCI_LN_GUBUN02.Enabled = false;
			this._rbCI_LN_GUBUN02.Location = new System.Drawing.Point(67, 6);
			this._rbCI_LN_GUBUN02.Name = "_rbCI_LN_GUBUN02";
			this._rbCI_LN_GUBUN02.Size = new System.Drawing.Size(58, 19);
			this._rbCI_LN_GUBUN02.TabIndex = 20;
			this._rbCI_LN_GUBUN02.Text = "희망";
			this._rbCI_LN_GUBUN02.UseVisualStyleBackColor = true;
			this._rbCI_LN_GUBUN02.Visible = false;
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(480, 33);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(67, 15);
			this.label10.TabIndex = 1106;
			this.label10.Text = "대출구분";
			this.label10.Visible = false;
			// 
			// _cmbCI_LNR_CD
			// 
			this._cmbCI_LNR_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCI_LNR_CD.DataSource = null;
			this._cmbCI_LNR_CD.DelegateProperty = true;
			this._cmbCI_LNR_CD.DroppedDown = false;
			this._cmbCI_LNR_CD.Enabled = false;
			this._cmbCI_LNR_CD.Location = new System.Drawing.Point(323, 30);
			this._cmbCI_LNR_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_LNR_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_LNR_CD.Name = "_cmbCI_LNR_CD";
			this._cmbCI_LNR_CD.SelectedIndex = -1;
			this._cmbCI_LNR_CD.SelectedItem = null;
			this._cmbCI_LNR_CD.SelectedValue = null;
			this._cmbCI_LNR_CD.Size = new System.Drawing.Size(130, 23);
			this._cmbCI_LNR_CD.TabIndex = 1110;
			this._cmbCI_LNR_CD.ValidationGroup = null;
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(265, 33);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(52, 15);
			this.label9.TabIndex = 1429;
			this.label9.Text = "여신사";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(5, 33);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(82, 15);
			this.label12.TabIndex = 10;
			this.label12.Text = "수익대리점";
			// 
			// _cmbCI_AGT_CD
			// 
			this._cmbCI_AGT_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCI_AGT_CD.DataSource = null;
			this._cmbCI_AGT_CD.DelegateProperty = true;
			this._cmbCI_AGT_CD.DroppedDown = false;
			this._cmbCI_AGT_CD.Enabled = false;
			this._cmbCI_AGT_CD.Location = new System.Drawing.Point(93, 30);
			this._cmbCI_AGT_CD.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_AGT_CD.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_AGT_CD.Name = "_cmbCI_AGT_CD";
			this._cmbCI_AGT_CD.SelectedIndex = -1;
			this._cmbCI_AGT_CD.SelectedItem = null;
			this._cmbCI_AGT_CD.SelectedValue = null;
			this._cmbCI_AGT_CD.Size = new System.Drawing.Size(130, 23);
			this._cmbCI_AGT_CD.TabIndex = 1100;
			this._cmbCI_AGT_CD.ValidationGroup = null;
			// 
			// _btnRate
			// 
			this._btnRate.DelegateProperty = true;
			this._btnRate.Enabled = false;
			this._btnRate.Image = global::DemoClient.Properties.Resources._1377801316_62660;
			this._btnRate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnRate.Location = new System.Drawing.Point(499, 76);
			this._btnRate.Name = "_btnRate";
			this._btnRate.Reserved = "      이자율 조정";
			this._btnRate.Size = new System.Drawing.Size(106, 27);
			this._btnRate.TabIndex = 1130;
			this._btnRate.Text = "      이자율 조정";
			this._btnRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnRate.UseVisualStyleBackColor = true;
			this._btnRate.ValidationGroup = null;
			this._btnRate.Click += new System.EventHandler(this._btnRate_Click);
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this._btnLimit);
			this.groupBox6.Controls.Add(this._btnSave04);
			this.groupBox6.Controls.Add(this.tableLayoutPanel4);
			this.groupBox6.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox6.Location = new System.Drawing.Point(10, 200);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(690, 111);
			this.groupBox6.TabIndex = 3;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "대출한도정보";
			// 
			// _btnLimit
			// 
			this._btnLimit.DelegateProperty = true;
			this._btnLimit.Enabled = false;
			this._btnLimit.Image = global::DemoClient.Properties.Resources._1377801316_62660;
			this._btnLimit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnLimit.Location = new System.Drawing.Point(514, 76);
			this._btnLimit.Name = "_btnLimit";
			this._btnLimit.Reserved = "      한도 조정";
			this._btnLimit.Size = new System.Drawing.Size(91, 27);
			this._btnLimit.TabIndex = 1050;
			this._btnLimit.Text = "      한도 조정";
			this._btnLimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnLimit.UseVisualStyleBackColor = true;
			this._btnLimit.ValidationGroup = null;
			this._btnLimit.Click += new System.EventHandler(this._btnLimit_Click);
			// 
			// _btnSave04
			// 
			this._btnSave04.ButtonConfirm = true;
			this._btnSave04.DelegateProperty = true;
			this._btnSave04.Enabled = false;
			this._btnSave04.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave04.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave04.Location = new System.Drawing.Point(611, 76);
			this._btnSave04.Name = "_btnSave04";
			this._btnSave04.Reserved = "      저   장";
			this._btnSave04.Size = new System.Drawing.Size(75, 27);
			this._btnSave04.TabIndex = 1060;
			this._btnSave04.Text = "      저   장";
			this._btnSave04.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave04.UseVisualStyleBackColor = true;
			this._btnSave04.ValidationGroup = null;
			this._btnSave04.Click += new System.EventHandler(this._btnSave01_Click);
			// 
			// tableLayoutPanel4
			// 
			this.tableLayoutPanel4.ColumnCount = 6;
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel4.Controls.Add(this._dtpCI_LMT_APP_DT, 1, 1);
			this.tableLayoutPanel4.Controls.Add(this._txtCI_TOT_LMT, 5, 0);
			this.tableLayoutPanel4.Controls.Add(this.label19, 4, 0);
			this.tableLayoutPanel4.Controls.Add(this.label21, 0, 0);
			this.tableLayoutPanel4.Controls.Add(this.label25, 0, 1);
			this.tableLayoutPanel4.Controls.Add(this.label4, 2, 0);
			this.tableLayoutPanel4.Controls.Add(this._txtCI_DAILY_LMT, 3, 0);
			this.tableLayoutPanel4.Controls.Add(this._txtCI_UNIT_LMT, 1, 0);
			this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel4.Name = "tableLayoutPanel4";
			this.tableLayoutPanel4.RowCount = 2;
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel4.Size = new System.Drawing.Size(684, 54);
			this.tableLayoutPanel4.TabIndex = 3;
			// 
			// _dtpCI_LMT_APP_DT
			// 
			this._dtpCI_LMT_APP_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpCI_LMT_APP_DT.Checked = false;
			this._dtpCI_LMT_APP_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpCI_LMT_APP_DT.DelegateProperty = true;
			this._dtpCI_LMT_APP_DT.Enabled = false;
			this._dtpCI_LMT_APP_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpCI_LMT_APP_DT.Location = new System.Drawing.Point(93, 30);
			this._dtpCI_LMT_APP_DT.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpCI_LMT_APP_DT.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpCI_LMT_APP_DT.Name = "_dtpCI_LMT_APP_DT";
			this._dtpCI_LMT_APP_DT.ShowCheckBox = true;
			this._dtpCI_LMT_APP_DT.Size = new System.Drawing.Size(130, 21);
			this._dtpCI_LMT_APP_DT.TabIndex = 1040;
			this._dtpCI_LMT_APP_DT.ValidationGroup = null;
			this._dtpCI_LMT_APP_DT.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 394);
			// 
			// _txtCI_TOT_LMT
			// 
			this._txtCI_TOT_LMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_TOT_LMT.DelegateProperty = true;
			this._txtCI_TOT_LMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_TOT_LMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtCI_TOT_LMT.Location = new System.Drawing.Point(553, 3);
			this._txtCI_TOT_LMT.Name = "_txtCI_TOT_LMT";
			this._txtCI_TOT_LMT.ReadOnly = true;
			this._txtCI_TOT_LMT.Size = new System.Drawing.Size(130, 23);
			this._txtCI_TOT_LMT.TabIndex = 1030;
			this._txtCI_TOT_LMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_TOT_LMT.ValidationGroup = null;
			this._txtCI_TOT_LMT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_TOT_LMT.WaterMarkText = "";
			// 
			// label19
			// 
			this.label19.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(465, 6);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(82, 15);
			this.label19.TabIndex = 10;
			this.label19.Text = "총대출한도";
			// 
			// label21
			// 
			this.label21.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(5, 0);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(82, 27);
			this.label21.TabIndex = 9;
			this.label21.Text = "건별대출한도";
			// 
			// label25
			// 
			this.label25.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(5, 33);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(82, 15);
			this.label25.TabIndex = 0;
			this.label25.Text = "적용시작일";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(242, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(75, 27);
			this.label4.TabIndex = 33;
			this.label4.Text = "1일대출한도";
			// 
			// _txtCI_DAILY_LMT
			// 
			this._txtCI_DAILY_LMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_DAILY_LMT.DelegateProperty = true;
			this._txtCI_DAILY_LMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_DAILY_LMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtCI_DAILY_LMT.Location = new System.Drawing.Point(323, 3);
			this._txtCI_DAILY_LMT.Name = "_txtCI_DAILY_LMT";
			this._txtCI_DAILY_LMT.ReadOnly = true;
			this._txtCI_DAILY_LMT.Size = new System.Drawing.Size(130, 23);
			this._txtCI_DAILY_LMT.TabIndex = 1020;
			this._txtCI_DAILY_LMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_DAILY_LMT.ValidationGroup = null;
			this._txtCI_DAILY_LMT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_DAILY_LMT.WaterMarkText = "";
			// 
			// _txtCI_UNIT_LMT
			// 
			this._txtCI_UNIT_LMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_UNIT_LMT.DelegateProperty = true;
			this._txtCI_UNIT_LMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_UNIT_LMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtCI_UNIT_LMT.Location = new System.Drawing.Point(93, 3);
			this._txtCI_UNIT_LMT.Name = "_txtCI_UNIT_LMT";
			this._txtCI_UNIT_LMT.ReadOnly = true;
			this._txtCI_UNIT_LMT.Size = new System.Drawing.Size(130, 23);
			this._txtCI_UNIT_LMT.TabIndex = 1010;
			this._txtCI_UNIT_LMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_UNIT_LMT.ValidationGroup = null;
			this._txtCI_UNIT_LMT.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_UNIT_LMT.WaterMarkText = "";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this._btnSave01);
			this.groupBox3.Controls.Add(this.tableLayoutPanel1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox3.Location = new System.Drawing.Point(10, 5);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(690, 195);
			this.groupBox3.TabIndex = 0;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "계약정보";
			// 
			// _btnSave01
			// 
			this._btnSave01.ButtonConfirm = true;
			this._btnSave01.DelegateProperty = true;
			this._btnSave01.Enabled = false;
			this._btnSave01.Image = global::DemoClient.Properties.Resources._1377801124_62679;
			this._btnSave01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave01.Location = new System.Drawing.Point(611, 162);
			this._btnSave01.Name = "_btnSave01";
			this._btnSave01.Reserved = "      저   장";
			this._btnSave01.Size = new System.Drawing.Size(75, 27);
			this._btnSave01.TabIndex = 1090;
			this._btnSave01.Text = "      저   장";
			this._btnSave01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSave01.UseVisualStyleBackColor = true;
			this._btnSave01.ValidationGroup = null;
			this._btnSave01.Click += new System.EventHandler(this._btnSave01_Click);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 6;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel6, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this.label15, 0, 4);
			this.tableLayoutPanel1.Controls.Add(this._txtCI_ACCOUNT_FEE, 5, 3);
			this.tableLayoutPanel1.Controls.Add(this.label14, 4, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtCI_BZL_PER, 5, 2);
			this.tableLayoutPanel1.Controls.Add(this.label28, 4, 2);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this._txtPRSNT_NM, 5, 0);
			this.tableLayoutPanel1.Controls.Add(this._txtSTR_NM, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this.label8, 4, 0);
			this.tableLayoutPanel1.Controls.Add(this.label7, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this._txtSTR_CD, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label5, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this._cmbCI_SVC_STAT, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.label2, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this._cmbCI_WTHR_STAT, 3, 2);
			this.tableLayoutPanel1.Controls.Add(this.lblCOMPANY_CD, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this._dtpCI_CNTR_STRT_DT, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.label1, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this._dtpCI_CNTR_END_DT, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this.lblUSR_PASS, 4, 1);
			this.tableLayoutPanel1.Controls.Add(this._dtpCI_WTHR_STRT_DT, 5, 1);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 5;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(684, 137);
			this.tableLayoutPanel1.TabIndex = 2;
			// 
			// flowLayoutPanel6
			// 
			this.tableLayoutPanel1.SetColumnSpan(this.flowLayoutPanel6, 3);
			this.flowLayoutPanel6.Controls.Add(this._rbCI_WTHR_TYPE_Y);
			this.flowLayoutPanel6.Controls.Add(this._rbCI_WTHR_TYPE_T);
			this.flowLayoutPanel6.Controls.Add(this._rbCI_WTHR_TYPE_E);
			this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel6.Location = new System.Drawing.Point(90, 108);
			this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel6.Name = "flowLayoutPanel6";
			this.flowLayoutPanel6.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel6.Size = new System.Drawing.Size(370, 29);
			this.flowLayoutPanel6.TabIndex = 1121;
			// 
			// _rbCI_WTHR_TYPE_Y
			// 
			this._rbCI_WTHR_TYPE_Y.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbCI_WTHR_TYPE_Y.AutoSize = true;
			this._rbCI_WTHR_TYPE_Y.Checked = true;
			this._rbCI_WTHR_TYPE_Y.DelegateProperty = true;
			this._rbCI_WTHR_TYPE_Y.Enabled = false;
			this._rbCI_WTHR_TYPE_Y.Location = new System.Drawing.Point(3, 6);
			this._rbCI_WTHR_TYPE_Y.Name = "_rbCI_WTHR_TYPE_Y";
			this._rbCI_WTHR_TYPE_Y.Size = new System.Drawing.Size(93, 19);
			this._rbCI_WTHR_TYPE_Y.TabIndex = 10;
			this._rbCI_WTHR_TYPE_Y.TabStop = true;
			this._rbCI_WTHR_TYPE_Y.Text = "전일 총액";
			this._rbCI_WTHR_TYPE_Y.UseVisualStyleBackColor = true;
			// 
			// _rbCI_WTHR_TYPE_T
			// 
			this._rbCI_WTHR_TYPE_T.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbCI_WTHR_TYPE_T.AutoSize = true;
			this._rbCI_WTHR_TYPE_T.DelegateProperty = true;
			this._rbCI_WTHR_TYPE_T.Enabled = false;
			this._rbCI_WTHR_TYPE_T.Location = new System.Drawing.Point(102, 6);
			this._rbCI_WTHR_TYPE_T.Name = "_rbCI_WTHR_TYPE_T";
			this._rbCI_WTHR_TYPE_T.Size = new System.Drawing.Size(86, 19);
			this._rbCI_WTHR_TYPE_T.TabIndex = 20;
			this._rbCI_WTHR_TYPE_T.Text = "당일 6시";
			this._rbCI_WTHR_TYPE_T.UseVisualStyleBackColor = true;
			// 
			// _rbCI_WTHR_TYPE_E
			// 
			this._rbCI_WTHR_TYPE_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._rbCI_WTHR_TYPE_E.AutoSize = true;
			this._rbCI_WTHR_TYPE_E.DelegateProperty = true;
			this._rbCI_WTHR_TYPE_E.Enabled = false;
			this._rbCI_WTHR_TYPE_E.Location = new System.Drawing.Point(194, 6);
			this._rbCI_WTHR_TYPE_E.Name = "_rbCI_WTHR_TYPE_E";
			this._rbCI_WTHR_TYPE_E.Size = new System.Drawing.Size(58, 19);
			this._rbCI_WTHR_TYPE_E.TabIndex = 21;
			this._rbCI_WTHR_TYPE_E.Text = "그외";
			this._rbCI_WTHR_TYPE_E.UseVisualStyleBackColor = true;
			// 
			// label15
			// 
			this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(20, 115);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(67, 15);
			this.label15.TabIndex = 1103;
			this.label15.Text = "출금유형";
			// 
			// _txtCI_ACCOUNT_FEE
			// 
			this._txtCI_ACCOUNT_FEE.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_ACCOUNT_FEE.DelegateProperty = true;
			this._txtCI_ACCOUNT_FEE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_ACCOUNT_FEE.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCI_ACCOUNT_FEE.Location = new System.Drawing.Point(553, 84);
			this._txtCI_ACCOUNT_FEE.Name = "_txtCI_ACCOUNT_FEE";
			this._txtCI_ACCOUNT_FEE.ReadOnly = true;
			this._txtCI_ACCOUNT_FEE.Size = new System.Drawing.Size(128, 23);
			this._txtCI_ACCOUNT_FEE.TabIndex = 12;
			this._txtCI_ACCOUNT_FEE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_ACCOUNT_FEE.ValidationGroup = null;
			this._txtCI_ACCOUNT_FEE.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_ACCOUNT_FEE.WaterMarkText = "";
			// 
			// label14
			// 
			this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(465, 81);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(82, 27);
			this.label14.TabIndex = 10;
			this.label14.Text = "정산수수료율";
			// 
			// _txtCI_BZL_PER
			// 
			this._txtCI_BZL_PER.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCI_BZL_PER.DelegateProperty = true;
			this._txtCI_BZL_PER.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCI_BZL_PER.ImeMode = BANANA.Windows.Controls.ImeMode.Decimal;
			this._txtCI_BZL_PER.Location = new System.Drawing.Point(553, 57);
			this._txtCI_BZL_PER.Name = "_txtCI_BZL_PER";
			this._txtCI_BZL_PER.ReadOnly = true;
			this._txtCI_BZL_PER.Size = new System.Drawing.Size(128, 23);
			this._txtCI_BZL_PER.TabIndex = 11;
			this._txtCI_BZL_PER.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCI_BZL_PER.ValidationGroup = null;
			this._txtCI_BZL_PER.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtCI_BZL_PER.WaterMarkText = "";
			// 
			// label28
			// 
			this.label28.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(475, 54);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(72, 27);
			this.label28.TabIndex = 9;
			this.label28.Text = "비즈론 이자율";
			// 
			// flowLayoutPanel1
			// 
			this.tableLayoutPanel1.SetColumnSpan(this.flowLayoutPanel1, 3);
			this.flowLayoutPanel1.Controls.Add(this._chkCI_USE_INSRNC);
			this.flowLayoutPanel1.Controls.Add(this._chkCI_USE_BLNC);
			this.flowLayoutPanel1.Controls.Add(this._chkCI_USE_SRT);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(90, 81);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
			this.flowLayoutPanel1.Size = new System.Drawing.Size(370, 27);
			this.flowLayoutPanel1.TabIndex = 1080;
			// 
			// _chkCI_USE_INSRNC
			// 
			this._chkCI_USE_INSRNC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._chkCI_USE_INSRNC.AutoSize = true;
			this._chkCI_USE_INSRNC.DelegateProperty = true;
			this._chkCI_USE_INSRNC.Enabled = false;
			this._chkCI_USE_INSRNC.Location = new System.Drawing.Point(3, 6);
			this._chkCI_USE_INSRNC.Name = "_chkCI_USE_INSRNC";
			this._chkCI_USE_INSRNC.Size = new System.Drawing.Size(89, 19);
			this._chkCI_USE_INSRNC.TabIndex = 10;
			this._chkCI_USE_INSRNC.Text = "보증보험";
			this._chkCI_USE_INSRNC.UseVisualStyleBackColor = true;
			this._chkCI_USE_INSRNC.Visible = false;
			// 
			// _chkCI_USE_BLNC
			// 
			this._chkCI_USE_BLNC.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._chkCI_USE_BLNC.AutoSize = true;
			this._chkCI_USE_BLNC.DelegateProperty = true;
			this._chkCI_USE_BLNC.Enabled = false;
			this._chkCI_USE_BLNC.Location = new System.Drawing.Point(98, 6);
			this._chkCI_USE_BLNC.Name = "_chkCI_USE_BLNC";
			this._chkCI_USE_BLNC.Size = new System.Drawing.Size(104, 19);
			this._chkCI_USE_BLNC.TabIndex = 20;
			this._chkCI_USE_BLNC.Text = "보증예치금";
			this._chkCI_USE_BLNC.UseVisualStyleBackColor = true;
			// 
			// _chkCI_USE_SRT
			// 
			this._chkCI_USE_SRT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._chkCI_USE_SRT.AutoSize = true;
			this._chkCI_USE_SRT.DelegateProperty = true;
			this._chkCI_USE_SRT.Enabled = false;
			this._chkCI_USE_SRT.Location = new System.Drawing.Point(208, 6);
			this._chkCI_USE_SRT.Name = "_chkCI_USE_SRT";
			this._chkCI_USE_SRT.Size = new System.Drawing.Size(104, 19);
			this._chkCI_USE_SRT.TabIndex = 30;
			this._chkCI_USE_SRT.Text = "연대보증인";
			this._chkCI_USE_SRT.UseVisualStyleBackColor = true;
			this._chkCI_USE_SRT.Visible = false;
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(5, 87);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(82, 15);
			this.label3.TabIndex = 1102;
			this.label3.Text = "서비스상태";
			// 
			// _txtPRSNT_NM
			// 
			this._txtPRSNT_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPRSNT_NM.Location = new System.Drawing.Point(553, 3);
			this._txtPRSNT_NM.Name = "_txtPRSNT_NM";
			this._txtPRSNT_NM.ReadOnly = true;
			this._txtPRSNT_NM.Size = new System.Drawing.Size(130, 25);
			this._txtPRSNT_NM.TabIndex = 1020;
			this._txtPRSNT_NM.ValidationGroup = null;
			this._txtPRSNT_NM.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtPRSNT_NM.WaterMarkText = "";
			// 
			// _txtSTR_NM
			// 
			this._txtSTR_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM.Location = new System.Drawing.Point(323, 3);
			this._txtSTR_NM.Name = "_txtSTR_NM";
			this._txtSTR_NM.ReadOnly = true;
			this._txtSTR_NM.Size = new System.Drawing.Size(130, 25);
			this._txtSTR_NM.TabIndex = 1010;
			this._txtSTR_NM.ValidationGroup = null;
			this._txtSTR_NM.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSTR_NM.WaterMarkText = "";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(480, 6);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(67, 15);
			this.label8.TabIndex = 10;
			this.label8.Text = "대표자명";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(250, 6);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(67, 15);
			this.label7.TabIndex = 10;
			this.label7.Text = "가맹점명";
			// 
			// _txtSTR_CD
			// 
			this._txtSTR_CD.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD.Location = new System.Drawing.Point(93, 3);
			this._txtSTR_CD.Name = "_txtSTR_CD";
			this._txtSTR_CD.ReadOnly = true;
			this._txtSTR_CD.Size = new System.Drawing.Size(130, 25);
			this._txtSTR_CD.TabIndex = 1000;
			this._txtSTR_CD.ValidationGroup = null;
			this._txtSTR_CD.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSTR_CD.WaterMarkText = "";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(5, 6);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(82, 15);
			this.label5.TabIndex = 9;
			this.label5.Text = "가맹점코드";
			// 
			// lblUSR_ID
			// 
			this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_ID.AutoSize = true;
			this.lblUSR_ID.Location = new System.Drawing.Point(5, 60);
			this.lblUSR_ID.Name = "lblUSR_ID";
			this.lblUSR_ID.Size = new System.Drawing.Size(82, 15);
			this.lblUSR_ID.TabIndex = 2;
			this.lblUSR_ID.Text = "서비스상태";
			// 
			// _cmbCI_SVC_STAT
			// 
			this._cmbCI_SVC_STAT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCI_SVC_STAT.DataSource = null;
			this._cmbCI_SVC_STAT.DelegateProperty = true;
			this._cmbCI_SVC_STAT.DroppedDown = false;
			this._cmbCI_SVC_STAT.Enabled = false;
			this._cmbCI_SVC_STAT.Location = new System.Drawing.Point(93, 57);
			this._cmbCI_SVC_STAT.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_SVC_STAT.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_SVC_STAT.Name = "_cmbCI_SVC_STAT";
			this._cmbCI_SVC_STAT.SelectedIndex = -1;
			this._cmbCI_SVC_STAT.SelectedItem = null;
			this._cmbCI_SVC_STAT.SelectedValue = null;
			this._cmbCI_SVC_STAT.Size = new System.Drawing.Size(130, 23);
			this._cmbCI_SVC_STAT.TabIndex = 1060;
			this._cmbCI_SVC_STAT.ValidationGroup = null;
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(250, 60);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(67, 15);
			this.label2.TabIndex = 10;
			this.label2.Text = "출금상태";
			// 
			// _cmbCI_WTHR_STAT
			// 
			this._cmbCI_WTHR_STAT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._cmbCI_WTHR_STAT.DataSource = null;
			this._cmbCI_WTHR_STAT.DelegateProperty = true;
			this._cmbCI_WTHR_STAT.DroppedDown = false;
			this._cmbCI_WTHR_STAT.Enabled = false;
			this._cmbCI_WTHR_STAT.Location = new System.Drawing.Point(323, 57);
			this._cmbCI_WTHR_STAT.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_WTHR_STAT.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_WTHR_STAT.Name = "_cmbCI_WTHR_STAT";
			this._cmbCI_WTHR_STAT.SelectedIndex = -1;
			this._cmbCI_WTHR_STAT.SelectedItem = null;
			this._cmbCI_WTHR_STAT.SelectedValue = null;
			this._cmbCI_WTHR_STAT.Size = new System.Drawing.Size(130, 23);
			this._cmbCI_WTHR_STAT.TabIndex = 1070;
			this._cmbCI_WTHR_STAT.ValidationGroup = null;
			// 
			// lblCOMPANY_CD
			// 
			this.lblCOMPANY_CD.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblCOMPANY_CD.AutoSize = true;
			this.lblCOMPANY_CD.Location = new System.Drawing.Point(20, 33);
			this.lblCOMPANY_CD.Name = "lblCOMPANY_CD";
			this.lblCOMPANY_CD.Size = new System.Drawing.Size(67, 15);
			this.lblCOMPANY_CD.TabIndex = 0;
			this.lblCOMPANY_CD.Text = "계약일자";
			// 
			// _dtpCI_CNTR_STRT_DT
			// 
			this._dtpCI_CNTR_STRT_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpCI_CNTR_STRT_DT.Checked = false;
			this._dtpCI_CNTR_STRT_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpCI_CNTR_STRT_DT.DelegateProperty = true;
			this._dtpCI_CNTR_STRT_DT.Enabled = false;
			this._dtpCI_CNTR_STRT_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpCI_CNTR_STRT_DT.Location = new System.Drawing.Point(93, 30);
			this._dtpCI_CNTR_STRT_DT.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpCI_CNTR_STRT_DT.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpCI_CNTR_STRT_DT.Name = "_dtpCI_CNTR_STRT_DT";
			this._dtpCI_CNTR_STRT_DT.ShowCheckBox = true;
			this._dtpCI_CNTR_STRT_DT.Size = new System.Drawing.Size(130, 21);
			this._dtpCI_CNTR_STRT_DT.TabIndex = 1030;
			this._dtpCI_CNTR_STRT_DT.ValidationGroup = null;
			this._dtpCI_CNTR_STRT_DT.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(250, 33);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(67, 15);
			this.label1.TabIndex = 9;
			this.label1.Text = "해지일자";
			// 
			// _dtpCI_CNTR_END_DT
			// 
			this._dtpCI_CNTR_END_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpCI_CNTR_END_DT.Checked = false;
			this._dtpCI_CNTR_END_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpCI_CNTR_END_DT.DelegateProperty = true;
			this._dtpCI_CNTR_END_DT.Enabled = false;
			this._dtpCI_CNTR_END_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpCI_CNTR_END_DT.Location = new System.Drawing.Point(323, 30);
			this._dtpCI_CNTR_END_DT.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpCI_CNTR_END_DT.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpCI_CNTR_END_DT.Name = "_dtpCI_CNTR_END_DT";
			this._dtpCI_CNTR_END_DT.ShowCheckBox = true;
			this._dtpCI_CNTR_END_DT.Size = new System.Drawing.Size(130, 21);
			this._dtpCI_CNTR_END_DT.TabIndex = 1040;
			this._dtpCI_CNTR_END_DT.ValidationGroup = null;
			this._dtpCI_CNTR_END_DT.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 477);
			// 
			// lblUSR_PASS
			// 
			this.lblUSR_PASS.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.lblUSR_PASS.AutoSize = true;
			this.lblUSR_PASS.Location = new System.Drawing.Point(465, 27);
			this.lblUSR_PASS.Name = "lblUSR_PASS";
			this.lblUSR_PASS.Size = new System.Drawing.Size(82, 27);
			this.lblUSR_PASS.TabIndex = 8;
			this.lblUSR_PASS.Text = "출금시작일자";
			// 
			// _dtpCI_WTHR_STRT_DT
			// 
			this._dtpCI_WTHR_STRT_DT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpCI_WTHR_STRT_DT.Checked = false;
			this._dtpCI_WTHR_STRT_DT.CustomFormat = "yyyy-MM-dd";
			this._dtpCI_WTHR_STRT_DT.DelegateProperty = true;
			this._dtpCI_WTHR_STRT_DT.Enabled = false;
			this._dtpCI_WTHR_STRT_DT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpCI_WTHR_STRT_DT.Location = new System.Drawing.Point(553, 30);
			this._dtpCI_WTHR_STRT_DT.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpCI_WTHR_STRT_DT.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpCI_WTHR_STRT_DT.Name = "_dtpCI_WTHR_STRT_DT";
			this._dtpCI_WTHR_STRT_DT.ShowCheckBox = true;
			this._dtpCI_WTHR_STRT_DT.Size = new System.Drawing.Size(130, 21);
			this._dtpCI_WTHR_STRT_DT.TabIndex = 1050;
			this._dtpCI_WTHR_STRT_DT.ValidationGroup = null;
			this._dtpCI_WTHR_STRT_DT.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 481);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1354, 76);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 7;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this._cmbCI_SVC_STAT_S, 1, 1);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel5, 6, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbCI_WTHR_STAT_S, 3, 1);
			this.tableLayoutPanel6.Controls.Add(this._txtPRSNT_NM_S, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label39, 2, 1);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label38, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 2;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1348, 52);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// _cmbCI_SVC_STAT_S
			// 
			this._cmbCI_SVC_STAT_S.DataSource = null;
			this._cmbCI_SVC_STAT_S.DelegateProperty = true;
			this._cmbCI_SVC_STAT_S.DroppedDown = false;
			this._cmbCI_SVC_STAT_S.Location = new System.Drawing.Point(95, 32);
			this._cmbCI_SVC_STAT_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_SVC_STAT_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_SVC_STAT_S.Name = "_cmbCI_SVC_STAT_S";
			this._cmbCI_SVC_STAT_S.SelectedIndex = -1;
			this._cmbCI_SVC_STAT_S.SelectedItem = null;
			this._cmbCI_SVC_STAT_S.SelectedValue = null;
			this._cmbCI_SVC_STAT_S.Size = new System.Drawing.Size(124, 23);
			this._cmbCI_SVC_STAT_S.TabIndex = 141;
			this._cmbCI_SVC_STAT_S.ValidationGroup = null;
			// 
			// flowLayoutPanel5
			// 
			this.flowLayoutPanel5.Controls.Add(this._btnSearch);
			this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel5.Location = new System.Drawing.Point(677, 1);
			this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel5.Name = "flowLayoutPanel5";
			this.flowLayoutPanel5.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
			this.flowLayoutPanel5.Size = new System.Drawing.Size(696, 27);
			this.flowLayoutPanel5.TabIndex = 325;
			// 
			// _btnSearch
			// 
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 2);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 23);
			this._btnSearch.TabIndex = 160;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _cmbCI_WTHR_STAT_S
			// 
			this._cmbCI_WTHR_STAT_S.DataSource = null;
			this._cmbCI_WTHR_STAT_S.DelegateProperty = true;
			this._cmbCI_WTHR_STAT_S.DroppedDown = false;
			this._cmbCI_WTHR_STAT_S.Location = new System.Drawing.Point(317, 32);
			this._cmbCI_WTHR_STAT_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbCI_WTHR_STAT_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbCI_WTHR_STAT_S.Name = "_cmbCI_WTHR_STAT_S";
			this._cmbCI_WTHR_STAT_S.SelectedIndex = -1;
			this._cmbCI_WTHR_STAT_S.SelectedItem = null;
			this._cmbCI_WTHR_STAT_S.SelectedValue = null;
			this._cmbCI_WTHR_STAT_S.Size = new System.Drawing.Size(124, 23);
			this._cmbCI_WTHR_STAT_S.TabIndex = 140;
			this._cmbCI_WTHR_STAT_S.ValidationGroup = null;
			// 
			// _txtPRSNT_NM_S
			// 
			this._txtPRSNT_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtPRSNT_NM_S.AutoTab = false;
			this._txtPRSNT_NM_S.DelegateProperty = true;
			this._txtPRSNT_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtPRSNT_NM_S.Location = new System.Drawing.Point(549, 4);
			this._txtPRSNT_NM_S.Name = "_txtPRSNT_NM_S";
			this._txtPRSNT_NM_S.Size = new System.Drawing.Size(124, 23);
			this._txtPRSNT_NM_S.TabIndex = 120;
			this._txtPRSNT_NM_S.ValidationGroup = null;
			this._txtPRSNT_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtPRSNT_NM_S.WaterMarkText = "";
			// 
			// _txtSTR_CD_S
			// 
			this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD_S.AutoTab = false;
			this._txtSTR_CD_S.DelegateProperty = true;
			this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_CD_S.Location = new System.Drawing.Point(317, 4);
			this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
			this._txtSTR_CD_S.Size = new System.Drawing.Size(124, 23);
			this._txtSTR_CD_S.TabIndex = 110;
			this._txtSTR_CD_S.ValidationGroup = null;
			this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_CD_S.WaterMarkText = "";
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 4);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(124, 23);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(21, 7);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(67, 15);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// label39
			// 
			this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label39.AutoSize = true;
			this.label39.Location = new System.Drawing.Point(243, 35);
			this.label39.Name = "label39";
			this.label39.Size = new System.Drawing.Size(67, 15);
			this.label39.TabIndex = 1118;
			this.label39.Text = "출금상태";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(228, 7);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(82, 15);
			this.label36.TabIndex = 1115;
			this.label36.Text = "가맹점코드";
			// 
			// label38
			// 
			this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label38.AutoSize = true;
			this.label38.Location = new System.Drawing.Point(6, 35);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(82, 15);
			this.label38.TabIndex = 1117;
			this.label38.Text = "서비스상태";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(475, 7);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(67, 15);
			this.label37.TabIndex = 1116;
			this.label37.Text = "대표자명";
			// 
			// BAS0805
			// 
			this.ClientSize = new System.Drawing.Size(1354, 733);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.collapsibleSplitter1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "BAS0805";
			this.Text = "가맹점.정산/계약정보관리:BAS0805";
			this.Load += new System.EventHandler(this.BAS0805_Load);
			this.Shown += new System.EventHandler(this.BAS0805_Shown);
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.panel1.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel2.PerformLayout();
			this.groupBox5.ResumeLayout(false);
			this.tableLayoutPanel3.ResumeLayout(false);
			this.tableLayoutPanel3.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel4.PerformLayout();
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			this.flowLayoutPanel3.ResumeLayout(false);
			this.flowLayoutPanel3.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.tableLayoutPanel4.ResumeLayout(false);
			this.tableLayoutPanel4.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.flowLayoutPanel6.ResumeLayout(false);
			this.flowLayoutPanel6.PerformLayout();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel5.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private Controls.TableLayoutPanel tableLayoutPanel6;
		private BANANA.Windows.Controls.ComboBox _cmbCI_WTHR_STAT_S;
		private BANANA.Windows.Controls.TextBox _txtPRSNT_NM_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
		private BANANA.Windows.Controls.Label label35;
		private BANANA.Windows.Controls.Label label39;
		private BANANA.Windows.Controls.Label label36;
		private BANANA.Windows.Controls.Label label38;
		private BANANA.Windows.Controls.Label label37;
		private BANANA.Windows.Controls.Panel panel1;
		private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
		private System.Windows.Forms.GroupBox groupBox2;
		private DemoClient.Controls.GridView gridView1;
		private BANANA.Windows.Controls.GroupBox groupBox5;
		private BANANA.Windows.Controls.GroupBox groupBox4;
		private BANANA.Windows.Controls.GroupBox groupBox3;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private BANANA.Windows.Controls.Label lblCOMPANY_CD;
		private BANANA.Windows.Controls.Label lblUSR_ID;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private BANANA.Windows.Controls.Label lblUSR_PASS;
		private System.Windows.Forms.Label label4;
		private DemoClient.Controls.BananaButton _btnSave01;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_STRT_DT;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_END_DT;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_WTHR_STRT_DT;
		private BANANA.Windows.Controls.ComboBox _cmbCI_SVC_STAT;
		private BANANA.Windows.Controls.ComboBox _cmbCI_WTHR_STAT;
		private BANANA.Windows.Controls.TextBox _txtCI_UNIT_LMT;
		private BANANA.Windows.Controls.TextBox _txtCI_DAILY_LMT;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private BANANA.Windows.Controls.CheckBox _chkCI_USE_INSRNC;
		private BANANA.Windows.Controls.CheckBox _chkCI_USE_BLNC;
		private BANANA.Windows.Controls.CheckBox _chkCI_USE_SRT;
		private BANANA.Windows.Controls.Label label3;
		private BANANA.Windows.Controls.TextBox _txtPRSNT_NM;
		private BANANA.Windows.Controls.TextBox _txtSTR_NM;
		private BANANA.Windows.Controls.Label label8;
		private BANANA.Windows.Controls.Label label7;
		private BANANA.Windows.Controls.TextBox _txtSTR_CD;
		private BANANA.Windows.Controls.Label label5;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private BANANA.Windows.Controls.Label label22;
		private System.Windows.Forms.Label label23;
		private BANANA.Windows.Controls.Label label24;
		private DemoClient.Controls.BananaButton _btnSave02;
		private BANANA.Windows.Controls.TextBox _txtCI_RDM_ACCT_NM;
		private BANANA.Windows.Controls.TextBox _txtCI_RDM_ACCT_NO;
		private BANANA.Windows.Controls.ComboBox _cmbCI_RDM_BNK_CD;
		private DemoClient.Controls.BananaButton _btnRate;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
		private BANANA.Windows.Controls.Label label11;
		private BANANA.Windows.Controls.Label label12;
		private BANANA.Windows.Controls.Label label13;
		private BANANA.Windows.Controls.ComboBox _cmbCI_AGT_CD;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_APP_DT;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private BANANA.Windows.Controls.TextBox _txtCI_LN_RATE;
		private BANANA.Windows.Controls.Label label6;
		private DemoClient.Controls.BananaButton _btnSave03;
		private BANANA.Windows.Controls.Label label10;
		private BANANA.Windows.Controls.ComboBox _cmbCI_LNR_CD;
		private BANANA.Windows.Controls.Label label9;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
		private BANANA.Windows.Controls.RadioButton _rbCI_LN_GUBUN01;
		private BANANA.Windows.Controls.RadioButton _rbCI_LN_GUBUN02;
		private BANANA.Windows.Controls.Label label16;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private BANANA.Windows.Controls.TextBox _txtCI_LN_OVD;
		private BANANA.Windows.Controls.Label label18;
		private BANANA.Windows.Controls.GroupBox groupBox6;
		private DemoClient.Controls.BananaButton _btnSave04;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
		private BANANA.Windows.Controls.TextBox _txtCI_TOT_LMT;
		private BANANA.Windows.Controls.Label label19;
		private BANANA.Windows.Controls.Label label21;
		private BANANA.Windows.Controls.Label label25;
		private DemoClient.Controls.BananaButton _btnLimit;
		private BANANA.Windows.Controls.DateTimePicker _dtpCI_LMT_APP_DT;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
		private DemoClient.Controls.BananaButton _btnSearch;
		private BANANA.Windows.Controls.Label label20;
		private BANANA.Windows.Controls.ComboBox _cmbCI_PAY_BNK_CD;
		private BANANA.Windows.Controls.TextBox _txtCI_PAY_ACCT_NO;
		private System.Windows.Forms.Label label26;
		private BANANA.Windows.Controls.Label label27;
		private BANANA.Windows.Controls.TextBox _txtCI_PAY_ACCT_NM;
		private BANANA.Windows.Controls.Label label28;
		private BANANA.Windows.Controls.TextBox _txtCI_BZL_PER;
		private BANANA.Windows.Controls.ComboBox _cmbCI_SVC_STAT_S;
		private BANANA.Windows.Controls.TextBox _txtCI_ACCOUNT_FEE;
		private BANANA.Windows.Controls.Label label14;
		private BANANA.Windows.Controls.Label label15;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
		private BANANA.Windows.Controls.RadioButton _rbCI_WTHR_TYPE_Y;
		private BANANA.Windows.Controls.RadioButton _rbCI_WTHR_TYPE_T;
		private BANANA.Windows.Controls.RadioButton _rbCI_WTHR_TYPE_E;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn PRSNT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_CNTR_STRT_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_CNTR_END_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_WTHR_STRT_DT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_SVC_STAT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_WTHR_STAT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_UNIT_LMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_DAILY_LMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_TOT_LMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_RATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_OVD;
		private System.Windows.Forms.DataGridViewTextBoxColumn LIVEWDRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_AGT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_APP_DT;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band01;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_RDM_BNK_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_RDM_ACCT_NO;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_RDM_ACCT_NM;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Band02;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_PAY_BNK_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_PAY_ACCT_NO;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_PAY_ACCT_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
	}
}
