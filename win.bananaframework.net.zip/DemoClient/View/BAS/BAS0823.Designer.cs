﻿namespace DemoClient.View.BAS
{
	partial class BAS0823
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAS0823));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gridView1 = new DemoClient.Controls.GridView();
            this.BAND01 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
            this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HST_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GROUP_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_CNTR_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_CNTR_END_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_WTHR_STRT_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_SVC_STAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_WTHR_STAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_USE_INSRNC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_USE_BLNC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_USE_SRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BAND02 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
            this.CI_LN_BNK_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_LN_ACCT_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_LN_ACCT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_RDM_BNK_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_RDM_ACCT_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_RDM_ACCT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BAND03 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
            this.CI_LN_RATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_LN_OVD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_AGT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_APP_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_LNR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_LN_GUBUN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BAND04 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
            this.CI_UNIT_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_DAILY_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_TOT_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CI_LMT_APP_DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSMODNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSDELDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSDELNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new DemoClient.Controls.TableLayoutPanel();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this._dtpSYSMODDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
            this.label11 = new BANANA.Windows.Controls.Label();
            this._dtpSYSMODDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
            this._txtSYSREGNAME_S = new BANANA.Windows.Controls.TextBox();
            this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
            this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this._txtCI_TOT_LMT_S = new BANANA.Windows.Controls.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this._txtCI_TOT_LMT_E = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this._txtCI_DAILY_LMT_S = new BANANA.Windows.Controls.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this._txtCI_DAILY_LMT_E = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this._txtCI_UNIT_LMT_S = new BANANA.Windows.Controls.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this._txtCI_UNIT_LMT_E = new BANANA.Windows.Controls.TextBox();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this._dtpCI_WTHR_STRT_DT_S = new BANANA.Windows.Controls.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this._dtpCI_WTHR_STRT_DT_E = new BANANA.Windows.Controls.DateTimePicker();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this._dtpCI_CNTR_END_DT_S = new BANANA.Windows.Controls.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this._dtpCI_CNTR_END_DT_E = new BANANA.Windows.Controls.DateTimePicker();
            this.label4 = new BANANA.Windows.Controls.Label();
            this.label3 = new BANANA.Windows.Controls.Label();
            this.label1 = new BANANA.Windows.Controls.Label();
            this.label2 = new BANANA.Windows.Controls.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this._btnExcel = new DemoClient.Controls.BananaButton();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this._dtpCI_CNTR_STRT_DT_S = new BANANA.Windows.Controls.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this._dtpCI_CNTR_STRT_DT_E = new BANANA.Windows.Controls.DateTimePicker();
            this.label40 = new BANANA.Windows.Controls.Label();
            this.label35 = new BANANA.Windows.Controls.Label();
            this.label39 = new BANANA.Windows.Controls.Label();
            this.label37 = new BANANA.Windows.Controls.Label();
            this.label38 = new BANANA.Windows.Controls.Label();
            this.label36 = new BANANA.Windows.Controls.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel8.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel7.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gridView1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 104);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1333, 629);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "검색 결과";
            // 
            // gridView1
            // 
            this.gridView1.AllowUserToAddRows = false;
            this.gridView1.AutoSelectRowWithRightButton = false;
            this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView1.ColumnHeadersHeight = 50;
            this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BAND01,
            this.IDX,
            this.HST_TYPE,
            this.GROUP_NO,
            this.STR_CD,
            this.STR_NM,
            this.CI_CNTR_STRT_DT,
            this.CI_CNTR_END_DT,
            this.CI_WTHR_STRT_DT,
            this.CI_SVC_STAT,
            this.CI_WTHR_STAT,
            this.CI_USE_INSRNC,
            this.CI_USE_BLNC,
            this.CI_USE_SRT,
            this.BAND02,
            this.CI_LN_BNK_NM,
            this.CI_LN_ACCT_NO,
            this.CI_LN_ACCT_NM,
            this.CI_RDM_BNK_NM,
            this.CI_RDM_ACCT_NO,
            this.CI_RDM_ACCT_NM,
            this.BAND03,
            this.CI_LN_RATE,
            this.CI_LN_OVD,
            this.CI_AGT_NM,
            this.CI_APP_DT,
            this.CI_LNR_NM,
            this.CI_LN_GUBUN,
            this.BAND04,
            this.CI_UNIT_LMT,
            this.CI_DAILY_LMT,
            this.CI_TOT_LMT,
            this.CI_LMT_APP_DT,
            this.SYSREGDATE,
            this.SYSREGNAME,
            this.SYSMODDATE,
            this.SYSMODNAME,
            this.SYSDELDATE,
            this.SYSDELNAME});
            this.gridView1.DelegateProperty = true;
            this.gridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridView1.Location = new System.Drawing.Point(3, 17);
            this.gridView1.Name = "gridView1";
            this.gridView1.ReadOnly = true;
            this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView1.Size = new System.Drawing.Size(1327, 609);
            this.gridView1.TabIndex = 1;
            this.gridView1.ShowHeaderCheckBox = false;
            // 
            // BAND01
            // 
            this.BAND01.Frozen = true;
            this.BAND01.HeaderText = "계약정보";
            this.BAND01.Name = "BAND01";
            this.BAND01.ReadOnly = true;
            this.BAND01.TargetColumnss.Add("CI_CNTR_STRT_DT");
            this.BAND01.TargetColumnss.Add("CI_CNTR_END_DT");
            this.BAND01.TargetColumnss.Add("CI_WTHR_STRT_DT");
            this.BAND01.TargetColumnss.Add("CI_SVC_STAT");
            this.BAND01.TargetColumnss.Add("CI_WTHR_STAT");
            this.BAND01.TargetColumnss.Add("CI_USE_INSRNC");
            this.BAND01.TargetColumnss.Add("CI_USE_BLNC");
            this.BAND01.TargetColumnss.Add("CI_USE_SRT");
            this.BAND01.Width = 57;
            // 
            // IDX
            // 
            this.IDX.DataPropertyName = "IDX";
            this.IDX.Frozen = true;
            this.IDX.HeaderText = "일련번호";
            this.IDX.Name = "IDX";
            this.IDX.ReadOnly = true;
            this.IDX.Width = 76;
            // 
            // HST_TYPE
            // 
            this.HST_TYPE.DataPropertyName = "HST_TYPE";
            this.HST_TYPE.Frozen = true;
            this.HST_TYPE.HeaderText = "이력구분";
            this.HST_TYPE.Name = "HST_TYPE";
            this.HST_TYPE.ReadOnly = true;
            this.HST_TYPE.Width = 76;
            // 
            // GROUP_NO
            // 
            this.GROUP_NO.DataPropertyName = "GROUP_NO";
            this.GROUP_NO.Frozen = true;
            this.GROUP_NO.HeaderText = "그룹번호";
            this.GROUP_NO.Name = "GROUP_NO";
            this.GROUP_NO.ReadOnly = true;
            this.GROUP_NO.Width = 76;
            // 
            // STR_CD
            // 
            this.STR_CD.DataPropertyName = "STR_CD";
            this.STR_CD.Frozen = true;
            this.STR_CD.HeaderText = "가맹점코드";
            this.STR_CD.Name = "STR_CD";
            this.STR_CD.ReadOnly = true;
            this.STR_CD.Width = 87;
            // 
            // STR_NM
            // 
            this.STR_NM.DataPropertyName = "STR_NM";
            this.STR_NM.Frozen = true;
            this.STR_NM.HeaderText = "가맹점명";
            this.STR_NM.Name = "STR_NM";
            this.STR_NM.ReadOnly = true;
            this.STR_NM.Width = 76;
            // 
            // CI_CNTR_STRT_DT
            // 
            this.CI_CNTR_STRT_DT.DataPropertyName = "CI_CNTR_STRT_DT";
            this.CI_CNTR_STRT_DT.HeaderText = "계약일자";
            this.CI_CNTR_STRT_DT.Name = "CI_CNTR_STRT_DT";
            this.CI_CNTR_STRT_DT.ReadOnly = true;
            this.CI_CNTR_STRT_DT.Width = 76;
            // 
            // CI_CNTR_END_DT
            // 
            this.CI_CNTR_END_DT.DataPropertyName = "CI_CNTR_END_DT";
            this.CI_CNTR_END_DT.HeaderText = "해지일자";
            this.CI_CNTR_END_DT.Name = "CI_CNTR_END_DT";
            this.CI_CNTR_END_DT.ReadOnly = true;
            this.CI_CNTR_END_DT.Width = 76;
            // 
            // CI_WTHR_STRT_DT
            // 
            this.CI_WTHR_STRT_DT.DataPropertyName = "CI_WTHR_STRT_DT";
            this.CI_WTHR_STRT_DT.HeaderText = "출금시작일자";
            this.CI_WTHR_STRT_DT.Name = "CI_WTHR_STRT_DT";
            this.CI_WTHR_STRT_DT.ReadOnly = true;
            this.CI_WTHR_STRT_DT.Width = 98;
            // 
            // CI_SVC_STAT
            // 
            this.CI_SVC_STAT.DataPropertyName = "CI_SVC_STAT";
            this.CI_SVC_STAT.HeaderText = "서비스상태";
            this.CI_SVC_STAT.Name = "CI_SVC_STAT";
            this.CI_SVC_STAT.ReadOnly = true;
            this.CI_SVC_STAT.Width = 87;
            // 
            // CI_WTHR_STAT
            // 
            this.CI_WTHR_STAT.DataPropertyName = "CI_WTHR_STAT";
            this.CI_WTHR_STAT.HeaderText = "출금상태";
            this.CI_WTHR_STAT.Name = "CI_WTHR_STAT";
            this.CI_WTHR_STAT.ReadOnly = true;
            this.CI_WTHR_STAT.Width = 76;
            // 
            // CI_USE_INSRNC
            // 
            this.CI_USE_INSRNC.DataPropertyName = "CI_USE_INSRNC";
            this.CI_USE_INSRNC.HeaderText = "보증보험";
            this.CI_USE_INSRNC.Name = "CI_USE_INSRNC";
            this.CI_USE_INSRNC.ReadOnly = true;
            this.CI_USE_INSRNC.Width = 76;
            // 
            // CI_USE_BLNC
            // 
            this.CI_USE_BLNC.DataPropertyName = "CI_USE_BLNC";
            this.CI_USE_BLNC.HeaderText = "보증예치금";
            this.CI_USE_BLNC.Name = "CI_USE_BLNC";
            this.CI_USE_BLNC.ReadOnly = true;
            this.CI_USE_BLNC.Width = 87;
            // 
            // CI_USE_SRT
            // 
            this.CI_USE_SRT.DataPropertyName = "CI_USE_SRT";
            this.CI_USE_SRT.HeaderText = "연대보증인";
            this.CI_USE_SRT.Name = "CI_USE_SRT";
            this.CI_USE_SRT.ReadOnly = true;
            this.CI_USE_SRT.Width = 87;
            // 
            // BAND02
            // 
            this.BAND02.HeaderText = "계좌정보";
            this.BAND02.Name = "BAND02";
            this.BAND02.ReadOnly = true;
            this.BAND02.TargetColumnss.Add("CI_LN_BNK_NM");
            this.BAND02.TargetColumnss.Add("CI_LN_ACCT_NO");
            this.BAND02.TargetColumnss.Add("CI_LN_ACCT_NM");
            this.BAND02.TargetColumnss.Add("CI_RDM_BNK_NM");
            this.BAND02.TargetColumnss.Add("CI_RDM_ACCT_NO");
            this.BAND02.TargetColumnss.Add("CI_RDM_ACCT_NM");
            this.BAND02.Width = 57;
            // 
            // CI_LN_BNK_NM
            // 
            this.CI_LN_BNK_NM.DataPropertyName = "CI_LN_BNK_NM";
            this.CI_LN_BNK_NM.HeaderText = "대출.은행";
            this.CI_LN_BNK_NM.Name = "CI_LN_BNK_NM";
            this.CI_LN_BNK_NM.ReadOnly = true;
            this.CI_LN_BNK_NM.Width = 79;
            // 
            // CI_LN_ACCT_NO
            // 
            this.CI_LN_ACCT_NO.DataPropertyName = "CI_LN_ACCT_NO";
            this.CI_LN_ACCT_NO.HeaderText = "대출.계좌번호";
            this.CI_LN_ACCT_NO.Name = "CI_LN_ACCT_NO";
            this.CI_LN_ACCT_NO.ReadOnly = true;
            this.CI_LN_ACCT_NO.Width = 101;
            // 
            // CI_LN_ACCT_NM
            // 
            this.CI_LN_ACCT_NM.DataPropertyName = "CI_LN_ACCT_NM";
            this.CI_LN_ACCT_NM.HeaderText = "대출.예금주";
            this.CI_LN_ACCT_NM.Name = "CI_LN_ACCT_NM";
            this.CI_LN_ACCT_NM.ReadOnly = true;
            this.CI_LN_ACCT_NM.Width = 90;
            // 
            // CI_RDM_BNK_NM
            // 
            this.CI_RDM_BNK_NM.DataPropertyName = "CI_RDM_BNK_NM";
            this.CI_RDM_BNK_NM.HeaderText = "상환.은행";
            this.CI_RDM_BNK_NM.Name = "CI_RDM_BNK_NM";
            this.CI_RDM_BNK_NM.ReadOnly = true;
            this.CI_RDM_BNK_NM.Width = 79;
            // 
            // CI_RDM_ACCT_NO
            // 
            this.CI_RDM_ACCT_NO.DataPropertyName = "CI_RDM_ACCT_NO";
            this.CI_RDM_ACCT_NO.HeaderText = "상환.계좌번호";
            this.CI_RDM_ACCT_NO.Name = "CI_RDM_ACCT_NO";
            this.CI_RDM_ACCT_NO.ReadOnly = true;
            this.CI_RDM_ACCT_NO.Width = 101;
            // 
            // CI_RDM_ACCT_NM
            // 
            this.CI_RDM_ACCT_NM.DataPropertyName = "CI_RDM_ACCT_NM";
            this.CI_RDM_ACCT_NM.HeaderText = "상환.예금주";
            this.CI_RDM_ACCT_NM.Name = "CI_RDM_ACCT_NM";
            this.CI_RDM_ACCT_NM.ReadOnly = true;
            this.CI_RDM_ACCT_NM.Width = 90;
            // 
            // BAND03
            // 
            this.BAND03.HeaderText = "대출이자정보";
            this.BAND03.Name = "BAND03";
            this.BAND03.ReadOnly = true;
            this.BAND03.TargetColumnss.Add("CI_LN_RATE");
            this.BAND03.TargetColumnss.Add("CI_LN_OVD");
            this.BAND03.TargetColumnss.Add("CI_AGT_NM");
            this.BAND03.TargetColumnss.Add("CI_APP_DT");
            this.BAND03.TargetColumnss.Add("CI_LNR_NM");
            this.BAND03.TargetColumnss.Add("CI_LN_GUBUN");
            this.BAND03.Width = 79;
            // 
            // CI_LN_RATE
            // 
            this.CI_LN_RATE.DataPropertyName = "CI_LN_RATE";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.NullValue = "0";
            this.CI_LN_RATE.DefaultCellStyle = dataGridViewCellStyle2;
            this.CI_LN_RATE.HeaderText = "대출이자율";
            this.CI_LN_RATE.Name = "CI_LN_RATE";
            this.CI_LN_RATE.ReadOnly = true;
            this.CI_LN_RATE.Width = 87;
            // 
            // CI_LN_OVD
            // 
            this.CI_LN_OVD.DataPropertyName = "CI_LN_OVD";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.NullValue = "0";
            this.CI_LN_OVD.DefaultCellStyle = dataGridViewCellStyle3;
            this.CI_LN_OVD.HeaderText = "연체이자율";
            this.CI_LN_OVD.Name = "CI_LN_OVD";
            this.CI_LN_OVD.ReadOnly = true;
            this.CI_LN_OVD.Width = 87;
            // 
            // CI_AGT_NM
            // 
            this.CI_AGT_NM.DataPropertyName = "CI_AGT_NM";
            this.CI_AGT_NM.HeaderText = "수익대리점";
            this.CI_AGT_NM.Name = "CI_AGT_NM";
            this.CI_AGT_NM.ReadOnly = true;
            this.CI_AGT_NM.Width = 87;
            // 
            // CI_APP_DT
            // 
            this.CI_APP_DT.DataPropertyName = "CI_APP_DT";
            this.CI_APP_DT.HeaderText = "적용시작일";
            this.CI_APP_DT.Name = "CI_APP_DT";
            this.CI_APP_DT.ReadOnly = true;
            this.CI_APP_DT.Width = 87;
            // 
            // CI_LNR_NM
            // 
            this.CI_LNR_NM.DataPropertyName = "CI_LNR_NM";
            this.CI_LNR_NM.HeaderText = "여신사";
            this.CI_LNR_NM.Name = "CI_LNR_NM";
            this.CI_LNR_NM.ReadOnly = true;
            this.CI_LNR_NM.Width = 65;
            // 
            // CI_LN_GUBUN
            // 
            this.CI_LN_GUBUN.DataPropertyName = "CI_LN_GUBUN";
            this.CI_LN_GUBUN.HeaderText = "대출구분";
            this.CI_LN_GUBUN.Name = "CI_LN_GUBUN";
            this.CI_LN_GUBUN.ReadOnly = true;
            this.CI_LN_GUBUN.Width = 76;
            // 
            // BAND04
            // 
            this.BAND04.HeaderText = "한도정보";
            this.BAND04.Name = "BAND04";
            this.BAND04.ReadOnly = true;
            this.BAND04.TargetColumnss.Add("CI_UNIT_LMT");
            this.BAND04.TargetColumnss.Add("CI_DAILY_LMT");
            this.BAND04.TargetColumnss.Add("CI_TOT_LMT");
            this.BAND04.TargetColumnss.Add("CI_LMT_APP_DT");
            this.BAND04.Width = 57;
            // 
            // CI_UNIT_LMT
            // 
            this.CI_UNIT_LMT.DataPropertyName = "CI_UNIT_LMT";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = "0";
            this.CI_UNIT_LMT.DefaultCellStyle = dataGridViewCellStyle4;
            this.CI_UNIT_LMT.HeaderText = "건별대출한도";
            this.CI_UNIT_LMT.Name = "CI_UNIT_LMT";
            this.CI_UNIT_LMT.ReadOnly = true;
            this.CI_UNIT_LMT.Width = 98;
            // 
            // CI_DAILY_LMT
            // 
            this.CI_DAILY_LMT.DataPropertyName = "CI_DAILY_LMT";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N0";
            dataGridViewCellStyle5.NullValue = "0";
            this.CI_DAILY_LMT.DefaultCellStyle = dataGridViewCellStyle5;
            this.CI_DAILY_LMT.HeaderText = "일대출한도";
            this.CI_DAILY_LMT.Name = "CI_DAILY_LMT";
            this.CI_DAILY_LMT.ReadOnly = true;
            this.CI_DAILY_LMT.Width = 87;
            // 
            // CI_TOT_LMT
            // 
            this.CI_TOT_LMT.DataPropertyName = "CI_TOT_LMT";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = "0";
            this.CI_TOT_LMT.DefaultCellStyle = dataGridViewCellStyle6;
            this.CI_TOT_LMT.HeaderText = "총대출한도";
            this.CI_TOT_LMT.Name = "CI_TOT_LMT";
            this.CI_TOT_LMT.ReadOnly = true;
            this.CI_TOT_LMT.Width = 87;
            // 
            // CI_LMT_APP_DT
            // 
            this.CI_LMT_APP_DT.DataPropertyName = "CI_LMT_APP_DT";
            this.CI_LMT_APP_DT.HeaderText = "적용시작일";
            this.CI_LMT_APP_DT.Name = "CI_LMT_APP_DT";
            this.CI_LMT_APP_DT.ReadOnly = true;
            this.CI_LMT_APP_DT.Width = 87;
            // 
            // SYSREGDATE
            // 
            this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE.HeaderText = "시스템등록일";
            this.SYSREGDATE.MinimumWidth = 140;
            this.SYSREGDATE.Name = "SYSREGDATE";
            this.SYSREGDATE.ReadOnly = true;
            this.SYSREGDATE.Width = 140;
            // 
            // SYSREGNAME
            // 
            this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
            this.SYSREGNAME.HeaderText = "시스템등록자";
            this.SYSREGNAME.Name = "SYSREGNAME";
            this.SYSREGNAME.ReadOnly = true;
            this.SYSREGNAME.Width = 98;
            // 
            // SYSMODDATE
            // 
            this.SYSMODDATE.DataPropertyName = "SYSMODDATE";
            this.SYSMODDATE.HeaderText = "시스템수정일";
            this.SYSMODDATE.MinimumWidth = 140;
            this.SYSMODDATE.Name = "SYSMODDATE";
            this.SYSMODDATE.ReadOnly = true;
            this.SYSMODDATE.Width = 140;
            // 
            // SYSMODNAME
            // 
            this.SYSMODNAME.DataPropertyName = "SYSMODNAME";
            this.SYSMODNAME.HeaderText = "시스템수정자";
            this.SYSMODNAME.Name = "SYSMODNAME";
            this.SYSMODNAME.ReadOnly = true;
            this.SYSMODNAME.Width = 98;
            // 
            // SYSDELDATE
            // 
            this.SYSDELDATE.DataPropertyName = "SYSDELDATE";
            this.SYSDELDATE.HeaderText = "시스템삭제일";
            this.SYSDELDATE.MinimumWidth = 140;
            this.SYSDELDATE.Name = "SYSDELDATE";
            this.SYSDELDATE.ReadOnly = true;
            this.SYSDELDATE.Width = 140;
            // 
            // SYSDELNAME
            // 
            this.SYSDELNAME.DataPropertyName = "SYSDELNAME";
            this.SYSDELNAME.HeaderText = "시스템삭제자";
            this.SYSDELNAME.Name = "SYSDELNAME";
            this.SYSDELNAME.ReadOnly = true;
            this.SYSDELNAME.Width = 98;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel6);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1333, 104);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "검색 조건";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel6.ColumnCount = 9;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel8, 7, 1);
            this.tableLayoutPanel6.Controls.Add(this._txtSYSREGNAME_S, 7, 0);
            this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel3, 5, 2);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel6, 5, 1);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel7, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel5, 3, 2);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.label4, 6, 1);
            this.tableLayoutPanel6.Controls.Add(this.label3, 4, 2);
            this.tableLayoutPanel6.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.label2, 6, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel2, 8, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label40, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label39, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.label38, 2, 2);
            this.tableLayoutPanel6.Controls.Add(this.label36, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 3;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1327, 84);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // flowLayoutPanel8
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.flowLayoutPanel8, 2);
            this.flowLayoutPanel8.Controls.Add(this.label11);
            this.flowLayoutPanel8.Location = new System.Drawing.Point(978, 29);
            this.flowLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel8.Size = new System.Drawing.Size(352, 27);
            this.flowLayoutPanel8.TabIndex = 170;
            // 
            // _dtpSYSMODDATE_S_S
            // 
            this._dtpSYSMODDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpSYSMODDATE_S_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this._dtpSYSMODDATE_S_S.DelegateProperty = true;
            this._dtpSYSMODDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpSYSMODDATE_S_S.Location = new System.Drawing.Point(3, 5);
            this._dtpSYSMODDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpSYSMODDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpSYSMODDATE_S_S.Name = "_dtpSYSMODDATE_S_S";
            this._dtpSYSMODDATE_S_S.Size = new System.Drawing.Size(150, 21);
            this._dtpSYSMODDATE_S_S.TabIndex = 26;
            this._dtpSYSMODDATE_S_S.ValidationGroup = null;
            this._dtpSYSMODDATE_S_S.Value = new System.DateTime(2014, 8, 8, 14, 1, 19, 635);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 2);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 12);
            this.label11.TabIndex = 21;
            this.label11.Text = "~";
            // 
            // _dtpSYSMODDATE_E_S
            // 
            this._dtpSYSMODDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpSYSMODDATE_E_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this._dtpSYSMODDATE_E_S.DelegateProperty = true;
            this._dtpSYSMODDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpSYSMODDATE_E_S.Location = new System.Drawing.Point(179, 5);
            this._dtpSYSMODDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpSYSMODDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpSYSMODDATE_E_S.Name = "_dtpSYSMODDATE_E_S";
            this._dtpSYSMODDATE_E_S.Size = new System.Drawing.Size(150, 21);
            this._dtpSYSMODDATE_E_S.TabIndex = 27;
            this._dtpSYSMODDATE_E_S.ValidationGroup = null;
            this._dtpSYSMODDATE_E_S.Value = new System.DateTime(2014, 8, 8, 14, 1, 19, 638);
            // 
            // _txtSYSREGNAME_S
            // 
            this._txtSYSREGNAME_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSYSREGNAME_S.AutoTab = false;
            this._txtSYSREGNAME_S.DelegateProperty = true;
            this._txtSYSREGNAME_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSYSREGNAME_S.Location = new System.Drawing.Point(981, 4);
            this._txtSYSREGNAME_S.Name = "_txtSYSREGNAME_S";
            this._txtSYSREGNAME_S.Size = new System.Drawing.Size(124, 20);
            this._txtSYSREGNAME_S.TabIndex = 130;
            this._txtSYSREGNAME_S.ValidationGroup = null;
            this._txtSYSREGNAME_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSYSREGNAME_S.WaterMarkText = "";
            // 
            // _txtSTR_CD_S
            // 
            this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_CD_S.AutoTab = false;
            this._txtSTR_CD_S.DelegateProperty = true;
            this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_CD_S.Location = new System.Drawing.Point(95, 32);
            this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
            this._txtSTR_CD_S.Size = new System.Drawing.Size(124, 20);
            this._txtSTR_CD_S.TabIndex = 140;
            this._txtSTR_CD_S.ValidationGroup = null;
            this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSTR_CD_S.WaterMarkText = "";
            // 
            // _txtSTR_NM_S
            // 
            this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_NM_S.AutoTab = false;
            this._txtSTR_NM_S.DelegateProperty = true;
            this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_NM_S.Location = new System.Drawing.Point(95, 4);
            this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
            this._txtSTR_NM_S.Size = new System.Drawing.Size(124, 20);
            this._txtSTR_NM_S.TabIndex = 100;
            this._txtSTR_NM_S.ValidationGroup = null;
            this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSTR_NM_S.WaterMarkText = "";
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this._txtCI_TOT_LMT_S);
            this.flowLayoutPanel3.Controls.Add(this.label6);
            this.flowLayoutPanel3.Controls.Add(this._txtCI_TOT_LMT_E);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(646, 57);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(240, 27);
            this.flowLayoutPanel3.TabIndex = 190;
            // 
            // _txtCI_TOT_LMT_S
            // 
            this._txtCI_TOT_LMT_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_TOT_LMT_S.AutoTab = false;
            this._txtCI_TOT_LMT_S.DelegateProperty = true;
            this._txtCI_TOT_LMT_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_TOT_LMT_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCI_TOT_LMT_S.Location = new System.Drawing.Point(3, 3);
            this._txtCI_TOT_LMT_S.Name = "_txtCI_TOT_LMT_S";
            this._txtCI_TOT_LMT_S.Size = new System.Drawing.Size(100, 20);
            this._txtCI_TOT_LMT_S.TabIndex = 10;
            this._txtCI_TOT_LMT_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCI_TOT_LMT_S.ValidationGroup = null;
            this._txtCI_TOT_LMT_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_TOT_LMT_S.WaterMarkText = "";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(109, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "~";
            // 
            // _txtCI_TOT_LMT_E
            // 
            this._txtCI_TOT_LMT_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_TOT_LMT_E.AutoTab = false;
            this._txtCI_TOT_LMT_E.DelegateProperty = true;
            this._txtCI_TOT_LMT_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_TOT_LMT_E.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCI_TOT_LMT_E.Location = new System.Drawing.Point(129, 3);
            this._txtCI_TOT_LMT_E.Name = "_txtCI_TOT_LMT_E";
            this._txtCI_TOT_LMT_E.Size = new System.Drawing.Size(100, 20);
            this._txtCI_TOT_LMT_E.TabIndex = 20;
            this._txtCI_TOT_LMT_E.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCI_TOT_LMT_E.ValidationGroup = null;
            this._txtCI_TOT_LMT_E.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_TOT_LMT_E.WaterMarkText = "";
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this._txtCI_DAILY_LMT_S);
            this.flowLayoutPanel6.Controls.Add(this.label9);
            this.flowLayoutPanel6.Controls.Add(this._txtCI_DAILY_LMT_E);
            this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(646, 29);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(240, 27);
            this.flowLayoutPanel6.TabIndex = 160;
            // 
            // _txtCI_DAILY_LMT_S
            // 
            this._txtCI_DAILY_LMT_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_DAILY_LMT_S.AutoTab = false;
            this._txtCI_DAILY_LMT_S.DelegateProperty = true;
            this._txtCI_DAILY_LMT_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_DAILY_LMT_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCI_DAILY_LMT_S.Location = new System.Drawing.Point(3, 3);
            this._txtCI_DAILY_LMT_S.Name = "_txtCI_DAILY_LMT_S";
            this._txtCI_DAILY_LMT_S.Size = new System.Drawing.Size(100, 20);
            this._txtCI_DAILY_LMT_S.TabIndex = 10;
            this._txtCI_DAILY_LMT_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCI_DAILY_LMT_S.ValidationGroup = null;
            this._txtCI_DAILY_LMT_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_DAILY_LMT_S.WaterMarkText = "";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(109, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 12);
            this.label9.TabIndex = 11;
            this.label9.Text = "~";
            // 
            // _txtCI_DAILY_LMT_E
            // 
            this._txtCI_DAILY_LMT_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_DAILY_LMT_E.AutoTab = false;
            this._txtCI_DAILY_LMT_E.DelegateProperty = true;
            this._txtCI_DAILY_LMT_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_DAILY_LMT_E.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCI_DAILY_LMT_E.Location = new System.Drawing.Point(129, 3);
            this._txtCI_DAILY_LMT_E.Name = "_txtCI_DAILY_LMT_E";
            this._txtCI_DAILY_LMT_E.Size = new System.Drawing.Size(100, 20);
            this._txtCI_DAILY_LMT_E.TabIndex = 20;
            this._txtCI_DAILY_LMT_E.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCI_DAILY_LMT_E.ValidationGroup = null;
            this._txtCI_DAILY_LMT_E.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_DAILY_LMT_E.WaterMarkText = "";
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.Controls.Add(this._txtCI_UNIT_LMT_S);
            this.flowLayoutPanel7.Controls.Add(this.label10);
            this.flowLayoutPanel7.Controls.Add(this._txtCI_UNIT_LMT_E);
            this.flowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel7.Location = new System.Drawing.Point(646, 1);
            this.flowLayoutPanel7.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Size = new System.Drawing.Size(240, 27);
            this.flowLayoutPanel7.TabIndex = 120;
            // 
            // _txtCI_UNIT_LMT_S
            // 
            this._txtCI_UNIT_LMT_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_UNIT_LMT_S.AutoTab = false;
            this._txtCI_UNIT_LMT_S.DelegateProperty = true;
            this._txtCI_UNIT_LMT_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_UNIT_LMT_S.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCI_UNIT_LMT_S.Location = new System.Drawing.Point(3, 3);
            this._txtCI_UNIT_LMT_S.Name = "_txtCI_UNIT_LMT_S";
            this._txtCI_UNIT_LMT_S.Size = new System.Drawing.Size(100, 20);
            this._txtCI_UNIT_LMT_S.TabIndex = 10;
            this._txtCI_UNIT_LMT_S.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCI_UNIT_LMT_S.ValidationGroup = null;
            this._txtCI_UNIT_LMT_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_UNIT_LMT_S.WaterMarkText = "";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(109, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 12);
            this.label10.TabIndex = 11;
            this.label10.Text = "~";
            // 
            // _txtCI_UNIT_LMT_E
            // 
            this._txtCI_UNIT_LMT_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtCI_UNIT_LMT_E.AutoTab = false;
            this._txtCI_UNIT_LMT_E.DelegateProperty = true;
            this._txtCI_UNIT_LMT_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtCI_UNIT_LMT_E.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtCI_UNIT_LMT_E.Location = new System.Drawing.Point(129, 3);
            this._txtCI_UNIT_LMT_E.Name = "_txtCI_UNIT_LMT_E";
            this._txtCI_UNIT_LMT_E.Size = new System.Drawing.Size(100, 20);
            this._txtCI_UNIT_LMT_E.TabIndex = 20;
            this._txtCI_UNIT_LMT_E.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtCI_UNIT_LMT_E.ValidationGroup = null;
            this._txtCI_UNIT_LMT_E.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtCI_UNIT_LMT_E.WaterMarkText = "";
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Controls.Add(this._dtpCI_WTHR_STRT_DT_S);
            this.flowLayoutPanel5.Controls.Add(this.label8);
            this.flowLayoutPanel5.Controls.Add(this._dtpCI_WTHR_STRT_DT_E);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(314, 57);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(240, 27);
            this.flowLayoutPanel5.TabIndex = 180;
            // 
            // _dtpCI_WTHR_STRT_DT_S
            // 
            this._dtpCI_WTHR_STRT_DT_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_WTHR_STRT_DT_S.Checked = false;
            this._dtpCI_WTHR_STRT_DT_S.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_WTHR_STRT_DT_S.DelegateProperty = true;
            this._dtpCI_WTHR_STRT_DT_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_WTHR_STRT_DT_S.Location = new System.Drawing.Point(3, 3);
            this._dtpCI_WTHR_STRT_DT_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpCI_WTHR_STRT_DT_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpCI_WTHR_STRT_DT_S.Name = "_dtpCI_WTHR_STRT_DT_S";
            this._dtpCI_WTHR_STRT_DT_S.ShowCheckBox = true;
            this._dtpCI_WTHR_STRT_DT_S.Size = new System.Drawing.Size(100, 21);
            this._dtpCI_WTHR_STRT_DT_S.TabIndex = 10;
            this._dtpCI_WTHR_STRT_DT_S.ValidationGroup = null;
            this._dtpCI_WTHR_STRT_DT_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(109, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 12);
            this.label8.TabIndex = 11;
            this.label8.Text = "~";
            // 
            // _dtpCI_WTHR_STRT_DT_E
            // 
            this._dtpCI_WTHR_STRT_DT_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_WTHR_STRT_DT_E.Checked = false;
            this._dtpCI_WTHR_STRT_DT_E.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_WTHR_STRT_DT_E.DelegateProperty = true;
            this._dtpCI_WTHR_STRT_DT_E.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_WTHR_STRT_DT_E.Location = new System.Drawing.Point(129, 3);
            this._dtpCI_WTHR_STRT_DT_E.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpCI_WTHR_STRT_DT_E.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpCI_WTHR_STRT_DT_E.Name = "_dtpCI_WTHR_STRT_DT_E";
            this._dtpCI_WTHR_STRT_DT_E.ShowCheckBox = true;
            this._dtpCI_WTHR_STRT_DT_E.Size = new System.Drawing.Size(100, 21);
            this._dtpCI_WTHR_STRT_DT_E.TabIndex = 20;
            this._dtpCI_WTHR_STRT_DT_E.ValidationGroup = null;
            this._dtpCI_WTHR_STRT_DT_E.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this._dtpCI_CNTR_END_DT_S);
            this.flowLayoutPanel4.Controls.Add(this.label7);
            this.flowLayoutPanel4.Controls.Add(this._dtpCI_CNTR_END_DT_E);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(314, 29);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(240, 27);
            this.flowLayoutPanel4.TabIndex = 150;
            // 
            // _dtpCI_CNTR_END_DT_S
            // 
            this._dtpCI_CNTR_END_DT_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_CNTR_END_DT_S.Checked = false;
            this._dtpCI_CNTR_END_DT_S.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_CNTR_END_DT_S.DelegateProperty = true;
            this._dtpCI_CNTR_END_DT_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_CNTR_END_DT_S.Location = new System.Drawing.Point(3, 3);
            this._dtpCI_CNTR_END_DT_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpCI_CNTR_END_DT_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_END_DT_S.Name = "_dtpCI_CNTR_END_DT_S";
            this._dtpCI_CNTR_END_DT_S.ShowCheckBox = true;
            this._dtpCI_CNTR_END_DT_S.Size = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_END_DT_S.TabIndex = 10;
            this._dtpCI_CNTR_END_DT_S.ValidationGroup = null;
            this._dtpCI_CNTR_END_DT_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(109, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 12);
            this.label7.TabIndex = 11;
            this.label7.Text = "~";
            // 
            // _dtpCI_CNTR_END_DT_E
            // 
            this._dtpCI_CNTR_END_DT_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_CNTR_END_DT_E.Checked = false;
            this._dtpCI_CNTR_END_DT_E.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_CNTR_END_DT_E.DelegateProperty = true;
            this._dtpCI_CNTR_END_DT_E.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_CNTR_END_DT_E.Location = new System.Drawing.Point(129, 3);
            this._dtpCI_CNTR_END_DT_E.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpCI_CNTR_END_DT_E.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_END_DT_E.Name = "_dtpCI_CNTR_END_DT_E";
            this._dtpCI_CNTR_END_DT_E.ShowCheckBox = true;
            this._dtpCI_CNTR_END_DT_E.Size = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_END_DT_E.TabIndex = 20;
            this._dtpCI_CNTR_END_DT_E.ValidationGroup = null;
            this._dtpCI_CNTR_END_DT_E.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(921, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 1118;
            this.label4.Text = "처리기간";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(577, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 1118;
            this.label3.Text = "총대출한도";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(257, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1118;
            this.label1.Text = "계약일자";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(933, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1121;
            this.label2.Text = "처리자";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this._btnSearch);
            this.flowLayoutPanel2.Controls.Add(this._btnExcel);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(1109, 1);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(243, 27);
            this.flowLayoutPanel2.TabIndex = 200;
            // 
            // _btnSearch
            // 
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(0, 2);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Size = new System.Drawing.Size(75, 23);
            this._btnSearch.TabIndex = 10;
            this._btnSearch.Text = "      검   색";
            this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            // 
            // _btnExcel
            // 
            this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnExcel.DelegateProperty = true;
            this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
            this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.Location = new System.Drawing.Point(75, 2);
            this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
            this._btnExcel.Name = "_btnExcel";
            this._btnExcel.Size = new System.Drawing.Size(75, 23);
            this._btnExcel.TabIndex = 20;
            this._btnExcel.Text = "      엑   셀";
            this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.UseVisualStyleBackColor = true;
            this._btnExcel.ValidationGroup = null;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this._dtpCI_CNTR_STRT_DT_S);
            this.flowLayoutPanel1.Controls.Add(this.label5);
            this.flowLayoutPanel1.Controls.Add(this._dtpCI_CNTR_STRT_DT_E);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(314, 1);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(240, 27);
            this.flowLayoutPanel1.TabIndex = 110;
            // 
            // _dtpCI_CNTR_STRT_DT_S
            // 
            this._dtpCI_CNTR_STRT_DT_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_CNTR_STRT_DT_S.Checked = false;
            this._dtpCI_CNTR_STRT_DT_S.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_CNTR_STRT_DT_S.DelegateProperty = true;
            this._dtpCI_CNTR_STRT_DT_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_CNTR_STRT_DT_S.Location = new System.Drawing.Point(3, 3);
            this._dtpCI_CNTR_STRT_DT_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpCI_CNTR_STRT_DT_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_STRT_DT_S.Name = "_dtpCI_CNTR_STRT_DT_S";
            this._dtpCI_CNTR_STRT_DT_S.ShowCheckBox = true;
            this._dtpCI_CNTR_STRT_DT_S.Size = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_STRT_DT_S.TabIndex = 10;
            this._dtpCI_CNTR_STRT_DT_S.ValidationGroup = null;
            this._dtpCI_CNTR_STRT_DT_S.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(109, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "~";
            // 
            // _dtpCI_CNTR_STRT_DT_E
            // 
            this._dtpCI_CNTR_STRT_DT_E.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpCI_CNTR_STRT_DT_E.Checked = false;
            this._dtpCI_CNTR_STRT_DT_E.CustomFormat = "yyyy-MM-dd";
            this._dtpCI_CNTR_STRT_DT_E.DelegateProperty = true;
            this._dtpCI_CNTR_STRT_DT_E.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpCI_CNTR_STRT_DT_E.Location = new System.Drawing.Point(129, 3);
            this._dtpCI_CNTR_STRT_DT_E.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpCI_CNTR_STRT_DT_E.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_STRT_DT_E.Name = "_dtpCI_CNTR_STRT_DT_E";
            this._dtpCI_CNTR_STRT_DT_E.ShowCheckBox = true;
            this._dtpCI_CNTR_STRT_DT_E.Size = new System.Drawing.Size(100, 21);
            this._dtpCI_CNTR_STRT_DT_E.TabIndex = 20;
            this._dtpCI_CNTR_STRT_DT_E.ValidationGroup = null;
            this._dtpCI_CNTR_STRT_DT_E.Value = new System.DateTime(2014, 7, 26, 14, 16, 17, 472);
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(571, 36);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(71, 12);
            this.label40.TabIndex = 1119;
            this.label40.Text = "1일대출한도";
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(35, 8);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 1114;
            this.label35.Text = "가맹점명";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(257, 36);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 12);
            this.label39.TabIndex = 1118;
            this.label39.Text = "해지일자";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(565, 8);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 12);
            this.label37.TabIndex = 1116;
            this.label37.Text = "건별대출한도";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(233, 64);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(77, 12);
            this.label38.TabIndex = 1117;
            this.label38.Text = "출금시작일자";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(23, 36);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(65, 12);
            this.label36.TabIndex = 1115;
            this.label36.Text = "가맹점코드";
            // 
            // BAS0823
            // 
            this.ClientSize = new System.Drawing.Size(1333, 733);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this._dtpSYSMODDATE_S_S);
            this.Controls.Add(this._dtpSYSMODDATE_E_S);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BAS0823";
            this.Text = "가맹점.보증보험이력조회:BAS0823";
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.flowLayoutPanel8.ResumeLayout(false);
            this.flowLayoutPanel8.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel6.PerformLayout();
            this.flowLayoutPanel7.ResumeLayout(false);
            this.flowLayoutPanel7.PerformLayout();
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private DemoClient.Controls.GridView gridView1;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BAND01;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
        private System.Windows.Forms.DataGridViewTextBoxColumn HST_TYPE;
        private System.Windows.Forms.DataGridViewTextBoxColumn GROUP_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_CNTR_STRT_DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_CNTR_END_DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_WTHR_STRT_DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_SVC_STAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_WTHR_STAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_USE_INSRNC;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_USE_BLNC;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_USE_SRT;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BAND02;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_BNK_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_ACCT_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_ACCT_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_RDM_BNK_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_RDM_ACCT_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_RDM_ACCT_NM;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BAND03;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_RATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_OVD;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_AGT_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_APP_DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LNR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LN_GUBUN;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BAND04;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_UNIT_LMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_DAILY_LMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_TOT_LMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn CI_LMT_APP_DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSMODNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSDELDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSDELNAME;
        private System.Windows.Forms.GroupBox groupBox1;
        private Controls.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private BANANA.Windows.Controls.Label label11;
        private BANANA.Windows.Controls.TextBox _txtSYSREGNAME_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private BANANA.Windows.Controls.TextBox _txtCI_TOT_LMT_S;
        private System.Windows.Forms.Label label6;
        private BANANA.Windows.Controls.TextBox _txtCI_TOT_LMT_E;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private BANANA.Windows.Controls.TextBox _txtCI_DAILY_LMT_S;
        private System.Windows.Forms.Label label9;
        private BANANA.Windows.Controls.TextBox _txtCI_DAILY_LMT_E;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private BANANA.Windows.Controls.TextBox _txtCI_UNIT_LMT_S;
        private System.Windows.Forms.Label label10;
        private BANANA.Windows.Controls.TextBox _txtCI_UNIT_LMT_E;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private BANANA.Windows.Controls.DateTimePicker _dtpCI_WTHR_STRT_DT_S;
        private System.Windows.Forms.Label label8;
        private BANANA.Windows.Controls.DateTimePicker _dtpCI_WTHR_STRT_DT_E;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_END_DT_S;
        private System.Windows.Forms.Label label7;
        private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_END_DT_E;
        private BANANA.Windows.Controls.Label label4;
        private BANANA.Windows.Controls.Label label3;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.Label label2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private DemoClient.Controls.BananaButton _btnSearch;
        private DemoClient.Controls.BananaButton _btnExcel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_STRT_DT_S;
        private System.Windows.Forms.Label label5;
        private BANANA.Windows.Controls.DateTimePicker _dtpCI_CNTR_STRT_DT_E;
        private BANANA.Windows.Controls.Label label40;
        private BANANA.Windows.Controls.Label label35;
        private BANANA.Windows.Controls.Label label39;
        private BANANA.Windows.Controls.Label label37;
        private BANANA.Windows.Controls.Label label38;
        private BANANA.Windows.Controls.Label label36;
        private BANANA.Windows.Controls.DateTimePicker _dtpSYSMODDATE_S_S;
        private BANANA.Windows.Controls.DateTimePicker _dtpSYSMODDATE_E_S;
	}
}
