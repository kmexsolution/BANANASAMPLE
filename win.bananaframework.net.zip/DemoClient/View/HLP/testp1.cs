﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DemoClient.Controllers;
namespace DemoClient.View.HLP
{
    public partial class testp1 : DemoClient.Controllers.BaseForm
    {
        public testp1()
        {
            InitializeComponent();
        }
    }
}
