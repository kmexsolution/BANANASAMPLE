﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient.View.ACC
{
    public partial class ACC0310 : DemoClient.Controllers.BaseForm
    {
        public ACC0310()
        {
            InitializeComponent();
        }
    }
}