﻿namespace DemoClient.View.ACC
{
	partial class ACC0200
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ACC0200));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpTRADEDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._dtpTRADEDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.Store_Info = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AGT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCT_INFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCTDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.REALDEPAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MANAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.WDR_INFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.EXPTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LOANAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.INTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.PYFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.WDR_INFO2 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.NONPYFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NONINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NONLOANAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNPYFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNLOANAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DDT_INFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.RTNDDTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIZ_INFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.BZDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZLOANAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BIZ_INFO2 = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.BZRTNDLYINST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZRTNINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZRTNLOANAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTNDPSTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRAMTDIFF = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.FINOVRFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.flowLayoutPanel4.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1303, 48);
			this.groupBox1.TabIndex = 21;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel6.ColumnCount = 7;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 360F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 6, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 1;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1297, 28);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(25, 8);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(53, 12);
			this.label35.TabIndex = 1115;
			this.label35.Text = "가맹점명";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(235, 8);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(65, 12);
			this.label36.TabIndex = 1116;
			this.label36.Text = "가맹점코드";
			// 
			// _txtSTR_CD_S
			// 
			this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD_S.AutoTab = false;
			this._txtSTR_CD_S.DelegateProperty = true;
			this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_CD_S.Location = new System.Drawing.Point(307, 4);
			this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
			this._txtSTR_CD_S.Size = new System.Drawing.Size(120, 20);
			this._txtSTR_CD_S.TabIndex = 110;
			this._txtSTR_CD_S.ValidationGroup = null;
			this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_CD_S.WaterMarkText = "";
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(85, 4);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(120, 20);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(469, 8);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(53, 12);
			this.label37.TabIndex = 1116;
			this.label37.Text = "정산일자";
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE_S_S);
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE_E_S);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(526, 1);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(360, 27);
			this.flowLayoutPanel1.TabIndex = 120;
			// 
			// _dtpTRADEDATE_S_S
			// 
			this._dtpTRADEDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_S_S.Checked = false;
			this._dtpTRADEDATE_S_S.CustomFormat = "yyyy-MM-dd";
			this._dtpTRADEDATE_S_S.DelegateProperty = true;
			this._dtpTRADEDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpTRADEDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_S_S.Name = "_dtpTRADEDATE_S_S";
			this._dtpTRADEDATE_S_S.Size = new System.Drawing.Size(150, 21);
			this._dtpTRADEDATE_S_S.TabIndex = 22;
			this._dtpTRADEDATE_S_S.ValidationGroup = null;
			this._dtpTRADEDATE_S_S.Value = new System.DateTime(2016, 9, 1, 0, 0, 0, 0);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(159, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(14, 12);
			this.label1.TabIndex = 1;
			this.label1.Text = "~";
			// 
			// _dtpTRADEDATE_E_S
			// 
			this._dtpTRADEDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_E_S.Checked = false;
			this._dtpTRADEDATE_E_S.CustomFormat = "yyyy-MM-dd";
			this._dtpTRADEDATE_E_S.DelegateProperty = true;
			this._dtpTRADEDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_E_S.Location = new System.Drawing.Point(179, 3);
			this._dtpTRADEDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_E_S.Name = "_dtpTRADEDATE_E_S";
			this._dtpTRADEDATE_E_S.Size = new System.Drawing.Size(150, 21);
			this._dtpTRADEDATE_E_S.TabIndex = 23;
			this._dtpTRADEDATE_E_S.ValidationGroup = null;
			this._dtpTRADEDATE_E_S.Value = new System.DateTime(2016, 9, 1, 0, 0, 0, 0);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.gridView1);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.Location = new System.Drawing.Point(0, 48);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1303, 532);
			this.groupBox2.TabIndex = 22;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Store_Info,
            this.STR_CD,
            this.STR_NM,
            this.AGT_NM,
            this.ACCT_INFO,
            this.IDX,
            this.ACCTDT,
            this.REALDEPAMT,
            this.MANAMT,
            this.WDR_INFO,
            this.EXPTAMT,
            this.LOANAMT,
            this.INTST,
            this.PYFEE,
            this.WDR_INFO2,
            this.NONPYFEE,
            this.NONINTST,
            this.NONLOANAMT,
            this.RTNPYFEE,
            this.RTNINTST,
            this.RTNLOANAMT,
            this.DDT_INFO,
            this.RTNDDTAMT,
            this.BIZ_INFO,
            this.BZDLYINTST,
            this.BZINTST,
            this.BZLOANAMT,
            this.BIZ_INFO2,
            this.BZRTNDLYINST,
            this.BZRTNINTST,
            this.BZRTNLOANAMT,
            this.RTNDPSTAMT,
            this.TRAMTDIFF,
            this.FINOVRFEE,
            this.SYSREGDATE,
            this.SYSREGNAME});
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 17);
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(1297, 512);
			this.gridView1.TabIndex = 1;
			this.gridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView1_DataBindingComplete);
			// 
			// Store_Info
			// 
			this.Store_Info.Frozen = true;
			this.Store_Info.HeaderText = "가맹점정보";
			this.Store_Info.Name = "Store_Info";
			this.Store_Info.ReadOnly = true;
			this.Store_Info.TargetColumnss.Add("STR_CD");
			this.Store_Info.TargetColumnss.Add("STR_NM");
			this.Store_Info.TargetColumnss.Add("AGT_NM");
			this.Store_Info.Width = 68;
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.Frozen = true;
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 87;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 76;
			// 
			// AGT_NM
			// 
			this.AGT_NM.DataPropertyName = "AGT_NM";
			this.AGT_NM.Frozen = true;
			this.AGT_NM.HeaderText = "대리점명";
			this.AGT_NM.Name = "AGT_NM";
			this.AGT_NM.ReadOnly = true;
			this.AGT_NM.Width = 76;
			// 
			// ACCT_INFO
			// 
			this.ACCT_INFO.Frozen = true;
			this.ACCT_INFO.HeaderText = "정산정보";
			this.ACCT_INFO.Name = "ACCT_INFO";
			this.ACCT_INFO.ReadOnly = true;
			this.ACCT_INFO.TargetColumnss.Add("IDX");
			this.ACCT_INFO.TargetColumnss.Add("ACCTDT");
			this.ACCT_INFO.TargetColumnss.Add("REALDEPAMT");
			this.ACCT_INFO.Width = 57;
			// 
			// IDX
			// 
			this.IDX.DataPropertyName = "IDX";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.Format = "N0";
			dataGridViewCellStyle2.NullValue = "0";
			this.IDX.DefaultCellStyle = dataGridViewCellStyle2;
			this.IDX.Frozen = true;
			this.IDX.HeaderText = "일련번호";
			this.IDX.Name = "IDX";
			this.IDX.ReadOnly = true;
			this.IDX.Width = 76;
			// 
			// ACCTDT
			// 
			this.ACCTDT.DataPropertyName = "ACCTDT";
			this.ACCTDT.HeaderText = "정산일자";
			this.ACCTDT.Name = "ACCTDT";
			this.ACCTDT.ReadOnly = true;
			this.ACCTDT.Width = 76;
			// 
			// REALDEPAMT
			// 
			this.REALDEPAMT.DataPropertyName = "REALDEPAMT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			dataGridViewCellStyle3.NullValue = "0";
			this.REALDEPAMT.DefaultCellStyle = dataGridViewCellStyle3;
			this.REALDEPAMT.HeaderText = "실입금액";
			this.REALDEPAMT.Name = "REALDEPAMT";
			this.REALDEPAMT.ReadOnly = true;
			this.REALDEPAMT.Width = 76;
			// 
			// MANAMT
			// 
			this.MANAMT.DataPropertyName = "MANAMT";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = "0";
			this.MANAMT.DefaultCellStyle = dataGridViewCellStyle4;
			this.MANAMT.HeaderText = "강제출금";
			this.MANAMT.Name = "MANAMT";
			this.MANAMT.ReadOnly = true;
			this.MANAMT.Width = 76;
			// 
			// WDR_INFO
			// 
			this.WDR_INFO.HeaderText = "입금예정정보(정산전)";
			this.WDR_INFO.Name = "WDR_INFO";
			this.WDR_INFO.ReadOnly = true;
			this.WDR_INFO.TargetColumnss.Add("EXPTAMT");
			this.WDR_INFO.TargetColumnss.Add("LOANAMT");
			this.WDR_INFO.TargetColumnss.Add("INTST");
			this.WDR_INFO.TargetColumnss.Add("PYFEE");
			this.WDR_INFO.Width = 120;
			// 
			// EXPTAMT
			// 
			this.EXPTAMT.DataPropertyName = "EXPTAMT";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			dataGridViewCellStyle5.NullValue = "0";
			this.EXPTAMT.DefaultCellStyle = dataGridViewCellStyle5;
			this.EXPTAMT.HeaderText = "입금예정금액";
			this.EXPTAMT.Name = "EXPTAMT";
			this.EXPTAMT.ReadOnly = true;
			this.EXPTAMT.Width = 98;
			// 
			// LOANAMT
			// 
			this.LOANAMT.DataPropertyName = "LOANAMT";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			dataGridViewCellStyle6.NullValue = "0";
			this.LOANAMT.DefaultCellStyle = dataGridViewCellStyle6;
			this.LOANAMT.HeaderText = "대출원금";
			this.LOANAMT.Name = "LOANAMT";
			this.LOANAMT.ReadOnly = true;
			this.LOANAMT.Width = 76;
			// 
			// INTST
			// 
			this.INTST.DataPropertyName = "INTST";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			dataGridViewCellStyle7.NullValue = "0";
			this.INTST.DefaultCellStyle = dataGridViewCellStyle7;
			this.INTST.HeaderText = "대출이자";
			this.INTST.Name = "INTST";
			this.INTST.ReadOnly = true;
			this.INTST.Width = 76;
			// 
			// PYFEE
			// 
			this.PYFEE.DataPropertyName = "PYFEE";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			dataGridViewCellStyle8.NullValue = "0";
			this.PYFEE.DefaultCellStyle = dataGridViewCellStyle8;
			this.PYFEE.HeaderText = "정산수수료";
			this.PYFEE.Name = "PYFEE";
			this.PYFEE.ReadOnly = true;
			this.PYFEE.Width = 87;
			// 
			// WDR_INFO2
			// 
			this.WDR_INFO2.HeaderText = "입금예정정보(정산후)";
			this.WDR_INFO2.Name = "WDR_INFO2";
			this.WDR_INFO2.ReadOnly = true;
			this.WDR_INFO2.TargetColumnss.Add("NONPYFEE");
			this.WDR_INFO2.TargetColumnss.Add("NONINTST");
			this.WDR_INFO2.TargetColumnss.Add("NONLOANAMT");
			this.WDR_INFO2.TargetColumnss.Add("RTNPYFEE");
			this.WDR_INFO2.TargetColumnss.Add("RTNINTST");
			this.WDR_INFO2.TargetColumnss.Add("RTNLOANAMT");
			this.WDR_INFO2.Width = 120;
			// 
			// NONPYFEE
			// 
			this.NONPYFEE.DataPropertyName = "NONPYFEE";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N0";
			dataGridViewCellStyle9.NullValue = "0";
			this.NONPYFEE.DefaultCellStyle = dataGridViewCellStyle9;
			this.NONPYFEE.HeaderText = "정산수수료미정산액";
			this.NONPYFEE.Name = "NONPYFEE";
			this.NONPYFEE.ReadOnly = true;
			this.NONPYFEE.Width = 131;
			// 
			// NONINTST
			// 
			this.NONINTST.DataPropertyName = "NONINTST";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N0";
			dataGridViewCellStyle10.NullValue = "0";
			this.NONINTST.DefaultCellStyle = dataGridViewCellStyle10;
			this.NONINTST.HeaderText = "대출이자미정산금액";
			this.NONINTST.Name = "NONINTST";
			this.NONINTST.ReadOnly = true;
			this.NONINTST.Width = 131;
			// 
			// NONLOANAMT
			// 
			this.NONLOANAMT.DataPropertyName = "NONLOANAMT";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle11.Format = "N0";
			dataGridViewCellStyle11.NullValue = "0";
			this.NONLOANAMT.DefaultCellStyle = dataGridViewCellStyle11;
			this.NONLOANAMT.HeaderText = "대출원금미정산금액";
			this.NONLOANAMT.Name = "NONLOANAMT";
			this.NONLOANAMT.ReadOnly = true;
			this.NONLOANAMT.Width = 131;
			// 
			// RTNPYFEE
			// 
			this.RTNPYFEE.DataPropertyName = "RTNPYFEE";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle12.Format = "N0";
			dataGridViewCellStyle12.NullValue = "0";
			this.RTNPYFEE.DefaultCellStyle = dataGridViewCellStyle12;
			this.RTNPYFEE.HeaderText = "정산수수료정산금액";
			this.RTNPYFEE.Name = "RTNPYFEE";
			this.RTNPYFEE.ReadOnly = true;
			this.RTNPYFEE.Width = 131;
			// 
			// RTNINTST
			// 
			this.RTNINTST.DataPropertyName = "RTNINTST";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle13.Format = "N0";
			dataGridViewCellStyle13.NullValue = "0";
			this.RTNINTST.DefaultCellStyle = dataGridViewCellStyle13;
			this.RTNINTST.HeaderText = "대출이자정산금액";
			this.RTNINTST.Name = "RTNINTST";
			this.RTNINTST.ReadOnly = true;
			this.RTNINTST.Width = 120;
			// 
			// RTNLOANAMT
			// 
			this.RTNLOANAMT.DataPropertyName = "RTNLOANAMT";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle14.Format = "N0";
			dataGridViewCellStyle14.NullValue = "0";
			this.RTNLOANAMT.DefaultCellStyle = dataGridViewCellStyle14;
			this.RTNLOANAMT.HeaderText = "대출원금정산금액";
			this.RTNLOANAMT.Name = "RTNLOANAMT";
			this.RTNLOANAMT.ReadOnly = true;
			this.RTNLOANAMT.Width = 120;
			// 
			// DDT_INFO
			// 
			this.DDT_INFO.HeaderText = "차감정보";
			this.DDT_INFO.Name = "DDT_INFO";
			this.DDT_INFO.ReadOnly = true;
			this.DDT_INFO.TargetColumnss.Add("RTNDDTAMT");
			this.DDT_INFO.Width = 57;
			// 
			// RTNDDTAMT
			// 
			this.RTNDDTAMT.DataPropertyName = "RTNDDTAMT";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle15.Format = "N0";
			dataGridViewCellStyle15.NullValue = "0";
			this.RTNDDTAMT.DefaultCellStyle = dataGridViewCellStyle15;
			this.RTNDDTAMT.HeaderText = "차감상환금액";
			this.RTNDDTAMT.Name = "RTNDDTAMT";
			this.RTNDDTAMT.ReadOnly = true;
			this.RTNDDTAMT.Width = 98;
			// 
			// BIZ_INFO
			// 
			this.BIZ_INFO.HeaderText = "비즈론정보(정산전)";
			this.BIZ_INFO.Name = "BIZ_INFO";
			this.BIZ_INFO.ReadOnly = true;
			this.BIZ_INFO.TargetColumnss.Add("BZDLYINTST");
			this.BIZ_INFO.TargetColumnss.Add("BZINTST");
			this.BIZ_INFO.TargetColumnss.Add("BZLOANAMT");
			this.BIZ_INFO.Width = 109;
			// 
			// BZDLYINTST
			// 
			this.BZDLYINTST.DataPropertyName = "BZDLYINTST";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle16.Format = "N0";
			dataGridViewCellStyle16.NullValue = "0";
			this.BZDLYINTST.DefaultCellStyle = dataGridViewCellStyle16;
			this.BZDLYINTST.HeaderText = "정산전비즈론연체이자합계";
			this.BZDLYINTST.Name = "BZDLYINTST";
			this.BZDLYINTST.ReadOnly = true;
			this.BZDLYINTST.Width = 164;
			// 
			// BZINTST
			// 
			this.BZINTST.DataPropertyName = "BZINTST";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle17.Format = "N0";
			dataGridViewCellStyle17.NullValue = "0";
			this.BZINTST.DefaultCellStyle = dataGridViewCellStyle17;
			this.BZINTST.HeaderText = "정산전비즈론상환이자합계";
			this.BZINTST.Name = "BZINTST";
			this.BZINTST.ReadOnly = true;
			this.BZINTST.Width = 164;
			// 
			// BZLOANAMT
			// 
			this.BZLOANAMT.DataPropertyName = "BZLOANAMT";
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle18.Format = "N0";
			dataGridViewCellStyle18.NullValue = "0";
			this.BZLOANAMT.DefaultCellStyle = dataGridViewCellStyle18;
			this.BZLOANAMT.HeaderText = "정산전비즈론대출원금합계";
			this.BZLOANAMT.Name = "BZLOANAMT";
			this.BZLOANAMT.ReadOnly = true;
			this.BZLOANAMT.Width = 164;
			// 
			// BIZ_INFO2
			// 
			this.BIZ_INFO2.HeaderText = "비즈론정보(정산후)";
			this.BIZ_INFO2.Name = "BIZ_INFO2";
			this.BIZ_INFO2.ReadOnly = true;
			this.BIZ_INFO2.TargetColumnss.Add("BZRTNDLYINST");
			this.BIZ_INFO2.TargetColumnss.Add("BZRTNINTST");
			this.BIZ_INFO2.TargetColumnss.Add("BZRTNLOANAMT");
			this.BIZ_INFO2.Width = 109;
			// 
			// BZRTNDLYINST
			// 
			this.BZRTNDLYINST.DataPropertyName = "BZRTNDLYINST";
			dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle19.Format = "N0";
			dataGridViewCellStyle19.NullValue = "0";
			this.BZRTNDLYINST.DefaultCellStyle = dataGridViewCellStyle19;
			this.BZRTNDLYINST.HeaderText = "비즈론연체이자정산금액";
			this.BZRTNDLYINST.Name = "BZRTNDLYINST";
			this.BZRTNDLYINST.ReadOnly = true;
			this.BZRTNDLYINST.Width = 153;
			// 
			// BZRTNINTST
			// 
			this.BZRTNINTST.DataPropertyName = "BZRTNINTST";
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle20.Format = "N0";
			dataGridViewCellStyle20.NullValue = "0";
			this.BZRTNINTST.DefaultCellStyle = dataGridViewCellStyle20;
			this.BZRTNINTST.HeaderText = "비즈론상환이자정산금액";
			this.BZRTNINTST.Name = "BZRTNINTST";
			this.BZRTNINTST.ReadOnly = true;
			this.BZRTNINTST.Width = 153;
			// 
			// BZRTNLOANAMT
			// 
			this.BZRTNLOANAMT.DataPropertyName = "BZRTNLOANAMT";
			dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle21.Format = "N0";
			dataGridViewCellStyle21.NullValue = "0";
			this.BZRTNLOANAMT.DefaultCellStyle = dataGridViewCellStyle21;
			this.BZRTNLOANAMT.HeaderText = "비즈론대출원금정산액";
			this.BZRTNLOANAMT.Name = "BZRTNLOANAMT";
			this.BZRTNLOANAMT.ReadOnly = true;
			this.BZRTNLOANAMT.Width = 142;
			// 
			// RTNDPSTAMT
			// 
			this.RTNDPSTAMT.DataPropertyName = "RTNDPSTAMT";
			dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle22.Format = "N0";
			dataGridViewCellStyle22.NullValue = "0";
			this.RTNDPSTAMT.DefaultCellStyle = dataGridViewCellStyle22;
			this.RTNDPSTAMT.HeaderText = "보증금상환금액";
			this.RTNDPSTAMT.Name = "RTNDPSTAMT";
			this.RTNDPSTAMT.ReadOnly = true;
			this.RTNDPSTAMT.Width = 109;
			// 
			// TRAMTDIFF
			// 
			this.TRAMTDIFF.DataPropertyName = "TRAMTDIFF";
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle23.Format = "N0";
			dataGridViewCellStyle23.NullValue = "0";
			this.TRAMTDIFF.DefaultCellStyle = dataGridViewCellStyle23;
			this.TRAMTDIFF.HeaderText = "차이금액(입금금액-입금예정금액)";
			this.TRAMTDIFF.Name = "TRAMTDIFF";
			this.TRAMTDIFF.ReadOnly = true;
			this.TRAMTDIFF.Width = 199;
			// 
			// FINOVRFEE
			// 
			this.FINOVRFEE.DataPropertyName = "FINOVRFEE";
			dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle24.Format = "N0";
			dataGridViewCellStyle24.NullValue = "0";
			this.FINOVRFEE.DefaultCellStyle = dataGridViewCellStyle24;
			this.FINOVRFEE.HeaderText = "출금예정금액";
			this.FINOVRFEE.Name = "FINOVRFEE";
			this.FINOVRFEE.ReadOnly = true;
			this.FINOVRFEE.Width = 98;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "시스템등록일";
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			this.SYSREGDATE.Width = 98;
			// 
			// SYSREGNAME
			// 
			this.SYSREGNAME.DataPropertyName = "SYSREGNAME";
			this.SYSREGNAME.HeaderText = "시스템등록자";
			this.SYSREGNAME.Name = "SYSREGNAME";
			this.SYSREGNAME.ReadOnly = true;
			this.SYSREGNAME.Width = 98;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.DataPropertyName = "SYSREGDATE";
			this.dataGridViewTextBoxColumn1.HeaderText = "시스템등록일";
			this.dataGridViewTextBoxColumn1.MinimumWidth = 140;
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			this.dataGridViewTextBoxColumn1.ReadOnly = true;
			this.dataGridViewTextBoxColumn1.Width = 140;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.DataPropertyName = "SYSREGNAME";
			this.dataGridViewTextBoxColumn2.HeaderText = "시스템등록자";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			this.dataGridViewTextBoxColumn2.ReadOnly = true;
			this.dataGridViewTextBoxColumn2.Width = 98;
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.DataPropertyName = "SYSMODDATE";
			this.dataGridViewTextBoxColumn3.HeaderText = "시스템수정일";
			this.dataGridViewTextBoxColumn3.MinimumWidth = 140;
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			this.dataGridViewTextBoxColumn3.ReadOnly = true;
			this.dataGridViewTextBoxColumn3.Width = 140;
			// 
			// dataGridViewTextBoxColumn4
			// 
			this.dataGridViewTextBoxColumn4.DataPropertyName = "SYSMODNAME";
			this.dataGridViewTextBoxColumn4.HeaderText = "시스템수정자";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			this.dataGridViewTextBoxColumn4.ReadOnly = true;
			this.dataGridViewTextBoxColumn4.Width = 98;
			// 
			// dataGridViewTextBoxColumn5
			// 
			this.dataGridViewTextBoxColumn5.DataPropertyName = "SYSDELDATE";
			this.dataGridViewTextBoxColumn5.HeaderText = "시스템삭제일";
			this.dataGridViewTextBoxColumn5.MinimumWidth = 140;
			this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			this.dataGridViewTextBoxColumn5.ReadOnly = true;
			this.dataGridViewTextBoxColumn5.Width = 140;
			// 
			// dataGridViewTextBoxColumn6
			// 
			this.dataGridViewTextBoxColumn6.DataPropertyName = "SYSDELNAME";
			this.dataGridViewTextBoxColumn6.HeaderText = "시스템삭제자";
			this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			this.dataGridViewTextBoxColumn6.ReadOnly = true;
			this.dataGridViewTextBoxColumn6.Width = 98;
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(75, 0);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 27);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 0);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 27);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._btnSearch);
			this.flowLayoutPanel4.Controls.Add(this._btnExcel);
			this.flowLayoutPanel4.Location = new System.Drawing.Point(887, 1);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(185, 27);
			this.flowLayoutPanel4.TabIndex = 160;
			// 
			// ACC0200
			// 
			this.ClientSize = new System.Drawing.Size(1303, 580);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ACC0200";
			this.Text = "정산내역조회:ACC0200";
			this.Load += new System.EventHandler(this.ACC0100_Load);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private BANANA.Windows.Controls.Label label37;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_S_S;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_E_S;
        private BANANA.Windows.Controls.Label label36;
        private BANANA.Windows.Controls.Label label35;
        private System.Windows.Forms.GroupBox groupBox2;
        private DemoClient.Controls.GridView gridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn Store_Info;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn AGT_NM;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn ACCT_INFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCTDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn REALDEPAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MANAMT;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn WDR_INFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn EXPTAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn LOANAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn INTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn PYFEE;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn WDR_INFO2;
        private System.Windows.Forms.DataGridViewTextBoxColumn NONPYFEE;
        private System.Windows.Forms.DataGridViewTextBoxColumn NONINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn NONLOANAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNPYFEE;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNLOANAMT;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn DDT_INFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNDDTAMT;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BIZ_INFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn BZDLYINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn BZINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn BZLOANAMT;
        private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BIZ_INFO2;
        private System.Windows.Forms.DataGridViewTextBoxColumn BZRTNDLYINST;
        private System.Windows.Forms.DataGridViewTextBoxColumn BZRTNINTST;
        private System.Windows.Forms.DataGridViewTextBoxColumn BZRTNLOANAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn RTNDPSTAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRAMTDIFF;
        private System.Windows.Forms.DataGridViewTextBoxColumn FINOVRFEE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGNAME;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private DemoClient.Controls.BananaButton _btnSearch;
		private DemoClient.Controls.BananaButton _btnExcel;
    }
}
