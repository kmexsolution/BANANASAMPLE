﻿namespace DemoClient.View.ACC
{
    partial class ACC0100
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ACC0100));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this._txtSTR_CD_S = new BANANA.Windows.Controls.TextBox();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.label36 = new BANANA.Windows.Controls.Label();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpTRADEDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._dtpTRADEDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this.groupBox2 = new BANANA.Windows.Controls.GroupBox();
			this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnCheckAll = new DemoClient.Controls.BananaButton();
			this._btnUnCheckAll = new DemoClient.Controls.BananaButton();
			this.label6 = new BANANA.Windows.Controls.Label();
			this._txtAPPRAMT = new BANANA.Windows.Controls.TextBox();
			this.label7 = new BANANA.Windows.Controls.Label();
			this.label8 = new BANANA.Windows.Controls.Label();
			this._txtCNCLAMT = new BANANA.Windows.Controls.TextBox();
			this.label11 = new BANANA.Windows.Controls.Label();
			this.label12 = new BANANA.Windows.Controls.Label();
			this._txtBUYING_FEE = new BANANA.Windows.Controls.TextBox();
			this.label9 = new BANANA.Windows.Controls.Label();
			this.label10 = new BANANA.Windows.Controls.Label();
			this._txtSUB_TOTAL = new BANANA.Windows.Controls.TextBox();
			this._btnCalMagam = new DemoClient.Controls.BananaButton();
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.CHK = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.STRINFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM_INDEX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AGT_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AGT_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RDMINFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.DUEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MAGAM_YN = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.lmt = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.CI_DAILY_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CI_TOT_LMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LIVEWDRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.APPR = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.APPRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CNCLAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BUYING_FEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LNINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCOUNT_FEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SUB_TOTAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRAMTDIFF = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.MNS_AMT_01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_AMT_02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_AMT_03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_AMT_04 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_AMT_99 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_ACTN_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZLOAN = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.BZPRINCIPAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZDLYINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BZTOTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.DPST_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DPST_ACTN_AMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MNS_AMT_00 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.WDRINFO = new BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn();
			this.TAPPRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TCNCLAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TBUYING_FEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TLNAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TLNINTST = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TACCOUNT_FEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TPAYAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.flowLayoutPanel3.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1340, 50);
			this.groupBox1.TabIndex = 6;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.ColumnCount = 7;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 340F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 6, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_CD_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label36, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 5, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 1;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1334, 30);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._btnSearch);
			this.flowLayoutPanel4.Controls.Add(this._btnExcel);
			this.flowLayoutPanel4.Location = new System.Drawing.Point(870, 0);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(250, 27);
			this.flowLayoutPanel4.TabIndex = 160;
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 0);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 27);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(75, 0);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 27);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// _txtSTR_CD_S
			// 
			this._txtSTR_CD_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_CD_S.AutoTab = false;
			this._txtSTR_CD_S.DelegateProperty = true;
			this._txtSTR_CD_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_CD_S.Location = new System.Drawing.Point(313, 5);
			this._txtSTR_CD_S.Name = "_txtSTR_CD_S";
			this._txtSTR_CD_S.Size = new System.Drawing.Size(120, 20);
			this._txtSTR_CD_S.TabIndex = 110;
			this._txtSTR_CD_S.ValidationGroup = null;
			this._txtSTR_CD_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_CD_S.WaterMarkText = "";
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(93, 5);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(120, 20);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(34, 9);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(53, 12);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// label36
			// 
			this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(242, 9);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(65, 12);
			this.label36.TabIndex = 1115;
			this.label36.Text = "가맹점코드";
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(450, 9);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(77, 12);
			this.label37.TabIndex = 1116;
			this.label37.Text = "입금예정일자";
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE_S_S);
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE_E_S);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(530, 0);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(340, 30);
			this.flowLayoutPanel1.TabIndex = 120;
			// 
			// _dtpTRADEDATE_S_S
			// 
			this._dtpTRADEDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_S_S.Checked = false;
			this._dtpTRADEDATE_S_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpTRADEDATE_S_S.DelegateProperty = true;
			this._dtpTRADEDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpTRADEDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_S_S.Name = "_dtpTRADEDATE_S_S";
			this._dtpTRADEDATE_S_S.Size = new System.Drawing.Size(150, 21);
			this._dtpTRADEDATE_S_S.TabIndex = 10;
			this._dtpTRADEDATE_S_S.ValidationGroup = null;
			this._dtpTRADEDATE_S_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(159, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(14, 12);
			this.label1.TabIndex = 1;
			this.label1.Text = "~";
			// 
			// _dtpTRADEDATE_E_S
			// 
			this._dtpTRADEDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_E_S.Checked = false;
			this._dtpTRADEDATE_E_S.CustomFormat = "yyyy-MM-dd HH:mm:ss";
			this._dtpTRADEDATE_E_S.DelegateProperty = true;
			this._dtpTRADEDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_E_S.Location = new System.Drawing.Point(179, 3);
			this._dtpTRADEDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_E_S.Name = "_dtpTRADEDATE_E_S";
			this._dtpTRADEDATE_E_S.Size = new System.Drawing.Size(150, 21);
			this._dtpTRADEDATE_E_S.TabIndex = 20;
			this._dtpTRADEDATE_E_S.ValidationGroup = null;
			this._dtpTRADEDATE_E_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.flowLayoutPanel3);
			this.groupBox2.Controls.Add(this._btnCalMagam);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox2.Location = new System.Drawing.Point(0, 541);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1340, 50);
			this.groupBox2.TabIndex = 7;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "명령 처리";
			// 
			// flowLayoutPanel3
			// 
			this.flowLayoutPanel3.Controls.Add(this._btnCheckAll);
			this.flowLayoutPanel3.Controls.Add(this._btnUnCheckAll);
			this.flowLayoutPanel3.Controls.Add(this.label6);
			this.flowLayoutPanel3.Controls.Add(this._txtAPPRAMT);
			this.flowLayoutPanel3.Controls.Add(this.label7);
			this.flowLayoutPanel3.Controls.Add(this.label8);
			this.flowLayoutPanel3.Controls.Add(this._txtCNCLAMT);
			this.flowLayoutPanel3.Controls.Add(this.label11);
			this.flowLayoutPanel3.Controls.Add(this.label12);
			this.flowLayoutPanel3.Controls.Add(this._txtBUYING_FEE);
			this.flowLayoutPanel3.Controls.Add(this.label9);
			this.flowLayoutPanel3.Controls.Add(this.label10);
			this.flowLayoutPanel3.Controls.Add(this._txtSUB_TOTAL);
			this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Left;
			this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 17);
			this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel3.Name = "flowLayoutPanel3";
			this.flowLayoutPanel3.Size = new System.Drawing.Size(870, 30);
			this.flowLayoutPanel3.TabIndex = 165;
			// 
			// _btnCheckAll
			// 
			this._btnCheckAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnCheckAll.DelegateProperty = true;
			this._btnCheckAll.Image = global::DemoClient.Properties.Resources._1377801059_62678;
			this._btnCheckAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnCheckAll.Location = new System.Drawing.Point(3, 3);
			this._btnCheckAll.Name = "_btnCheckAll";
			this._btnCheckAll.Reserved = "      전체체크";
			this._btnCheckAll.Size = new System.Drawing.Size(91, 27);
			this._btnCheckAll.TabIndex = 162;
			this._btnCheckAll.Text = "      전체체크";
			this._btnCheckAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnCheckAll.UseVisualStyleBackColor = true;
			this._btnCheckAll.ValidationGroup = null;
			this._btnCheckAll.Click += new System.EventHandler(this._btnCheckAll_Click);
			// 
			// _btnUnCheckAll
			// 
			this._btnUnCheckAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnUnCheckAll.DelegateProperty = true;
			this._btnUnCheckAll.Image = global::DemoClient.Properties.Resources._1377801059_62678;
			this._btnUnCheckAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnUnCheckAll.Location = new System.Drawing.Point(100, 3);
			this._btnUnCheckAll.Name = "_btnUnCheckAll";
			this._btnUnCheckAll.Reserved = "      전체해제";
			this._btnUnCheckAll.Size = new System.Drawing.Size(91, 27);
			this._btnUnCheckAll.TabIndex = 163;
			this._btnUnCheckAll.Text = "      전체해제";
			this._btnUnCheckAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnUnCheckAll.UseVisualStyleBackColor = true;
			this._btnUnCheckAll.ValidationGroup = null;
			this._btnUnCheckAll.Click += new System.EventHandler(this._btnUnCheckAll_Click);
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(197, 10);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(29, 12);
			this.label6.TabIndex = 165;
			this.label6.Text = "승인";
			// 
			// _txtAPPRAMT
			// 
			this._txtAPPRAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtAPPRAMT.DelegateProperty = true;
			this._txtAPPRAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtAPPRAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtAPPRAMT.Location = new System.Drawing.Point(232, 6);
			this._txtAPPRAMT.Name = "_txtAPPRAMT";
			this._txtAPPRAMT.ReadOnly = true;
			this._txtAPPRAMT.Size = new System.Drawing.Size(100, 20);
			this._txtAPPRAMT.TabIndex = 166;
			this._txtAPPRAMT.TabStop = false;
			this._txtAPPRAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtAPPRAMT.ValidationGroup = null;
			this._txtAPPRAMT.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtAPPRAMT.WaterMarkText = "";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(338, 10);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(11, 12);
			this.label7.TabIndex = 168;
			this.label7.Text = "-";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(355, 10);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(29, 12);
			this.label8.TabIndex = 169;
			this.label8.Text = "취소";
			// 
			// _txtCNCLAMT
			// 
			this._txtCNCLAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtCNCLAMT.DelegateProperty = true;
			this._txtCNCLAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtCNCLAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtCNCLAMT.Location = new System.Drawing.Point(390, 6);
			this._txtCNCLAMT.Name = "_txtCNCLAMT";
			this._txtCNCLAMT.ReadOnly = true;
			this._txtCNCLAMT.Size = new System.Drawing.Size(100, 20);
			this._txtCNCLAMT.TabIndex = 170;
			this._txtCNCLAMT.TabStop = false;
			this._txtCNCLAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtCNCLAMT.ValidationGroup = null;
			this._txtCNCLAMT.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtCNCLAMT.WaterMarkText = "";
			// 
			// label11
			// 
			this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(496, 10);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(11, 12);
			this.label11.TabIndex = 171;
			this.label11.Text = "-";
			// 
			// label12
			// 
			this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(513, 10);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(89, 12);
			this.label12.TabIndex = 172;
			this.label12.Text = "매입카드수수료";
			// 
			// _txtBUYING_FEE
			// 
			this._txtBUYING_FEE.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtBUYING_FEE.DelegateProperty = true;
			this._txtBUYING_FEE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtBUYING_FEE.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtBUYING_FEE.Location = new System.Drawing.Point(608, 6);
			this._txtBUYING_FEE.Name = "_txtBUYING_FEE";
			this._txtBUYING_FEE.ReadOnly = true;
			this._txtBUYING_FEE.Size = new System.Drawing.Size(100, 20);
			this._txtBUYING_FEE.TabIndex = 173;
			this._txtBUYING_FEE.TabStop = false;
			this._txtBUYING_FEE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtBUYING_FEE.ValidationGroup = null;
			this._txtBUYING_FEE.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtBUYING_FEE.WaterMarkText = "";
			// 
			// label9
			// 
			this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(714, 10);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(11, 12);
			this.label9.TabIndex = 172;
			this.label9.Text = "=";
			// 
			// label10
			// 
			this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(731, 10);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(29, 12);
			this.label10.TabIndex = 173;
			this.label10.Text = "합계";
			// 
			// _txtSUB_TOTAL
			// 
			this._txtSUB_TOTAL.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSUB_TOTAL.DelegateProperty = true;
			this._txtSUB_TOTAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSUB_TOTAL.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
			this._txtSUB_TOTAL.Location = new System.Drawing.Point(766, 6);
			this._txtSUB_TOTAL.Name = "_txtSUB_TOTAL";
			this._txtSUB_TOTAL.ReadOnly = true;
			this._txtSUB_TOTAL.Size = new System.Drawing.Size(100, 20);
			this._txtSUB_TOTAL.TabIndex = 174;
			this._txtSUB_TOTAL.TabStop = false;
			this._txtSUB_TOTAL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this._txtSUB_TOTAL.ValidationGroup = null;
			this._txtSUB_TOTAL.WaterMarkColor = System.Drawing.Color.Empty;
			this._txtSUB_TOTAL.WaterMarkText = "";
			// 
			// _btnCalMagam
			// 
			this._btnCalMagam.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this._btnCalMagam.ButtonConfirm = true;
			this._btnCalMagam.DelegateProperty = true;
			this._btnCalMagam.Image = global::DemoClient.Properties.Resources._1377801059_62678;
			this._btnCalMagam.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnCalMagam.Location = new System.Drawing.Point(1223, 17);
			this._btnCalMagam.Name = "_btnCalMagam";
			this._btnCalMagam.Reserved = "      정산마감처리";
			this._btnCalMagam.Size = new System.Drawing.Size(111, 27);
			this._btnCalMagam.TabIndex = 161;
			this._btnCalMagam.Text = "      정산마감처리";
			this._btnCalMagam.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnCalMagam.UseVisualStyleBackColor = true;
			this._btnCalMagam.ValidationGroup = null;
			this._btnCalMagam.Click += new System.EventHandler(this._btnCalMagam_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(0, 50);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(1340, 491);
			this.groupBox3.TabIndex = 8;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			this.gridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CHK,
            this.STRINFO,
            this.STR_NM,
            this.STR_CD,
            this.STR_NM_INDEX,
            this.AGT_CD,
            this.AGT_NM,
            this.RDMINFO,
            this.DUEDATE,
            this.TRAMT,
            this.MAGAM_YN,
            this.lmt,
            this.CI_DAILY_LMT,
            this.CI_TOT_LMT,
            this.LIVEWDRAMT,
            this.APPR,
            this.APPRAMT,
            this.CNCLAMT,
            this.BUYING_FEE,
            this.LNAMT,
            this.LNINTST,
            this.ACCOUNT_FEE,
            this.SUB_TOTAL,
            this.TRAMTDIFF,
            this.MNS,
            this.MNS_AMT_01,
            this.MNS_AMT_02,
            this.MNS_AMT_03,
            this.MNS_AMT_04,
            this.MNS_AMT_99,
            this.MNS_ACTN_AMT,
            this.BZLOAN,
            this.BZPRINCIPAL,
            this.BZINTST,
            this.BZDLYINTST,
            this.BZTOTAMT,
            this.DPST,
            this.DPST_AMT,
            this.DPST_ACTN_AMT,
            this.MNS_AMT_00,
            this.WDRINFO,
            this.TAPPRAMT,
            this.TCNCLAMT,
            this.TBUYING_FEE,
            this.TLNAMT,
            this.TLNINTST,
            this.TACCOUNT_FEE,
            this.TPAYAMT});
			dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle34.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.DefaultCellStyle = dataGridViewCellStyle34;
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 17);
			this.gridView1.MultiSelect = false;
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.RowTemplate.Height = 23;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(1334, 471);
			this.gridView1.TabIndex = 0;
			this.gridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView1_DataBindingComplete);
			// 
			// CHK
			// 
			this.CHK.DataPropertyName = "CHK";
			this.CHK.FalseValue = "N";
			this.CHK.Frozen = true;
			this.CHK.HeaderText = "";
			this.CHK.IndeterminateValue = "";
			this.CHK.MinimumWidth = 20;
			this.CHK.Name = "CHK";
			this.CHK.ReadOnly = true;
			this.CHK.TrueValue = "Y";
			this.CHK.Width = 20;
			// 
			// STRINFO
			// 
			this.STRINFO.Frozen = true;
			this.STRINFO.HeaderText = "가맹점정보";
			this.STRINFO.Name = "STRINFO";
			this.STRINFO.ReadOnly = true;
			this.STRINFO.TargetColumnss.Add("STR_NM");
			this.STRINFO.TargetColumnss.Add("STR_CD");
			this.STRINFO.TargetColumnss.Add("STR_NM_INDEX");
			this.STRINFO.TargetColumnss.Add("AGT_CD");
			this.STRINFO.TargetColumnss.Add("AGT_NM");
			this.STRINFO.Width = 68;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 76;
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.Frozen = true;
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 87;
			// 
			// STR_NM_INDEX
			// 
			this.STR_NM_INDEX.DataPropertyName = "STR_NM_INDEX";
			this.STR_NM_INDEX.Frozen = true;
			this.STR_NM_INDEX.HeaderText = "인덱스용 가맹점명";
			this.STR_NM_INDEX.Name = "STR_NM_INDEX";
			this.STR_NM_INDEX.ReadOnly = true;
			this.STR_NM_INDEX.Visible = false;
			this.STR_NM_INDEX.Width = 124;
			// 
			// AGT_CD
			// 
			this.AGT_CD.DataPropertyName = "AGT_CD";
			this.AGT_CD.Frozen = true;
			this.AGT_CD.HeaderText = "대리점코드";
			this.AGT_CD.Name = "AGT_CD";
			this.AGT_CD.ReadOnly = true;
			this.AGT_CD.Visible = false;
			this.AGT_CD.Width = 87;
			// 
			// AGT_NM
			// 
			this.AGT_NM.DataPropertyName = "AGT_NM";
			this.AGT_NM.Frozen = true;
			this.AGT_NM.HeaderText = "대리점명";
			this.AGT_NM.Name = "AGT_NM";
			this.AGT_NM.ReadOnly = true;
			this.AGT_NM.Width = 76;
			// 
			// RDMINFO
			// 
			this.RDMINFO.HeaderText = "입금정보";
			this.RDMINFO.Name = "RDMINFO";
			this.RDMINFO.ReadOnly = true;
			this.RDMINFO.TargetColumnss.Add("DUEDATE");
			this.RDMINFO.TargetColumnss.Add("TRAMT");
			this.RDMINFO.TargetColumnss.Add("MAGAM_YN");
			this.RDMINFO.Width = 57;
			// 
			// DUEDATE
			// 
			this.DUEDATE.DataPropertyName = "DUEDATE";
			this.DUEDATE.HeaderText = "입금예정일자";
			this.DUEDATE.Name = "DUEDATE";
			this.DUEDATE.ReadOnly = true;
			this.DUEDATE.Width = 98;
			// 
			// TRAMT
			// 
			this.TRAMT.DataPropertyName = "TRAMT";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.Format = "N0";
			dataGridViewCellStyle2.NullValue = "0";
			this.TRAMT.DefaultCellStyle = dataGridViewCellStyle2;
			this.TRAMT.HeaderText = "입금금액";
			this.TRAMT.Name = "TRAMT";
			this.TRAMT.ReadOnly = true;
			this.TRAMT.Width = 76;
			// 
			// MAGAM_YN
			// 
			this.MAGAM_YN.DataPropertyName = "MAGAM_YN";
			this.MAGAM_YN.HeaderText = "정산마감여부";
			this.MAGAM_YN.Name = "MAGAM_YN";
			this.MAGAM_YN.ReadOnly = true;
			this.MAGAM_YN.Width = 98;
			// 
			// lmt
			// 
			this.lmt.HeaderText = "한도";
			this.lmt.Name = "lmt";
			this.lmt.ReadOnly = true;
			this.lmt.TargetColumnss.Add("CI_DAILY_LMT");
			this.lmt.TargetColumnss.Add("CI_TOT_LMT");
			this.lmt.TargetColumnss.Add("LIVEWDRAMT");
			this.lmt.Width = 35;
			// 
			// CI_DAILY_LMT
			// 
			this.CI_DAILY_LMT.DataPropertyName = "CI_DAILY_LMT";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			dataGridViewCellStyle3.NullValue = "0";
			this.CI_DAILY_LMT.DefaultCellStyle = dataGridViewCellStyle3;
			this.CI_DAILY_LMT.HeaderText = "1일한도";
			this.CI_DAILY_LMT.Name = "CI_DAILY_LMT";
			this.CI_DAILY_LMT.ReadOnly = true;
			this.CI_DAILY_LMT.Width = 71;
			// 
			// CI_TOT_LMT
			// 
			this.CI_TOT_LMT.DataPropertyName = "CI_TOT_LMT";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = "0";
			this.CI_TOT_LMT.DefaultCellStyle = dataGridViewCellStyle4;
			this.CI_TOT_LMT.HeaderText = "총한도";
			this.CI_TOT_LMT.Name = "CI_TOT_LMT";
			this.CI_TOT_LMT.ReadOnly = true;
			this.CI_TOT_LMT.Width = 65;
			// 
			// LIVEWDRAMT
			// 
			this.LIVEWDRAMT.DataPropertyName = "LIVEWDRAMT";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			dataGridViewCellStyle5.NullValue = "0";
			this.LIVEWDRAMT.DefaultCellStyle = dataGridViewCellStyle5;
			this.LIVEWDRAMT.HeaderText = "잔여한도";
			this.LIVEWDRAMT.Name = "LIVEWDRAMT";
			this.LIVEWDRAMT.ReadOnly = true;
			this.LIVEWDRAMT.Width = 76;
			// 
			// APPR
			// 
			this.APPR.HeaderText = "입금예정정보(정산대상)";
			this.APPR.Name = "APPR";
			this.APPR.ReadOnly = true;
			this.APPR.TargetColumnss.Add("APPRAMT");
			this.APPR.TargetColumnss.Add("CNCLAMT");
			this.APPR.TargetColumnss.Add("BUYING_FEE");
			this.APPR.TargetColumnss.Add("LNAMT");
			this.APPR.TargetColumnss.Add("LNINTST");
			this.APPR.TargetColumnss.Add("ACCOUNT_FEE");
			this.APPR.TargetColumnss.Add("SUB_TOTAL");
			this.APPR.TargetColumnss.Add("TRAMTDIFF");
			this.APPR.Width = 131;
			// 
			// APPRAMT
			// 
			this.APPRAMT.DataPropertyName = "APPRAMT";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			dataGridViewCellStyle6.NullValue = "0";
			this.APPRAMT.DefaultCellStyle = dataGridViewCellStyle6;
			this.APPRAMT.HeaderText = "승인금액";
			this.APPRAMT.Name = "APPRAMT";
			this.APPRAMT.ReadOnly = true;
			this.APPRAMT.Width = 76;
			// 
			// CNCLAMT
			// 
			this.CNCLAMT.DataPropertyName = "CNCLAMT";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			dataGridViewCellStyle7.NullValue = "0";
			this.CNCLAMT.DefaultCellStyle = dataGridViewCellStyle7;
			this.CNCLAMT.HeaderText = "취소금액";
			this.CNCLAMT.Name = "CNCLAMT";
			this.CNCLAMT.ReadOnly = true;
			this.CNCLAMT.Width = 76;
			// 
			// BUYING_FEE
			// 
			this.BUYING_FEE.DataPropertyName = "BUYING_FEE";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			dataGridViewCellStyle8.NullValue = "0";
			this.BUYING_FEE.DefaultCellStyle = dataGridViewCellStyle8;
			this.BUYING_FEE.HeaderText = "매입카드수수료";
			this.BUYING_FEE.Name = "BUYING_FEE";
			this.BUYING_FEE.ReadOnly = true;
			this.BUYING_FEE.Width = 109;
			// 
			// LNAMT
			// 
			this.LNAMT.DataPropertyName = "LNAMT";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N0";
			dataGridViewCellStyle9.NullValue = "0";
			this.LNAMT.DefaultCellStyle = dataGridViewCellStyle9;
			this.LNAMT.HeaderText = "대출원금";
			this.LNAMT.Name = "LNAMT";
			this.LNAMT.ReadOnly = true;
			this.LNAMT.Width = 76;
			// 
			// LNINTST
			// 
			this.LNINTST.DataPropertyName = "LNINTST";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N0";
			dataGridViewCellStyle10.NullValue = "0";
			this.LNINTST.DefaultCellStyle = dataGridViewCellStyle10;
			this.LNINTST.HeaderText = "대출이자";
			this.LNINTST.Name = "LNINTST";
			this.LNINTST.ReadOnly = true;
			this.LNINTST.Width = 76;
			// 
			// ACCOUNT_FEE
			// 
			this.ACCOUNT_FEE.DataPropertyName = "ACCOUNT_FEE";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle11.Format = "N0";
			dataGridViewCellStyle11.NullValue = "0";
			this.ACCOUNT_FEE.DefaultCellStyle = dataGridViewCellStyle11;
			this.ACCOUNT_FEE.HeaderText = "정산수수료";
			this.ACCOUNT_FEE.Name = "ACCOUNT_FEE";
			this.ACCOUNT_FEE.ReadOnly = true;
			this.ACCOUNT_FEE.Width = 87;
			// 
			// SUB_TOTAL
			// 
			this.SUB_TOTAL.DataPropertyName = "SUB_TOTAL";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle12.Format = "N0";
			dataGridViewCellStyle12.NullValue = "0";
			this.SUB_TOTAL.DefaultCellStyle = dataGridViewCellStyle12;
			this.SUB_TOTAL.HeaderText = "입금예정금액";
			this.SUB_TOTAL.Name = "SUB_TOTAL";
			this.SUB_TOTAL.ReadOnly = true;
			this.SUB_TOTAL.Width = 98;
			// 
			// TRAMTDIFF
			// 
			this.TRAMTDIFF.DataPropertyName = "TRAMTDIFF";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle13.Format = "N0";
			dataGridViewCellStyle13.NullValue = "0";
			this.TRAMTDIFF.DefaultCellStyle = dataGridViewCellStyle13;
			this.TRAMTDIFF.HeaderText = "차이금액(입금금액-입금예정금액)";
			this.TRAMTDIFF.Name = "TRAMTDIFF";
			this.TRAMTDIFF.ReadOnly = true;
			this.TRAMTDIFF.Width = 199;
			// 
			// MNS
			// 
			this.MNS.HeaderText = "차감정보";
			this.MNS.Name = "MNS";
			this.MNS.ReadOnly = true;
			this.MNS.TargetColumnss.Add("MNS_AMT_01");
			this.MNS.TargetColumnss.Add("MNS_AMT_02");
			this.MNS.TargetColumnss.Add("MNS_AMT_03");
			this.MNS.TargetColumnss.Add("MNS_AMT_04");
			this.MNS.TargetColumnss.Add("MNS_AMT_99");
			this.MNS.TargetColumnss.Add("MNS_ACTN_AMT");
			this.MNS.Width = 57;
			// 
			// MNS_AMT_01
			// 
			this.MNS_AMT_01.DataPropertyName = "MNS_AMT_01";
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle14.Format = "N0";
			dataGridViewCellStyle14.NullValue = "0";
			this.MNS_AMT_01.DefaultCellStyle = dataGridViewCellStyle14;
			this.MNS_AMT_01.HeaderText = "차감대상금액(원금)";
			this.MNS_AMT_01.Name = "MNS_AMT_01";
			this.MNS_AMT_01.ReadOnly = true;
			this.MNS_AMT_01.Width = 128;
			// 
			// MNS_AMT_02
			// 
			this.MNS_AMT_02.DataPropertyName = "MNS_AMT_02";
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle15.Format = "N0";
			dataGridViewCellStyle15.NullValue = "0";
			this.MNS_AMT_02.DefaultCellStyle = dataGridViewCellStyle15;
			this.MNS_AMT_02.HeaderText = "차감대상금액(이자)";
			this.MNS_AMT_02.Name = "MNS_AMT_02";
			this.MNS_AMT_02.ReadOnly = true;
			this.MNS_AMT_02.Width = 128;
			// 
			// MNS_AMT_03
			// 
			this.MNS_AMT_03.DataPropertyName = "MNS_AMT_03";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle16.Format = "N0";
			dataGridViewCellStyle16.NullValue = "0";
			this.MNS_AMT_03.DefaultCellStyle = dataGridViewCellStyle16;
			this.MNS_AMT_03.HeaderText = "차감대상금액(연체이자)";
			this.MNS_AMT_03.Name = "MNS_AMT_03";
			this.MNS_AMT_03.ReadOnly = true;
			this.MNS_AMT_03.Width = 150;
			// 
			// MNS_AMT_04
			// 
			this.MNS_AMT_04.DataPropertyName = "MNS_AMT_04";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle17.Format = "N0";
			dataGridViewCellStyle17.NullValue = "0";
			this.MNS_AMT_04.DefaultCellStyle = dataGridViewCellStyle17;
			this.MNS_AMT_04.HeaderText = "차감대상금액(수수료)";
			this.MNS_AMT_04.Name = "MNS_AMT_04";
			this.MNS_AMT_04.ReadOnly = true;
			this.MNS_AMT_04.Width = 139;
			// 
			// MNS_AMT_99
			// 
			this.MNS_AMT_99.DataPropertyName = "MNS_AMT_99";
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle18.Format = "N0";
			dataGridViewCellStyle18.NullValue = "0";
			this.MNS_AMT_99.DefaultCellStyle = dataGridViewCellStyle18;
			this.MNS_AMT_99.HeaderText = "차감대상금액(기타)";
			this.MNS_AMT_99.Name = "MNS_AMT_99";
			this.MNS_AMT_99.ReadOnly = true;
			this.MNS_AMT_99.Width = 128;
			// 
			// MNS_ACTN_AMT
			// 
			this.MNS_ACTN_AMT.DataPropertyName = "MNS_ACTN_AMT";
			dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle19.Format = "N0";
			dataGridViewCellStyle19.NullValue = "0";
			this.MNS_ACTN_AMT.DefaultCellStyle = dataGridViewCellStyle19;
			this.MNS_ACTN_AMT.HeaderText = "차감처리금액";
			this.MNS_ACTN_AMT.Name = "MNS_ACTN_AMT";
			this.MNS_ACTN_AMT.ReadOnly = true;
			this.MNS_ACTN_AMT.Width = 98;
			// 
			// BZLOAN
			// 
			this.BZLOAN.HeaderText = "비즈론";
			this.BZLOAN.Name = "BZLOAN";
			this.BZLOAN.ReadOnly = true;
			this.BZLOAN.TargetColumnss.Add("BZPRINCIPAL");
			this.BZLOAN.TargetColumnss.Add("BZINTST");
			this.BZLOAN.TargetColumnss.Add("BZDLYINTST");
			this.BZLOAN.TargetColumnss.Add("BZTOTAMT");
			this.BZLOAN.TargetColumnss.Add("BZPRINCIPAL");
			this.BZLOAN.TargetColumnss.Add("BZINTST");
			this.BZLOAN.TargetColumnss.Add("BZDLYINTST");
			this.BZLOAN.TargetColumnss.Add("BZTOTAMT");
			this.BZLOAN.Width = 46;
			// 
			// BZPRINCIPAL
			// 
			this.BZPRINCIPAL.DataPropertyName = "BZPRCP";
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle20.Format = "N0";
			dataGridViewCellStyle20.NullValue = "0";
			this.BZPRINCIPAL.DefaultCellStyle = dataGridViewCellStyle20;
			this.BZPRINCIPAL.HeaderText = "대상원금";
			this.BZPRINCIPAL.Name = "BZPRINCIPAL";
			this.BZPRINCIPAL.ReadOnly = true;
			this.BZPRINCIPAL.Width = 76;
			// 
			// BZINTST
			// 
			this.BZINTST.DataPropertyName = "BZINTST";
			dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle21.Format = "N0";
			dataGridViewCellStyle21.NullValue = "0";
			this.BZINTST.DefaultCellStyle = dataGridViewCellStyle21;
			this.BZINTST.HeaderText = "대상이자";
			this.BZINTST.Name = "BZINTST";
			this.BZINTST.ReadOnly = true;
			this.BZINTST.Width = 76;
			// 
			// BZDLYINTST
			// 
			this.BZDLYINTST.DataPropertyName = "BZDLYINTST";
			dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle22.Format = "N0";
			dataGridViewCellStyle22.NullValue = "0";
			this.BZDLYINTST.DefaultCellStyle = dataGridViewCellStyle22;
			this.BZDLYINTST.HeaderText = "대상연체이자";
			this.BZDLYINTST.Name = "BZDLYINTST";
			this.BZDLYINTST.ReadOnly = true;
			this.BZDLYINTST.Width = 98;
			// 
			// BZTOTAMT
			// 
			this.BZTOTAMT.DataPropertyName = "BZTOTAMT";
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle23.Format = "N0";
			dataGridViewCellStyle23.NullValue = "0";
			this.BZTOTAMT.DefaultCellStyle = dataGridViewCellStyle23;
			this.BZTOTAMT.HeaderText = "합계";
			this.BZTOTAMT.Name = "BZTOTAMT";
			this.BZTOTAMT.ReadOnly = true;
			this.BZTOTAMT.Width = 54;
			// 
			// DPST
			// 
			this.DPST.HeaderText = "보증예치금 정보";
			this.DPST.Name = "DPST";
			this.DPST.ReadOnly = true;
			this.DPST.TargetColumnss.Add("DPST_AMT");
			this.DPST.TargetColumnss.Add("DPST_ACTN_AMT");
			this.DPST.Width = 94;
			// 
			// DPST_AMT
			// 
			this.DPST_AMT.DataPropertyName = "DPST_AMT";
			dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle24.Format = "N0";
			dataGridViewCellStyle24.NullValue = "0";
			this.DPST_AMT.DefaultCellStyle = dataGridViewCellStyle24;
			this.DPST_AMT.HeaderText = "설정금액";
			this.DPST_AMT.Name = "DPST_AMT";
			this.DPST_AMT.ReadOnly = true;
			this.DPST_AMT.Width = 76;
			// 
			// DPST_ACTN_AMT
			// 
			this.DPST_ACTN_AMT.DataPropertyName = "DPST_ACTN_AMT";
			dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle25.Format = "N0";
			dataGridViewCellStyle25.NullValue = "0";
			this.DPST_ACTN_AMT.DefaultCellStyle = dataGridViewCellStyle25;
			this.DPST_ACTN_AMT.HeaderText = "보증예치금";
			this.DPST_ACTN_AMT.Name = "DPST_ACTN_AMT";
			this.DPST_ACTN_AMT.ReadOnly = true;
			this.DPST_ACTN_AMT.Width = 87;
			// 
			// MNS_AMT_00
			// 
			this.MNS_AMT_00.DataPropertyName = "MNS_AMT_00";
			dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle26.Format = "N0";
			dataGridViewCellStyle26.NullValue = "0";
			this.MNS_AMT_00.DefaultCellStyle = dataGridViewCellStyle26;
			this.MNS_AMT_00.HeaderText = "강제출금";
			this.MNS_AMT_00.Name = "MNS_AMT_00";
			this.MNS_AMT_00.ReadOnly = true;
			this.MNS_AMT_00.Width = 76;
			// 
			// WDRINFO
			// 
			this.WDRINFO.HeaderText = "출금정보(실출금액)";
			this.WDRINFO.Name = "WDRINFO";
			this.WDRINFO.ReadOnly = true;
			this.WDRINFO.TargetColumnss.Add("TAPPRAMT");
			this.WDRINFO.TargetColumnss.Add("TCNCLAMT");
			this.WDRINFO.TargetColumnss.Add("TBUYING_FEE");
			this.WDRINFO.TargetColumnss.Add("TLNAMT");
			this.WDRINFO.TargetColumnss.Add("TACCOUNT_FEE");
			this.WDRINFO.TargetColumnss.Add("TLNINTST");
			this.WDRINFO.TargetColumnss.Add("TPAYAMT");
			this.WDRINFO.Width = 109;
			// 
			// TAPPRAMT
			// 
			this.TAPPRAMT.DataPropertyName = "TAPPRAMT";
			dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle27.Format = "N0";
			dataGridViewCellStyle27.NullValue = "0";
			this.TAPPRAMT.DefaultCellStyle = dataGridViewCellStyle27;
			this.TAPPRAMT.HeaderText = "승인금액";
			this.TAPPRAMT.Name = "TAPPRAMT";
			this.TAPPRAMT.ReadOnly = true;
			this.TAPPRAMT.Width = 76;
			// 
			// TCNCLAMT
			// 
			this.TCNCLAMT.DataPropertyName = "TCNCLAMT";
			dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle28.Format = "N0";
			dataGridViewCellStyle28.NullValue = "0";
			this.TCNCLAMT.DefaultCellStyle = dataGridViewCellStyle28;
			this.TCNCLAMT.HeaderText = "취소금액";
			this.TCNCLAMT.Name = "TCNCLAMT";
			this.TCNCLAMT.ReadOnly = true;
			this.TCNCLAMT.Width = 76;
			// 
			// TBUYING_FEE
			// 
			this.TBUYING_FEE.DataPropertyName = "TBUYING_FEE";
			dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle29.Format = "N0";
			dataGridViewCellStyle29.NullValue = "0";
			this.TBUYING_FEE.DefaultCellStyle = dataGridViewCellStyle29;
			this.TBUYING_FEE.HeaderText = "카드사수수료";
			this.TBUYING_FEE.Name = "TBUYING_FEE";
			this.TBUYING_FEE.ReadOnly = true;
			this.TBUYING_FEE.Width = 98;
			// 
			// TLNAMT
			// 
			this.TLNAMT.DataPropertyName = "TLNAMT";
			dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle30.Format = "N0";
			dataGridViewCellStyle30.NullValue = "0";
			this.TLNAMT.DefaultCellStyle = dataGridViewCellStyle30;
			this.TLNAMT.HeaderText = "대출원금";
			this.TLNAMT.Name = "TLNAMT";
			this.TLNAMT.ReadOnly = true;
			this.TLNAMT.Width = 76;
			// 
			// TLNINTST
			// 
			this.TLNINTST.DataPropertyName = "TLNINTST";
			dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle31.Format = "N0";
			dataGridViewCellStyle31.NullValue = "0";
			this.TLNINTST.DefaultCellStyle = dataGridViewCellStyle31;
			this.TLNINTST.HeaderText = "대출이자";
			this.TLNINTST.Name = "TLNINTST";
			this.TLNINTST.ReadOnly = true;
			this.TLNINTST.Width = 76;
			// 
			// TACCOUNT_FEE
			// 
			this.TACCOUNT_FEE.DataPropertyName = "TACCOUNT_FEE";
			dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle32.Format = "N0";
			dataGridViewCellStyle32.NullValue = "0";
			this.TACCOUNT_FEE.DefaultCellStyle = dataGridViewCellStyle32;
			this.TACCOUNT_FEE.HeaderText = "정산수수료";
			this.TACCOUNT_FEE.Name = "TACCOUNT_FEE";
			this.TACCOUNT_FEE.ReadOnly = true;
			this.TACCOUNT_FEE.Width = 87;
			// 
			// TPAYAMT
			// 
			this.TPAYAMT.DataPropertyName = "TPAYAMT";
			dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle33.Format = "N0";
			dataGridViewCellStyle33.NullValue = "0";
			this.TPAYAMT.DefaultCellStyle = dataGridViewCellStyle33;
			this.TPAYAMT.HeaderText = "출금예정금액";
			this.TPAYAMT.Name = "TPAYAMT";
			this.TPAYAMT.ReadOnly = true;
			this.TPAYAMT.Width = 98;
			// 
			// ACC0100
			// 
			this.ClientSize = new System.Drawing.Size(1340, 591);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ACC0100";
			this.Text = "정산마감처리:ACC0100";
			this.Load += new System.EventHandler(this.ACC0100_Load);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.flowLayoutPanel3.ResumeLayout(false);
			this.flowLayoutPanel3.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private DemoClient.Controls.BananaButton _btnSearch;
        private DemoClient.Controls.BananaButton _btnExcel;
        private BANANA.Windows.Controls.TextBox _txtSTR_CD_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private BANANA.Windows.Controls.Label label35;
        private BANANA.Windows.Controls.Label label36;
        private BANANA.Windows.Controls.Label label37;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_S_S;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_E_S;
        private BANANA.Windows.Controls.GroupBox groupBox2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private DemoClient.Controls.BananaButton _btnCheckAll;
        private DemoClient.Controls.BananaButton _btnUnCheckAll;
        private BANANA.Windows.Controls.Label label6;
        private BANANA.Windows.Controls.TextBox _txtAPPRAMT;
        private BANANA.Windows.Controls.Label label7;
        private BANANA.Windows.Controls.Label label8;
        private BANANA.Windows.Controls.TextBox _txtCNCLAMT;
        private BANANA.Windows.Controls.Label label11;
        private BANANA.Windows.Controls.Label label12;
        private BANANA.Windows.Controls.TextBox _txtBUYING_FEE;
        private BANANA.Windows.Controls.Label label9;
        private BANANA.Windows.Controls.Label label10;
        private BANANA.Windows.Controls.TextBox _txtSUB_TOTAL;
        private DemoClient.Controls.BananaButton _btnCalMagam;
        private BANANA.Windows.Controls.GroupBox groupBox3;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewCheckBoxColumn CHK;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn STRINFO;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM_INDEX;
		private System.Windows.Forms.DataGridViewTextBoxColumn AGT_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn AGT_NM;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn RDMINFO;
		private System.Windows.Forms.DataGridViewTextBoxColumn DUEDATE;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MAGAM_YN;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn lmt;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_DAILY_LMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CI_TOT_LMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn LIVEWDRAMT;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn APPR;
		private System.Windows.Forms.DataGridViewTextBoxColumn APPRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn CNCLAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn BUYING_FEE;
		private System.Windows.Forms.DataGridViewTextBoxColumn LNAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn LNINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn ACCOUNT_FEE;
		private System.Windows.Forms.DataGridViewTextBoxColumn SUB_TOTAL;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRAMTDIFF;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn MNS;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_01;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_02;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_03;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_04;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_99;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_ACTN_AMT;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn BZLOAN;
		private System.Windows.Forms.DataGridViewTextBoxColumn BZPRINCIPAL;
		private System.Windows.Forms.DataGridViewTextBoxColumn BZINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn BZDLYINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn BZTOTAMT;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn DPST;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_AMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DPST_ACTN_AMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn MNS_AMT_00;
		private BANANA.Windows.Controls.DataGridView.DataGridViewBandColumn WDRINFO;
		private System.Windows.Forms.DataGridViewTextBoxColumn TAPPRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn TCNCLAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn TBUYING_FEE;
		private System.Windows.Forms.DataGridViewTextBoxColumn TLNAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn TLNINTST;
		private System.Windows.Forms.DataGridViewTextBoxColumn TACCOUNT_FEE;
		private System.Windows.Forms.DataGridViewTextBoxColumn TPAYAMT;
    }
}
