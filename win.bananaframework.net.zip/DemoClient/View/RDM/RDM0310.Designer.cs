﻿namespace DemoClient.View.RDM
{
    partial class RDM0310
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RDM0310));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this._btnExcel = new DemoClient.Controls.BananaButton();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this._dtpTRADEDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._dtpTRADEDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.label2 = new BANANA.Windows.Controls.Label();
			this._cmbBUYING_CD_S = new BANANA.Windows.Controls.ComboBox();
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_CD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.예정일자 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.BCCRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.KBCRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SAMSUNGCRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SHINHANCRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HYUNDAICRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LOTTECRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.HANACRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.YEHWANCRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.NHCRD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ETCCRDTOT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TOTAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.flowLayoutPanel4.SuspendLayout();
			this.flowLayoutPanel1.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1145, 57);
			this.groupBox1.TabIndex = 27;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.ColumnCount = 10;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 142F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 385F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 9, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 8, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 7, 0);
			this.tableLayoutPanel6.Controls.Add(this.label2, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this._cmbBUYING_CD_S, 3, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 1;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 37);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(93, 8);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(120, 20);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(34, 12);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(53, 12);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Controls.Add(this._btnSearch);
			this.flowLayoutPanel4.Controls.Add(this._btnExcel);
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(1153, 0);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(55, 37);
			this.flowLayoutPanel4.TabIndex = 160;
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(0, 0);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 27);
			this._btnSearch.TabIndex = 10;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// _btnExcel
			// 
			this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnExcel.DelegateProperty = true;
			this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
			this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.Location = new System.Drawing.Point(0, 27);
			this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
			this._btnExcel.Name = "_btnExcel";
			this._btnExcel.Reserved = "      엑   셀";
			this._btnExcel.Size = new System.Drawing.Size(75, 27);
			this._btnExcel.TabIndex = 20;
			this._btnExcel.Text = "      엑   셀";
			this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnExcel.UseVisualStyleBackColor = true;
			this._btnExcel.ValidationGroup = null;
			this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE_S_S);
			this.flowLayoutPanel1.Controls.Add(this.label1);
			this.flowLayoutPanel1.Controls.Add(this._dtpTRADEDATE_E_S);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(768, 0);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(385, 37);
			this.flowLayoutPanel1.TabIndex = 120;
			// 
			// _dtpTRADEDATE_S_S
			// 
			this._dtpTRADEDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_S_S.Checked = false;
			this._dtpTRADEDATE_S_S.CustomFormat = "yyyy-MM-dd";
			this._dtpTRADEDATE_S_S.DelegateProperty = true;
			this._dtpTRADEDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_S_S.Location = new System.Drawing.Point(3, 3);
			this._dtpTRADEDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_S_S.Name = "_dtpTRADEDATE_S_S";
			this._dtpTRADEDATE_S_S.Size = new System.Drawing.Size(150, 21);
			this._dtpTRADEDATE_S_S.TabIndex = 28;
			this._dtpTRADEDATE_S_S.ValidationGroup = null;
			this._dtpTRADEDATE_S_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(159, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(14, 12);
			this.label1.TabIndex = 1;
			this.label1.Text = "~";
			// 
			// _dtpTRADEDATE_E_S
			// 
			this._dtpTRADEDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_E_S.Checked = false;
			this._dtpTRADEDATE_E_S.CustomFormat = "yyyy-MM-dd";
			this._dtpTRADEDATE_E_S.DelegateProperty = true;
			this._dtpTRADEDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_E_S.Location = new System.Drawing.Point(179, 3);
			this._dtpTRADEDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_E_S.Name = "_dtpTRADEDATE_E_S";
			this._dtpTRADEDATE_E_S.Size = new System.Drawing.Size(150, 21);
			this._dtpTRADEDATE_E_S.TabIndex = 29;
			this._dtpTRADEDATE_E_S.ValidationGroup = null;
			this._dtpTRADEDATE_E_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(712, 12);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(53, 12);
			this.label37.TabIndex = 1116;
			this.label37.Text = "예정일자";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(284, 12);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(41, 12);
			this.label2.TabIndex = 1117;
			this.label2.Text = "카드사";
			// 
			// _cmbBUYING_CD_S
			// 
			this._cmbBUYING_CD_S.DataSource = null;
			this._cmbBUYING_CD_S.DelegateProperty = true;
			this._cmbBUYING_CD_S.DroppedDown = false;
			this._cmbBUYING_CD_S.Location = new System.Drawing.Point(331, 3);
			this._cmbBUYING_CD_S.MaximumSize = new System.Drawing.Size(500, 60);
			this._cmbBUYING_CD_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._cmbBUYING_CD_S.Name = "_cmbBUYING_CD_S";
			this._cmbBUYING_CD_S.SelectedIndex = -1;
			this._cmbBUYING_CD_S.SelectedItem = null;
			this._cmbBUYING_CD_S.SelectedValue = null;
			this._cmbBUYING_CD_S.Size = new System.Drawing.Size(103, 21);
			this._cmbBUYING_CD_S.TabIndex = 1118;
			this._cmbBUYING_CD_S.ValidationGroup = null;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.gridView1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(0, 57);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(1145, 613);
			this.groupBox3.TabIndex = 28;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "검색 결과";
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STR_NM,
            this.STR_CD,
            this.예정일자,
            this.BCCRD,
            this.KBCRD,
            this.SAMSUNGCRD,
            this.SHINHANCRD,
            this.HYUNDAICRD,
            this.LOTTECRD,
            this.HANACRD,
            this.YEHWANCRD,
            this.NHCRD,
            this.ETCCRDTOT,
            this.TOTAMT});
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle14.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.DefaultCellStyle = dataGridViewCellStyle14;
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 17);
			this.gridView1.MultiSelect = false;
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.RowTemplate.Height = 23;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(1139, 593);
			this.gridView1.TabIndex = 0;
			this.gridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView1_DataBindingComplete);
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 76;
			// 
			// STR_CD
			// 
			this.STR_CD.DataPropertyName = "STR_CD";
			this.STR_CD.Frozen = true;
			this.STR_CD.HeaderText = "가맹점코드";
			this.STR_CD.Name = "STR_CD";
			this.STR_CD.ReadOnly = true;
			this.STR_CD.Width = 87;
			// 
			// 예정일자
			// 
			this.예정일자.DataPropertyName = "DUEDATE";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			this.예정일자.DefaultCellStyle = dataGridViewCellStyle2;
			this.예정일자.HeaderText = "예정일자";
			this.예정일자.Name = "예정일자";
			this.예정일자.ReadOnly = true;
			this.예정일자.Width = 76;
			// 
			// BCCRD
			// 
			this.BCCRD.DataPropertyName = "BCCRD";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle3.Format = "N0";
			this.BCCRD.DefaultCellStyle = dataGridViewCellStyle3;
			this.BCCRD.HeaderText = "BC";
			this.BCCRD.MinimumWidth = 100;
			this.BCCRD.Name = "BCCRD";
			this.BCCRD.ReadOnly = true;
			// 
			// KBCRD
			// 
			this.KBCRD.DataPropertyName = "KBCRD";
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle4.Format = "N0";
			dataGridViewCellStyle4.NullValue = "0";
			this.KBCRD.DefaultCellStyle = dataGridViewCellStyle4;
			this.KBCRD.HeaderText = "KB";
			this.KBCRD.MinimumWidth = 100;
			this.KBCRD.Name = "KBCRD";
			this.KBCRD.ReadOnly = true;
			// 
			// SAMSUNGCRD
			// 
			this.SAMSUNGCRD.DataPropertyName = "SAMSUNGCRD";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle5.Format = "N0";
			this.SAMSUNGCRD.DefaultCellStyle = dataGridViewCellStyle5;
			this.SAMSUNGCRD.HeaderText = "삼성";
			this.SAMSUNGCRD.MinimumWidth = 100;
			this.SAMSUNGCRD.Name = "SAMSUNGCRD";
			this.SAMSUNGCRD.ReadOnly = true;
			// 
			// SHINHANCRD
			// 
			this.SHINHANCRD.DataPropertyName = "SHINHANCRD";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle6.Format = "N0";
			this.SHINHANCRD.DefaultCellStyle = dataGridViewCellStyle6;
			this.SHINHANCRD.HeaderText = "신한";
			this.SHINHANCRD.MinimumWidth = 100;
			this.SHINHANCRD.Name = "SHINHANCRD";
			this.SHINHANCRD.ReadOnly = true;
			// 
			// HYUNDAICRD
			// 
			this.HYUNDAICRD.DataPropertyName = "HYUNDAICRD";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			this.HYUNDAICRD.DefaultCellStyle = dataGridViewCellStyle7;
			this.HYUNDAICRD.HeaderText = "현대";
			this.HYUNDAICRD.MinimumWidth = 100;
			this.HYUNDAICRD.Name = "HYUNDAICRD";
			this.HYUNDAICRD.ReadOnly = true;
			// 
			// LOTTECRD
			// 
			this.LOTTECRD.DataPropertyName = "LOTTECRD";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			this.LOTTECRD.DefaultCellStyle = dataGridViewCellStyle8;
			this.LOTTECRD.HeaderText = "롯데";
			this.LOTTECRD.MinimumWidth = 100;
			this.LOTTECRD.Name = "LOTTECRD";
			this.LOTTECRD.ReadOnly = true;
			// 
			// HANACRD
			// 
			this.HANACRD.DataPropertyName = "HANACRD";
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle9.Format = "N0";
			this.HANACRD.DefaultCellStyle = dataGridViewCellStyle9;
			this.HANACRD.HeaderText = "하나SK";
			this.HANACRD.MinimumWidth = 100;
			this.HANACRD.Name = "HANACRD";
			this.HANACRD.ReadOnly = true;
			// 
			// YEHWANCRD
			// 
			this.YEHWANCRD.DataPropertyName = "YEHWANCRD";
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle10.Format = "N0";
			this.YEHWANCRD.DefaultCellStyle = dataGridViewCellStyle10;
			this.YEHWANCRD.HeaderText = "외환";
			this.YEHWANCRD.MinimumWidth = 100;
			this.YEHWANCRD.Name = "YEHWANCRD";
			this.YEHWANCRD.ReadOnly = true;
			// 
			// NHCRD
			// 
			this.NHCRD.DataPropertyName = "NHCRD";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle11.Format = "N0";
			this.NHCRD.DefaultCellStyle = dataGridViewCellStyle11;
			this.NHCRD.HeaderText = "NH";
			this.NHCRD.MinimumWidth = 100;
			this.NHCRD.Name = "NHCRD";
			this.NHCRD.ReadOnly = true;
			// 
			// ETCCRDTOT
			// 
			this.ETCCRDTOT.DataPropertyName = "ETCCRDTOT";
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle12.Format = "N0";
			this.ETCCRDTOT.DefaultCellStyle = dataGridViewCellStyle12;
			this.ETCCRDTOT.HeaderText = "기타";
			this.ETCCRDTOT.MinimumWidth = 100;
			this.ETCCRDTOT.Name = "ETCCRDTOT";
			this.ETCCRDTOT.ReadOnly = true;
			// 
			// TOTAMT
			// 
			this.TOTAMT.DataPropertyName = "TOTAMT";
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle13.Format = "N0";
			this.TOTAMT.DefaultCellStyle = dataGridViewCellStyle13;
			this.TOTAMT.HeaderText = "합계";
			this.TOTAMT.MinimumWidth = 100;
			this.TOTAMT.Name = "TOTAMT";
			this.TOTAMT.ReadOnly = true;
			// 
			// RDM0310
			// 
			this.ClientSize = new System.Drawing.Size(1145, 670);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "RDM0310";
			this.Text = "상환예정조회:RDM0310";
			this.Load += new System.EventHandler(this.RDM0310_Load);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.flowLayoutPanel4.ResumeLayout(false);
			this.flowLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel1.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private BANANA.Windows.Controls.Label label35;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private DemoClient.Controls.BananaButton _btnSearch;
        private DemoClient.Controls.BananaButton _btnExcel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_S_S;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_E_S;
        private BANANA.Windows.Controls.Label label37;
        private BANANA.Windows.Controls.Label label2;
        private BANANA.Windows.Controls.ComboBox _cmbBUYING_CD_S;
        private BANANA.Windows.Controls.GroupBox groupBox3;
		private DemoClient.Controls.GridView gridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_CD;
		private System.Windows.Forms.DataGridViewTextBoxColumn 예정일자;
		private System.Windows.Forms.DataGridViewTextBoxColumn BCCRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn KBCRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn SAMSUNGCRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn SHINHANCRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn HYUNDAICRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn LOTTECRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn HANACRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn YEHWANCRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn NHCRD;
		private System.Windows.Forms.DataGridViewTextBoxColumn ETCCRDTOT;
		private System.Windows.Forms.DataGridViewTextBoxColumn TOTAMT;



    }
}
