﻿namespace DemoClient.View.RDM
{
    partial class RDM0410
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RDM0410));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
			this._dtpTRADEDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
			this._dtpTRADEDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
			this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
			this.label35 = new BANANA.Windows.Controls.Label();
			this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.label37 = new BANANA.Windows.Controls.Label();
			this.label1 = new BANANA.Windows.Controls.Label();
			this._btnSearch = new DemoClient.Controls.BananaButton();
			this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
			this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.gridView2 = new DemoClient.Controls.GridView();
			this.IDX1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRDT1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRAMT1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DEPTYPENM1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RMKS1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRTXT1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRTCD1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRANSFEE1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCTFLAG1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCT0100_IDX1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCTDT1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.gridView1 = new DemoClient.Controls.GridView();
			this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DEPTYPENM = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RMKS = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRTXT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRTCD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.TRANSFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCTFLAG = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCT0100_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ACCTDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1145, 57);
			this.groupBox1.TabIndex = 33;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "검색 조건";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.ColumnCount = 10;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 507F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel6.Controls.Add(this._dtpTRADEDATE_E_S, 5, 0);
			this.tableLayoutPanel6.Controls.Add(this._dtpTRADEDATE_S_S, 3, 0);
			this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 9, 0);
			this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 8, 0);
			this.tableLayoutPanel6.Controls.Add(this.label37, 2, 0);
			this.tableLayoutPanel6.Controls.Add(this.label1, 4, 0);
			this.tableLayoutPanel6.Controls.Add(this._btnSearch, 6, 0);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 21);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 2;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 33);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// _dtpTRADEDATE_E_S
			// 
			this._dtpTRADEDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_E_S.Checked = false;
			this._dtpTRADEDATE_E_S.CustomFormat = "yyyy-MM-dd";
			this._dtpTRADEDATE_E_S.DelegateProperty = true;
			this._dtpTRADEDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_E_S.Location = new System.Drawing.Point(460, 4);
			this._dtpTRADEDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_E_S.Name = "_dtpTRADEDATE_E_S";
			this._dtpTRADEDATE_E_S.Size = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_E_S.TabIndex = 35;
			this._dtpTRADEDATE_E_S.ValidationGroup = null;
			this._dtpTRADEDATE_E_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// _dtpTRADEDATE_S_S
			// 
			this._dtpTRADEDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._dtpTRADEDATE_S_S.Checked = false;
			this._dtpTRADEDATE_S_S.CustomFormat = "yyyy-MM-dd";
			this._dtpTRADEDATE_S_S.DelegateProperty = true;
			this._dtpTRADEDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this._dtpTRADEDATE_S_S.Location = new System.Drawing.Point(331, 4);
			this._dtpTRADEDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
			this._dtpTRADEDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
			this._dtpTRADEDATE_S_S.Name = "_dtpTRADEDATE_S_S";
			this._dtpTRADEDATE_S_S.Size = new System.Drawing.Size(103, 21);
			this._dtpTRADEDATE_S_S.TabIndex = 34;
			this._dtpTRADEDATE_S_S.ValidationGroup = null;
			this._dtpTRADEDATE_S_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
			// 
			// _txtSTR_NM_S
			// 
			this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._txtSTR_NM_S.AutoTab = false;
			this._txtSTR_NM_S.DelegateProperty = true;
			this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this._txtSTR_NM_S.Location = new System.Drawing.Point(93, 3);
			this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
			this._txtSTR_NM_S.Size = new System.Drawing.Size(120, 23);
			this._txtSTR_NM_S.TabIndex = 100;
			this._txtSTR_NM_S.ValidationGroup = null;
			this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
			this._txtSTR_NM_S.WaterMarkText = "";
			// 
			// label35
			// 
			this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(20, 7);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(67, 15);
			this.label35.TabIndex = 1114;
			this.label35.Text = "가맹점명";
			// 
			// flowLayoutPanel4
			// 
			this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel4.Location = new System.Drawing.Point(1228, 0);
			this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel4.Name = "flowLayoutPanel4";
			this.flowLayoutPanel4.Size = new System.Drawing.Size(55, 30);
			this.flowLayoutPanel4.TabIndex = 160;
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(721, 0);
			this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(507, 30);
			this.flowLayoutPanel1.TabIndex = 120;
			// 
			// label37
			// 
			this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(258, 7);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(67, 15);
			this.label37.TabIndex = 1116;
			this.label37.Text = "입금일자";
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(440, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(14, 15);
			this.label1.TabIndex = 1;
			this.label1.Text = "~";
			// 
			// _btnSearch
			// 
			this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this._btnSearch.DelegateProperty = true;
			this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
			this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.Location = new System.Drawing.Point(567, 1);
			this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
			this._btnSearch.Name = "_btnSearch";
			this._btnSearch.Reserved = "      검   색";
			this._btnSearch.Size = new System.Drawing.Size(75, 27);
			this._btnSearch.TabIndex = 1117;
			this._btnSearch.Text = "      검   색";
			this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this._btnSearch.UseVisualStyleBackColor = true;
			this._btnSearch.ValidationGroup = null;
			this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.collapsibleSplitter1);
			this.groupBox3.Controls.Add(this.gridView1);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(0, 57);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(1145, 329);
			this.groupBox3.TabIndex = 34;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "입금거래목록";
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.groupBox2;
			this.collapsibleSplitter1.Cursor = System.Windows.Forms.Cursors.HSplit;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(3, 318);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 4;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
			this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.gridView2);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox2.Location = new System.Drawing.Point(0, 386);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(1145, 284);
			this.groupBox2.TabIndex = 35;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "이력 정보";
			// 
			// gridView2
			// 
			this.gridView2.AutoSelectRowWithRightButton = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.gridView2.ColumnHeadersHeight = 50;
			this.gridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX1,
            this.STR_NM1,
            this.TRDT1,
            this.TRAMT1,
            this.DEPTYPENM1,
            this.RMKS1,
            this.TRTXT1,
            this.TRTCD1,
            this.TRANSFEE1,
            this.ACCTFLAG1,
            this.ACCT0100_IDX1,
            this.ACCTDT1,
            this.SYSREGDATE1});
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle9.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView2.DefaultCellStyle = dataGridViewCellStyle9;
			this.gridView2.DelegateProperty = true;
			this.gridView2.Location = new System.Drawing.Point(3, 21);
			this.gridView2.MultiSelect = false;
			this.gridView2.Name = "gridView2";
			this.gridView2.ReadOnly = true;
			this.gridView2.RowTemplate.Height = 23;
			this.gridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView2.Size = new System.Drawing.Size(1139, 260);
			this.gridView2.TabIndex = 1;
			// 
			// IDX1
			// 
			this.IDX1.DataPropertyName = "IDX1";
			this.IDX1.Frozen = true;
			this.IDX1.HeaderText = "이력번호";
			this.IDX1.Name = "IDX1";
			this.IDX1.ReadOnly = true;
			this.IDX1.Width = 94;
			// 
			// STR_NM1
			// 
			this.STR_NM1.DataPropertyName = "STR_NM1";
			this.STR_NM1.Frozen = true;
			this.STR_NM1.HeaderText = "가맹점명";
			this.STR_NM1.Name = "STR_NM1";
			this.STR_NM1.ReadOnly = true;
			this.STR_NM1.Width = 94;
			// 
			// TRDT1
			// 
			this.TRDT1.DataPropertyName = "TRDT1";
			this.TRDT1.Frozen = true;
			this.TRDT1.HeaderText = "입금일자";
			this.TRDT1.Name = "TRDT1";
			this.TRDT1.ReadOnly = true;
			this.TRDT1.Width = 94;
			// 
			// TRAMT1
			// 
			this.TRAMT1.DataPropertyName = "TRAMT1";
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle2.Format = "N0";
			this.TRAMT1.DefaultCellStyle = dataGridViewCellStyle2;
			this.TRAMT1.HeaderText = "입금금액";
			this.TRAMT1.MinimumWidth = 100;
			this.TRAMT1.Name = "TRAMT1";
			this.TRAMT1.ReadOnly = true;
			// 
			// DEPTYPENM1
			// 
			this.DEPTYPENM1.DataPropertyName = "DEPTYPENM1";
			dataGridViewCellStyle3.Format = "N0";
			dataGridViewCellStyle3.NullValue = "0";
			this.DEPTYPENM1.DefaultCellStyle = dataGridViewCellStyle3;
			this.DEPTYPENM1.HeaderText = "입금구분";
			this.DEPTYPENM1.MinimumWidth = 100;
			this.DEPTYPENM1.Name = "DEPTYPENM1";
			this.DEPTYPENM1.ReadOnly = true;
			// 
			// RMKS1
			// 
			this.RMKS1.DataPropertyName = "RMKS1";
			dataGridViewCellStyle4.Format = "N0";
			this.RMKS1.DefaultCellStyle = dataGridViewCellStyle4;
			this.RMKS1.HeaderText = "적요";
			this.RMKS1.MinimumWidth = 100;
			this.RMKS1.Name = "RMKS1";
			this.RMKS1.ReadOnly = true;
			// 
			// TRTXT1
			// 
			this.TRTXT1.DataPropertyName = "TRTXT1";
			dataGridViewCellStyle5.Format = "N0";
			this.TRTXT1.DefaultCellStyle = dataGridViewCellStyle5;
			this.TRTXT1.HeaderText = "기재내용";
			this.TRTXT1.MinimumWidth = 100;
			this.TRTXT1.Name = "TRTXT1";
			this.TRTXT1.ReadOnly = true;
			// 
			// TRTCD1
			// 
			this.TRTCD1.DataPropertyName = "TRTCD1";
			dataGridViewCellStyle6.Format = "N0";
			this.TRTCD1.DefaultCellStyle = dataGridViewCellStyle6;
			this.TRTCD1.HeaderText = "취급점";
			this.TRTCD1.MinimumWidth = 100;
			this.TRTCD1.Name = "TRTCD1";
			this.TRTCD1.ReadOnly = true;
			// 
			// TRANSFEE1
			// 
			this.TRANSFEE1.DataPropertyName = "TRANSFEE1";
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle7.Format = "N0";
			this.TRANSFEE1.DefaultCellStyle = dataGridViewCellStyle7;
			this.TRANSFEE1.HeaderText = "송금수수료";
			this.TRANSFEE1.MinimumWidth = 100;
			this.TRANSFEE1.Name = "TRANSFEE1";
			this.TRANSFEE1.ReadOnly = true;
			this.TRANSFEE1.Width = 108;
			// 
			// ACCTFLAG1
			// 
			this.ACCTFLAG1.DataPropertyName = "ACCTFLAG1";
			this.ACCTFLAG1.HeaderText = "정산처리";
			this.ACCTFLAG1.MinimumWidth = 100;
			this.ACCTFLAG1.Name = "ACCTFLAG1";
			this.ACCTFLAG1.ReadOnly = true;
			// 
			// ACCT0100_IDX1
			// 
			this.ACCT0100_IDX1.DataPropertyName = "ACCT0100_IDX1";
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle8.Format = "N0";
			this.ACCT0100_IDX1.DefaultCellStyle = dataGridViewCellStyle8;
			this.ACCT0100_IDX1.HeaderText = "정산번호";
			this.ACCT0100_IDX1.MinimumWidth = 100;
			this.ACCT0100_IDX1.Name = "ACCT0100_IDX1";
			this.ACCT0100_IDX1.ReadOnly = true;
			// 
			// ACCTDT1
			// 
			this.ACCTDT1.DataPropertyName = "ACCTDT1";
			this.ACCTDT1.HeaderText = "정산일자";
			this.ACCTDT1.MinimumWidth = 100;
			this.ACCTDT1.Name = "ACCTDT1";
			this.ACCTDT1.ReadOnly = true;
			// 
			// SYSREGDATE1
			// 
			this.SYSREGDATE1.DataPropertyName = "SYSREGDATE1";
			this.SYSREGDATE1.HeaderText = "등록일자";
			this.SYSREGDATE1.MinimumWidth = 100;
			this.SYSREGDATE1.Name = "SYSREGDATE1";
			this.SYSREGDATE1.ReadOnly = true;
			// 
			// gridView1
			// 
			this.gridView1.AutoSelectRowWithRightButton = false;
			dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle10.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
			this.gridView1.ColumnHeadersHeight = 50;
			this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX,
            this.STR_NM,
            this.TRDT,
            this.TRAMT,
            this.DEPTYPENM,
            this.RMKS,
            this.TRTXT,
            this.TRTCD,
            this.TRANSFEE,
            this.ACCTFLAG,
            this.ACCT0100_IDX,
            this.ACCTDT,
            this.SYSREGDATE});
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle18.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.gridView1.DefaultCellStyle = dataGridViewCellStyle18;
			this.gridView1.DelegateProperty = true;
			this.gridView1.Location = new System.Drawing.Point(3, 21);
			this.gridView1.MultiSelect = false;
			this.gridView1.Name = "gridView1";
			this.gridView1.ReadOnly = true;
			this.gridView1.RowTemplate.Height = 23;
			this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gridView1.Size = new System.Drawing.Size(1139, 305);
			this.gridView1.TabIndex = 0;
			this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
			// 
			// IDX
			// 
			this.IDX.DataPropertyName = "IDX";
			this.IDX.Frozen = true;
			this.IDX.HeaderText = "입금번호";
			this.IDX.Name = "IDX";
			this.IDX.ReadOnly = true;
			this.IDX.Width = 94;
			// 
			// STR_NM
			// 
			this.STR_NM.DataPropertyName = "STR_NM";
			this.STR_NM.Frozen = true;
			this.STR_NM.HeaderText = "가맹점명";
			this.STR_NM.Name = "STR_NM";
			this.STR_NM.ReadOnly = true;
			this.STR_NM.Width = 94;
			// 
			// TRDT
			// 
			this.TRDT.DataPropertyName = "TRDT";
			this.TRDT.Frozen = true;
			this.TRDT.HeaderText = "입금일자";
			this.TRDT.Name = "TRDT";
			this.TRDT.ReadOnly = true;
			this.TRDT.Width = 94;
			// 
			// TRAMT
			// 
			this.TRAMT.DataPropertyName = "TRAMT";
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle11.Format = "N0";
			this.TRAMT.DefaultCellStyle = dataGridViewCellStyle11;
			this.TRAMT.HeaderText = "입금금액";
			this.TRAMT.MinimumWidth = 100;
			this.TRAMT.Name = "TRAMT";
			this.TRAMT.ReadOnly = true;
			// 
			// DEPTYPENM
			// 
			this.DEPTYPENM.DataPropertyName = "DEPTYPENM";
			dataGridViewCellStyle12.Format = "N0";
			dataGridViewCellStyle12.NullValue = "0";
			this.DEPTYPENM.DefaultCellStyle = dataGridViewCellStyle12;
			this.DEPTYPENM.HeaderText = "입금구분";
			this.DEPTYPENM.MinimumWidth = 100;
			this.DEPTYPENM.Name = "DEPTYPENM";
			this.DEPTYPENM.ReadOnly = true;
			// 
			// RMKS
			// 
			this.RMKS.DataPropertyName = "RMKS";
			dataGridViewCellStyle13.Format = "N0";
			this.RMKS.DefaultCellStyle = dataGridViewCellStyle13;
			this.RMKS.HeaderText = "적요";
			this.RMKS.MinimumWidth = 100;
			this.RMKS.Name = "RMKS";
			this.RMKS.ReadOnly = true;
			// 
			// TRTXT
			// 
			this.TRTXT.DataPropertyName = "TRTXT";
			dataGridViewCellStyle14.Format = "N0";
			this.TRTXT.DefaultCellStyle = dataGridViewCellStyle14;
			this.TRTXT.HeaderText = "기재내용";
			this.TRTXT.MinimumWidth = 100;
			this.TRTXT.Name = "TRTXT";
			this.TRTXT.ReadOnly = true;
			// 
			// TRTCD
			// 
			this.TRTCD.DataPropertyName = "TRTCD";
			dataGridViewCellStyle15.Format = "N0";
			this.TRTCD.DefaultCellStyle = dataGridViewCellStyle15;
			this.TRTCD.HeaderText = "취급점";
			this.TRTCD.MinimumWidth = 100;
			this.TRTCD.Name = "TRTCD";
			this.TRTCD.ReadOnly = true;
			// 
			// TRANSFEE
			// 
			this.TRANSFEE.DataPropertyName = "TRANSFEE";
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle16.Format = "N0";
			this.TRANSFEE.DefaultCellStyle = dataGridViewCellStyle16;
			this.TRANSFEE.HeaderText = "송금수수료";
			this.TRANSFEE.MinimumWidth = 100;
			this.TRANSFEE.Name = "TRANSFEE";
			this.TRANSFEE.ReadOnly = true;
			this.TRANSFEE.Width = 108;
			// 
			// ACCTFLAG
			// 
			this.ACCTFLAG.DataPropertyName = "ACCTFLAG";
			this.ACCTFLAG.HeaderText = "정산처리";
			this.ACCTFLAG.MinimumWidth = 100;
			this.ACCTFLAG.Name = "ACCTFLAG";
			this.ACCTFLAG.ReadOnly = true;
			// 
			// ACCT0100_IDX
			// 
			this.ACCT0100_IDX.DataPropertyName = "ACCT0100_IDX";
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
			dataGridViewCellStyle17.Format = "N0";
			this.ACCT0100_IDX.DefaultCellStyle = dataGridViewCellStyle17;
			this.ACCT0100_IDX.HeaderText = "정산번호";
			this.ACCT0100_IDX.MinimumWidth = 100;
			this.ACCT0100_IDX.Name = "ACCT0100_IDX";
			this.ACCT0100_IDX.ReadOnly = true;
			// 
			// ACCTDT
			// 
			this.ACCTDT.DataPropertyName = "ACCTDT";
			this.ACCTDT.HeaderText = "정산일자";
			this.ACCTDT.MinimumWidth = 100;
			this.ACCTDT.Name = "ACCTDT";
			this.ACCTDT.ReadOnly = true;
			// 
			// SYSREGDATE
			// 
			this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
			this.SYSREGDATE.HeaderText = "등록일자";
			this.SYSREGDATE.MinimumWidth = 100;
			this.SYSREGDATE.Name = "SYSREGDATE";
			this.SYSREGDATE.ReadOnly = true;
			// 
			// RDM0410
			// 
			this.ClientSize = new System.Drawing.Size(1145, 670);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "RDM0410";
			this.Text = "상환마감이력내역조회:RDM0410";
			this.Load += new System.EventHandler(this.RDM0410_Load);
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_E_S;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_S_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private BANANA.Windows.Controls.Label label35;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.Label label37;
        private BANANA.Windows.Controls.Label label1;
        private DemoClient.Controls.BananaButton _btnSearch;
        private BANANA.Windows.Controls.GroupBox groupBox3;
        private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
        private DemoClient.Controls.GridView gridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRAMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DEPTYPENM;
        private System.Windows.Forms.DataGridViewTextBoxColumn RMKS;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRTXT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRTCD;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRANSFEE;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCTFLAG;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCT0100_IDX;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCTDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
        private System.Windows.Forms.GroupBox groupBox2;
        private DemoClient.Controls.GridView gridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDX1;
        private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRDT1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRAMT1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DEPTYPENM1;
        private System.Windows.Forms.DataGridViewTextBoxColumn RMKS1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRTXT1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRTCD1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRANSFEE1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCTFLAG1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCT0100_IDX1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCTDT1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE1;



    }
}
