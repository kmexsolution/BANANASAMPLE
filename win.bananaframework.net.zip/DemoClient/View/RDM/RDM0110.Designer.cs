﻿namespace DemoClient.View.RDM
{
    partial class RDM0110
	{
		/// <summary>
		/// 필수 디자이너 변수입니다.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 사용 중인 모든 리소스를 정리합니다.
		/// </summary>
		/// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 디자이너에서 생성한 코드

		/// <summary>
		/// 디자이너 지원에 필요한 메서드입니다.
		/// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RDM0110));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this._cmbACCTYN = new BANANA.Windows.Controls.ComboBox();
            this.label5 = new BANANA.Windows.Controls.Label();
            this._dtpTRADEDATE_S_S = new BANANA.Windows.Controls.DateTimePicker();
            this._txtSTR_NM_S = new BANANA.Windows.Controls.TextBox();
            this.label35 = new BANANA.Windows.Controls.Label();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this._btnSearch = new DemoClient.Controls.BananaButton();
            this._btnExcel = new DemoClient.Controls.BananaButton();
            this._btnAdd01 = new DemoClient.Controls.BananaButton();
            this.label37 = new BANANA.Windows.Controls.Label();
            this.label1 = new BANANA.Windows.Controls.Label();
            this._dtpTRADEDATE_E_S = new BANANA.Windows.Controls.DateTimePicker();
            this.groupBox3 = new BANANA.Windows.Controls.GroupBox();
            this.collapsibleSplitter1 = new DemoClient.Controls.CollapsibleSplitter();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this._btnSave = new DemoClient.Controls.BananaButton();
            this._btnDel = new DemoClient.Controls.BananaButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this._rbACCTY = new BANANA.Windows.Controls.RadioButton();
            this._rbACCTN = new BANANA.Windows.Controls.RadioButton();
            this._dtpACCTDT = new BANANA.Windows.Controls.DateTimePicker();
            this._dtpTRDT = new BANANA.Windows.Controls.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this._cmbDEPTYPE = new BANANA.Windows.Controls.ComboBox();
            this._txtTRANSFEE = new BANANA.Windows.Controls.TextBox();
            this._txtTRTCD = new BANANA.Windows.Controls.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this._txtTRAMT = new BANANA.Windows.Controls.TextBox();
            this._txtSTR_NM = new BANANA.Windows.Controls.TextBox();
            this.label101 = new BANANA.Windows.Controls.Label();
            this.lblUSR_ID = new BANANA.Windows.Controls.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this._txtIDX = new BANANA.Windows.Controls.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this._txtRMKS = new BANANA.Windows.Controls.TextBox();
            this._txtTRTXT = new BANANA.Windows.Controls.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.gridView1 = new DemoClient.Controls.GridView();
            this.IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STR_NM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRAMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DEPTYPENM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RMKS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRTXT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRTCD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRANSFEE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACCTYN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACCT0100_IDX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACCTDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SYSREGDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel6);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1145, 57);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "검색 조건";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 10;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 114F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel6.Controls.Add(this._cmbACCTYN, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label5, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this._dtpTRADEDATE_S_S, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this._txtSTR_NM_S, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel4, 9, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel1, 8, 0);
            this.tableLayoutPanel6.Controls.Add(this.label37, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.label1, 6, 0);
            this.tableLayoutPanel6.Controls.Add(this._dtpTRADEDATE_E_S, 7, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1139, 37);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // _cmbACCTYN
            // 
            this._cmbACCTYN.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._cmbACCTYN.DataSource = null;
            this._cmbACCTYN.DelegateProperty = true;
            this._cmbACCTYN.DroppedDown = false;
            this._cmbACCTYN.Location = new System.Drawing.Point(331, 4);
            this._cmbACCTYN.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbACCTYN.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbACCTYN.Name = "_cmbACCTYN";
            this._cmbACCTYN.SelectedIndex = -1;
            this._cmbACCTYN.SelectedItem = null;
            this._cmbACCTYN.SelectedValue = null;
            this._cmbACCTYN.Size = new System.Drawing.Size(103, 21);
            this._cmbACCTYN.TabIndex = 1118;
            this._cmbACCTYN.ValidationGroup = null;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(272, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 1117;
            this.label5.Text = "정산처리";
            // 
            // _dtpTRADEDATE_S_S
            // 
            this._dtpTRADEDATE_S_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpTRADEDATE_S_S.Checked = false;
            this._dtpTRADEDATE_S_S.CustomFormat = "yyyy-MM-dd";
            this._dtpTRADEDATE_S_S.DelegateProperty = true;
            this._dtpTRADEDATE_S_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpTRADEDATE_S_S.Location = new System.Drawing.Point(523, 4);
            this._dtpTRADEDATE_S_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpTRADEDATE_S_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpTRADEDATE_S_S.Name = "_dtpTRADEDATE_S_S";
            this._dtpTRADEDATE_S_S.Size = new System.Drawing.Size(103, 21);
            this._dtpTRADEDATE_S_S.TabIndex = 31;
            this._dtpTRADEDATE_S_S.ValidationGroup = null;
            this._dtpTRADEDATE_S_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
            // 
            // _txtSTR_NM_S
            // 
            this._txtSTR_NM_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_NM_S.AutoTab = false;
            this._txtSTR_NM_S.DelegateProperty = true;
            this._txtSTR_NM_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_NM_S.Location = new System.Drawing.Point(93, 5);
            this._txtSTR_NM_S.Name = "_txtSTR_NM_S";
            this._txtSTR_NM_S.Size = new System.Drawing.Size(120, 20);
            this._txtSTR_NM_S.TabIndex = 100;
            this._txtSTR_NM_S.ValidationGroup = null;
            this._txtSTR_NM_S.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSTR_NM_S.WaterMarkText = "";
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(34, 9);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 1114;
            this.label35.Text = "가맹점명";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(1064, 0);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(75, 30);
            this.flowLayoutPanel4.TabIndex = 160;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this._btnSearch);
            this.flowLayoutPanel1.Controls.Add(this._btnExcel);
            this.flowLayoutPanel1.Controls.Add(this._btnAdd01);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(787, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(277, 30);
            this.flowLayoutPanel1.TabIndex = 120;
            // 
            // _btnSearch
            // 
            this._btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnSearch.DelegateProperty = true;
            this._btnSearch.Image = global::DemoClient.Properties.Resources._1377801181_62668;
            this._btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.Location = new System.Drawing.Point(0, 0);
            this._btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this._btnSearch.Name = "_btnSearch";
            this._btnSearch.Reserved = "      검   색";
            this._btnSearch.Size = new System.Drawing.Size(75, 27);
            this._btnSearch.TabIndex = 1117;
            this._btnSearch.Text = "      검   색";
            this._btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSearch.UseVisualStyleBackColor = true;
            this._btnSearch.ValidationGroup = null;
            this._btnSearch.Click += new System.EventHandler(this._btnSearch_Click);
            // 
            // _btnExcel
            // 
            this._btnExcel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._btnExcel.DelegateProperty = true;
            this._btnExcel.Image = global::DemoClient.Properties.Resources.EXCEL_0002;
            this._btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.Location = new System.Drawing.Point(75, 0);
            this._btnExcel.Margin = new System.Windows.Forms.Padding(0);
            this._btnExcel.Name = "_btnExcel";
            this._btnExcel.Reserved = "      엑   셀";
            this._btnExcel.Size = new System.Drawing.Size(75, 27);
            this._btnExcel.TabIndex = 1118;
            this._btnExcel.Text = "      엑   셀";
            this._btnExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnExcel.UseVisualStyleBackColor = true;
            this._btnExcel.ValidationGroup = null;
            this._btnExcel.Click += new System.EventHandler(this._btnExcel_Click);
            // 
            // _btnAdd01
            // 
            this._btnAdd01.DelegateProperty = true;
            this._btnAdd01.Image = global::DemoClient.Properties.Resources._1377801089_62655;
            this._btnAdd01.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.Location = new System.Drawing.Point(150, 0);
            this._btnAdd01.Margin = new System.Windows.Forms.Padding(0);
            this._btnAdd01.Name = "_btnAdd01";
            this._btnAdd01.Reserved = "      추   가";
            this._btnAdd01.Size = new System.Drawing.Size(75, 27);
            this._btnAdd01.TabIndex = 1121;
            this._btnAdd01.Text = "      추   가";
            this._btnAdd01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnAdd01.UseVisualStyleBackColor = true;
            this._btnAdd01.ValidationGroup = null;
            this._btnAdd01.Click += new System.EventHandler(this._btnAdd_Click);
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(464, 9);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 12);
            this.label37.TabIndex = 1116;
            this.label37.Text = "입금일자";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(637, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "~";
            // 
            // _dtpTRADEDATE_E_S
            // 
            this._dtpTRADEDATE_E_S.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpTRADEDATE_E_S.Checked = false;
            this._dtpTRADEDATE_E_S.CustomFormat = "yyyy-MM-dd";
            this._dtpTRADEDATE_E_S.DelegateProperty = true;
            this._dtpTRADEDATE_E_S.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpTRADEDATE_E_S.Location = new System.Drawing.Point(660, 4);
            this._dtpTRADEDATE_E_S.MaximumSize = new System.Drawing.Size(250, 21);
            this._dtpTRADEDATE_E_S.MinimumSize = new System.Drawing.Size(100, 21);
            this._dtpTRADEDATE_E_S.Name = "_dtpTRADEDATE_E_S";
            this._dtpTRADEDATE_E_S.Size = new System.Drawing.Size(100, 21);
            this._dtpTRADEDATE_E_S.TabIndex = 32;
            this._dtpTRADEDATE_E_S.ValidationGroup = null;
            this._dtpTRADEDATE_E_S.Value = new System.DateTime(2014, 7, 26, 13, 51, 32, 431);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.collapsibleSplitter1);
            this.groupBox3.Controls.Add(this.gridView1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 57);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(447, 613);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "입금거래목록";
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.AnimationDelay = 20;
            this.collapsibleSplitter1.AnimationStep = 20;
            this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter1.ControlToHide = this.groupBox2;
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.collapsibleSplitter1.ExpandParentForm = false;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(436, 17);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.TabIndex = 4;
            this.collapsibleSplitter1.TabStop = false;
            this.collapsibleSplitter1.UseAnimations = false;
            this.collapsibleSplitter1.VisualStyle = DemoClient.Controls.VisualStyles.Mozilla;
            this.collapsibleSplitter1.DoubleClick += new System.EventHandler(this.collapsibleSplitter1_DoubleClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this._btnSave);
            this.groupBox2.Controls.Add(this._btnDel);
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.Location = new System.Drawing.Point(447, 57);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(698, 613);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "상세 정보";
            // 
            // _btnSave
            // 
            this._btnSave.ButtonConfirm = true;
            this._btnSave.DelegateProperty = true;
            this._btnSave.Enabled = false;
            this._btnSave.Image = global::DemoClient.Properties.Resources._1377801124_62679;
            this._btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave.Location = new System.Drawing.Point(530, 205);
            this._btnSave.Name = "_btnSave";
            this._btnSave.Reserved = "      저   장";
            this._btnSave.Size = new System.Drawing.Size(75, 27);
            this._btnSave.TabIndex = 1112;
            this._btnSave.Text = "      저   장";
            this._btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnSave.UseVisualStyleBackColor = true;
            this._btnSave.ValidationGroup = "a";
            this._btnSave.Click += new System.EventHandler(this._btnSave_Click);
            // 
            // _btnDel
            // 
            this._btnDel.ButtonConfirm = true;
            this._btnDel.DelegateProperty = true;
            this._btnDel.Enabled = false;
            this._btnDel.Image = global::DemoClient.Properties.Resources.red_62690;
            this._btnDel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel.Location = new System.Drawing.Point(611, 205);
            this._btnDel.Name = "_btnDel";
            this._btnDel.Reserved = "      삭   제";
            this._btnDel.Size = new System.Drawing.Size(75, 27);
            this._btnDel.TabIndex = 1113;
            this._btnDel.Text = "      삭   제";
            this._btnDel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this._btnDel.UseVisualStyleBackColor = true;
            this._btnDel.ValidationGroup = null;
            this._btnDel.Click += new System.EventHandler(this._btnDel_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel6, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this._dtpACCTDT, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this._dtpTRDT, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this._cmbDEPTYPE, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtTRANSFEE, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this._txtTRTCD, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this._txtTRAMT, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtSTR_NM, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label101, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblUSR_ID, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this._txtIDX, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtRMKS, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this._txtTRTXT, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label14, 4, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(692, 175);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this._rbACCTY);
            this.flowLayoutPanel6.Controls.Add(this._rbACCTN);
            this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(320, 135);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.flowLayoutPanel6.Size = new System.Drawing.Size(140, 27);
            this.flowLayoutPanel6.TabIndex = 1118;
            // 
            // _rbACCTY
            // 
            this._rbACCTY.AutoSize = true;
            this._rbACCTY.Checked = true;
            this._rbACCTY.DelegateProperty = true;
            this._rbACCTY.Enabled = false;
            this._rbACCTY.Location = new System.Drawing.Point(3, 6);
            this._rbACCTY.Name = "_rbACCTY";
            this._rbACCTY.Size = new System.Drawing.Size(31, 16);
            this._rbACCTY.TabIndex = 10;
            this._rbACCTY.TabStop = true;
            this._rbACCTY.Text = "Y";
            this._rbACCTY.UseVisualStyleBackColor = true;
            // 
            // _rbACCTN
            // 
            this._rbACCTN.AutoSize = true;
            this._rbACCTN.DelegateProperty = true;
            this._rbACCTN.Enabled = false;
            this._rbACCTN.Location = new System.Drawing.Point(40, 6);
            this._rbACCTN.Name = "_rbACCTN";
            this._rbACCTN.Size = new System.Drawing.Size(32, 16);
            this._rbACCTN.TabIndex = 20;
            this._rbACCTN.Text = "N";
            this._rbACCTN.UseVisualStyleBackColor = true;
            // 
            // _dtpACCTDT
            // 
            this._dtpACCTDT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpACCTDT.Checked = false;
            this._dtpACCTDT.CustomFormat = "yyyy-MM-dd";
            this._dtpACCTDT.DelegateProperty = true;
            this._dtpACCTDT.Enabled = false;
            this._dtpACCTDT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpACCTDT.Location = new System.Drawing.Point(93, 138);
            this._dtpACCTDT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpACCTDT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpACCTDT.Name = "_dtpACCTDT";
            this._dtpACCTDT.Size = new System.Drawing.Size(130, 20);
            this._dtpACCTDT.TabIndex = 1116;
            this._dtpACCTDT.ValidationGroup = "a";
            this._dtpACCTDT.Value = new System.DateTime(2014, 7, 25, 10, 20, 16, 341);
            // 
            // _dtpTRDT
            // 
            this._dtpTRDT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._dtpTRDT.Checked = false;
            this._dtpTRDT.CustomFormat = "yyyy-MM-dd";
            this._dtpTRDT.DelegateProperty = true;
            this._dtpTRDT.Enabled = false;
            this._dtpTRDT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtpTRDT.Location = new System.Drawing.Point(93, 30);
            this._dtpTRDT.MaximumSize = new System.Drawing.Size(250, 20);
            this._dtpTRDT.MinimumSize = new System.Drawing.Size(100, 20);
            this._dtpTRDT.Name = "_dtpTRDT";
            this._dtpTRDT.Size = new System.Drawing.Size(130, 20);
            this._dtpTRDT.TabIndex = 1115;
            this._dtpTRDT.ValidationGroup = "a";
            this._dtpTRDT.Value = new System.DateTime(2014, 7, 25, 10, 20, 16, 341);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(494, 34);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 1114;
            this.label13.Text = "입금금액";
            // 
            // _cmbDEPTYPE
            // 
            this._cmbDEPTYPE.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._cmbDEPTYPE.DataSource = null;
            this._cmbDEPTYPE.DelegateProperty = true;
            this._cmbDEPTYPE.DroppedDown = false;
            this._cmbDEPTYPE.Location = new System.Drawing.Point(323, 30);
            this._cmbDEPTYPE.MaximumSize = new System.Drawing.Size(500, 60);
            this._cmbDEPTYPE.MinimumSize = new System.Drawing.Size(100, 21);
            this._cmbDEPTYPE.Name = "_cmbDEPTYPE";
            this._cmbDEPTYPE.SelectedIndex = -1;
            this._cmbDEPTYPE.SelectedItem = null;
            this._cmbDEPTYPE.SelectedValue = null;
            this._cmbDEPTYPE.Size = new System.Drawing.Size(130, 21);
            this._cmbDEPTYPE.TabIndex = 1114;
            this._cmbDEPTYPE.ValidationGroup = null;
            // 
            // _txtTRANSFEE
            // 
            this._txtTRANSFEE.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTRANSFEE.DelegateProperty = true;
            this._txtTRANSFEE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTRANSFEE.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtTRANSFEE.Location = new System.Drawing.Point(553, 138);
            this._txtTRANSFEE.Name = "_txtTRANSFEE";
            this._txtTRANSFEE.Size = new System.Drawing.Size(130, 20);
            this._txtTRANSFEE.TabIndex = 1051;
            this._txtTRANSFEE.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtTRANSFEE.ValidationGroup = null;
            this._txtTRANSFEE.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTRANSFEE.WaterMarkText = "";
            // 
            // _txtTRTCD
            // 
            this._txtTRTCD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tableLayoutPanel1.SetColumnSpan(this._txtTRTCD, 5);
            this._txtTRTCD.DelegateProperty = true;
            this._txtTRTCD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTRTCD.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtTRTCD.Location = new System.Drawing.Point(93, 111);
            this._txtTRTCD.Name = "_txtTRTCD";
            this._txtTRTCD.Size = new System.Drawing.Size(590, 20);
            this._txtTRTCD.TabIndex = 1061;
            this._txtTRTCD.ValidationGroup = null;
            this._txtTRTCD.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTRTCD.WaterMarkText = "";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(46, 115);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 39;
            this.label12.Text = "취급점";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 34;
            this.label8.Text = "기재내용";
            // 
            // _txtTRAMT
            // 
            this._txtTRAMT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtTRAMT.DelegateProperty = true;
            this._txtTRAMT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTRAMT.ImeMode = BANANA.Windows.Controls.ImeMode.Integer;
            this._txtTRAMT.Location = new System.Drawing.Point(553, 30);
            this._txtTRAMT.Name = "_txtTRAMT";
            this._txtTRAMT.Size = new System.Drawing.Size(130, 20);
            this._txtTRAMT.TabIndex = 1071;
            this._txtTRAMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this._txtTRAMT.ValidationGroup = null;
            this._txtTRAMT.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTRAMT.WaterMarkText = "";
            // 
            // _txtSTR_NM
            // 
            this._txtSTR_NM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtSTR_NM.DelegateProperty = true;
            this._txtSTR_NM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtSTR_NM.Location = new System.Drawing.Point(323, 3);
            this._txtSTR_NM.Name = "_txtSTR_NM";
            this._txtSTR_NM.ReadOnly = true;
            this._txtSTR_NM.Size = new System.Drawing.Size(130, 20);
            this._txtSTR_NM.TabIndex = 1010;
            this._txtSTR_NM.ValidationGroup = "a";
            this._txtSTR_NM.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtSTR_NM.WaterMarkText = "";
            // 
            // label101
            // 
            this.label101.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(34, 7);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(53, 12);
            this.label101.TabIndex = 0;
            this.label101.Text = "입금번호";
            // 
            // lblUSR_ID
            // 
            this.lblUSR_ID.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblUSR_ID.AutoSize = true;
            this.lblUSR_ID.Location = new System.Drawing.Point(34, 34);
            this.lblUSR_ID.Name = "lblUSR_ID";
            this.lblUSR_ID.Size = new System.Drawing.Size(53, 12);
            this.lblUSR_ID.TabIndex = 2;
            this.lblUSR_ID.Text = "입금일자";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "가맹점명";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(264, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "입금구분";
            // 
            // _txtIDX
            // 
            this._txtIDX.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this._txtIDX.DelegateProperty = true;
            this._txtIDX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtIDX.Location = new System.Drawing.Point(93, 3);
            this._txtIDX.Name = "_txtIDX";
            this._txtIDX.ReadOnly = true;
            this._txtIDX.Size = new System.Drawing.Size(130, 20);
            this._txtIDX.TabIndex = 1000;
            this._txtIDX.ValidationGroup = "a";
            this._txtIDX.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtIDX.WaterMarkText = "";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 31;
            this.label4.Text = "적요";
            // 
            // _txtRMKS
            // 
            this._txtRMKS.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tableLayoutPanel1.SetColumnSpan(this._txtRMKS, 5);
            this._txtRMKS.DelegateProperty = true;
            this._txtRMKS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtRMKS.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtRMKS.Location = new System.Drawing.Point(93, 57);
            this._txtRMKS.Name = "_txtRMKS";
            this._txtRMKS.Size = new System.Drawing.Size(590, 20);
            this._txtRMKS.TabIndex = 1060;
            this._txtRMKS.ValidationGroup = null;
            this._txtRMKS.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtRMKS.WaterMarkText = "";
            // 
            // _txtTRTXT
            // 
            this._txtTRTXT.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tableLayoutPanel1.SetColumnSpan(this._txtTRTXT, 5);
            this._txtTRTXT.DelegateProperty = true;
            this._txtTRTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this._txtTRTXT.ImeMode = BANANA.Windows.Controls.ImeMode.DashNumeric;
            this._txtTRTXT.Location = new System.Drawing.Point(93, 84);
            this._txtTRTXT.Name = "_txtTRTXT";
            this._txtTRTXT.Size = new System.Drawing.Size(590, 20);
            this._txtTRTXT.TabIndex = 1070;
            this._txtTRTXT.ValidationGroup = null;
            this._txtTRTXT.WaterMarkColor = System.Drawing.Color.Silver;
            this._txtTRTXT.WaterMarkText = "";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 142);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 34;
            this.label11.Text = "정산일자";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(264, 142);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 33;
            this.label10.Text = "정산처리";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(482, 142);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 32;
            this.label14.Text = "송금수수료";
            // 
            // gridView1
            // 
            this.gridView1.AutoSelectRowWithRightButton = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gridView1.ColumnHeadersHeight = 50;
            this.gridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDX,
            this.STR_NM,
            this.TRDT,
            this.TRAMT,
            this.DEPTYPENM,
            this.RMKS,
            this.TRTXT,
            this.TRTCD,
            this.TRANSFEE,
            this.ACCTYN,
            this.ACCT0100_IDX,
            this.ACCTDT,
            this.SYSREGDATE});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("맑은 고딕", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gridView1.DefaultCellStyle = dataGridViewCellStyle10;
            this.gridView1.DelegateProperty = true;
            this.gridView1.Location = new System.Drawing.Point(3, 17);
            this.gridView1.MultiSelect = false;
            this.gridView1.Name = "gridView1";
            this.gridView1.ReadOnly = true;
            this.gridView1.RowTemplate.Height = 23;
            this.gridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridView1.Size = new System.Drawing.Size(441, 593);
            this.gridView1.TabIndex = 0;
            this.gridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridView1_CellClick);
            this.gridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gridView1_DataBindingComplete);
            // 
            // IDX
            // 
            this.IDX.DataPropertyName = "IDX";
            this.IDX.Frozen = true;
            this.IDX.HeaderText = "입금번호";
            this.IDX.Name = "IDX";
            this.IDX.ReadOnly = true;
            this.IDX.Width = 76;
            // 
            // STR_NM
            // 
            this.STR_NM.DataPropertyName = "STR_NM";
            this.STR_NM.Frozen = true;
            this.STR_NM.HeaderText = "가맹점명";
            this.STR_NM.Name = "STR_NM";
            this.STR_NM.ReadOnly = true;
            this.STR_NM.Width = 76;
            // 
            // TRDT
            // 
            this.TRDT.DataPropertyName = "TRDT";
            this.TRDT.Frozen = true;
            this.TRDT.HeaderText = "입금일자";
            this.TRDT.Name = "TRDT";
            this.TRDT.ReadOnly = true;
            this.TRDT.Width = 76;
            // 
            // TRAMT
            // 
            this.TRAMT.DataPropertyName = "TRAMT";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N0";
            this.TRAMT.DefaultCellStyle = dataGridViewCellStyle2;
            this.TRAMT.HeaderText = "입금금액";
            this.TRAMT.MinimumWidth = 100;
            this.TRAMT.Name = "TRAMT";
            this.TRAMT.ReadOnly = true;
            // 
            // DEPTYPENM
            // 
            this.DEPTYPENM.DataPropertyName = "DEPTYPENM";
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = "0";
            this.DEPTYPENM.DefaultCellStyle = dataGridViewCellStyle3;
            this.DEPTYPENM.HeaderText = "입금구분";
            this.DEPTYPENM.MinimumWidth = 100;
            this.DEPTYPENM.Name = "DEPTYPENM";
            this.DEPTYPENM.ReadOnly = true;
            // 
            // RMKS
            // 
            this.RMKS.DataPropertyName = "RMKS";
            dataGridViewCellStyle4.Format = "N0";
            this.RMKS.DefaultCellStyle = dataGridViewCellStyle4;
            this.RMKS.HeaderText = "적요";
            this.RMKS.MinimumWidth = 100;
            this.RMKS.Name = "RMKS";
            this.RMKS.ReadOnly = true;
            // 
            // TRTXT
            // 
            this.TRTXT.DataPropertyName = "TRTXT";
            dataGridViewCellStyle5.Format = "N0";
            this.TRTXT.DefaultCellStyle = dataGridViewCellStyle5;
            this.TRTXT.HeaderText = "기재내용";
            this.TRTXT.MinimumWidth = 100;
            this.TRTXT.Name = "TRTXT";
            this.TRTXT.ReadOnly = true;
            // 
            // TRTCD
            // 
            this.TRTCD.DataPropertyName = "TRTCD";
            dataGridViewCellStyle6.Format = "N0";
            this.TRTCD.DefaultCellStyle = dataGridViewCellStyle6;
            this.TRTCD.HeaderText = "취급점";
            this.TRTCD.MinimumWidth = 100;
            this.TRTCD.Name = "TRTCD";
            this.TRTCD.ReadOnly = true;
            // 
            // TRANSFEE
            // 
            this.TRANSFEE.DataPropertyName = "TRANSFEE";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N0";
            this.TRANSFEE.DefaultCellStyle = dataGridViewCellStyle7;
            this.TRANSFEE.HeaderText = "송금수수료";
            this.TRANSFEE.MinimumWidth = 100;
            this.TRANSFEE.Name = "TRANSFEE";
            this.TRANSFEE.ReadOnly = true;
            // 
            // ACCTYN
            // 
            this.ACCTYN.DataPropertyName = "ACCTYN";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ACCTYN.DefaultCellStyle = dataGridViewCellStyle8;
            this.ACCTYN.HeaderText = "정산처리";
            this.ACCTYN.MinimumWidth = 100;
            this.ACCTYN.Name = "ACCTYN";
            this.ACCTYN.ReadOnly = true;
            // 
            // ACCT0100_IDX
            // 
            this.ACCT0100_IDX.DataPropertyName = "ACCT0100_IDX";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N0";
            this.ACCT0100_IDX.DefaultCellStyle = dataGridViewCellStyle9;
            this.ACCT0100_IDX.HeaderText = "정산번호";
            this.ACCT0100_IDX.MinimumWidth = 100;
            this.ACCT0100_IDX.Name = "ACCT0100_IDX";
            this.ACCT0100_IDX.ReadOnly = true;
            // 
            // ACCTDT
            // 
            this.ACCTDT.DataPropertyName = "ACCTDT";
            this.ACCTDT.HeaderText = "정산일자";
            this.ACCTDT.MinimumWidth = 100;
            this.ACCTDT.Name = "ACCTDT";
            this.ACCTDT.ReadOnly = true;
            // 
            // SYSREGDATE
            // 
            this.SYSREGDATE.DataPropertyName = "SYSREGDATE";
            this.SYSREGDATE.HeaderText = "등록일자";
            this.SYSREGDATE.MinimumWidth = 100;
            this.SYSREGDATE.Name = "SYSREGDATE";
            this.SYSREGDATE.ReadOnly = true;
            // 
            // RDM0110
            // 
            this.ClientSize = new System.Drawing.Size(1145, 670);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RDM0110";
            this.Text = "상환마감처리:RDM0110";
            this.Load += new System.EventHandler(this.RDM0110_Load);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_E_S;
        private BANANA.Windows.Controls.Label label1;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRADEDATE_S_S;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM_S;
        private BANANA.Windows.Controls.Label label35;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BANANA.Windows.Controls.Label label37;
        private BANANA.Windows.Controls.GroupBox groupBox3;
        private DemoClient.Controls.GridView gridView1;
        private DemoClient.Controls.BananaButton _btnSearch;
        private DemoClient.Controls.BananaButton _btnExcel;
        private DemoClient.Controls.BananaButton _btnAdd01;
        private DemoClient.Controls.CollapsibleSplitter collapsibleSplitter1;
        private System.Windows.Forms.GroupBox groupBox2;
        private DemoClient.Controls.BananaButton _btnSave;
        private DemoClient.Controls.BananaButton _btnDel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label13;
        private BANANA.Windows.Controls.ComboBox _cmbDEPTYPE;
        private BANANA.Windows.Controls.TextBox _txtTRANSFEE;
        private BANANA.Windows.Controls.TextBox _txtTRTCD;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private BANANA.Windows.Controls.TextBox _txtTRAMT;
        private BANANA.Windows.Controls.TextBox _txtSTR_NM;
        private BANANA.Windows.Controls.Label label101;
        private BANANA.Windows.Controls.Label lblUSR_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private BANANA.Windows.Controls.TextBox _txtIDX;
        private System.Windows.Forms.Label label4;
        private BANANA.Windows.Controls.TextBox _txtRMKS;
        private BANANA.Windows.Controls.TextBox _txtTRTXT;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private BANANA.Windows.Controls.DateTimePicker _dtpTRDT;
		private BANANA.Windows.Controls.DateTimePicker _dtpACCTDT;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private BANANA.Windows.Controls.RadioButton _rbACCTY;
		private BANANA.Windows.Controls.RadioButton _rbACCTN;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn STR_NM;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRDT;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRAMT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DEPTYPENM;
		private System.Windows.Forms.DataGridViewTextBoxColumn RMKS;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRTXT;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRTCD;
		private System.Windows.Forms.DataGridViewTextBoxColumn TRANSFEE;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACCTYN;
		private System.Windows.Forms.DataGridViewTextBoxColumn ACCT0100_IDX;
		private System.Windows.Forms.DataGridViewTextBoxColumn ACCTDT;
		private System.Windows.Forms.DataGridViewTextBoxColumn SYSREGDATE;
        private BANANA.Windows.Controls.ComboBox _cmbACCTYN;
        private BANANA.Windows.Controls.Label label5;
    }
}
