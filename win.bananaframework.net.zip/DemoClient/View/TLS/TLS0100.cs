﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoClient.View.TLS
{
	public partial class TLS0100 : DemoClient.Controllers.BasePopupForm
	{
		public TLS0100()
		{
			InitializeComponent();
		}
	}
}
