﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoClient.Controls
{
    public partial class Kmex_GroupBox : UserControl
    {
        public Kmex_GroupBox()
        {
            InitializeComponent();
        }
    }
}
