﻿using System.Reflection;

#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyConfiguration("Release")]
#endif
[assembly: AssemblyCompany("바나나프레임워크")]
[assembly: AssemblyCopyright("Copyright © 바나나프레임워크 2019")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyTrademark("")]
