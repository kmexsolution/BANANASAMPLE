﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoClient.Controls
{
	public enum ButtonImage { Search, List, Save, Delete, Print, Excel, New, Modify, Add, Apply, Send, Next, Previous, OK, Cancel, Top, Bottom, Left, Right, Etc }
	public enum FooterMath { Sum, Avg }
}
